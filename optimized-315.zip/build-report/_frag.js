        // ===================================================================
        // 無限ボスラッシュ＆世界レベル
        // ===================================================================
        function getWorldLevel() {
            const lv = parseInt(state.worldLevel, 10);
            return (!isNaN(lv) && lv >= 1 && lv <= 10) ? lv : 1;
        }

        // 世界レベルの敵ステータス倍率（HP/ATK）と同時に獲得金額に適用
        function getWorldLevelMult(levelOverride) {
            const lv = levelOverride !== undefined ? (parseInt(levelOverride, 10) || 1) : getWorldLevel();
            if (lv <= 5) return lv;
            if (lv === 6) return 10;
            if (lv === 7) return 20;
            if (lv === 8) return 30;
            if (lv === 9) return 50;
            if (lv === 10) return 100;
            return 1;
        }

        function setWorldLevel(lv) {
            const v = parseInt(lv, 10);
            if (isNaN(v) || v < 1 || v > 10) return;
            if (bossRushState && bossRushState.active) return;
            state.worldLevel = v;
            saveState();
            renderBossRushView();
        }

        function getBossRushRoundMult(round) {
            const r = Math.max(1, Math.min(3, round || 1));
            return [0, 1, 5, 10][r];
        }

        function ensureBossRush() {
            if (!bossRushState) {
                bossRushState = state.bossRushProgress && typeof state.bossRushProgress === 'object'
                    ? state.bossRushProgress
                    : { active: false, round: 1, stage: 1, scoreKills: 0, worldLevel: getWorldLevel(), playerHp: null };
            }
            if (!bossRushState.worldLevel) bossRushState.worldLevel = getWorldLevel();
            return bossRushState;
        }

        function startBossRush() {
            if (state.deck.length === 0) {
                showCustomAlert("部隊未編成", "出撃するキャラクターが編成されていません。「編成」画面からキャラを選択してください。");
                return;
            }
            normalizeBossRushSelection();
            const selectedLevel = getWorldLevel();
            ensureBossRush();
            bossRushState.active = true;
            bossRushState.round = 1;
            bossRushState.stage = 1;
            bossRushState.scoreKills = 0;
            bossRushState.playerHp = null;
            bossRushState.worldLevel = selectedLevel;
            saveState();
            enterBossRushBattle();
        }

        function continueBossRush() {
            if (!bossRushState || !bossRushState.active) {
                startBossRush();
                return;
            }
            saveState();
            enterBossRushBattle();
        }

        function abandonBossRush() {
            if (!bossRushState) return;
            const defeated = bossRushState.scoreKills || 0;
            const wm = getWorldLevelMult(getBossRushRunWorldLevel());
            const reward = defeated * 600 * wm;
            bossRushState.active = false;
            state.coins += reward;
            saveState();
            showCustomAlert(
                "ボスラッシュ中断",
                `今回の撃破数: ${defeated}\n報酬: +${reward.toLocaleString()}文（世界レベル×${wm}）`,
                () => {
                    bossRushState = null;
                    saveState();
                    exitBattleView();
                    renderBossRushView();
                }
            );
        }

        function enterBossRushBattle() {
            if (!bossRushState) return;
            const stageInRound = bossRushState.stage;
            const bossRushStageIds = getBossRushStageIds();
            const mappedStageId = bossRushStageIds[Math.max(0, Math.min(bossRushStageIds.length - 1, stageInRound - 1))] || 'd01_s01';
            // 実在する200ステージを順番にボスラッシュへ割り当てる。
            startBattle(mappedStageId, false, { bossRush: true });
            // ⑥ ボスラッシュ用に敵ステータスを周回倍率でオーバーライド
            // startBattle内でworldMultが既にかかっているため、除算してから再適用することで二重を防ぐ
            const roundMult = getBossRushRoundMult(bossRushState.round);
            const worldMult = getWorldLevelMult(getBossRushRunWorldLevel());
            // 世界レベル倍率を一旦除去（startBattle時に適用済み）してroundMultのみ追加
            const baseEnemyHp = Math.max(1, Math.round(battleState.enemyHp / worldMult));
            const baseEnemyAtk = Math.max(1, Math.round(battleState.enemyAtk / worldMult));
            battleState.bossRush = true;
            if (typeof bossRushState.playerHp === "number") {
                battleState.playerHp = Math.min(battleState.maxPlayerHp, Math.max(1, bossRushState.playerHp));
            }
            // 正しい倍率: worldMult × roundMult（重複なし）
            battleState.enemyHp = Math.max(1, Math.floor(baseEnemyHp * worldMult * roundMult));
            battleState.maxEnemyHp = Math.max(1, Math.floor(baseEnemyHp * worldMult * roundMult));
            battleState.enemyAtk = Math.max(1, Math.floor(baseEnemyAtk * worldMult * roundMult));
            battleState.enemySpeedSec = Math.max(0.4, battleState.enemySpeedSec);
            document.getElementById("battleStageTitle").textContent = `ボスラッシュ ${bossRushState.round}周目 - ステージ${stageInRound}/200`;
            document.getElementById("enemyNameText").textContent = `ボスラッシュボス Round${bossRushState.round}`;
            document.getElementById("enemySubText").textContent = `Stage${stageInRound}/200 ・ 世界Lv.${getBossRushRunWorldLevel()} ・ 敵倍率×${roundMult}×世界Lv×${worldMult}`;
            updateBattleUI();
            renderBossRushView();
        }

        function renderBossRushView() {
            normalizeBossRushSelection();
            const activeRun = bossRushState && bossRushState.active;
            const lv = activeRun ? getBossRushRunWorldLevel() : getWorldLevel();
            const disp = document.getElementById("bossRushWorldLevelDisplay");
            if (disp) disp.textContent = `Lv.${lv}`;
            const grid = document.getElementById("bossRushWorldLevelGrid");
            if (grid) {
                __PERF.setHTML(grid, "");
                getAvailableBossRushLevels().forEach(i => {
                    const b = document.createElement("button");
                    const isActive = i === lv;
                    b.className = `py-2 px-1 rounded-lg text-xs font-bold transition border-2 ${isActive ? 'bg-amber-500 text-black border-amber-200 shadow' : 'bg-black/60 text-amber-200 border-amber-500/40 hover:bg-amber-900/40'}`;
                    b.textContent = `${i}`;
                    b.disabled = !!activeRun;
                    if (activeRun) b.classList.add('opacity-70', 'cursor-not-allowed');
                    b.onclick = () => setWorldLevel(i);
                    grid.appendChild(b);
                });
            }

            const bestValEl = document.getElementById("bossRushBestVal");
            const roundValEl = document.getElementById("bossRushRoundVal");
            const stageValEl = document.getElementById("bossRushStageVal");
            const killValEl = document.getElementById("bossRushKillVal");

            const bestStage = state.bossRushBest || 0;
            if (bestValEl) bestValEl.textContent = bestStage;

            if (bossRushState && bossRushState.active) {
                if (roundValEl) roundValEl.textContent = `${bossRushState.round}`;
                if (stageValEl) stageValEl.textContent = `${bossRushState.stage}`;
                if (killValEl) killValEl.textContent = `${bossRushState.scoreKills}`;
                const contBox = document.getElementById("bossRushContinueBox");
                if (contBox) {
                    contBox.classList.remove("hidden");
                    const total = (bossRushState.round - 1) * 200 + bossRushState.stage;
                    const status = document.getElementById("bossRushContinueStatus");
                    if (status) __PERF.setHTML(status, `現在: <span class="text-amber-300 font-bold">世界Lv.${bossRushState.worldLevel || lv} / ${bossRushState.round}周目 - ${bossRushState.stage}/200</span>(累計 ${total})<br>今回撃破数: <span class="text-red-300 font-bold">${bossRushState.scoreKills}</span>体`);
                }
            } else {
                if (roundValEl) roundValEl.textContent = "-";
                if (stageValEl) stageValEl.textContent = "-";
                if (killValEl) killValEl.textContent = "0";
                const contBox = document.getElementById("bossRushContinueBox");
                if (contBox) contBox.classList.add("hidden");
            }
        }

        // Explicitly bind all globally referenced methods to window
        window.startBossRush = startBossRush;
        window.continueBossRush = continueBossRush;
        window.abandonBossRush = abandonBossRush;
        window.enterBossRushBattle = enterBossRushBattle;
        window.getBossRushRoundMult = getBossRushRoundMult;
        window.getWorldLevel = getWorldLevel;
        window.getWorldLevelMult = getWorldLevelMult;
        window.setWorldLevel = setWorldLevel;
        window.renderBossRushView = renderBossRushView;
        window.checkAchievements = checkAchievements;
        window.renderAchievementsView = renderAchievementsView;
        window.ensureBossRush = ensureBossRush;

        window.renderDungeonsView = renderDungeonsView;
        window.renderFormationSlots = renderFormationSlots;
        window.promptSaveFormation = promptSaveFormation;
        window.loadFormation = loadFormation;
        window.deleteFormation = deleteFormation;
        window.openDataTransferModal = openDataTransferModal;
        window.openSettingsModal = openSettingsModal;
        window.saveSettings = saveSettings;
        window.showGachaSubtab = showGachaSubtab;
        window.performReviewGacha = performReviewGacha;
        window.exportDataTransfer = exportDataTransfer;
        window.copyDataTransfer = copyDataTransfer;
        window.importDataTransfer = importDataTransfer;
        window.performGemLottery = performGemLottery;
        window.renderDeckView = renderDeckView;
        window.renderGrowthView = renderGrowthView;
        window.renderSynergyView = renderSynergyView;
        window.performGacha = performGacha;
        window.renderNewGachaPanels = renderNewGachaPanels;
        window.toggleDeckUnit = toggleDeckUnit;
        window.autoBuildSynergyDeck = autoBuildSynergyDeck;
        window.setOutfitCategory = setOutfitCategory;
        window.upgradeOutfit = upgradeOutfit;
        window.upgradeUnitLevel = upgradeUnitLevel;
        window.upgradeUnitSpecial = upgradeUnitSpecial;
        window.openStageModal = openStageModal;
        window.startBattle = startBattle;
        window.startReviewBattle = startReviewBattle;
        window.triggerSpecialMove = triggerSpecialMove;
        window.handleQuizAnswer = handleQuizAnswer;
        window.promptResetData = promptResetData;
        window.promptRetreat = promptRetreat;
        window.closeModal = closeModal;
        window.openGachaRatesModal = openGachaRatesModal;
        window.endBattle = endBattle;
        window.startBattleFromExplain = function () {
            if (_explainStageId) startBattle(_explainStageId);
        };

        window.exitBattleView = exitBattleView;
        window.createFloatingText = createFloatingText;

        function applySmartphoneModeClass() {
            document.body.classList.toggle('smphone-mode', !!(state.settings && state.settings.smartphoneMode));
            if (document.body.classList.contains('smphone-mode')) fitBattleStage();
            else {
                var st = document.getElementById('battleStage');
                if (st) st.style.transform = '';
            }
        }

        // スマホモード: 戦闘ステージを端末ビューポートへそのままフィット
        function fitBattleStage() {
            var stage = document.getElementById('battleStage');
            if (!stage || !document.body.classList.contains('smphone-mode')) return;
            stage.style.width = window.innerWidth + 'px';
            stage.style.height = window.innerHeight + 'px';
            stage.style.transform = 'none';
        }
        window.addEventListener('resize', function () {
            if (document.body.classList.contains('smphone-mode')) fitBattleStage();
        });


/* =========================================================================
 * ネット対戦モード（PeerJS）: ホスト権威モデル（ホストが設定・対戦判定を保持）
 * ・通信: HybridP2PManager による動的トポロジー（外部バックエンドサーバーなし・PeerJSクラウドのみ）
 *    2〜4人: 単一グループのフルメッシュP2P / 5〜16人: 最大4名のグループ×リーダーメッシュ
 * ・ホスト: Peer() で「対戦コード」部屋を作成, 最大16人(ホスト+15ゲスト)
 * ・ゲスト: 対戦コード(=ホストPeerID)へ接続のうえ、固定PeerIDでグループメンバーとメッシュ接続
 * ・ホスト離脱時: 残りメンバーのうち最小スロットのプレイヤーへ権限が自動移譲
 * ========================================================================= */
(function () {
  if (typeof window === 'undefined') return;
  var P = { state: {}, battle: null };
  var RARITY_ORDER = ['神', 'UR', 'SSR', 'SR', 'R', 'N'];
  var MAX_ROOM = 16;   // ★16人対応: ホスト+ゲスト15名
  var MAX_QUESTIONS = 30;
  var ANSWER_TIMEOUT_MS = 8000;   // ①オフライン同様のテンポ重視
  var COUNTER_RATE = 0.5;
  // ★①修正: 自分が間違えるほど「自分への反撃」が増える倍率（累積ミス1回ごとに+30%）
  var PVP_MISS_PENALTY = 0.3;
  var SPECIAL_WINDOW_MS = 1100;   // ①回答解決後に必殺技を打てる猶予

  // ★修正: 対戦準備フェーズを堅牢化する追加定数
  var BATTLE_AWAIT_TIMEOUT_MS = 12000; // 「対戦準備中…」が12秒続いたらタイムアウト
  var MAX_QUIZ_RETRY = 3;              // クイズ送信の自動リトライ回数
  var QUIZ_RETRY_INTERVAL = 800;       // クイズ再送間隔(ms)
  var MAX_ASK_DECK_RETRY = 3;          // askDeck再送の上限（初回送信は呼び出し元で実施済み）
  var ASK_DECK_INTERVAL = 3000;        // askDeck再送間隔(ms)
  P._pvpTimers = [];
  P._quizRetryTimers = [];

  // =========================================================================
  // HybridP2PManager: 参加人数に応じて最適なP2Pトポロジーを自動構築・管理する通信層
  // ・2〜4人 : 全員が1つのグループ（フルメッシュP2P）で相互接続
  // ・5〜16人: 最大4名ずつのグループへ自動分割
  //    [グループ内] フルメッシュP2P … 詳細な操作データを最小遅延で相互送信
  //    [グループ間] 各グループ先頭プレイヤー=リーダー同士がP2P接続（リーダーメッシュ）
  //      詳細データはグループ外へ送らず、各リーダーが200ms周期で「集計データ」のみ
  //      他リーダーへブロードキャスト送信する
  // 外部バックエンドなし（PeerJS クラウドのみ）。ゲストは入室時に固定PeerIDを得て全員から到達可能。
  // =========================================================================
  function HybridP2PManager() {
    this.conns = {};          // {slot: DataConnection} 直接接続（自グループメッシュ＋リーダーメッシュ）
    this._lastEnsureAt = 0;
    this.groups = [];         // [{groupId, leader, members:[slot,...]}] グループ構成
    this.bySlot = {};         // {slot: {groupId, leader}} 全プレイヤーの所属情報
    this.memberAgg = {};      // {slot: {name, inBattle, ts}} … グループ内メンバーのステータス
    this.groupAggCache = {};  // {groupId: {members, ts, leaderSlot}} … 他グループの集計キャッシュ
    this._aggTimer = null;    // 200ms集計タイマー
    this._retryAt = {};       // {slot: ts} 接続再試行のクールダウン
  }

  HybridP2PManager.prototype.playerList = function () {
    return (P.state && P.state.players) || [];
  };
  HybridP2PManager.prototype.mySlot = function () {
    return P.state ? P.state.mySlot : 0;
  };
  HybridP2PManager.prototype.playerNameOf = function (slot) {
    var ps = this.playerList();
    for (var i = 0; i < ps.length; i++) if (ps[i].slot === slot) return ps[i].name;
    return '';
  };
  // スロット→固定PeerID（players配列のpeerIdを優先、未登録時は命名規則で導出）
  HybridP2PManager.prototype.peerIdOf = function (slot) {
    var ps = this.playerList();
    for (var i = 0; i < ps.length; i++) if (ps[i].slot === slot && ps[i].peerId) return ps[i].peerId;
    var code = (P.state && P.state.code) ? String(P.state.code).toLowerCase() : '';
    if (!code) return '';
    return slot === 0 ? ('tk315pvp-' + code + '-h') : ('tk315pvp-' + code + '-g' + pad(slot));
  };
  // PeerID→スロット（受信コネクションの特定に使用）
  HybridP2PManager.prototype.slotByPeerId = function (pid) {
    if (!pid) return null;
    var ps = this.playerList();
    for (var i = 0; i < ps.length; i++) {
      if (ps[i].peerId === pid || this.peerIdOf(ps[i].slot) === pid) return ps[i].slot;
    }
    return null;
  };

  // ---- 参加人数に応じたグループ分割（スロット順で最大4名ずつ。先頭=リーダー） ----
  HybridP2PManager.prototype.assignGroups = function (players) {
    var list = (players || this.playerList()).slice();
    list.sort(function (a, b) { return a.slot - b.slot; });
    var n = list.length;
    var groups = [], bySlot = {}, gid = 0;
    if (n <= 4) {
      // 2〜4人: 全員1グループ（フルメッシュP2P）
      groups.push({ groupId: 0, leader: n ? list[0].slot : 0, members: list.map(function (p) { return p.slot; }) });
    } else {
      // 5〜16人: 最大4名ずつのグループへ分割
      for (var i = 0; i < n; i += 4) {
        var chunk = list.slice(i, i + 4);
        groups.push({ groupId: gid, leader: chunk[0].slot, members: chunk.map(function (p) { return p.slot; }) });
        gid++;
      }
    }
    for (var g = 0; g < groups.length; g++) {
      var gr = groups[g];
      for (var m = 0; m < gr.members.length; m++) bySlot[gr.members[m]] = { groupId: gr.groupId, leader: gr.leader };
    }
    return { groups: groups, bySlot: bySlot };
  };

  // グループ構成と接続を再計算（入退室・リーダー交代のたびに呼ぶ）
  HybridP2PManager.prototype.syncTopology = function () {
    var s = P.state;
    if (!s || !s.role || !s.peer) return;
    var players = this.playerList();
    if (!players.length) return;
    var topo = this.assignGroups(players);
    this.groups = topo.groups;
    this.bySlot = topo.bySlot;
    this.ensureConnections();
    this.updateAggTimer();
    jlog('topology', 'n=' + players.length, this.groups.map(function (g) { return 'G' + g.groupId + '[L' + g.leader + '](' + g.members.join(',') + ')'; }).join(' '));
  };

  // 自グループの全メンバー ＋ 全グループのリーダー との接続を確保（フルメッシュ＋リーダーメッシュ）
  HybridP2PManager.prototype.ensureConnections = function () {
    var me = this.mySlot();
    var myInfo = this.bySlot[me];
    var targets = [];
    if (myInfo && this.groups[myInfo.groupId]) {
      var gr = this.groups[myInfo.groupId];
      for (var i = 0; i < gr.members.length; i++) if (gr.members[i] !== me) targets.push(gr.members[i]);
    }
    for (var g = 0; g < this.groups.length; g++) {
      var L = this.groups[g].leader;
      if (L !== me && targets.indexOf(L) === -1) targets.push(L);
    }
    var _this = this;
    for (var t = 0; t < targets.length; t++) _this.ensureConn(targets[t]);
  };

  // 1対1の接続を確保（失敗時は2秒クールダウン後に自動再試行）
  HybridP2PManager.prototype.ensureConn = function (slot) {
    var s = P.state;
    if (!s || !s.peer) return;
    if (this.conns[slot] && this.conns[slot].open) return;
    if (!s.players.some(function (p) { return p.slot === slot; })) return; // 退出済みスロット
    var nowT = Date.now();
    if (this._retryAt[slot] && nowT < this._retryAt[slot]) return;
    this._retryAt[slot] = nowT + 2000;
    var pid = this.peerIdOf(slot);
    if (!pid || pid === (s.peer && s.peer.id)) return; // 自分自身とは接続しない
    var _this = this, conn = null;
    try { conn = s.peer.connect(pid, { reliable: true }); } catch (e) { return; }
    conn.on('open', function () {
      _this.conns[slot] = conn;
      jlog('mesh conn open', 'slot=' + slot, pid);
    });
    conn.on('data', function (d) { routeIn(slot, conn, d); });
    conn.on('close', function () {
      jlog('mesh conn close', 'slot=' + slot);
      if (_this.conns[slot] === conn) delete _this.conns[slot];
      onMeshConnLoss(slot);
    });
    conn.on('error', function (e) { jlog('mesh conn err', 'slot=' + slot, e && e.type); });
  };

  // 受信コネクションを peerId からスロット特定して登録（未知ならfalse＝従来のハンドシェイクへ委譲）
  function registerConn(conn) {
    if (!conn || !conn.peer) return false;
    var slot = P2P.slotByPeerId(conn.peer);
    if (slot === null || slot === undefined) return false;
    P2P.conns[slot] = conn;
    conn.on('data', function (d) { routeIn(slot, conn, d); });
    conn.on('close', function () {
      if (P2P.conns[slot] === conn) delete P2P.conns[slot];
      onMeshConnLoss(slot);
    });
    conn.on('error', function () {});
    jlog('inbound conn registered', 'slot=' + slot, conn.peer);
    return true;
  }

  // Peer の connection イベントの共通入口（既知プレイヤー=メッシュ受信 / 未知=従来joinハンドシェイク）
  function onPeerConn(conn) {
    if (!registerConn(conn)) acceptGuestConn(conn);
  }

  // 接続喪失: 全員トポロジー再計算、ホストは退室判定も実施
  function onMeshConnLoss(slot) {
    var s = P.state;
    if (!s || !s.role) return;
    P2P.syncTopology();
    if (s.role !== 'host') return;
    var alive = !!(P2P.conns[slot] && P2P.conns[slot].open) || !!(s.guestConns[slot] && s.guestConns[slot].open);
    if (!alive && s.players.some(function (p) { return p.slot === slot && !p.isHost; })) {
      hostRemoveGuest(slot, true);
    }
  }

  // ==================== データ受信ルーティング ====================
  // 各ノード共通: リレー/集計は通信層で処理し、通常メッセージは従来のゲーム層ハンドラへ配送
  function routeIn(slot, conn, d) {
    if (!d || !d.t) return;
    if (d.t === '__relay') { P2P.handleRelay(d); return; }
    if (d.t === 'groupAgg' || d.t === 'groupAggX') { P2P.receiveGroupAgg(d); return; }
    if (d.t === 'agg') { P2P.receiveMemberAgg(slot, d); return; }
    if (P.state.role === 'host') {
      if (d.t === 'iAmGuest') {
        // ホスト移譲後の再接続（従来 acceptGuestConn が担っていた処理を同型で実施）
        var sl2 = parseInt(d.slot, 10);
        if (!isNaN(sl2) && sl2 >= 1 && sl2 < MAX_ROOM) {
          P.state.guestConns[sl2] = conn;
          var nm2 = String(d.name || 'プレイヤー').slice(0, 10);
          var ex2 = (P.state.players || []).find ? P.state.players.find(function (x) { return x.slot === sl2; }) : null;
          if (ex2) ex2.name = nm2;
          else upsertPlayer(sl2, nm2, false, 'tk315pvp-' + String(P.state.code || '').toLowerCase() + '-g' + pad(sl2));
          dedupePlayersList();
          hostBroadcast(playersPayload());
        }
        return;
      }
      if (d.t === 'join' || d.t === 'join2') { P._lastConn = conn; }
      hostHandleData(slot, d);
    } else {
      guestHandleData(d);
    }
  }

  // グループ間リレー: 詳細データはグループ外へ直接送らず、リーダーメッシュ経由で宛先まで配送
  HybridP2PManager.prototype.handleRelay = function (d) {
    var to = parseInt(d.to, 10), from = parseInt(d.from, 10);
    if (isNaN(to)) return;
    if (to === this.mySlot()) { this.dispatchLocal(from, d.p); return; }
    var myInfo = this.bySlot[this.mySlot()];
    var toInfo = this.bySlot[to];
    if (!myInfo || !toInfo) return;
    if (myInfo.groupId === toInfo.groupId) {
      // 同じグループ内の最終配送（通常は発生しない保険）
      try { if (this.conns[to] && this.conns[to].open) this.conns[to].send(d); } catch (e) {}
      return;
    }
    if (this.mySlot() === myInfo.leader) {
      // リーダー同士の直接接続で宛先グループのリーダーへ転送
      this.ensureConn(toInfo.leader);
      try { if (this.conns[toInfo.leader] && this.conns[toInfo.leader].open) { this.conns[toInfo.leader].send(d); return; } } catch (e) {}
    }
    // 転送先が未確立なら無視（接続再確立後、次回送信で再送される）
  };

  // リレー最終到達点での配送（送信元スロット付きでゲーム層へ）
  HybridP2PManager.prototype.dispatchLocal = function (fromSlot, p) {
    if (!p || !p.t) return;
    if (p.t === '__relay') { this.handleRelay(p); return; }
    if (p.t === 'groupAgg' || p.t === 'groupAggX') { this.receiveGroupAgg(p); return; }
    if (p.t === 'agg') { this.receiveMemberAgg(fromSlot, p); return; }
    if (P.state.role === 'host') hostHandleData(fromSlot, p);
    else guestHandleData(p);
  };

  // ==================== 送信 ====================
  // 同一グループ=直接メッシュ送信 / 別グループ=リーダー経由リレー（詳細データの外部直接送信なし）
  HybridP2PManager.prototype.sendTo = function (slot, obj) {
    var me = this.mySlot();
    if (slot === me) return false;
    var c = this.conns[slot];
    if (c && c.open) { try { c.send(obj); return true; } catch (e) {} }
    var myInfo = this.bySlot[me];
    var toInfo = this.bySlot[slot];
    if (myInfo && toInfo && myInfo.groupId !== toInfo.groupId) {
      var env = { t: '__relay', from: me, to: slot, p: obj };
      if (me === myInfo.leader) {
        this.ensureConn(toInfo.leader);
        var lc = this.conns[toInfo.leader];
        if (lc && lc.open) { try { lc.send(env); return true; } catch (e) {} }
      } else {
        var mc = this.conns[myInfo.leader];
        if (mc && mc.open) { try { mc.send(env); return true; } catch (e) {} }
      }
    }
    return false;
  };
  HybridP2PManager.prototype.broadcast = function (obj) {
    var me = this.mySlot(), ps = this.playerList(), any = false;
    for (var i = 0; i < ps.length; i++) { if (ps[i].slot !== me && this.sendTo(ps[i].slot, obj)) any = true; }
    return any;
  };
  // リレー不要の直接送信（集計データ用）
  HybridP2PManager.prototype.rawSend = function (slot, obj) {
    var c = this.conns[slot];
    if (c && c.open) { try { c.send(obj); return true; } catch (e) {} }
    return false;
  };

  // ==================== 200ms周期の集計データ通信 ====================
  HybridP2PManager.prototype.inBattleNow = function () {
    var b = P.state && P.state.battle;
    return !!(b && b.active && b.isPlayer === true);
  };
  HybridP2PManager.prototype.updateAggTimer = function () {
    var _this = this;
    var me = this.mySlot();
    var myInfo = this.bySlot[me];
    if (!myInfo) return;
    if (this._aggTimer) { clearInterval(this._aggTimer); this._aggTimer = null; }
    this._aggTimer = __PERF.keepAliveInterval(function () {
      var s = P.state;
      if (!s || !s.role || !s.peer) { _this.stopAgg(); return; }
      var info = _this.bySlot[_this.mySlot()];
      if (!info) return;
      var gr = _this.groups[info.groupId];
      if (!gr) return;
      // 接続再試行には既存の2秒クールダウンがあるため、毎200msのトポロジー走査を避ける
      var now = Date.now();
      if (now - _this._lastEnsureAt >= 2000) {
        _this._lastEnsureAt = now;
        _this.ensureConnections();
      }
      if (info.leader === _this.mySlot()) {
        // リーダー: 自グループの集計データのみ他リーダーへブロードキャスト（200ms周期）
        var members = [];
        for (var i = 0; i < gr.members.length; i++) {
          var sl = gr.members[i];
          var ag = _this.memberAgg[sl] || {};
          members.push({ slot: sl, name: ag.name || _this.playerNameOf(sl) || 'プレイヤー', inBattle: !!(ag.inBattle) });
        }
        var agg = { t: 'groupAgg', srcGroup: gr.groupId, leaderSlot: info.leader, members: members, ts: Date.now() };
        for (var g = 0; g < _this.groups.length; g++) {
          var L = _this.groups[g].leader;
          if (L !== _this.mySlot()) _this.rawSend(L, agg);
        }
      } else {
        // 一般メンバー: 自分のステータスを自グループのリーダーへ通知（集計の材料）
        var nm = _this.playerNameOf(_this.mySlot()) || (P.state.myName || 'プレイヤー');
        _this.rawSend(info.leader, { t: 'agg', name: nm, inBattle: _this.inBattleNow() });
      }
    }, 200);
  };
  HybridP2PManager.prototype.receiveMemberAgg = function (slot, d) {
    this.memberAgg[slot] = { name: String(d.name || '').slice(0, 10), inBattle: !!d.inBattle, ts: Date.now() };
  };
  HybridP2PManager.prototype.receiveGroupAgg = function (d) {
    var gid = parseInt(d.srcGroup, 10);
    if (isNaN(gid)) return;
    this.groupAggCache[gid] = { members: d.members || [], ts: Date.now(), leaderSlot: d.leaderSlot };
    // リーダー受信時のみ、自グループのメンバーへ軽量な集計通知を転送（詳細データは含めない）
    if (d.t === 'groupAgg') {
      var myInfo = this.bySlot[this.mySlot()];
      if (myInfo && this.groups[myInfo.groupId]) {
        var gr = this.groups[myInfo.groupId], _this2 = this;
        for (var i = 0; i < gr.members.length; i++) {
          var sl2 = gr.members[i];
          if (sl2 !== _this2.mySlot()) _this2.rawSend(sl2, { t: 'groupAggX', srcGroup: gid, members: d.members || [], ts: d.ts });
        }
      }
    }
  };
  HybridP2PManager.prototype.stopAgg = function () {
    if (this._aggTimer) { clearInterval(this._aggTimer); this._aggTimer = null; }
  };
  HybridP2PManager.prototype.reset = function () {
    this.stopAgg();
    this.conns = {};
    this.groups = [];
    this.bySlot = {};
    this.memberAgg = {};
    this.groupAggCache = {};
    this._retryAt = {};
    this._lastEnsureAt = 0;
  };

  // 部屋内の全プレイヤー（ホスト/ゲスト共通）で共有する通信マネージャ
  var P2P = new HybridP2PManager();

  // 全タイマーを一括クリア（ロビー復帰・対戦終了・キャンセル時に呼ぶ）
  function pvpClearTimers() {
    if (P._pvpLoop) { clearInterval(P._pvpLoop); P._pvpLoop = null; }
    (P._pvpTimers || []).forEach(function (id) { try { clearTimeout(id); } catch (e) {} });
    (P._quizRetryTimers || []).forEach(function (id) { try { clearTimeout(id); } catch (e) {} });
    P._pvpTimers = [];
    P._quizRetryTimers = [];
    var s = P.state;
    if (s) {
      if (s._deckWaitTimer) { clearTimeout(s._deckWaitTimer); s._deckWaitTimer = null; }
      s._deckRetryCount = 0;
      s._pbStartRetry = false;
      if (s.battle && s.battle._awaitTimer) { clearTimeout(s.battle._awaitTimer); s.battle._awaitTimer = null; }
    }
  }
  function pvpSetTimer(fn, ms) { var id = setTimeout(fn, ms); P._pvpTimers.push(id); return id; }
  // ==================== カウントダウン表示（5→4→3→2→1→スタート） ====================
  var PVP_COUNTDOWN_STEPS = ['5', '4', '3', '2', '1', 'スタート'];
  function pvpShowCountdown(onDone) {
    try {
      var existing = document.getElementById('pvpCountdownOverlay');
      if (existing) { try { existing.parentNode.removeChild(existing); } catch (e) {} }
    } catch (e) {}
    var ov = document.createElement('div');
    ov.id = 'pvpCountdownOverlay';
    ov.className = 'pvp-countdown-overlay';
    var num = document.createElement('div');
    num.id = 'pvpCountdownNum';
    num.className = 'pvp-countdown-num';
    num.textContent = '';
    ov.appendChild(num);
    document.body.appendChild(ov);
    var i = 0;
    function step() {
      if (i >= PVP_COUNTDOWN_STEPS.length) {
        try { num.textContent = ''; } catch (e) {}
        try { setTimeout(function () { if (ov && ov.parentNode) ov.parentNode.removeChild(ov); }, 250); } catch (e) {}
        if (typeof onDone === 'function') { try { onDone(); } catch (e) {} }
        return;
      }
      var key = PVP_COUNTDOWN_STEPS[i];
      num.textContent = key;
      if (key === 'スタート') { num.classList.add('go'); } else { num.classList.remove('go'); }
      // スタートの合図で効果音を再生（AudioFX は自動再生制限対策済み）
      if (key === 'スタート') { try { pvpPlayStartSound(); } catch (e) {} }
      // アニメーションを毎回トリガするためクラスを付け直す
      num.style.animation = 'none';
      try { void num.offsetWidth; } catch (e) {}
      num.style.animation = '';
      var dur = 1000;
      i++;
      pvpSetTimer(step, dur);
    }
    step();
  }
  // ★修正: スタートの合図で鳴らす効果音（AudioFX のファンファーレ）
  function pvpPlayStartSound() {
    try {
      if (typeof AudioFX === 'undefined' || !AudioFX) return;
      AudioFX.playStart();
    } catch (e) {}
  }
  function pvpBeginCountdownIfNeeded(onDone) {
    try {
      var s = P.state;
      var b = s && s.battle;
      if (!b || !b.active) { if (typeof onDone === 'function') onDone(); return; }
      if (b._countdownDone) { if (typeof onDone === 'function') onDone(); return; }
    } catch (e) { if (typeof onDone === 'function') onDone(); return; }
    function _armBattleOnCountdownDone() {
      try {
        var b2 = P.state.battle;
        if (!b2 || !b2.active) return;
        b2._countdownDone = true;
        b2._acceptAnswer = true;
        if (!b2.startedAt) b2.startedAt = Date.now();
        if (P.state.role === 'host') {
          try { hostBroadcast({ t: 'countdownDone' }); } catch (e) {}
          try {
            if (b2.a !== undefined && b2.a !== null) hostSendQuizToSlot(b2.a, 0);
            if (b2.b !== undefined && b2.b !== null && b2.b !== b2.a) hostSendQuizToSlot(b2.b, 0);
            if (b2.isPlayer) renderDuel();
          } catch (e) {}
        } else {
          try {
            if (!b2.questionMap || !b2.questionMap[b2.mySlot]) guestSend({ t: 'pleaseSendQuiz' });
          } catch (e) {}
        }
      } catch (e) {}
      if (typeof onDone === 'function') { try { onDone(); } catch (e) {} }
    }
    pvpShowCountdown(_armBattleOnCountdownDone);
  }
  // 通信失敗時の安全な復帰: タイマーを掃除してロビーへ戻る（接続自体は部屋維持のため保持）
  function pvpSafeBackToLobby() {
    pvpClearTimers();
    var s = P.state;
    if (s.battle) { s.battle.active = false; s.battle = null; }
    try { pbCancelCurrentMatch(); } catch (e) {}
    s.pendingBattle = null;
    s.pendingChallenge = null;
    jlog('通信失敗 → ロビーへ安全復帰');
    renderLobby();
  }
  // 「対戦準備中…」監視: 接続は正常なのにクイズが届かない状態を検知したら
  // 表示ダイアログやトーストは一切出さず、ホスト側なら自動再送・ゲスト側なら静かに再要求する
  function pvpArmAwaitWatchdog() {
    var b = P.state.battle;
    if (!b || !b.active) return;
    if (b._awaitTimer) { clearTimeout(b._awaitTimer); }
    b._awaitTimer = pvpSetTimer(function () {
      var b2 = P.state.battle;
      if (!b2 || !b2.active || b2.state !== 'await') return;
      jlog('対戦準備中タイムアウト（' + BATTLE_AWAIT_TIMEOUT_MS + 'ms）— ダイアログは出さず自動再送のみ');
      // ★応答がありませんダイアログは廃止。ホストはクイズを再送、ゲストは再要求のみ送る
      if (P.state.role === 'host') {
        var bb = P.state.battle;
        if (bb && bb.active && bb.a !== undefined && bb.a !== null && bb.b !== undefined && bb.b !== null) {
          hostSendQuizToSlot(bb.a, 0);
          if (bb.b !== bb.a) hostSendQuizToSlot(bb.b, 0);
          jlog('対戦準備中タイムアウト → クイズ再送', bb.a, bb.b);
        }
      } else {
        try { guestSend({ t: 'reqQuiz' }); } catch (e) {}
      }
      pvpArmAwaitWatchdog();
    }, BATTLE_AWAIT_TIMEOUT_MS);
  }

  function el(id) { return document.getElementById(id); }
  function pvpSetHeaderClose(hidden) { var x = el('pvpHeaderCloseBtn'); if (!x) return; if (hidden) x.classList.add('hidden'); else x.classList.remove('hidden'); }
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  function jlog() { try { console.log.apply(console, ['[PVP]'].concat(Array.prototype.slice.call(arguments))); } catch (e) {} }
  function pad(n) { return String(n).padStart(2, '0'); }
  function now() { return Date.now(); }
  function randCode(len) {
    var chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    var out = '';
    for (var i = 0; i < len; i++) out += chars.charAt(Math.floor(Math.random() * chars.length));
    return out;
  }
  function pvpToast(title, msg) {
    try { showCustomAlert(title, msg); } catch (e) { window.alert(title + '\n' + msg); }
  }

  function defaultSettings() {
    return {
      equalize: true, level: 300, slots: 10,
      rank: { '神': 1, 'UR': 3, 'SSR': null, 'SR': null, 'R': null, 'N': null },
      gimmicks: { mon: false, tue: false, wed: false, thu: false, fri: false, enrage: false },
      // ★ オンライン対戦の初期設定は公式設定（ホストが何も変えなければ公式扱いのまま）
      noFullHeal: true,
      noHeal: false,
      official: true
    };
  }

  // ---------- ユーザー名 / セーブ ----------
  function getName() {
    var n = '';
    try { n = localStorage.getItem('kobun_pvp_name') || ''; } catch (e) {}
    if (!n) {
      n = window.prompt('対戦時の表示名を入力してください（10文字以内）', 'プレイヤー');
      if (n == null) n = '';
      n = String(n).trim().slice(0, 10);
      if (!n) n = 'プレイヤー';
      try { localStorage.setItem('kobun_pvp_name', n); } catch (e) {}
    }
    return n;
  }

  // ---------- 所属ユニット解決 ----------
  function pvpGetUnit(id) { try { return getUnit(id); } catch (e) { return null; } }

  // ---------- 編成検証（ホスト・ゲスト双方で実行。ホスト側で最終判定） ----------
  function pvpValidateDeck(deckIds, settings) {
    var ids = [];
    (deckIds || []).forEach(function (id) {
      if (!pvpGetUnit(id)) return;
      if (ids.indexOf(id) === -1) ids.push(id);
    });
    if (ids.length === 0) return { ok: false, msg: '部隊が編成されていません。編成タブからキャラを編成してください。' };
    var maxSlots = Math.max(1, parseInt(settings && settings.slots, 10) || 10);
    if (ids.length > maxSlots) return { ok: false, msg: '枠数が上限（' + maxSlots + '枠）を超えています。編成を減らしてください。' };
    var counts = {};
    ids.forEach(function (id) {
      var u = pvpGetUnit(id);
      var r = (u && u.rarity) ? u.rarity : 'N';
      counts[r] = (counts[r] || 0) + 1;
    });
    for (var i = 0; i < RARITY_ORDER.length; i++) {
      var r2 = RARITY_ORDER[i];
      var lim = settings && settings.rank ? settings.rank[r2] : null;
      if (lim !== null && lim !== undefined && lim !== '' && (counts[r2] || 0) > Number(lim)) {
        return { ok: false, msg: r2 + 'ランクは最大' + lim + '体までです（現在' + (counts[r2] || 0) + '体）。編成を調整してください。' };
      }
    }
    return { ok: true, ids: ids };
  }

  // ---------- 対戦用パーティ構築（レベル均一 or 実レベル） ----------
  function pvpBuildParty(deckIds, levels, nobleLevel, settings) {
    var party = [];
    (deckIds || []).forEach(function (id) {
      var u = pvpGetUnit(id);
      if (!u) return;
      var lvl;
      if (settings && settings.equalize) {
        lvl = Math.max(1, parseInt(settings.level, 10) || 1);
      } else if (id === 'ch_000') {
        lvl = Math.max(1, parseInt(nobleLevel, 10) || 1);
      } else {
        lvl = Math.max(1, parseInt((levels && levels[id]) || 1, 10) || 1);
      }
      var st;
      try { st = getScaledUnitStatsByLevel(u, lvl); } catch (e) { st = { hp: 200, atk: 20 }; }
      if (settings && settings.official && u.rarity === '神' && id !== 'ch_000') st.hp = 0;
      party.push({
        id: id,
        name: u.name || id,
        rarity: u.rarity || 'N',
        lvl: lvl,
        hp: st.hp,
        atk: st.atk,
        icon: u.icon || 'fa-user',
        skill: u.skill || null,
        specialName: (u.special_move && u.special_move.name) || '奥義',
        specialEffectText: (u.special_move && u.special_move.effect) || '',
        special_effect: u.special_effect || null,
        gaugePerCorrect: u.gaugePerCorrect,
        gaugeNeedsVotes: u.gaugeNeedsVotes,
        gender: u.gender || null
      });
    });
    return party;
  }
  function pvpPartyTotalAtk(party) {
    var total = party.reduce(function (s, u) { return s + u.atk; }, 0);
    var hasNarihira = party.some(function (u) { return u.id === 'so_007'; });
    var femaleCount = party.filter(function (u) { return u.gender === '女性'; }).length;
    if (hasNarihira && femaleCount > 0) total = Math.floor(total * (1 + femaleCount * 0.5));
    return total;
  }
  function pvpPartyTotalHp(party) { return party.reduce(function (s, u) { return s + u.hp; }, 0); }
  function pvpSynCount(deckIds) {
    try { return getActiveSynergiesForDeck(deckIds).length; } catch (e) { return 0; }
  }
  function pvpHasUnit(player, id) {
    return !!(player && player.party && player.party.some(function (u) { return u && u.id === id; }));
  }
  function pvpCountGender(player, gender) {
    return (player && player.party ? player.party.filter(function (u) { return u && u.gender === gender; }).length : 0);
  }
  function pvpGetSynergies(deckIds) {
    try { return getActiveSynergiesForDeck(deckIds || []) || []; } catch (e) { return []; }
  }
  function pvpDurationTurns(v, fallback) {
    var n = Array.isArray(v) ? Number(v[1]) : Number(v);
    if (!isFinite(n) || n <= 0) n = fallback || 6;
    return Math.max(1, Math.round(n / 3));
  }
  function pvpEffectPct(v, fallback) {
    var n = Array.isArray(v) ? Number(v[0]) : Number(v);
    if (!isFinite(n) || n <= 0) n = fallback || 0;
    return Math.max(0, n);
  }
  function pvpSetTimedPct(target, prefix, pct, turns) {
    target[prefix + 'Pct'] = Math.max(target[prefix + 'Pct'] || 0, pct || 0);
    target[prefix + 'Turns'] = Math.max(target[prefix + 'Turns'] || 0, turns || 0);
  }
  function pvpApplyDamageReduction(target, dmg) {
    var red = (target.defPct || 0) + (target.allPct || 0);
    if (red > 0) dmg = Math.floor(dmg * (100 / (100 + red)));
    if (target.damageCutPct) dmg = Math.floor(dmg * Math.max(0.2, 1 - target.damageCutPct / 100));
    if (pvpHasUnit(target, 'so_002') && Math.random() < 0.15) return { dmg: 0, blocked: true };
    if ((target.shield || 0) > 0) {
      target.shield--;
      return { dmg: 0, blocked: true, shielded: true };
    }
    return { dmg: Math.max(0, dmg), blocked: false };
  }
  function pvpSyncCombatant(player) {
    if (!player || !player.party) return player;
    player.deckIds = player.deckIds || player.party.map(function (u) { return u.id; });
    player.synergies = pvpGetSynergies(player.deckIds);
    player.synCount = player.synergies.length;
    var femaleCount = pvpCountGender(player, '女性');
    var maleCount = pvpCountGender(player, '男性');
    var totalAtk = 0, totalHp = 0;
    player.party.forEach(function (u) {
      if (!u) return;
      var atk = Number(u.atk) || 0;
      var hp = Number(u.hp) || 0;
      if (u.gender === '女性' && pvpHasUnit(player, 'ok_007')) atk = Math.floor(atk * 1.3);
      if (u.gender === '女性' && pvpHasUnit(player, 'ge_001')) atk = Math.floor(atk * 1.7);
      if (u.gender === '男性' && pvpHasUnit(player, 'so_010')) hp = Math.floor(hp * 1.3);
      totalAtk += atk;
      totalHp += hp;
    });
    if (pvpHasUnit(player, 'ok_004')) totalAtk = Math.floor(totalAtk * 1.3);
    if (pvpHasUnit(player, 'so_007') && femaleCount > 0) totalAtk = Math.floor(totalAtk * (1 + femaleCount * 0.5));
    if (player.michinagaStacks) totalAtk = Math.floor(totalAtk * (1 + player.michinagaStacks * 0.02));
    var synAtkPct = 0, synHpPct = 0, synSpecPct = 0, synInitGauge = 0, synRecoveryPct = 0;
    (player.synergies || []).forEach(function (syn) {
      var eff = String((syn && syn.effect) || '');
      if (/全ステータス/.test(eff)) {
        var p = quizPctFromText(eff, 12);
        synAtkPct += p; synHpPct += p;
      }
      if (/攻撃|会心|クリティカル|与ダメ/.test(eff)) synAtkPct += quizPctFromText(eff, /大幅/.test(eff) ? 22 : 12);
      if (/HP|防御|耐久|回復/.test(eff)) synHpPct += quizPctFromText(eff, /大幅/.test(eff) ? 18 : 10);
      if (/必殺ゲージ|ゲージ獲得|必要正解数/.test(eff)) synSpecPct += quizPctFromText(eff, /大幅/.test(eff) ? 30 : 16);
      if (/初期必殺ゲージ/.test(eff)) synInitGauge += quizPctFromText(eff, 18);
      if (/回復量/.test(eff)) synRecoveryPct += quizPctFromText(eff, 12);
    });
    player.femaleCount = femaleCount;
    player.maleCount = maleCount;
    player.baseTotalAtk = Math.max(1, Math.floor(totalAtk * (1 + synAtkPct / 100)));
    player.baseMaxHp = Math.max(1, Math.floor(totalHp * (1 + synHpPct / 100)));
    player.synSpecPct = synSpecPct;
    player.synInitGauge = synInitGauge;
    player.synRecoveryPct = synRecoveryPct;
    player.totalAtk = player.baseTotalAtk;
    if (!player.maxHp) player.maxHp = player.baseMaxHp;
    if (!player.hp && player.hp !== 0) player.hp = player.maxHp;
    if (player.hp > player.maxHp) player.hp = player.maxHp;
    return player;
  }
  function pvpRefreshCombatant(player) {
    if (!player) return;
    var atkPct = (player.buffAtkPct || 0) + (player.dmgUpPct || 0) + Math.max(0, player.allPct || 0) - Math.max(0, player.atkDownPct || 0);
    if (pvpHasUnit(player, 'ok_001')) atkPct += 20;
    player.totalAtk = Math.max(1, Math.floor((player.baseTotalAtk || player.totalAtk || 1) * (1 + atkPct / 100)));
  }
  function pvpGaugeGain(player, unit, isCorrect) {
    var gp = (unit && unit.gaugePerCorrect !== undefined) ? (Number(unit.gaugePerCorrect) || 0) : 15;
    var gain = gp * (isCorrect ? 0.7 : 0.3);
    gain *= (1 + ((player.buffSpecGainPct || 0) + (player.synSpecPct || 0) - (player.specSlowPct || 0)) / 100);
    if (pvpHasUnit(player, 'se_001') && isCorrect) gain *= 1.2;
    return Math.max(1, gain);
  }
  function pvpApplyGaugeGain(player, gauges, isCorrect) {
    if (!player || !player.party || !gauges) return;
    player.party.forEach(function (u, ii) {
      gauges[ii] = Math.min(100, (gauges[ii] || 0) + pvpGaugeGain(player, u, isCorrect));
    });
  }
  function pvpApplyHeal(player, healPct, logs, label, b) {
    if (!healPct || !player) return 0;
    var hs = (b && b.settings) || {};
    if (hs.noHeal) {
      if (logs && label) logs.push('🚫 ' + label + 'は回復無効化設定のため不発');
      return 0;
    }
    var amount = Math.floor(player.maxHp * healPct * (1 + (player.synRecoveryPct || 0) / 100));
    amount = Math.max(1, amount);
    var before = player.hp;
    player.hp = Math.min(player.maxHp, player.hp + amount);
    if (logs && player.hp > before) logs.push('💚 ' + player.name + ' HP回復 +' + (player.hp - before));
    return player.hp - before;
  }
  function pvpApplyEffectBundle(caster, target, fx, logs, label, b) {
    fx = fx || {};
    var kind = 'buff';
    if (fx.dmg) {
      var base = Math.floor((caster.totalAtk || caster.baseTotalAtk || 1) * Math.max(0.6, Number(fx.dmg) || 1));
      if (caster.specPowerBonusPct) base = Math.floor(base * (1 + caster.specPowerBonusPct / 100));
      var crit = !!(fx.crit && Math.random() < Math.min(1, Number(fx.crit) || 0));
      if (crit) base = Math.floor(base * 1.8);
      base = Math.max(1, Math.floor(base * pvpSDMult()));
      var mitigated = pvpApplyDamageReduction(target, base);
      var dealt = mitigated.dmg;
      target.hp = Math.max(0, target.hp - dealt);
      logs.push((crit ? '💥 ' : '⚡ ') + label + ' ' + (dealt > 0 ? ('-' + dealt) : 'を防いだ'));
      kind = dealt > 0 ? 'atk' : 'shield';
    }
    if (fx.selfDmgPct) {
      var sd = Math.max(1, Math.floor(caster.maxHp * Number(fx.selfDmgPct)));
      caster.hp = Math.max(0, caster.hp - sd);
      logs.push('💢 ' + caster.name + ' 自傷 -' + sd);
    }
    if (fx.healPct) { pvpApplyHeal(caster, Math.min(1, Number(fx.healPct) || 0), logs, label, b); kind = 'heal'; }
    if (fx.shield) { caster.shield = Math.min(3, (caster.shield || 0) + 1); logs.push('🔰 ' + caster.name + ' 結界付与'); kind = 'shield'; }
    if (fx.buffAtk) { pvpSetTimedPct(caster, 'buffAtk', pvpEffectPct(fx.buffAtk, 20), pvpDurationTurns(fx.buffAtk, 6)); logs.push('⚔️ ' + caster.name + ' 攻撃力UP'); kind = 'buff'; }
    if (fx.buffDef) { pvpSetTimedPct(caster, 'def', pvpEffectPct(fx.buffDef, 20), pvpDurationTurns(fx.buffDef, 6)); logs.push('🛡️ ' + caster.name + ' 防御UP'); kind = 'buff'; }
    if (fx.buffAll) { pvpSetTimedPct(caster, 'all', pvpEffectPct(fx.buffAll, 15), pvpDurationTurns(fx.buffAll, 6)); logs.push('✨ ' + caster.name + ' 全能力UP'); kind = 'buff'; }
    if (fx.buffSpecGain) { pvpSetTimedPct(caster, 'buffSpecGain', pvpEffectPct(fx.buffSpecGain, 25), pvpDurationTurns(fx.buffSpecGain, 6)); logs.push('⚡ ' + caster.name + ' 必殺ゲージ上昇'); kind = 'buff'; }
    if (fx.buffDmgUp) { pvpSetTimedPct(caster, 'dmgUp', pvpEffectPct(fx.buffDmgUp, 20), pvpDurationTurns(fx.buffDmgUp, 6)); logs.push('💥 ' + caster.name + ' 与ダメUP'); kind = 'buff'; }
    if (fx.enemyAtkDown) { pvpSetTimedPct(target, 'atkDown', pvpEffectPct(fx.enemyAtkDown, 20), pvpDurationTurns(fx.enemyAtkDown, 6)); logs.push('📉 ' + target.name + ' 攻撃力DOWN'); kind = 'debuff'; }
    if (fx.enemySpeedDown) { pvpSetTimedPct(target, 'specSlow', pvpEffectPct(fx.enemySpeedDown, 20), pvpDurationTurns(fx.enemySpeedDown, 6)); logs.push('🐢 ' + target.name + ' ゲージ増加DOWN'); kind = 'debuff'; }
    if (fx.stun || fx.confuse || fx.miss) { target.stun = Math.min(3, (target.stun || 0) + 1); logs.push('🌀 ' + target.name + ' 行動阻害'); kind = 'stun'; }
    if (fx.dot) { target.dotPct = Math.max(target.dotPct || 0, Math.min(0.25, (Number(fx.dot) || 0) * 0.08)); target.dotTurns = Math.max(target.dotTurns || 0, 2); logs.push('☠️ ' + target.name + ' に継続ダメージ'); kind = 'debuff'; }
    if (fx.regen) { caster.regenPct = Math.max(caster.regenPct || 0, Math.min(0.2, (Number(fx.regen) || 0) * 0.06)); caster.regenTurns = Math.max(caster.regenTurns || 0, 2); logs.push('🌿 ' + caster.name + ' に再生'); kind = 'heal'; }
    if (fx.cleanse) {
      caster.atkDownPct = 0; caster.atkDownTurns = 0; caster.specSlowPct = 0; caster.specSlowTurns = 0;
      caster.dotPct = 0; caster.dotTurns = 0; caster.stun = 0;
      logs.push('🕊️ ' + caster.name + ' 状態異常解除'); kind = 'buff';
    }
    if (fx.specPowerUp) { caster.specPowerBonusPct = Math.max(caster.specPowerBonusPct || 0, pvpEffectPct(fx.specPowerUp, 20)); logs.push('🔥 ' + caster.name + ' 必殺強化'); kind = 'buff'; }
    pvpRefreshCombatant(caster);
    pvpRefreshCombatant(target);
    return kind;
  }
  function pvpTriggerSkills(player, opp, trigger, logs, ctx, b) {
    if (!player || !player.party) return;
    ctx = ctx || {};
    player.party.forEach(function (u) {
      if (!u || !u.skill) return;
      var sk = u.skill;
      if (sk.trigger !== trigger) return;
      if (sk.once && player['skillOnce_' + u.id]) return;
      var fire = true;
      if (trigger === 'sameRarityCorrect') {
        fire = !!ctx.sameRarity;
      } else if (trigger === 'lowHpCorrect') {
        fire = player.hp <= Math.floor(player.maxHp * 0.35);
      } else if (trigger === 'highGaugeCorrect') {
        fire = !!ctx.highGauge;
      } else if (trigger === 'combo3') {
        fire = (player.combo || 0) >= 3;
      } else if (trigger === 'afterHit') {
        fire = !!ctx.tookDamage;
      } else if (trigger === 'lowHpHit') {
        fire = !!ctx.tookDamage && player.hp <= Math.floor(player.maxHp * 0.35);
      }
      if (!fire) return;
      player['skillOnce_' + u.id] = !!sk.once;
      var kind = pvpApplyEffectBundle(player, opp, sk.fx || {}, logs, player.name + 'のスキル【' + (sk.name || '技能') + '】', b);
      if (kind && !sk.fx) logs.push('✨ ' + player.name + 'のスキル【' + (sk.name || '技能') + '】発動');
    });
    if (trigger === 'correct' && pvpHasUnit(player, 'ok_005')) player.michinagaStacks = (player.michinagaStacks || 0) + 1;
    if ((trigger === 'afterHit' || trigger === 'lowHpHit') && pvpHasUnit(player, 'ge_006') && !player._ge006Revived && player.hp > 0 && player.hp <= Math.floor(player.maxHp * 0.3)) {
      player._ge006Revived = true;
      var reviveHp = Math.floor(player.maxHp * 0.85);
      player.hp = Math.max(player.hp, reviveHp);
      logs.push('🌸 ' + player.name + 'は更衣の加護で復活した');
    }
    pvpRefreshCombatant(player);
  }
  function pvpAdvanceTurnEffects(players, logs, b) {
    (players || []).forEach(function (p) {
      if (!p || p.hp <= 0) return;
      if (p.dotTurns > 0 && p.dotPct > 0) {
        var d = Math.max(1, Math.floor(p.maxHp * p.dotPct));
        p.hp = Math.max(0, p.hp - d);
        p.dotTurns--;
        if (p.dotTurns <= 0) p.dotPct = 0;
        logs.push('☠️ ' + p.name + ' 継続ダメージ -' + d);
      }
      if (p.regenTurns > 0 && p.regenPct > 0) {
        var before = p.hp;
        pvpApplyHeal(p, p.regenPct, logs, p.name + 'の再生', b);
        p.regenTurns--;
        if (p.regenTurns <= 0) p.regenPct = 0;
      }
      ['buffAtk', 'def', 'all', 'buffSpecGain', 'dmgUp', 'atkDown', 'specSlow'].forEach(function (key) {
        var t = key + 'Turns', pct = key + 'Pct';
        if ((p[t] || 0) > 0) {
          p[t]--;
          if (p[t] <= 0) p[pct] = 0;
        }
      });
      pvpRefreshCombatant(p);
    });
  }

  function resetState() {
    try { if (P.state && P.state.pointBattle && P.state.pointBattle._timer) { clearInterval(P.state.pointBattle._timer); } } catch (e) {}
    P.state = {
      role: '',            // 'host' | 'guest'
      code: '',
      mySlot: 0,           // ホスト=0, ゲスト=1..5
      myName: getName(),
      peer: null,
      hostConn: null,      // ゲストが保持するホストへの接続（固定接続）
      tempConn: null,      // ゲスト入室直後の暫定接続（固定接続確立まで使用）
      guestConns: {},      // ホストが保持する {slot: conn}
      players: [],         // [{slot,name,isHost,peerId}]
      settings: defaultSettings(),
      myDeckIds: [],
      pendingChallenge: null,
      battle: null,
      pointBattle: null,
      spectatingMatchId: ''
    };
    P._roomCreated = false;
    P._welcomeReceived = false;
    try { P2P.reset(); } catch (e) {}
  }
  function myPlayer() {
    var s = P.state;
    return s.players.find ? s.players.find(function (p) { return p.slot === s.mySlot; }) : null;
  }
  function hostPlayer() {
    return P.state.players.find ? P.state.players.find(function (p) { return p.isHost; }) : null;
  }

  // ==================== メッセージ送信 ====================
  // ★16人対応: 全送信を HybridP2PManager 経由に切替（同一グループ=メッシュ直接 / 別グループ=リーダー経由リレー）
  // 接続未確立時は従来コネクション（guestConns / hostConn / tempConn）へフォールバックして安全性を維持
  function guestSend(obj) {
    try {
      if (P.state.role !== 'host') { if (P2P.sendTo(0, obj)) return true; }
      if (P.state.hostConn && P.state.hostConn.open) { P.state.hostConn.send(obj); return true; }
      if (P.state.tempConn && P.state.tempConn.open) { P.state.tempConn.send(obj); return true; }
    } catch (e) { jlog('guestSend err', e); }
    jlog('guestSend失敗（接続なし）', obj && obj.t);
    return false;
  }
  function hostSend(slot, obj) {
    try {
      if (P2P.sendTo(slot, obj)) return true;
      var c = P.state.guestConns[slot];
      if (c && c.open && P2P.conns[slot] !== c) { c.send(obj); return true; }
    } catch (e) { jlog('hostSend err', e); }
    return false;
  }
  function hostBroadcast(obj) {
    // 送信前に自分側のトポロジーを最新化（入退室・リーダー交代のたびに呼ばれる）
    try { P2P.syncTopology(); } catch (e) {}
    P2P.broadcast(obj);
    Object.keys(P.state.guestConns).forEach(function (slot) {
      var c = P.state.guestConns[slot];
      // メッシュ登録済みと同一コネクションなら二重送信しない
      if (c && c.open && P2P.conns[slot] !== c) { try { c.send(obj); } catch (e) {} }
    });
  }
  function playersPayload() {
    return { t: 'players', players: P.state.players, settings: P.state.settings, hostIsYou: true };
  }

  // ★修正: 重複入室バグ対策 — slot と peerId の両方をキーに「同一人物は1件だけ」に正規化する
  // join / join2 / iAmGuest / ホスト移譲など、プレイヤー追加経路が複数あるため
  // 「必ず upsert」する共通ヘルパーに統一し、既存エントリと衝突したら情報を上書きして新規 push しない。
  function upsertPlayer(slot, name, isHost, peerId) {
    var s = P.state;
    if (!s) return null;
    if (!s.players) s.players = [];
    slot = parseInt(slot, 10);
    if (isNaN(slot)) return null;
    // ① peerId が一致するエントリが既にあれば最優先で上書き（再接続＝同一人物とみなす）
    if (peerId) {
      for (var i = 0; i < s.players.length; i++) {
        if (s.players[i].peerId && s.players[i].peerId === peerId) {
          s.players[i].slot = slot;
          if (name) s.players[i].name = String(name).slice(0, 10);
          s.players[i].isHost = !!isHost;
          return s.players[i];
        }
      }
    }
    // ② 同じ slot のエントリが既にあれば上書き
    for (var j = 0; j < s.players.length; j++) {
      if (s.players[j].slot === slot) {
        if (name) s.players[j].name = String(name).slice(0, 10);
        if (peerId) s.players[j].peerId = peerId;
        s.players[j].isHost = !!isHost;
        return s.players[j];
      }
    }
    // ③ どちらもなければ新規追加
    var np = { slot: slot, name: (name ? String(name) : 'プレイヤー').slice(0, 10), isHost: !!isHost, peerId: peerId || null };
    s.players.push(np);
    return np;
  }
  // 念のための二重チェック: 配列内に peerId か slot が重複しているエントリがあれば 1 件にまとめる
  function dedupePlayersList() {
    var s = P.state;
    if (!s || !s.players) return;
    var seen = {};
    var out = [];
    // peerId を最優先キー、なければ slot をキーに最初に出現したものだけ残す
    s.players.forEach(function (p) {
      var key = p.peerId ? ('pid:' + p.peerId) : ('slot:' + p.slot);
      if (seen[key]) return; // 2件目以降は破棄
      seen[key] = true;
      out.push(p);
    });
    s.players = out;
  }


  // ==================== ポイント争奪戦（20分タイムリミット・自動1対1マッチング） ====================
  function isVisible(id) {
    var x = el(id);
    return !!(x && !x.classList.contains('hidden'));
  }
  var PB_DEFAULT_DURATION_SEC = 1200; // 既定の制限時間（20分＝1,200秒）ホストが任意に変更可
  var PB_DURATION_SEC = PB_DEFAULT_DURATION_SEC; // 現在の制限時間（ホスト入力で更新）
  var PB_MIN_DURATION_SEC = 180;   // 最低3分
  var PB_MAX_DURATION_SEC = 3600;  // 最大60分
  var PB_WIN_POINTS = 30;     // 勝利ポイント
  var PB_LOSE_POINTS = 10;    // 敗北ポイント
  var PB_MIN_PLAYERS = 3;     // 開始に必要な最低人数
  // ★争奪戦中は編成変更・保存・読み込みを全面ロック（ホスト・ゲスト問わず）

  function pbState() {
    var s = P.state;
    if (!s.pointBattle) {
      s.pointBattle = {
        active: false, suddenDeath: false, ended: false,
        startedAt: 0, remainSec: PB_DURATION_SEC,
        queue: [],        // [{slot, since}] since=待機開始時刻（古いほど優先）
        lastOpp: {},      // {slot: 直前の相手slot} 連続マッチング防止
        points: {},       // {slot: 所持ポイント}
        names: {},        // {slot: 表示名}（退出後も最終結果に残す）
        livePair: null,   // {a, b} 現在対戦中のペア
        ranking: null     // 終了時の最終ランキング（同点は同率順位）
      };
    }
    return s.pointBattle;
  }
  function pbIsActive() { return !!(P.state.pointBattle && P.state.pointBattle.active && !P.state.pointBattle.ended); }
  function pbSanitize(pb) {
    if (!pb) return null;
    // タイマーハンドル等の内部フィールド（_から始まるキー）を先に除去してから複製する
    var c = {};
    Object.keys(pb).forEach(function (k) { if (k.charAt(0) !== '_') c[k] = pb[k]; });
    try { return JSON.parse(JSON.stringify(c)); } catch (e) { return c; }
  }
  function broadcastPointBattleState() {
    if (P.state.role !== 'host') return;
    hostBroadcast({ t: 'pointBattleState', pb: pbSanitize(P.state.pointBattle) });
  }
  function pbRemainSec() {
    var pb = P.state.pointBattle;
    if (!pb || !pb.startedAt) return 0;
    var ds = pb.durationSec || PB_DURATION_SEC;
    return Math.max(0, ds - Math.floor((Date.now() - pb.startedAt) / 1000));
  }
  function pbPlayerName(slot) {
    var s = P.state;
    var q = s.players.find(function (p) { return p.slot === slot; });
    if (q) return q.name;
    var pb = s.pointBattle;
    return (pb && pb.names && pb.names[slot]) ? pb.names[slot] : ('プレイヤー' + slot);
  }
  // マッチング優先度: ①待機時間が最も長い ②待機時間が同じならポイントが低い方 ③それも同点ならランダム
  function pbSortedQueue() {
    var pb = pbState();
    return (pb.queue || []).slice().sort(function (a, b) {
      if (a.since !== b.since) return a.since - b.since;
      var pa = pb.points[a.slot] || 0, pbb = pb.points[b.slot] || 0;
      if (pa !== pbb) return pa - pbb;
      return Math.random() - 0.5;
    });
  }
  // ★ホストがポイントを争奪できる時間を分で指定するダイアログ（キャンセル＝既定値のまま開始）
  function pbPromptDurationMin() {
    try {
      var cur = Math.round(PB_DURATION_SEC / 60);
      var ans = window.prompt(
        'ポイント争奪戦の制限時間（分）を入力してください。\n' +
        '※範囲: ' + PB_MIN_DURATION_SEC / 60 + '分 〜 ' + PB_MAX_DURATION_SEC / 60 + '分（既定 ' + PB_DEFAULT_DURATION_SEC / 60 + '分）',
        String(cur)
      );
      if (ans == null) return PB_DURATION_SEC;
      var n = parseInt(String(ans).trim(), 10);
      if (isNaN(n) || n < PB_MIN_DURATION_SEC / 60 || n > PB_MAX_DURATION_SEC / 60) {
        // 既定値にフォールバックして静かに開始（エラーポップアップは出さない）
        return PB_DEFAULT_DURATION_SEC;
      }
      return n * 60;
    } catch (e) { return PB_DEFAULT_DURATION_SEC; }
  }
  // ★ホスト開始前に「現在の編成（getCombinedBattleDeckIds）」に基づく妥当性を全員分チェック
  // ★ホスト自席の編成フラグを実機の state から直接更新（askDeck の応答待ちに依存しない）
  function pbRefreshMyDeckFlag() {
    var s = P.state;
    var p = s.players.find(function (x) { return x.slot === 0; });
    if (!p) return;
    try {
      var ids = getCombinedBattleDeckIds();
      var v = pvpValidateDeck(ids, s.settings);
      _pbMarkDeckOk(0, v.ok && v.ids.length > 0, v.msg, v.ids || []);
    } catch (e) { _pbMarkDeckOk(0, false, '編成の確認中にエラー', []); }
  }
  // ★全員の編成を今すぐ取り直す（ロビーの定期更新と、開始失敗時の再取得に使用）
  //   ゲストの編成は askDeck→myDeck の往復でしか取得できないため、開始前に必ず取り直す。
  function pbRefreshAllDecks() {
    var s = P.state;
    if (s.role !== 'host') return;
    if (s.battle && s.battle.active) return;
    try { pbRefreshMyDeckFlag(); } catch (e) {}
    (s.players || []).forEach(function (p) {
      if (p.slot === 0) return;
      try { hostSend(p.slot, { t: 'askDeck', silent: true }); } catch (e) {}
    });
  }
  // ★ロビー滞在中はホストが全員の編成状態を定期的に取り直す（開始ボタンが無反応になるのを防ぐ）
  function pbArmLobbyDeckRefresh() {
    var s = P.state;
    var busy = !!(s.battle && s.battle.active);
    if (s.role !== 'host' || pbIsActive() || busy) {
      if (P._pbDeckRefreshTimer) { clearInterval(P._pbDeckRefreshTimer); P._pbDeckRefreshTimer = null; }
      return;
    }
    // 即時1回（3秒以内の連続呼び出しは間引いて通信のスパムを防ぐ）
    if (!P._pbDeckRefreshAt || Date.now() - P._pbDeckRefreshAt > 3000) {
      P._pbDeckRefreshAt = Date.now();
      try { pbRefreshAllDecks(); } catch (e) { jlog('pb deck refresh err', e); }
    }
    if (!P._pbDeckRefreshTimer) {
      P._pbDeckRefreshTimer = __PERF.keepAliveInterval(function () {
        var s2 = P.state;
        if (s2.role !== 'host' || pbIsActive() || (s2.battle && s2.battle.active)) {
          if (P._pbDeckRefreshTimer) { clearInterval(P._pbDeckRefreshTimer); P._pbDeckRefreshTimer = null; }
          return;
        }
        P._pbDeckRefreshAt = Date.now();
        try { pbRefreshAllDecks(); } catch (e) {}
      }, 5000);
    }
  }
  function pbCheckAllFormationsReady() {
    var s = P.state;
    // ★ホスト自席は実機の state を直接検証（askDeck の応答待ちには依存しない）
    //   ゲストはホスト側で保持するデッキ妥当性フラグを使用（未取得なら pbRefreshAllDecks で取り直す）
    var problems = [];
    s.players.forEach(function (p) {
      if (p.slot === 0) {
        try {
          var ids = getCombinedBattleDeckIds();
          var v = pvpValidateDeck(ids, s.settings);
          if (!v.ok) { problems.push({ slot: 0, name: p.name, msg: v.msg }); }
          else { _pbMarkDeckOk(0, true, '', v.ids || []); }
        } catch (e) { problems.push({ slot: 0, name: p.name, msg: '編成の確認中にエラー' }); }
      } else {
        if (!p._pbDeckOk) problems.push({ slot: p.slot, name: p.name, msg: p._pbDeckReason || '編成が未確認または不正' });
      }
    });
    return { ok: problems.length === 0, problems: problems };
  }
  // ★ゲストの askDeck→myDeck 応答を保存してホスト側の pbCheckAllFormationsReady で参照
  function _pbMarkDeckOk(slot, ok, reason, ids) {
    var s = P.state;
    var p = s.players.find(function (x) { return x.slot === slot; });
    if (!p) return;
    p._pbDeckOk = !!ok;
    p._pbDeckReason = reason || '';
    p._pbDeckIds = ids || [];
  }
  function startPointBattle() {
    var s = P.state;
    if (s.role !== 'host') return;
    if (s.battle && s.battle.active) { /* 静かに無視（トーストなし） */ return; }
    if ((s.players || []).length < PB_MIN_PLAYERS) { /* 静かに無視（人数不足はボタン自体が無効） */ return; }
    // ★開始前の全員編成バリデーション — 不備者がいる場合は理由だけを静かに記録して中断
    // ★開始前の全員編成バリデーション
    //   ゲストの編成は askDeck→myDeck の往復で取得するため、未取得のまま開始すると必ず失敗してボタンが無反応になる。
    //   ここでは自動で全員へ askDeck を送り、応答を待ってからもう一度だけ判定する。
    var chk = pbCheckAllFormationsReady();
    if (!chk.ok) {
      try { console.log('[PVP] point battle formation not ready -> refetch', chk.problems); } catch (e) {}
      pbRefreshAllDecks();
      if (!s._pbStartRetry) {
        s._pbStartRetry = true;
        setTimeout(function () { try { startPointBattle(); } catch (e) { jlog('pb start retry err', e); } }, 1300);
        return;
      }
      s._pbStartRetry = false;
      var _pbn = chk.problems.map(function (p) { return p.name; }).join('、');
      pvpToast('ポイント争奪戦を開始できません', '編成を確認できませんでした（不備: ' + _pbn + '）。数秒待ってからもう一度お試しください。');
      return;
    }
    s._pbStartRetry = false;
    // ★ホストが時間（分）を決める。空入力や範囲外は既定値20分。
    PB_DURATION_SEC = pbPromptDurationMin();
    // ゲストへ新しい制限時間を通知（ホスト側の時計と完全に同期させるための基準値）
    var pb = pbState();
    pb.durationSec = PB_DURATION_SEC;
    pb.active = true; pb.suddenDeath = false; pb.ended = false;
    pb.startedAt = Date.now(); pb.remainSec = PB_DURATION_SEC;
    pb.points = {}; pb.names = {}; pb.queue = []; pb.lastOpp = {}; pb.livePair = null; pb.ranking = null;
    s.players.forEach(function (p) {
      pb.points[p.slot] = 0;
      pb.names[p.slot] = p.name;
      pb.queue.push({ slot: p.slot, since: Date.now() });
    });
    if (pb._timer) { clearInterval(pb._timer); }
    pb._timer = __PERF.keepAliveInterval(function () { try { pbTick(); } catch (e) { jlog('pbTick err', e); } }, 1000);
    hostBroadcast({ t: 'pointBattleStart', durationSec: PB_DURATION_SEC, startedAt: pb.startedAt });
    broadcastPointBattleState();
    renderLobby();
    // ★トースト（黄色枠のポップアップ）は表示しない
    pbMatchNext();
  }
  function stopPointBattle() {
    if (P.state.role !== 'host') return;
    var pb = pbState();
    if (!pb.active || pb.ended) return;
    pbEnd();
  }
  // 1秒ごとの共通タイマー処理（ホスト権威）
  function pbTick() {
    var s = P.state, pb = s.pointBattle;
    if (!pb || !pb.active || pb.ended) {
      if (pb && pb._timer) { clearInterval(pb._timer); pb._timer = null; }
      return;
    }
    pb.remainSec = pbRemainSec();
    if (pb.remainSec <= 0 && !pb.suddenDeath) { pbForceSuddenDeath(); }
    // ★時間切れ時に試合が進行していないと、サドンデス待ちのまま集計されないため必ず終了判定する
    if (pb.suddenDeath) { try { pbCheckEnd(); } catch (e) { jlog('pbCheckEnd err', e); } }
  }
  // 20分到達: 全員へサドンデス開始通知 ／ 対戦中の部屋には既存サドンデス処理を即時適用
  function pbForceSuddenDeath() {
    var s = P.state, pb = pbState();
    if (!pb.active || pb.ended || pb.suddenDeath) return;
    pb.suddenDeath = true;
    pb.queue = []; // サドンデス後は新規マッチングせず、残試合の決着のみ待つ
    hostBroadcast({ t: 'pointBattleSuddenDeath', at: Date.now() });
    pvpToast('サドンデス開始', '20分経過！対戦中の部屋に既存サドンデス処理を適用して決着を促します。');
    var b = s.battle;
    if (b && b.active) {
      b._sdAllowed = true;
      b._forceSDAt = Date.now();
    }
    broadcastPointBattleState();
    renderLobby();
    // ★保険: 対戦中の試合が無い／決着済みでも必ず最終集計へ到達させる
    setTimeout(function () { try { pbCheckEnd(); } catch (e) {} }, 1500);
  }
  // 自動1対1マッチング（既存エンジンは1試合ずつのため順次実行・待機時間が優先度に反映される）
  function pbMatchNext() {
    var s = P.state, pb = pbState();
    if (!pb.active || pb.ended || pb.suddenDeath) return;
    if (s.battle && s.battle.active) return;
    if (pb._coolUntil && Date.now() < pb._coolUntil) return;
    // 退出者をキューから除去
    pb.queue = (pb.queue || []).filter(function (q) { return s.players.some(function (p) { return p.slot === q.slot; }); });
    while (pb.queue.length >= 2 && !(s.battle && s.battle.active)) {
      var sorted = pbSortedQueue();
      var a = sorted[0];
      // 直前に戦った相手とは連続でマッチング不可（候補が他にいれば避ける・枯渇時は許容）
      var lastA = pb.lastOpp ? pb.lastOpp[a.slot] : undefined;
      var bCand = null;
      for (var k = 1; k < sorted.length; k++) { if (sorted[k].slot !== lastA) { bCand = sorted[k]; break; } }
      if (!bCand) bCand = sorted[1];
      pb.queue = pb.queue.filter(function (q) { return q.slot !== a.slot && q.slot !== bCand.slot; });
      pb.lastOpp[a.slot] = bCand.slot;
      pb.lastOpp[bCand.slot] = a.slot;
      pbStartMatch(a.slot, bCand.slot);
      break;
    }
    broadcastPointBattleState();
  }
  function pbStartMatch(slotA, slotB) {
    var s = P.state, pb = pbState();
    pb.livePair = { a: slotA, b: slotB };
    s.pendingBattle = { a: slotA, b: slotB, decks: {}, pointMode: true };
    s._deckRetryCount = 0; // ★試合ごとにリトライ回数をリセット
    if (slotA === 0) hostHandleData(0, { t: 'askDeck' }); else hostSend(slotA, { t: 'askDeck' });
    if (slotB === 0) hostHandleData(0, { t: 'askDeck' }); else hostSend(slotB, { t: 'askDeck' });
    hostArmDeckWait();
    broadcastPointBattleState();
    renderLobby();
  }
  // 編成送信失敗・キャンセル時: ペアをキューへ戻す（ポイント保持）
  function pbCancelCurrentMatch() {
    var s = P.state, pb = s.pointBattle;
    if (!pb || !pb.livePair) return;
    var now = Date.now();
    [pb.livePair.a, pb.livePair.b].forEach(function (sl) {
      if (s.players.some(function (p) { return p.slot === sl; }) && !pb.queue.some(function (q) { return q.slot === sl; })) {
        pb.queue.push({ slot: sl, since: now });
      }
    });
    pb.livePair = null;
    pb._coolUntil = now + 5000; // 連続失敗の急速ループ防止
    broadcastPointBattleState();
    setTimeout(function () { try { pbMatchNext(); } catch (e) {} }, 6000);
  }
  // 対戦決着: ポイント付与（勝利+30/敗北+10）→ 両者を待機キューへ戻して次のマッチング
  function pbFinishCurrentMatch(winnerSlot, reason) {
    var s = P.state, pb = pbState();
    if (!pb.livePair) return;
    var a = pb.livePair.a, b = pb.livePair.b;
    pb.livePair = null;
    if (winnerSlot != null) {
      var loserSlot = (winnerSlot === a) ? b : a;
      pb.points[a] = (pb.points[a] || 0) + ((winnerSlot === a) ? PB_WIN_POINTS : PB_LOSE_POINTS);
      pb.points[b] = (pb.points[b] || 0) + ((winnerSlot === b) ? PB_WIN_POINTS : PB_LOSE_POINTS);
    } else {
      // 相打ち（仕様外）: 両者を敗北扱い（+10）として処理
      pb.points[a] = (pb.points[a] || 0) + PB_LOSE_POINTS;
      pb.points[b] = (pb.points[b] || 0) + PB_LOSE_POINTS;
    }
    var now = Date.now();
    [a, b].forEach(function (sl) {
      pb.names[sl] = pbPlayerName(sl);
      if (s.players.some(function (p) { return p.slot === sl; })) pb.queue.push({ slot: sl, since: now });
    });
    broadcastPointBattleState();
    pbCheckEnd();
    // ★呼び出し元の hostEndBattle はこの直後に s.battle / s.pendingBattle を初期化するため、
    //   同期で pbMatchNext() を呼ぶと新しい試合の pendingBattle が消され、2試合目以降が始まらない。
    if (pb.active && !pb.ended) {
      setTimeout(function () { try { pbMatchNext(); } catch (e) { jlog('pb match next err', e); } }, 400);
    }
  }
  // 切断処理: 対戦中ならhostEndBattle経由で不戦勝（ 既存flow）/ 待機中ならキューから除去（ポイントは保持）
  function pbHandleDisconnect(slot) {
    var s = P.state, pb = pbState();
    if (s.battle && s.battle.active && (slot === s.battle.a || slot === s.battle.b)) {
      // hostRemoveGuest の既存flowが hostEndBattle を呼び、pbFinishCurrentMatch でポイント付与される
      return;
    }
    pb.queue = (pb.queue || []).filter(function (q) { return q.slot !== slot; });
    broadcastPointBattleState();
  }
  // 途中再接続（リカバリー）: ポイントを保持したまま待機キューへ復帰
  function pbRejoin(slot) {
    var s = P.state, pb = pbState();
    if (!pb.active || pb.ended) return;
    if (pb.points[slot] === undefined) pb.points[slot] = 0;
    pb.names[slot] = pbPlayerName(slot);
    if (!pb.queue.some(function (q) { return q.slot === slot; })) {
      pb.queue.push({ slot: slot, since: Date.now() });
    }
    broadcastPointBattleState();
  }
  // サドンデス後に全試合が決着したら最終集計へ
  function pbCheckEnd() {
    var s = P.state, pb = pbState();
    if (!pb.active || pb.ended || !pb.suddenDeath) return;
    if (s.battle && s.battle.active) return;
    pbEnd();
  }
  // 最終ポイント集計（同点は同率順位）
  function pbEnd() {
    var s = P.state, pb = pbState();
    if (!pb.active || pb.ended) return;
    pb.ended = true; pb.active = false;
    if (pb._timer) { clearInterval(pb._timer); pb._timer = null; }
    var entries = Object.keys(pb.points).map(function (k) { return parseInt(k, 10); });
    entries.sort(function (x, y) { return (pb.points[y] || 0) - (pb.points[x] || 0); });
    var ranking = []; var lastPts = null, lastRank = 0;
    entries.forEach(function (sl, i) {
      var pt = pb.points[sl] || 0;
      var rank = (pt === lastPts) ? lastRank : (i + 1); // 同点は同率順位（同率1位など）
      lastPts = pt; lastRank = rank;
      ranking.push({ slot: sl, name: pbPlayerName(sl), points: pt, rank: rank });
    });
    pb.ranking = ranking;
    hostBroadcast({ t: 'pointBattleEnd', pb: pbSanitize(pb) });
    pvpToast('ポイント争奪戦 終了', '20分間のポイント争奪戦が終了しました。最終結果を集計します。');
    renderLobby();
  }
  // ロビーの残り時間表示（1秒ごとにローカル計算で更新）
  function pbArmLobbyTimer() {
    if (P._pbLobbyTimer) { clearInterval(P._pbLobbyTimer); P._pbLobbyTimer = null; }
    if (!pbIsActive()) return;
    P._pbLobbyTimer = __PERF.keepAliveInterval(function () {
      var t2 = document.getElementById('pbRemainText');
      if (!t2) { if (P._pbLobbyTimer) { clearInterval(P._pbLobbyTimer); P._pbLobbyTimer = null; } return; }
      var r = pbRemainSec();
      if (r > 0) {
        var mm = Math.floor(r / 60), ss = r % 60;
        t2.textContent = mm + ':' + ('0' + ss).slice(-2);
      } else {
        t2.innerHTML = '<span class="text-red-400 font-black">サドンデス</span>';
      }
    }, 1000);
  }
  // ロビー下部のポイント争奪戦パネル
  function pbLobbyHtml() {
    var s = P.state, pb = s.pointBattle;
    if (!pb) return '';
    if (pb.active) {
      var r = pbRemainSec();
      var myPts = (pb.points && pb.points[s.mySlot] !== undefined) ? pb.points[s.mySlot] : 0;
      var qCount = (pb.queue || []).length;
      var liveTxt = '';
      if (pb.livePair) {
        liveTxt = '<div class="text-[11px] text-red-300 font-bold mt-1">⚔ 対戦中: ' + esc(pbPlayerName(pb.livePair.a)) + ' vs ' + esc(pbPlayerName(pb.livePair.b)) + '</div>';
      } else if (!pb.suddenDeath) {
        liveTxt = '<div class="text-[11px] text-gray-400 mt-1">自動マッチング: 待機時間が長い順に1対1を組みます（直前の相手とは連続で組みません）</div>';
      }
      var sdTxt = pb.suddenDeath ? '<span class="bg-red-900/60 border border-red-500/50 rounded px-2 py-1 text-red-300 font-black">☠ サドンデス進行中</span>' : '';
      var stopBtn = (s.role === 'host') ? '<button onclick="PVPROOT.stopPointBattle()" class="bg-gray-700 hover:bg-gray-600 text-gray-200 text-[11px] font-bold px-3 py-1.5 rounded-lg">モードを終了して集計</button>' : '';
      return '<div class="bg-purple-950/60 border-2 border-purple-500/50 rounded-2xl p-4 shadow-xl mt-4">' +
        '<div class="flex flex-wrap items-center justify-between gap-2">' +
          '<div><div class="font-mincho text-base font-bold text-purple-200"><i class="fa-solid fa-stopwatch mr-1.5"></i>ポイント争奪戦（20分タイムリミット）</div>' +
          '<div class="text-[11px] text-gray-400 mt-0.5">勝利 +30pt ／ 敗北 +10pt</div></div>' +
          '<div class="text-right"><div class="text-[10px] text-gray-400">残り時間</div><div id="pbRemainText" class="font-mono text-2xl font-black text-amber-200">' + Math.floor(r / 60) + ':' + ('0' + (r % 60)).slice(-2) + '</div></div>' +
        '</div>' +
        '<div class="mt-2 flex flex-wrap items-center gap-2 text-xs">' +
          '<span class="bg-black/50 border border-heian-gold/30 rounded px-2 py-1 text-amber-200 font-bold">あなたのポイント: ' + myPts + 'pt</span>' +
          '<span class="bg-black/50 border border-heian-gold/30 rounded px-2 py-1 text-gray-200">待機 ' + qCount + '人</span>' + sdTxt + '</div>' +
        liveTxt +
        '<div class="mt-2">' + stopBtn + '</div>' +
      '</div>';
    }
    if (pb.ended && pb.ranking) {
      var rows = pb.ranking.map(function (e) {
        return '<div class="flex items-center justify-between bg-black/40 border border-heian-gold/20 rounded-lg px-3 py-1.5 text-xs">' +
          '<span class="text-yellow-100 font-bold">' + e.rank + '位: ' + esc(e.name) + '</span>' +
          '<span class="font-mono text-amber-300 font-bold">' + e.points + 'pt</span></div>';
      }).join('');
      var againBtn = (s.role === 'host') ? '<button onclick="PVPROOT.startPointBattle()" class="gold-button text-[11px] px-3 py-1.5 rounded-lg font-bold shadow">もう一度開始</button>' : '';
      return '<div class="bg-purple-950/60 border-2 border-purple-500/50 rounded-2xl p-4 shadow-xl mt-4">' +
        '<div class="font-mincho text-base font-bold text-purple-200 mb-2"><i class="fa-solid fa-ranking-star mr-1.5"></i>ポイント争奪戦 最終結果（同点は同率順位）</div>' + rows +
        '<div class="mt-2 text-[11px] text-gray-400">獲得ポイント: 勝利 +30 ／ 敗北 +10</div>' +
        '<div class="mt-2">' + againBtn + '</div></div>';
    }
    if (s.role === 'host') {
      var can = s.players.length >= PB_MIN_PLAYERS;
      return '<div class="bg-black/30 border border-heian-gold/20 rounded-xl p-4"><div class="flex flex-wrap items-center justify-between gap-3"><div>' +
        '<div class="font-mincho text-base font-bold text-amber-200"><i class="fa-solid fa-stopwatch mr-1.5"></i>ポイント争奪戦モード</div>' +
        '<div class="text-xs text-gray-400 mt-1">20分間のタイムリミット内にポイントを稼ぐモードです。<b>3人以上</b>で開始できます。開始すると自動で1対1のマッチングを繰り返し、勝利+30pt・敗北+10ptを蓄積。20分経過時に対戦中の試合には既存のサドンデス処理を即時適用して強制決着します。対戦中の切断は不戦勝扱い（勝者+30 / 切断者+10）、20分以内の再接続でポイント保持のまま復帰できます。</div>' +
        (function () {
          // ★全員の編成が完了しているかリアルタイム判定（不備者名を出してボタン無効化）
          var chk = { ok: true, problems: [] };
          try { chk = pbCheckAllFormationsReady(); } catch (e) {}
          if (!chk.ok) {
            var names = chk.problems.map(function (p) { return p.name; }).join('、');
            return '<div class="text-[11px] text-red-300 mt-1">全員の編成が完了していません（不備: ' + esc(names) + '）。</div>';
          }
          return (can ? '' : '<div class="text-[11px] text-red-300 mt-1">開始には3人以上の参加が必要です（現在' + s.players.length + '人）。</div>');
        })() +
        '</div>' +
        '<button ' + (can ? 'onclick="PVPROOT.startPointBattle()"' : 'disabled') + ' class="' + (can ? 'gold-button' : 'bg-gray-800 text-gray-500 opacity-50 cursor-not-allowed') + ' px-4 py-2 rounded-lg text-sm font-extrabold shadow">ポイント争奪戦を開始</button>' +
        '</div></div>';
    }
    return '<div class="bg-black/30 border border-heian-gold/20 rounded-xl p-4 text-xs text-gray-400">ホストがポイント争奪戦を開始すると、20分間のポイント獲得競争が始まります。</div>';
  }
  // 参加者判定
  function b_isPlayer() {
    try {
      var s = P.state, b = s.battle;
      return !!(b && b.active && b.slotA === s.mySlot);
    } catch (e) { return false; }
  }
  function spectateBattle() {
    var s = P.state;
    if (!s.battle || !s.battle.active) { pvpToast('観戦不可', '現在進行中の試合がありません。'); return; }
    renderDuel();
  }
  function closeSpectateView() {
    if (P.state && P.state.pointBattle && P.state.pointBattle.active) renderLobby();
    else renderHome();
  }

  // ==================== ホスト処理 ====================
  function hostHandleData(slot, d) {
    if (!d || !d.t) return;
    jlog('hostHandleData', 'slot=' + slot, d.t);
    var s = P.state;
    if (d.t === 'join') {
      if (Object.keys(s.guestConns).length >= MAX_ROOM - 1) {
        try { if (P._lastConn) { P._lastConn.send({ t: 'err', msg: '部屋は満員です（最大' + MAX_ROOM + '人）。' }); P._lastConn.close(); } } catch (e) {}
        return;
      }
      var used = {};
      s.players.forEach(function (p) { used[p.slot] = true; });
      var goto = 1;
      while (used[goto]) goto++;
      s.guestConns[goto] = P._lastConn;
      var myId = 'tk315pvp-' + s.code.toLowerCase() + '-g' + pad(goto);
      upsertPlayer(goto, String(d.name || 'プレイヤー').slice(0, 10), false, myId);
      dedupePlayersList();
      try { pbRejoin(goto); } catch (e) {}
      try { P._lastConn.send({ t: 'welcome', slot: goto, code: s.code, settings: s.settings, players: s.players.map(function(p){return {slot:p.slot,name:p.name,isHost:!!p.isHost};}), myPeerId: myId }); } catch (e) {}
      hostBroadcast(playersPayload());
      return;
    }
    if (d.t === 'join2') {
      var sl = parseInt(d.slot, 10);
      if (isNaN(sl) || sl < 1 || sl >= MAX_ROOM) return;
      try {
        var old = s.guestConns[sl];
        if (old && old !== P._lastConn) { try { old.close(); } catch (e) {} }
      } catch (e) {}
      s.guestConns[sl] = P._lastConn;
      var exJoin = s.players.find(function (p) { return p.slot === sl; });
      if (exJoin) { exJoin.name = String(d.name || 'プレイヤー').slice(0, 10); exJoin.peerId = 'tk315pvp-' + s.code.toLowerCase() + '-g' + pad(sl); }
      else { upsertPlayer(sl, String(d.name || 'プレイヤー').slice(0, 10), false, 'tk315pvp-' + s.code.toLowerCase() + '-g' + pad(sl)); }
      dedupePlayersList();
      try { pbRejoin(sl); } catch (e) {}
      hostBroadcast(playersPayload());
      return;
    }
    if (d.t === 'askDeck') {
      jlog('askDeck', 'slot=' + slot);
      if (slot !== 0) return;
      var ids = [];
      try { ids = getCombinedBattleDeckIds(); } catch (e) {}
      var lv = {};
      try { lv = state.unitLevels || {}; } catch (e) {}
      var nlv = 1;
      try { nlv = state.noble ? state.noble.level : 1; } catch (e) {}
      var v = pvpValidateDeck(ids, s.settings);
      if (!v.ok) { hostBattleCancel('あなたの編成が制限に違反しています: ' + v.msg); return; }
      if (!s.pendingBattle) s.pendingBattle = { decks: {} };
      s.pendingBattle.decks[0] = { deckIds: v.ids, levels: lv, nobleLevel: nlv, titles: pvpTitleCount() };
      // ★ホスト自身の編成妥当性も記録
      _pbMarkDeckOk(0, v.ok && v.ids.length > 0, v.msg, v.ids);
      hostTryStartBattle();
      return;
    }
    if (d.t === 'myDeck') {
      // ★ロビーでの編成取り直し（askDeck）への応答は、対戦準備中（a/b 確定）でなければ
      //   戦闘デッキに書き込まない（存在しない試合のデッキを捺造して誤開始しないため）。
      var _pbReady = !!(s.pendingBattle && s.pendingBattle.a !== undefined && s.pendingBattle.a !== null && s.pendingBattle.b !== undefined && s.pendingBattle.b !== null);
      var _myIds = d.deckIds || [];
      if (_pbReady) {
        if (!s.pendingBattle.decks) s.pendingBattle.decks = {};
        s.pendingBattle.decks[slot] = { deckIds: _myIds, levels: d.levels || {}, nobleLevel: d.nobleLevel || 1, titles: Math.max(0, Math.floor(Number(d.titles) || 0)) };
      }
      // ★相手の編成妥当性を記録（ポイント争奪戦開始前の全員チェックで使用）
      var v2 = pvpValidateDeck(_myIds, s.settings);
      _pbMarkDeckOk(slot, v2.ok && _myIds.length > 0, v2.msg, _myIds);
      if (_pbReady) hostTryStartBattle();
      return;
    }
    if (d.t === 'challenge') {
      var target = parseInt(d.targetSlot, 10);
      if (isNaN(target) || target === slot) return;
      var fromP = s.players.find(function (p) { return p.slot === slot; });
      if (!fromP) return;
      var toP = s.players.find(function (p) { return p.slot === target; });
      if (!toP) return;
      if (pbIsActive()) { hostSend(slot, { t: 'err', msg: 'ポイント争奪戦進行中は手動の1対1申込はできません。' }); return; }
      if (s.battle && s.battle.active) { hostSend(slot, { t: 'err', msg: '対戦中のため申し込みできません。' }); return; }
      s.pendingChallenge = { fromSlot: slot, toSlot: target, fromName: fromP.name };
      // ★修正: 相手がホスト自身(slot0)の場合、hostSend(0)はゲスト接続にしか届かないため画面へ直接表示する
      if (target === 0) { renderLobby(); } else { hostSend(target, { t: 'challengeFrom', fromSlot: slot, fromName: fromP.name }); }
      return;
    }
    if (d.t === 'challengeReply') {
      if (!s.pendingChallenge) return;
      var pc = s.pendingChallenge;
      if (slot !== pc.toSlot) return;
      s.pendingChallenge = null;
      if (d.accept) {
        var toName = (function(){ var q = s.players.find(function(p){return p.slot===pc.toSlot;}); return q ? q.name : '相手'; })();
        if (pc.fromSlot !== 0) hostSend(pc.fromSlot, { t: 'challengeAccepted', toSlot: pc.toSlot, toName: toName });
        s.pendingBattle = { a: pc.fromSlot, b: pc.toSlot, decks: {} };
        // ★修正: ホスト自身(0)が対戦者なら askDeck を直接処理（hostSend(0) では自分に届かない）
        if (pc.fromSlot === 0) hostHandleData(0, { t: 'askDeck' }); else hostSend(pc.fromSlot, { t: 'askDeck' });
        if (pc.toSlot === 0) hostHandleData(0, { t: 'askDeck' }); else hostSend(pc.toSlot, { t: 'askDeck' });
        // ★修正: 編成送信のタイムアウト監視を開始（応答が無ければ askDeck を再送）
        hostArmDeckWait();
      } else {
        hostSend(pc.fromSlot, { t: 'challengeDeclined', toSlot: pc.toSlot });
      }
      return;
    }
    if (d.t === 'surrender') {
      var ls2 = parseInt(slot, 10);
      var ws2 = (s.battle && s.battle.active && (s.battle.a === ls2 || s.battle.b === ls2)) ? ((s.battle.a === ls2) ? s.battle.b : s.battle.a) : null;
      if (ws2 !== null) {
        var wn2 = (s.players.find(function (x) { return x.slot === ws2; }) || {}).name || '相手';
        hostEndBattle(ws2, wn2, '相手が降参しました');
      }
      return;
    }
    if (d.t === 'reqQuiz') {
      // ★修正: ゲスト側のタイムアウト再試行要求 → 未配信クイズがあれば再送
      jlog('reqQuiz', 'slot=' + slot);
      var rb = s.battle;
      if (rb && rb.active && (slot === rb.a || slot === rb.b)) {
        var qm = rb.questionMap && rb.questionMap[slot];
        if (qm) {
          hostSend(slot, { t: 'quiz', targetSlot: slot, qnum: qm.qnum, word: qm.word, kogo: qm.kogo, choices: qm.choices || [] });
        } else {
          hostSendQuizToSlot(slot, 0);
        }
      }
      return;
    }
    if (d.t === 'answer') {
      if (s.battle && s.battle.active) {
        hostResolveAnswer(slot, (d.idx === undefined || d.idx === null) ? null : parseInt(d.idx, 10));
      }
      return;
    }
    if (d.t === 'surrender') {
      if (s.battle && s.battle.active) {
        var winnerSlot = (slot === s.battle.a) ? s.battle.b : s.battle.a;
        hostEndBattle(winnerSlot, s.battle.players[0].slot === winnerSlot ? s.battle.players[0].name : s.battle.players[1].name, '相手が降参しました');
      }
      return;
    }
    if (d.t === 'special') {
      if (s.battle && s.battle.active) {
        hostApplySpecial(slot, parseInt(d.unitIdx, 10));
      }
      return;
    }
    if (d.t === 'leave') {
      hostRemoveGuest(slot, true);
      return;
    }
    if (d.t === 'rename') {
      var rp = s.players.find(function (x) { return x.slot === slot; });
      if (rp) { rp.name = String(d.name || 'プレイヤー').slice(0, 10) || 'プレイヤー'; hostBroadcast(playersPayload()); }
      return;
    }
    if (d.t === 'rematch') {
      var wantSlot = parseInt(d.targetSlot, 10);
      if (s.battle && s.battle.active) return;
      if (pbIsActive()) { hostSend(slot, { t: 'err', msg: 'ポイント争奪戦進行中は再戦申込はできません。' }); return; }
      var a2 = slot, b2 = wantSlot;
      if (isNaN(b2)) return;
      s.pendingBattle = { a: a2, b: b2, decks: {} };
      // ★修正: a2 がホスト自身(0)の場合も askDeck を直接処理する
      if (a2 === 0) hostHandleData(0, { t: 'askDeck' }); else hostSend(a2, { t: 'askDeck' });
      if (b2 === 0) hostHandleData(0, { t: 'askDeck' }); else hostSend(b2, { t: 'askDeck' });
      // ★修正: 編成送信のタイムアウト監視を開始
      hostArmDeckWait();
      return;
    }
  }

  function hostRemoveGuest(slot, notify) {
    var s = P.state;
    try { P2P.syncTopology(); } catch (e) {} // ★16人対応: 退出前の構成を最新化
    var p = s.players.find(function (x) { return x.slot === slot; });
    if (p) {
      s.players = s.players.filter(function (x) { return x.slot !== slot; });
      if (s.battle && s.battle.active && (slot === s.battle.a || slot === s.battle.b)) {
        var wslot = (slot === s.battle.a) ? s.battle.b : s.battle.a;
        var wname = s.players.find(function (x) { return x.slot === wslot; });
        hostEndBattle(wslot, wname ? wname.name : '相手', '対戦相手が退室しました');
      }
    }
    try { delete s.guestConns[slot]; } catch (e) {}
      if (s.pendingChallenge) {
        if (s.pendingChallenge.fromSlot === slot || s.pendingChallenge.toSlot === slot) s.pendingChallenge = null;
      }
      if (pbIsActive()) {
        try { pbHandleDisconnect(slot); } catch (e) { jlog('pointBattle disconnect err', e); }
      }
      if (notify !== false) hostBroadcast(playersPayload());
      try { renderLobby(); } catch (e) {}
    }

  // ★修正: 編成送信(askDeck→myDeck)のタイムアウト監視。応答が無ければaskDeckを再送し、上限を超えたら安全にロビーへ戻す
  function hostArmDeckWait() {
    var s = P.state;
    if (s._deckWaitTimer) { clearTimeout(s._deckWaitTimer); s._deckWaitTimer = null; }
    s._deckWaitTimer = pvpSetTimer(function () {
      var s2 = P.state;
      if (s2._deckWaitTimer) { clearTimeout(s2._deckWaitTimer); s2._deckWaitTimer = null; }
      var pb = s2.pendingBattle;
      if (!pb) return;
      if (s2.battle && s2.battle.active) return; // 対戦開始済みなら何もしない
      var missing = [];
      if (pb.a === undefined || pb.a === null || !(pb.decks && pb.decks[pb.a])) missing.push(pb.a);
      if (pb.b === undefined || pb.b === null || !(pb.decks && pb.decks[pb.b])) missing.push(pb.b);
      missing = missing.filter(function (sl) { return sl === 0 || s2.players.some(function (p) { return p.slot === sl; }); });
      // ★修正: 双方の編成が届いているなら何もしない（通常経路の hostTryStartBattle が既に処理済みのため、重複開始を防ぐ）
      if (!missing.length) { return; }
      s2._deckRetryCount = (s2._deckRetryCount || 0) + 1;
      if (s2._deckRetryCount > MAX_ASK_DECK_RETRY) {
        jlog('編成取得タイムアウト', missing);
        s2.pendingBattle = null;
        pvpToast('対戦開始に失敗', '相手の編成送信がタイムアウトしました。もう一度対戦を申し込んでください。');
        pvpSafeBackToLobby();
        return;
      }
      missing.forEach(function (sl) {
        jlog('askDeckリトライ', 'slot=' + sl, 'retry=' + s2._deckRetryCount);
        if (sl === 0) hostHandleData(0, { t: 'askDeck' });
        else hostSend(sl, { t: 'askDeck' });
      });
      hostArmDeckWait();
    }, ASK_DECK_INTERVAL);
  }

  function hostTryStartBattle() {
    var s = P.state;
    if (s.battle && s.battle.active) return; // ★対戦中の重複開始を防止（進行中の試合を上書きしない）
    var pb = s.pendingBattle;
    if (!pb || !pb.decks || !pb.decks[pb.a] || !pb.decks[pb.b]) return;
    var decA = pb.decks[pb.a], decB = pb.decks[pb.b];
    var va = pvpValidateDeck(decA.deckIds, s.settings);
    var vb = pvpValidateDeck(decB.deckIds, s.settings);
    if (!va.ok) { hostBattleCancel('「' + (function(){ var q=s.players.find(function(x){return x.slot===pb.a;}); return q?q.name:'A'; })() + '」の編成が制限に違反しています: ' + va.msg); return; }
    if (!vb.ok) { hostBattleCancel('「' + (function(){ var q=s.players.find(function(x){return x.slot===pb.b;}); return q?q.name:'B'; })() + '」の編成が制限に違反しています: ' + vb.msg); return; }
    var pa = pvpBuildParty(va.ids, decA.levels, decA.nobleLevel, s.settings);
    var pb2 = pvpBuildParty(vb.ids, decB.levels, decB.nobleLevel, s.settings);
    if (!pa.length || !pb2.length) { hostBattleCancel('どちらかの編成が空です。'); return; }
    var nameA = (function(){ var q = s.players.find(function(x){return x.slot===pb.a;}); return q?q.name:'A'; })();
    var nameB = (function(){ var q = s.players.find(function(x){return x.slot===pb.b;}); return q?q.name:'B'; })();
    var pA = pvpSyncCombatant({ slot: pb.a, name: nameA, deckIds: va.ids.slice(), party: pa, totalAtk: pvpPartyTotalAtk(pa), hp: pvpPartyTotalHp(pa), maxHp: pvpPartyTotalHp(pa), combo: 0, synCount: pvpSynCount(va.ids) });
    var pB = pvpSyncCombatant({ slot: pb.b, name: nameB, deckIds: vb.ids.slice(), party: pb2, totalAtk: pvpPartyTotalAtk(pb2), hp: pvpPartyTotalHp(pb2), maxHp: pvpPartyTotalHp(pb2), combo: 0, synCount: pvpSynCount(vb.ids) });
    // ★ 称号システム: 各プレイヤーの称号保持数（結果計算に使用）
    if (pb.a === 0) pA.titles = pvpTitleCount();
    else pA.titles = Math.max(0, Math.floor(Number((pb.decks && pb.decks[pb.a] && pb.decks[pb.a].titles)) || 0));
    pB.titles = Math.max(0, Math.floor(Number((pb.decks && pb.decks[pb.b] && pb.decks[pb.b].titles)) || 0));
    s.battle = {
      active: true, state: 'await', a: pb.a, b: pb.b,
      players: [pA, pB], answers: {}, qnum: 0,
      quizTimer: null,
      hazards: {},
      logs: [],
      settings: JSON.parse(JSON.stringify(s.settings)),
      questionMap: {},
      qNums: {},
      totalAnswers: 0,
      startedAt: null,
      correctBySlot: {},
      official: !!s.settings.official,
      _slotMode: true,
      _quizRetry: {},
      isAlive: { 0: true, 1: true },
      matchStatus: 'pending',
      timeRemaining: 9999,
      _countdownDone: false,
      _acceptAnswer: false,
      _sdAllowed: false,
      _winnerDeclared: false
    };
    s.battle.hazards[pb.a] = { monMult: 1, monQ: 0, tueBonus: 0, tueQ: 0, wedDelta: 0, wedQ: 0 };
    s.battle.hazards[pb.b] = { monMult: 1, monQ: 0, tueBonus: 0, tueQ: 0, wedDelta: 0, wedQ: 0 };
    var payload = {
      t: 'battleStart', a: pb.a, b: pb.b,
      players: [
        { slot: pb.a, name: nameA, party: pa, maxHp: pA.maxHp, synText: pA.synCount, titles: pA.titles },
        { slot: pb.b, name: nameB, party: pb2, maxHp: pB.maxHp, synText: pB.synCount, titles: pB.titles }
      ],
      qnum: 0,
      startedAt: Date.now()
    };
    try {
      QUIZ_BALANCE_STATE.pvpNormal = { recentWords: [], recentGroups: [] };
      QUIZ_BALANCE_STATE.pvpKogo = { recentWords: [], recentGroups: [] };
    } catch (e) { }
    hostBroadcast(payload);
    // ★修正: s.battle は既に _slotMode/questionMap/qNums/hazards/_quizRetry/settings 等を
    // 完備した状態で構築済み。ここで新規オブジェクトで丸ごと上書きすると、直後の
    // hostSendQuizToSlot() 先頭の安全チェック (!b.questionMap || !b.qNums) で即 return され、
    // クイズが全く配信されず両者が「対戦準備中…」のまま固まる（12秒後に watchdog ダイアログが出る）。
    // 表示用フィールドは既存 s.battle に直接後付けするだけで十分。
    var hv = s.battle;
    hv.state = 'await';
    hv.mySlot = 0;
    hv.isPlayer = (pb.a === 0 || pb.b === 0);
    hv.you = (pb.a === 0) ? 0 : 1;
    hv.hpA = pA.maxHp; hv.hpB = pB.maxHp; hv.maxA = pA.maxHp; hv.maxB = pB.maxHp;
    hv.gaugesA = pa.map(function () { return Math.max(0, Math.min(100, pA.synInitGauge || 0)); });
    hv.gaugesB = pb2.map(function () { return Math.max(0, Math.min(100, pB.synInitGauge || 0)); });
    hv._gA = hv.gaugesA.slice();
    hv._gB = hv.gaugesB.slice();
    hv.specFired = [];
    hv.qnum = 0; hv.myQnum = 0; hv.logs = [];
    hv.startedAt = Date.now();
    hv.suddenDeath = { active: false, mult: 1, intensity: 0 };
    hv.qMax = MAX_QUESTIONS; hv.answered = false; hv.myChoice = -1;
    if (!hv.isAlive) hv.isAlive = { 0: true, 1: true };
    if (!hv.matchStatus) hv.matchStatus = 'pending';
    if (hv._countdownDone === undefined) hv._countdownDone = false;
    if (hv._acceptAnswer === undefined) hv._acceptAnswer = false;
    if (hv._sdAllowed === undefined) hv._sdAllowed = false;
    if (hv._winnerDeclared === undefined) hv._winnerDeclared = false;
    if (hv.startedAt === undefined) hv.startedAt = null;
    // ⑤ 対戦中のみ: 全キャラHPを1/5に（退室時に通常値へ復元できるよう倍率を保存）
    try {
      var _pvpScale = (window.PVPROOT && typeof PVPROOT.getHPScale === 'function') ? PVPROOT.getHPScale() : 1;
      hv._hpScale = _pvpScale;
      if (_pvpScale !== 1) {
        hv.hpA = hv.hpA * _pvpScale; hv.hpB = hv.hpB * _pvpScale;
        hv.maxA = hv.maxA * _pvpScale; hv.maxB = hv.maxB * _pvpScale;
      }
    } catch (e) { jlog('pvp hp 1/5 apply err', e); }
    if (s._deckWaitTimer) { clearTimeout(s._deckWaitTimer); s._deckWaitTimer = null; }
    if (hv._awaitTimer) { clearTimeout(hv._awaitTimer); hv._awaitTimer = null; }
    if (hv.isPlayer) renderDuel();
    else renderLobby();
    pvpArmAwaitWatchdog();
    hostSendQuizToSlot(pb.a, 150);
    hostSendQuizToSlot(pb.b, 150);
  }

  function hostSendQuizToSlot(slot, delayMs) {
    var s = P.state;
    var b = s.battle;
    if (!b || !b.active) return;
    // ★修正: 安全対策 — 対戦スロット・プレイヤー配列・クイズ格納先が未初期化なら処理しない
    if (b.a === undefined || b.a === null || b.b === undefined || b.b === null) return;
    if (!(b.players && b.players.length >= 2 && b.players[0] && b.players[1])) return;
    if (!(b.questionMap && b.qNums)) return;
    var delay = Math.max(0, parseInt(delayMs, 10) || 0);
    setTimeout(function () {
      var s2 = P.state, b2 = s2.battle;
      if (!b2 || !b2.active) return;
      if (slot !== b2.a && slot !== b2.b) return;
      if (!(b2.players && b2.players.length >= 2 && b2.players[0] && b2.players[1])) return;
      if (!(b2.questionMap && b2.qNums)) return;
      // ★修正: クイズプールは安全取得（pvpQuizPool）。木曜ギミック(kogo)は設定から正しく判定
      var kogo = !!(s2.settings && s2.settings.gimmicks && s2.settings.gimmicks.thu);
      var pool = pvpQuizPool(kogo);
      if (!pool || !pool.length) { jlog('クイズプール不足', 'slot=' + slot); return; }
      var q = pvpPickQuiz(kogo);
      // ★修正: 生成失敗時は対戦を止めず、再送して自己回復させる
      if (!q || !(q.choices && q.choices.length) || typeof q.correctIndex !== 'number' || q.correctIndex < 0) {
        jlog('クイズ生成失敗 → 再送試行', 'slot=' + slot);
        var rid = setTimeout(function () { hostSendQuizToSlot(slot, 0); }, QUIZ_RETRY_INTERVAL);
        P._quizRetryTimers.push(rid);
        return;
      }
      b2.qNums[slot] = (b2.qNums[slot] || 0) + 1;
      b2.questionMap[slot] = { word: q.word, kogo: q.kogo, choices: q.choices || [], correctIndex: q.correctIndex, qnum: b2.qNums[slot] };
      var payload = { t: 'quiz', targetSlot: slot, qnum: b2.qNums[slot], word: q.word, kogo: q.kogo, choices: q.choices };
      // ★修正: クイズ送信は自動リトライ（失敗時に最大3回まで800ms間隔で再送）
      if (slot === 0) {
        var hv = P.state.battle;
        // ★修正: hv.you===0 を条件から外す。slot===0 (=ホスト自身) で hv.isPlayer なら
        //         A側・B側どちらの表示枠でも問題を受信して遷移する必要がある。
        if (hv && hv.active && hv.isPlayer) {
          hv.state = 'question';
          hv.qnum = b2.qNums[slot];
          hv.myQnum = b2.qNums[slot];
          hv.word = q.word;
          hv.kogo = q.kogo;
          hv.choices = q.choices || [];
          hv.answered = false;
          hv.myChoice = -1;
          hv.specFired = [];
          renderDuelQuiz();
        }
      } else {
        // ★修正: 送信失敗時に再試行する（接続復帰待ち・パケット消失対策）
        function trySendQuiz() {
          if (hostSend(slot, payload)) { b2._quizRetry[slot] = 0; return; }
          var rc = (b2._quizRetry[slot] || 0) + 1;
          b2._quizRetry[slot] = rc;
          if (rc >= MAX_QUIZ_RETRY) {
            jlog('quiz送信失敗(上限到達)', 'slot=' + slot, 'rc=' + rc);
            return;
          }
          var tid = setTimeout(trySendQuiz, QUIZ_RETRY_INTERVAL);
          P._quizRetryTimers.push(tid);
        }
        trySendQuiz();
      }
    }, delay);
  }

  function hostResolveAnswer(slot, idx) {
    var s = P.state, b = s.battle;
    if (!b || !b.active) return;
    if (!b._countdownDone || !b._acceptAnswer) {
      try { hostSendQuizToSlot(slot, 250); } catch (e) {}
      return;
    }
    if (!(b.players && b.players.length >= 2 && b.players[0] && b.players[1])) return;
    if (!(b.questionMap && b.qNums)) return;
    if (slot !== b.a && slot !== b.b) return;
    var q = b.questionMap && b.questionMap[slot];
    if (!q) return;
    var attackerIdx = (b.players[0].slot === slot) ? 0 : 1;
    var defenderIdx = 1 - attackerIdx;
    var player = b.players[attackerIdx];
    var opp = b.players[defenderIdx];
    pvpSyncCombatant(player); pvpSyncCombatant(opp);
    pvpRefreshCombatant(player); pvpRefreshCombatant(opp);
    var curQ = q.qnum || ((b.qNums && b.qNums[slot]) || 0);
    var res = { qnum: curQ, actorSlot: slot, a: { correct: false, dmg: 0, crit: false, counter: 0, combo: player.combo || 0 }, b: { correct: false, dmg: 0, crit: false, counter: 0, combo: opp.combo || 0 }, logs: [], hpA: 0, hpB: 0, qMax: MAX_QUESTIONS };
    var out = attackerIdx === 0 ? res.a : res.b;
    var correct = (idx !== null && idx !== undefined && parseInt(idx, 10) === q.correctIndex);
    var gs = attackerIdx === 0
      ? (b._gA || (b._gA = b.players[0].party.map(function () { return player.synInitGauge || 0; })))
      : (b._gB || (b._gB = b.players[1].party.map(function () { return player.synInitGauge || 0; })));

    if (correct) {
      b.correctBySlot[slot] = (b.correctBySlot[slot] || 0) + 1;
      player.combo = (player.combo || 0) + 1;
      var stunned = (player.stun || 0) > 0;
      var dmgRes = pvpCalcDmg(player, opp, b.hazards[player.slot]);
      if (stunned) {
        player.stun--;
        dmgRes.dmg = 0;
        res.logs.push('🌀 ' + player.name + 'は行動阻害中で攻撃できなかった');
      }
      out.correct = true;
      out.dmg = dmgRes.dmg;
      out.crit = !!dmgRes.crit;
      out.combo = player.combo;
      if (!stunned) {
        var mitigated = pvpApplyDamageReduction(opp, dmgRes.dmg);
        out.dmg = mitigated.dmg;
        opp.hp = Math.max(0, opp.hp - mitigated.dmg);
        res.logs.push((dmgRes.crit ? '💥' : '⚔️') + ' ' + player.name + 'の正解攻撃 ' + mitigated.dmg + (dmgRes.crit ? ' CRITICAL!' : '') + ' → ' + opp.name + (mitigated.shielded ? '（結界）' : mitigated.blocked ? '（無効化）' : ''));
        pvpTriggerSkills(player, opp, 'correct', res.logs, {
          highGauge: gs.some(function (g) { return g >= 80; }),
          sameRarity: (player.party || []).every(function (u) { return u && u.rarity === (player.party[0] && player.party[0].rarity); })
        }, b);
        pvpTriggerSkills(player, opp, 'combo3', res.logs, {}, b);
        pvpTriggerSkills(player, opp, 'lowHpCorrect', res.logs, {}, b);
        pvpTriggerSkills(player, opp, 'highGaugeCorrect', res.logs, { highGauge: gs.some(function (g) { return g >= 80; }) }, b);
        pvpTriggerSkills(player, opp, 'sameRarityCorrect', res.logs, { sameRarity: (player.party || []).every(function (u) { return u && u.rarity === (player.party[0] && player.party[0].rarity); }) }, b);
        if (mitigated.dmg > 0) {
          pvpTriggerSkills(opp, player, 'afterHit', res.logs, { tookDamage: true }, b);
          pvpTriggerSkills(opp, player, 'lowHpHit', res.logs, { tookDamage: true }, b);
        }
      }
    } else {
      player.combo = 0;
      out.correct = false;
      out.combo = 0;
      player.missTotal = (player.missTotal || 0) + 1;
      var missMult = 1 + player.missTotal * PVP_MISS_PENALTY;
      var counterBase = Math.floor((opp.totalAtk || opp.baseTotalAtk || 1) * COUNTER_RATE);
      counterBase = Math.floor(counterBase * missMult * pvpSDMult());
      var counterMitigated = pvpApplyDamageReduction(player, counterBase);
      var counter = counterMitigated.dmg;
      player.hp = Math.max(0, player.hp - counter);
      out.counter = counter;
      if (counterMitigated.shielded) res.logs.push('🔰 ' + player.name + 'の結界が反撃を防いだ');
      else if (counterMitigated.blocked) res.logs.push('🛡️ ' + player.name + 'が反撃を無効化した');
      else if (counter > 0) res.logs.push('💢 ' + player.name + 'の不正解反撃 ' + counter + '（累積ミス×' + player.missTotal + '）');
      pvpApplyHazards(player, opp, curQ, b, res.logs);
      if (counter > 0) {
        pvpTriggerSkills(player, opp, 'afterHit', res.logs, { tookDamage: true }, b);
        pvpTriggerSkills(player, opp, 'lowHpHit', res.logs, { tookDamage: true }, b);
      }
    }

    pvpApplyGaugeGain(player, gs, correct);

    if (b.settings.gimmicks && b.settings.gimmicks.enrage) {
      if (Math.random() < ((b.totalAnswers || 0) % 10 === 9 ? 0.18 : 0.10)) {
        var envA = Math.floor(b.players[0].maxHp * 0.03), envB = Math.floor(b.players[1].maxHp * 0.03);
        b.players[0].hp = Math.max(0, b.players[0].hp - envA);
        b.players[1].hp = Math.max(0, b.players[1].hp - envB);
        res.logs.push('⚡ 敵強化！' + b.players[0].name + ' -' + envA + ' / ' + b.players[1].name + ' -' + envB);
      }
    }

    pvpAdvanceTurnEffects(b.players, res.logs, b);
    pvpRefreshCombatant(player); pvpRefreshCombatant(opp);
    res.hpA = b.players[0].hp;
    res.hpB = b.players[1].hp;
    b.totalAnswers = (b.totalAnswers || 0) + 1;
    try { delete b.questionMap[slot]; } catch (e) {}

    hostBroadcast({
      t: 'roundResult', kind: 'answer', actorSlot: slot, qnum: curQ, res: res,
      hpA: b.players[0].hp, hpB: b.players[1].hp, maxA: b.players[0].maxHp, maxB: b.players[1].maxHp,
      gaugesA: (b._gA || b.players[0].party.map(function () { return b.players[0].synInitGauge || 0; })).slice(),
      gaugesB: (b._gB || b.players[1].party.map(function () { return b.players[1].synInitGauge || 0; })).slice()
    });
    try { pvpPlayRoundSounds(res); } catch (e) { }

    var hv = P.state.battle;
    if (hv && hv.active) {
      hv.hpA = b.players[0].hp; hv.hpB = b.players[1].hp;
      hv.gaugesA = (b._gA || b.players[0].party.map(function () { return b.players[0].synInitGauge || 0; })).slice();
      hv.gaugesB = (b._gB || b.players[1].party.map(function () { return b.players[1].synInitGauge || 0; })).slice();
      hv.logs = (hv.logs || []).concat(res.logs).slice(-12);
      hv.myComboA = b.players[0].combo || 0;
      hv.myComboB = b.players[1].combo || 0;
      if (hv.isPlayer || isVisible('pvpDuelView')) renderDuel();
      try { pvpDamageFloats(hv, res); } catch (e) { }
    }

    if (b._countdownDone) {
      if (b.players[0].hp <= 0 && b.players[1].hp <= 0) { setTimeout(function () { hostEndBattle(null, null, '相打ち'); }, 250); hostSendQuizToSlot(slot, 0); return; }
      if (b.players[0].hp <= 0) { setTimeout(function () { hostEndBattle(b.players[1].slot, b.players[1].name, 'HPが尽きました'); }, 250); hostSendQuizToSlot(slot, 0); return; }
      if (b.players[1].hp <= 0) { setTimeout(function () { hostEndBattle(b.players[0].slot, b.players[0].name, 'HPが尽きました'); }, 250); hostSendQuizToSlot(slot, 0); return; }
    }
    hostSendQuizToSlot(slot, 0);
  }

  function hostBattleCancel(msg) {
    pvpClearTimers();
    hostBroadcast({ t: 'battleCancel', msg: msg });
    try { pbCancelCurrentMatch(); } catch (e) {}
    P.state.pendingBattle = null;
    P.state.battle = null;
    if (P.state.role === 'host') {
      pvpToast('対戦キャンセル', msg);
      renderLobby();
    }
  }

  function hostNextQuiz() {
    var s = P.state, b = s.battle;
    if (!b || !b.active) return;
    // ★修正: スロット別クイズ方式（対戦バトル）では旧・同時出題フローを無効化
    if (b._slotMode) return;
    b.qnum++;
    // ★修正: 問題数での終了を廃止（HP0のみで決着）
    b.state = 'question';
    b.answers = {};
    b._correctIndex = -1;
    var kogo = !!(s.settings.gimmicks && s.settings.gimmicks.thu);
    var q = pvpPickQuiz(kogo);
    if (!q) { hostEndBattle(null, null, 'クイズデータ不足'); return; }
    b._correctIndex = q.correctIndex;
    var payload = { t: 'quiz', qnum: b.qnum, qid: b.qnum, word: q.word, kogo: q.kogo, choices: q.choices, correctIndex: q.correctIndex };
    hostBroadcast(payload);
    // ホスト自身の画面も更新
    var hv = P.state.battle;
    if (hv && hv.active) {
      hv.state = 'question'; hv.qnum = b.qnum; hv.word = q.word; hv.kogo = q.kogo; hv.choices = q.choices; hv.answered = false; hv.myChoice = -1; hv.specFired = [];
      renderDuel();
    }
    if (b.quizTimer) clearTimeout(b.quizTimer);
    b.quizTimer = setTimeout(function () {
      if (s.battle && s.battle.active && s.battle.state === 'question') {
        hostCheckAnswers(true);
      }
    }, ANSWER_TIMEOUT_MS);
  }

  // ★修正: クイズ単語プールの安全な取得（フォールバック付き）
  // 通常は本体内の KOBUN_WORDS / KOGO_REVERSE_QUIZ（同一 <script> 内の const）を参照する。
  // 万一その定数に到達できない環境・読み込み順序でも、対戦が止まらないよう最小プールで代替する。
  var PVP_FALLBACK_POOL = [
    { word: "見る", primary: "見る・会う・思う・分かる", synonymous: ["見る", "会う", "結婚する", "理解する", "面倒を見る"], group: "action" },
    { word: "言ふ", primary: "言う・語る・評判が高い", synonymous: ["言う", "語る", "噂する"], group: "action" },
    { word: "思ふ", primary: "思う・感じる・恋い慕う", synonymous: ["思う", "感じる", "恋い慕う"], group: "feeling" },
    { word: "行く", primary: "行く・過ぎ去る・亡くなる", synonymous: ["行く", "過ぎ去る", "亡くなる"], group: "action" },
    { word: "あり", primary: "ある・存在する・生きている", synonymous: ["ある", "存在する", "生きている"], group: "existence" },
    { word: "をかし", primary: "趣深い・おもしろい", synonymous: ["趣深い", "おもしろい"], group: "feeling", kogoMode: true },
    { word: "あはれなり", primary: "しみじみとした趣がある", synonymous: ["しみじみとした趣", "趣深い"], group: "feeling", kogoMode: true },
    { word: "うつくし", primary: "美しい・かわいらしい", synonymous: ["美しい", "かわいらしい"], group: "feeling", kogoMode: true },
    { word: "あさまし", primary: "意外だ・驚きだ", synonymous: ["意外だ", "驚きだ"], group: "feeling", kogoMode: true },
    { word: "ゆかし", primary: "見てみたい・知りたい", synonymous: ["見てみたい", "知りたい", "風情がある"], group: "feeling", kogoMode: true }
  ];
  function pvpQuizPool(kogo) {
    var pool = null;
    try {
      if (kogo) {
        pool = (typeof KOGO_REVERSE_QUIZ !== 'undefined') ? KOGO_REVERSE_QUIZ : (window.KOGO_REVERSE_QUIZ || null);
      } else {
        pool = (typeof KOBUN_WORDS !== 'undefined') ? KOBUN_WORDS : (window.KOBUN_WORDS || null);
      }
    } catch (e) { pool = null; }
    if (!pool || !pool.length) {
      jlog('クイズプール未取得 → フォールバック', kogo ? 'kogo' : 'normal');
      pool = PVP_FALLBACK_POOL;
    }
    return pool;
  }

  function pvpPickQuiz(kogo) {
    try {
      var pool = pvpQuizPool(kogo);
      if (!pool || !pool.length) return null;
      var bucket = quizBalanceBucket(!!kogo, true);
      var q = pickBalancedQuizQuestion(pool, bucket);
      if (!q || q.primary === undefined || q.primary === null || q.primary === '') return null;
      var built = buildQuizChoicesFromPool(q, pool);
      return { word: q.word, kogo: !!q.kogoMode, choices: built.allChoices, correctIndex: built.allChoices.indexOf(built.targetAnswer) };
    } catch (e) { jlog('pickQuiz err', e); return null; }
  }

  function hostCheckAnswers(force) {
    var s = P.state, b = s.battle;
    if (!b || !b.active || b.state !== 'question') return;
    var a = b.answers[b.a];
    var bb = b.answers[b.b];
    var hasA = (a !== undefined), hasB = (bb !== undefined);
    if (!force && !(hasA && hasB)) return; // 両方そろうまで待つ
    b.state = 'resolving';
    if (b.quizTimer) { clearTimeout(b.quizTimer); b.quizTimer = null; }
    var curQ = b.qnum;
    var res = { qnum: curQ, a: { correct: false, dmg: 0, crit: false, counter: 0, combo: 0 }, b: { correct: false, dmg: 0, crit: false, counter: 0, combo: 0 }, logs: [], hpA: 0, hpB: 0, qMax: MAX_QUESTIONS };
    var pA = b.players[0], pB = b.players[1];
    var ansA = hasA ? a : null, ansB = hasB ? bb : null;
    var correctIndex = b._correctIndex;
    if (correctIndex === undefined || correctIndex === null || correctIndex < 0) correctIndex = -1;

    function sideResult(player, ans, opp, out) {
      if (ans !== null && ans === correctIndex) {
        b.correctBySlot[player.slot] = (b.correctBySlot[player.slot] || 0) + 1; // ★ 称号: 全体正解カウント
        player.combo++;
        var dmgRes = pvpCalcDmg(player, b.hazards[player.slot]);
        // 必殺技「行動不能/見切り」: 相手の次の正解攻撃が空振り
        var stunned = (opp.stun || 0) > 0;
        if (stunned) { opp.stun--; dmgRes.dmg = 0; res.logs.push('🌀 ' + opp.name + 'は行動不能！' + player.name + 'の攻撃は空振りした'); }
        out.correct = true; out.dmg = dmgRes.dmg; out.crit = dmgRes.crit; out.combo = player.combo;
        opp.hp = Math.max(0, opp.hp - dmgRes.dmg);
        if (!stunned) res.logs.push((dmgRes.crit ? '💥' : '⚔️') + ' ' + player.name + 'の正解攻撃 ' + dmgRes.dmg + (dmgRes.crit ? ' CRITICAL!' : '') + ' → ' + opp.name);
      } else {
        player.combo = 0;
        out.correct = false; out.combo = 0;
        // 必殺技「結界」: 次の反撃を無効化 / 敵デバフ「攻撃力DOWN」で反撃減少
        // ★①修正: 自分が間違えた回数に応じて「自分への反撃」が累積増加（相手への攻撃力は不変）
        player.missTotal = (player.missTotal || 0) + 1;
        var missMult = 1 + player.missTotal * PVP_MISS_PENALTY;
        var counter = Math.floor(opp.totalAtk * COUNTER_RATE * (1 - ((opp.atkDownPct || 0) / 100)));
        counter = Math.floor(counter * missMult * pvpSDMult());
        if ((player.shield || 0) > 0) {
          player.shield--;
          counter = 0;
          res.logs.push('🔰 ' + player.name + ' 結界が反撃を防いだ！');
        }
        player.hp = Math.max(0, player.hp - counter);
        out.counter = counter;
        if (counter > 0) res.logs.push('💢 ' + player.name + 'の不正解反撃 ' + counter + '（' + opp.name + 'の攻勢・累積ミス×' + player.missTotal + ' / 自分への攻撃' + Math.round((missMult - 1) * 100) + '%増）');
        pvpApplyHazards(player, opp, curQ, b, res.logs);
      }
    }
    sideResult(pA, ansA === undefined ? null : ansA, pB, res.a);
    sideResult(pB, ansB === undefined ? null : ansB, pA, res.b);
    // 敵強化ギミック: 毎問 一定確率で環境ダメージ（双方）
    if (b.settings.gimmicks && b.settings.gimmicks.enrage) {
      if (Math.random() < (curQ % 5 === 0 ? 0.18 : 0.10)) {
        var envT = Math.floor(pA.maxHp * 0.03), envB = Math.floor(pB.maxHp * 0.03);
        pA.hp = Math.max(0, pA.hp - envT); pB.hp = Math.max(0, pB.hp - envB);
        res.logs.push('⚡ 敵強化！' + pA.name + ' -' + envT + ' / ' + pB.name + ' -' + envB);
      }
    }
    // 必殺ゲージ加算（正解:大 / 不正解:小）— オフラインと同じ感覚で必殺技を打てるように
    var gA2 = b._gA || (b._gA = b.players[0].party.map(function () { return 0; }));
    var gB2 = b._gB || (b._gB = b.players[1].party.map(function () { return 0; }));
    function chargeGauge(sideP, gs, ok) {
      sideP.party.forEach(function (uu, ii) {
        var gp = (uu.gaugePerCorrect !== undefined) ? (Number(uu.gaugePerCorrect) || 0) : 15;
        gs[ii] = Math.min(100, gs[ii] + (ok ? gp * 0.7 : gp * 0.3));
      });
    }
    chargeGauge(pA, gA2, ansA !== undefined && ansA !== null && ansA === correctIndex);
    chargeGauge(pB, gB2, ansB !== undefined && ansB !== null && ansB === correctIndex);
    res.hpA = pA.hp; res.hpB = pB.hp;
    hostBroadcast({ t: 'roundResult', qnum: curQ, res: res, hpA: pA.hp, hpB: pB.hp, maxA: pA.maxHp, maxB: pB.maxHp, gaugesA: gA2.slice(), gaugesB: gB2.slice() });
    try { pvpPlayRoundSounds(res); } catch (e) { }
    // ホスト自身の画面反映
    var hv = P.state.battle;
    if (hv && hv.active) {
      hv.hpA = pA.hp; hv.hpB = pB.hp;
      hv.gaugesA = gA2.slice(); hv.gaugesB = gB2.slice();
      hv.state = 'resolving';
      hv.logs = (hv.logs || []).concat(res.logs).slice(-12);
      hv.myComboA = res.a.combo || 0;
      hv.myComboB = res.b.combo || 0;
      renderDuel();
    }
    if (pA.hp <= 0 || pB.hp <= 0) {
      setTimeout(function () {
        hostEndBattle(pA.hp <= 0 ? pB.slot : pA.slot, pA.hp <= 0 ? pB.name : pA.name, 'HPが尽きました');
      }, 400);
      return;
    }
    // 必殺技を打つ時間を確保（オフラインの殴り合い感覚）
    b._win = setTimeout(hostNextQuiz, SPECIAL_WINDOW_MS);
  }

  function pvpCalcDmg(player, opp, haz) {
    var atk = player.totalAtk || player.baseTotalAtk || 1;
    if (haz) {
      if (haz.monMult < 1) atk = Math.floor(atk * haz.monMult);
      atk += (haz.tueBonus || 0) + (haz.wedDelta || 0);
    }
    var synMul = 1 + ((player.synCount || 0) * 0.13);
    if (pvpHasUnit(player, 'ok_001')) synMul += 0.10;
    var dmg = Math.floor(atk * (1 + (player.combo || 0) * 0.10) * synMul);
    var critChance = ((player.combo || 0) >= 3 ? 1 : 0.25);
    if (player.critRatePct) critChance += player.critRatePct / 100;
    var crit = Math.random() < Math.min(1, critChance);
    if (crit) dmg = Math.floor(dmg * (1.5 + ((player.critDmgPct || 0) / 100)));
    if (opp && opp.defPct) dmg = Math.floor(dmg * (100 / (100 + opp.defPct + (opp.allPct || 0))));
    dmg = Math.max(1, Math.floor(dmg * pvpSDMult()));
    return { dmg: dmg, crit: crit };
  }

  function pvpApplyHazards(player, opp, curQ, b, logs) {
    var g = b.settings.gimmicks || {};
    var haz = b.hazards[player.slot];
    if (!haz) return;
    var ohaz = b.hazards[opp.slot];
    if (g.mon && Math.random() < 0.35) {
      haz.monMult = 0.5; haz.monQ = curQ + 4;
      logs.push('🌙 レベル半減！' + player.name + 'の与ダメージ半減（次の4問）');
    }
    if (g.tue && Math.random() < 0.30) {
      var strongest = player.party.slice().sort(function (a2, b2) { return b2.atk - a2.atk; })[0];
      var bonus = Math.floor((strongest ? strongest.atk : player.totalAtk) * 0.5);
      if (ohaz) { ohaz.tueBonus = (ohaz.tueBonus || 0) + bonus; ohaz.tueQ = curQ + 4; }
      logs.push('🔥 寝返り！' + (strongest ? strongest.name : '部隊') + 'が敵陣営に加勢（+' + bonus + '）');
    }
    if (g.wed && Math.random() < 0.30) {
      var delta = Math.floor(player.totalAtk * (Math.random() * 0.6 - 0.3));
      haz.wedDelta = delta; haz.wedQ = curQ + 4;
      logs.push('🎭 変身！' + player.name + 'の部隊が混乱（攻撃' + (delta >= 0 ? '+' : '') + delta + '）');
    }
    if (g.fri && Math.random() < 0.30) {
      var swapBonus = Math.floor(player.totalAtk * 0.35);
      if (ohaz) { ohaz.tueBonus = (ohaz.tueBonus || 0) + swapBonus; ohaz.tueQ = curQ + 4; }
      logs.push('🎲 ランダム編成！' + player.name + 'の先鋒が交代（相手に+' + swapBonus + '）');
    }
  }

  function hostEndBattle(winnerSlot, winnerName, reason) {
    var s = P.state, b = s.battle;
    if (!b || !b.active) return;
    pvpClearTimers();
    b.active = false;
    if (b.quizTimer) { clearTimeout(b.quizTimer); b.quizTimer = null; }
    if (b._win) { clearTimeout(b._win); b._win = null; }
    var pA = b.players[0], pB = b.players[1];
    var qnum = b.qnum || 0;
    // ★ 称号システム: 結果計算（公式設定のみ・全体正解20問以上・30秒以上でポイント変動）
    var correctTotal = 0;
    Object.keys(b.correctBySlot || {}).forEach(function (k) { correctTotal += (b.correctBySlot[k] || 0); });
    var elapsed = (Date.now() - (b.startedAt || 0)) / 1000;
    var elig = !!b.official && correctTotal >= 20 && elapsed >= 30;
    var pts = {};
    [pA, pB].forEach(function (pl) {
      var opp = (pl === pA) ? pB : pA;
      var plT = Math.max(0, Math.floor(Number(pl.titles) || 0));
      var opT = Math.max(0, Math.floor(Number(opp.titles) || 0));
      var diff = opT - plT;
      var delta = 0, reason = '';
      if (!elig) {
        reason = '公式設定・20問・30秒の条件未達のため対象外（正解' + correctTotal + '問/' + Math.round(elapsed) + '秒）';
      } else if (winnerSlot !== null && winnerSlot !== undefined && pl.slot === winnerSlot) {
        delta = 30; reason = '勝利';
      } else if (winnerSlot !== null && winnerSlot !== undefined) {
        delta = diff >= 5 ? 10 : -10;
        reason = diff >= 5 ? '敗北（称号差5以上: +10）' : '敗北';
      } else {
        reason = '引き分け';
      }
      pts[pl.slot] = { delta: delta, reason: reason, elig: elig, myTitles: plT, oppTitles: opT, totalCorrect: correctTotal, elapsedSec: Math.round(elapsed) };
    });
    hostBroadcast({ t: 'battleEnd', winnerSlot: winnerSlot, winnerName: winnerName || '', reason: reason || '',
      hpA: pA.hp, hpB: pB.hp, maxA: pA.maxHp, maxB: pB.maxHp, qnum: qnum, pts: pts });
    // ホスト自身の結果表示
    var hostIsPlayer = (b.a === 0 || b.b === 0);
    P.state.battle = {
      active: false, isPlayer: hostIsPlayer, a: b.a, b: b.b, mySlot: 0,
      you: (b.a === 0) ? 0 : 1,
      players: [ { name: pA.name, party: pA.party }, { name: pB.name, party: pB.party } ],
      hpA: pA.hp, hpB: pB.hp, maxA: pA.maxHp, maxB: pB.maxHp,
      lastQnum: qnum, pts: pts, winnerSlot: winnerSlot, winnerName: winnerName || '', reason: reason || ''
    };
    renderResult();
    if (pbIsActive() && P.state.pointBattle.livePair) {
      try { pbFinishCurrentMatch(winnerSlot, reason); } catch (e) { jlog('pointBattle finish err', e); }
    }
    // ★ 称号: ホスト自身（slot0）がプレイヤーなら結果を適用
    if (hostIsPlayer && pts && pts[0] !== undefined) { pvpApplyMatchResult(pts[0]); }
    s.battle = { active: false, lastWinnerSlot: winnerSlot, lastWinnerName: winnerName, lastQnum: qnum };
    s.pendingBattle = null;
  }

  // ==================== ホスト離脱 → 権限移譲 ====================
  function onHostGone() {
    var s = P.state;
    if (s.role !== 'guest') return;
    setTimeout(function () {
      if (s.role !== 'guest') return;
      if (s.hostConn && s.hostConn.open) return; // 復帰済み
      var promoSrc = s.players.filter(function (p) { return p.slot > 0; });
      if (!promoSrc.length) { P.state.role = ''; renderHome(); return; }
      var promoSlot = Math.min.apply(null, promoSrc.map(function (p) { return p.slot; }));
      if (s.mySlot === promoSlot) {
        becomeHost();
      } else {
        var pid = 'tk315pvp-' + s.code.toLowerCase() + '-g' + pad(promoSlot);
        try {
          var c = s.peer.connect(pid, { reliable: true });
          c.on('open', function () {
            c.send({ t: 'iAmGuest', name: s.myName, slot: s.mySlot });
            s.hostConn = c;
            bindHostConnHandlers(c, true);
          });
          c.on('close', function () { s.hostConn = null; });
          c.on('error', function () { jlog('rejoin err'); });
        } catch (e) { jlog('rejoin fail', e); }
      }
    }, 2500);
  }

  function becomeHost() {
    var s = P.state;
    s.role = 'host';
    s.guestConns = {};
    try { P2P.reset(); } catch (e) {} // ★16人対応: 旧接続を破棄し、ホストとして再構成
    var me = s.players.find(function (p) { return p.slot === s.mySlot; });
    if (!me) { s.players = [{ slot: s.mySlot, name: s.myName, isHost: true, peerId: s.peer && s.peer.id }]; }
    else {
      me.isHost = true;
      s.players = [{ slot: me.slot, name: me.name, isHost: true, peerId: s.peer && s.peer.id }].concat(s.players.filter(function (p) { return p.slot !== s.mySlot; }));
    }
    s.mySlot = 0;
    // 自分がホスト Peer になる（固定IDは維持: gスロットIDのままでも可）
    P.state.peer.on('connection', function (conn) { onPeerConn(conn); });
    try { P2P.syncTopology(); } catch (e) {}
    renderLobby();
    pvpToast('ホスト権限が移りました', '前のホストが退出したため、あなたが新しいホストになりました。\n部屋は継続しています。');
  }

  function acceptGuestConn(conn) {
    P._lastConn = conn;
    conn.on('data', function (d) {
      if (!d) return;
      jlog('guest conn data', d.t);
      if (d.t === 'iAmGuest') {
        var sl = parseInt(d.slot, 10);
        if (!isNaN(sl) && sl >= 1 && sl < MAX_ROOM) {
          P.state.guestConns[sl] = conn;
          var nm = String(d.name || 'プレイヤー').slice(0, 10);
          var existing = P.state.players.find(function (p) { return p.slot === sl; });
          if (existing) { existing.name = nm; existing.peerId = 'tk315pvp-' + P.state.code.toLowerCase() + '-g' + pad(sl); }
          else upsertPlayer(sl, nm, false, 'tk315pvp-' + P.state.code.toLowerCase() + '-g' + pad(sl));
          dedupePlayersList();
          hostBroadcast(playersPayload());
        }
        return;
      }
      // 通常メッセージ: どのスロットからの接続か判定
      var slot = -1;
      Object.keys(P.state.guestConns).forEach(function (k) {
        if (P.state.guestConns[k] === conn) slot = parseInt(k, 10);
      });
      if (slot < 0) {
        // 未登録コネクション: スロット割当用の join/join2 のみ受け付ける
        // ★修正: 従来は myDeck/answer 等も hostHandleData(-2, d) に流れ、
        //   decks[-2] 等が積まれて「デッキが揃わず対戦開始が無反応」の原因になっていた
        if (d.t === 'join' || d.t === 'join2') {
          P._lastConn = conn;
          hostHandleData(-2, d);
        } else {
          jlog('未登録コネクションのメッセージを破棄', d.t);
        }
        return;
      }
      hostHandleData(slot, d);
    });
    conn.on('close', function () {
      jlog('guest conn close');
      var closedSlot = -1;
      Object.keys(P.state.guestConns).forEach(function (k) {
        if (P.state.guestConns[k] === conn) closedSlot = parseInt(k, 10);
      });
      // 最新コネクションが閉じた時のみ退出扱い（join2 で差し替え済みなら無視）
      if (closedSlot >= 0 && P.state.guestConns[closedSlot] === conn) hostRemoveGuest(closedSlot, true);
    });
    conn.on('error', function (e) { jlog('guest conn error', e); });
  }

  // ==================== ゲスト処理 ====================
  function bindHostConnHandlers(conn, isRejoin) {
    conn.on('data', function (d) { jlog('host→guest data', d && d.t); if (d && d.t) guestHandleData(d); });
    conn.on('close', function () { jlog('host conn close'); P.state.hostConn = null; onHostGone(); });
    conn.on('error', function (e) { jlog('host conn error', e); });
  }
  function guestHandleData(d) {
    var s = P.state;
    jlog('guestHandleData', d.t);
    switch (d.t) {
      case 'welcome':
        s.settings = d.settings || defaultSettings();
        s.players = d.players || [];
        P._welcomeReceived = true;
        s.mySlot = parseInt(d.slot, 10);
        var fixedId = d.myPeerId || ('tk315pvp-' + s.code.toLowerCase() + '-g' + pad(s.mySlot));
        try {
          var np = new Peer(fixedId, { debug: 1 });
          np.on('open', function () {
            jlog('fixed peer open', fixedId);
            s.peer = np;
            // ★16人対応: 他プレイヤーからのメッシュ接続を受信できるようにする
            np.on('connection', function (conn) { onPeerConn(conn); });
            try { P2P.syncTopology(); } catch (e) {}
            var c = np.connect('tk315pvp-' + s.code.toLowerCase() + '-h', { reliable: true });
            c.on('open', function () {
              c.send({ t: 'join2', name: s.myName, slot: s.mySlot });
              s.hostConn = c;
              s.tempConn = null;
              bindHostConnHandlers(c, true);
              try { if (P.state.tempPeer) { P.state.tempPeer.destroy(); P.state.tempPeer = null; } } catch (e) {}
            });
          });
          np.on('error', function (err) {
            jlog('fixed peer err', err);
            try { if (s.tempPeer) s.tempPeer.destroy(); } catch (e) {}
            var np2 = new Peer(fixedId + '-' + String(Math.floor(Math.random() * 999)), { debug: 1 });
            np2.on('open', function () {
              jlog('fallback fixed peer open');
              s.peer = np2;
              np2.on('connection', function (conn) { onPeerConn(conn); });
              try { P2P.syncTopology(); } catch (e) {}
              var c = np2.connect('tk315pvp-' + s.code.toLowerCase() + '-h', { reliable: true });
              c.on('open', function () {
                jlog('guest fixed conn open');
                c.send({ t: 'join2', name: s.myName, slot: s.mySlot });
                s.hostConn = c;
                s.tempConn = null;
                bindHostConnHandlers(c, true);
                try { if (P.state.tempPeer) { P.state.tempPeer.destroy(); P.state.tempPeer = null; } } catch (e) {}
              });
            });
          });
        } catch (e) { jlog('fixed peer fail', e); }
        renderLobby();
        break;
      case 'players':
        s.players = d.players || [];
        s.settings = d.settings || s.settings || defaultSettings();
        // ★16人対応: プレイヤー一覧の更新に合わせてトポロジーを再構築
        try { P2P.syncTopology(); } catch (e) {}
        renderLobby();
        break;
      case 'pointBattleState':
        s.pointBattle = d.pb || null;
        if (isVisible('pvpLobbyView') || isVisible('pvpHomeView')) renderLobby();
        break;
      case 'pointBattleSuddenDeath':
        // 20分到達: 対戦中なら既存サドンデス処理を即時適用（_forceSDAtで強制発動）
        if (s.battle && s.battle.active) { s.battle._sdAllowed = true; s.battle._forceSDAt = d.at || Date.now(); }
        pvpToast('サドンデス開始', '20分経過！対戦中の試合はサドンデスで強制決着されます。');
        break;
      case 'pointBattleStart':
        // ★ホストから始まったら duration はその値で上書き（ゲスト側も同じ制限時間にする）
        try { PB_DURATION_SEC = d.durationSec || PB_DURATION_SEC; } catch (e) {}
        try {
          var pbN = pbState();
          pbN.durationSec = d.durationSec || PB_DURATION_SEC;
          pbN.startedAt = d.startedAt || Date.now();
        } catch (e) {}
        break;
      case 'pointBattleEnd':
        s.pointBattle = d.pb || null;
        pvpToast('ポイント争奪戦 終了', '最終ポイント集計をお知らせします。');
        if (isVisible('pvpLobbyView') || isVisible('pvpHomeView')) renderLobby();
        break;
      case 'err':
        pvpShowErr(d.msg || 'エラー');
        break;
      case 'challengeFrom':
        s.pendingChallenge = { fromSlot: d.fromSlot, fromName: d.fromName || '相手' };
        renderLobby();
        break;
      case 'challengeAccepted':
        // ★修正: 受諾時に文言・トーストは一切表示しない。battleStart 到着で即対戦画面に遷移し「スタート」カウントダウンが始まる
        break;
      case 'challengeDeclined':
        pvpToast('申込却下', '相手は対戦の申し込みを断りました。');
        break;
      case 'pleaseSendQuiz':
        try {
          if (s.battle && s.battle.active && slot !== 0 && slot !== undefined) {
            hostSendQuizToSlot(slot, 0);
          }
        } catch (e) {}
        break;
      case 'askDeck':
        var ids = [];
        try { ids = getCombinedBattleDeckIds(); } catch (e) {}
        var lv = {};
        try { lv = state.unitLevels || {}; } catch (e) {}
        var nlv = 1;
        try { nlv = state.noble ? state.noble.level : 1; } catch (e) {}
        var v = pvpValidateDeck(ids, s.settings);
        // silent: silent 付き askDeck（ロビーの定期取り直し）では警告トーストを出さない
        if (!v.ok) { if (!d.silent) pvpToast('編成が制限に違反しています', v.msg); guestSend({ t: 'myDeck', deckIds: [], levels: {}, nobleLevel: 1, titles: pvpTitleCount() }); }
        else { guestSend({ t: 'myDeck', deckIds: v.ids, levels: lv, nobleLevel: nlv, titles: pvpTitleCount() }); }
        break;
      case 'battleStart':
        s.battle = {
          active: true, state: 'await', a: d.a, b: d.b,
          mySlot: s.mySlot,
          players: d.players || [],
          hpA: (d.players && d.players[0]) ? d.players[0].maxHp : 1,
          hpB: (d.players && d.players[1]) ? d.players[1].maxHp : 1,
          maxA: (d.players && d.players[0]) ? d.players[0].maxHp : 1,
          maxB: (d.players && d.players[1]) ? d.players[1].maxHp : 1,
          gaugesA: ((d.players && d.players[0] && d.players[0].party) || []).map(function () { return 0; }),
          gaugesB: ((d.players && d.players[1] && d.players[1].party) || []).map(function () { return 0; }),
          specFired: [], qnum: 0, myQnum: 0, logs: [], qMax: MAX_QUESTIONS,
          isPlayer: (d.a === s.mySlot || d.b === s.mySlot),
          you: (d.a === s.mySlot) ? 0 : 1,
          answered: false,
          myChoice: -1,
          word: '',
          kogo: false,
          choices: [],
          startedAt: d.startedAt || Date.now(),
          suddenDeath: { active: false, mult: 1, intensity: 0 }
        };
        if (s.battle.isPlayer) {
          renderDuel();
        } else {
          s._spectatorCandidate = {
            a: d.a, b: d.b,
            players: d.players || [],
            startedAt: d.startedAt || Date.now()
          };
          try { updateSpectatorBanner(); } catch (e) {}
          renderLobby();
        }
        try { pvpArmAwaitWatchdog(); } catch (e) {}
        break;
      case 'countdownDone':
        if (!s.battle || !s.battle.active) break;
        s.battle._countdownDone = true;
        s.battle._acceptAnswer = true;
        if (!s.battle.startedAt) s.battle.startedAt = Date.now();
        try { if (s.battle.isPlayer || isVisible('pvpDuelView')) renderDuel(); } catch (e) {}
        break;
      case 'quiz':
        if (!s.battle || !s.battle.active) break;
        if (d.targetSlot !== undefined && d.targetSlot !== null && parseInt(d.targetSlot, 10) !== s.mySlot) break;
        s.battle.qnum = d.qnum || s.battle.qnum || 0;
        s.battle.myQnum = d.qnum || s.battle.myQnum || 0;
        s.battle.state = 'question';
        s.battle.word = d.word;
        s.battle.kogo = d.kogo;
        s.battle.choices = d.choices || [];
        s.battle.correctIndex = (d.correctIndex !== undefined) ? d.correctIndex : -1;
        s.battle.answered = false;
        s.battle.myChoice = -1;
        s.battle.specFired = [];
        // ★修正: クイズ受信で待機監視を解除
        if (s.battle._awaitTimer) { clearTimeout(s.battle._awaitTimer); s.battle._awaitTimer = null; }
        renderDuelQuiz();
        break;
      case 'roundResult':
        if (!s.battle || !s.battle.active) break;
        s.battle.hpA = d.hpA; s.battle.hpB = d.hpB;
        s.battle.maxA = d.maxA; s.battle.maxB = d.maxB;
        if (d.gaugesA) s.battle.gaugesA = d.gaugesA;
        if (d.gaugesB) s.battle.gaugesB = d.gaugesB;
        if (d.res && d.res.logs) { s.battle.logs = s.battle.logs.concat(d.res.logs).slice(-12); }
        if (d.res) { s.battle.myComboA = (d.res.a && d.res.a.combo) || 0; s.battle.myComboB = (d.res.b && d.res.b.combo) || 0; }
        if (d.kind === 'spec' && d.specUnit) { try { pvpShowSpecFx(d.specUnit, d.specType || 'atk'); } catch (e) { } }
        if (s.battle.isPlayer || isVisible('pvpDuelView')) renderDuel();
        else if (s.pointBattle && s.pointBattle.active) renderLobby();
        // ★修正: オフライン同様のダメージモーション（フローティング表示）
        try { pvpDamageFloats(s.battle, d.res); } catch (e) { }
        // ★②修正: ゲスト側でも攻撃ヒット音を再生
        try { pvpPlayRoundSounds(d.res); } catch (e) { }
        break;
      case 'battleEnd':
        pvpClearTimers();
        if (!s.battle) break;
        var wasSpectating = !!(s.battle.isSpectator);
        s.battle.active = false;
        s.battle.winnerSlot = d.winnerSlot;
        s.battle.winnerName = d.winnerName;
        s.battle.reason = d.reason;
        s.battle.hpA = d.hpA; s.battle.hpB = d.hpB;
        s.battle.lastQnum = d.qnum;
        s.battle.pts = d.pts || null;
        if (wasSpectating) {
          s._spectatorCandidate = null;
          s.battle = null;
          try { updateSpectatorBanner(); } catch (e) {}
          try { updateSpectatorHeader(); } catch (e) {}
          renderLobby();
        } else {
          renderResult();
        }
        if (d.pts && s.battle.isPlayer && d.pts[s.mySlot] !== undefined) { pvpApplyMatchResult(d.pts[s.mySlot]); }
        break;
      case 'battleCancel':
        if (s.battle && s.battle.active) { s.battle.active = false; s.battle = null; }
        pvpToast('対戦キャンセル', d.msg || '編成が制限に違反しているため対戦を開始できませんでした。');
        renderLobby();
        break;
      default:
        break;
    }
  }

  // ---------- ①オンライン版必殺技（ホスト権威で判定・オフライン演出を流用） ----------
  function hostApplySpecial(slot, unitIdx) {
    var s = P.state, b = s.battle;
    if (!b || !b.active) return;
    if (!b._countdownDone || !b._acceptAnswer) return;
    if (!(unitIdx >= 0)) return;
    var idx = (b.a === slot) ? 0 : 1;
    var p = b.players[idx];
    if (!p) return;
    var u = p.party[unitIdx];
    if (!u) return;
    pvpSyncCombatant(p); pvpSyncCombatant(b.players[1 - idx]);
    var gA = b._gA || (b._gA = b.players[0].party.map(function () { return b.players[0].synInitGauge || 0; }));
    var gB = b._gB || (b._gB = b.players[1].party.map(function () { return b.players[1].synInitGauge || 0; }));
    var gs = idx === 0 ? gA : gB;
    if (!(gs[unitIdx] >= 100)) return;
    gs[unitIdx] = 0;
    var opp = b.players[1 - idx];
    var fx;
    try { fx = SPECIAL_EFFECTS[u.id] || NEW_SPECIAL_EFFECTS[u.id] || u.special_effect || { dmg: 1.0 }; } catch (e) { fx = { dmg: 1.0 }; }
    var specName = u.specialName || '奥義';
    var logs = [];
    var specType = pvpApplyEffectBundle(p, opp, fx, logs, p.name + 'の必殺技【' + specName + '】', b);
    if (!logs.length) logs.push('✨ ' + p.name + 'の必殺技【' + specName + '】を発動');
    pvpAdvanceTurnEffects(b.players, logs, b);

    hostBroadcast({
      t: 'roundResult', kind: 'spec', actorSlot: slot, qnum: b.qnum || 0, res: { logs: logs },
      hpA: b.players[0].hp, hpB: b.players[1].hp, maxA: b.players[0].maxHp, maxB: b.players[1].maxHp,
      gaugesA: gA.slice(), gaugesB: gB.slice(),
      specUnit: { id: u.id, name: u.name, specName: specName }, specType: specType
    });
    var hv = P.state.battle;
    if (hv && hv.active) {
      hv.hpA = b.players[0].hp; hv.hpB = b.players[1].hp;
      hv.gaugesA = gA.slice(); hv.gaugesB = gB.slice();
      hv.logs = (hv.logs || []).concat(logs).slice(-12);
      if (hv.isPlayer || isVisible('pvpDuelView')) renderDuel();
      else if (P.state.pointBattle && P.state.pointBattle.active) renderLobby();
    }
    try { pvpShowSpecFx({ id: u.id, name: u.name, specName: specName }, specType); } catch (e) { }
    if (b.players[0].hp <= 0 && b.players[1].hp <= 0) { setTimeout(function () { hostEndBattle(null, null, '相打ち'); }, 250); return; }
    if (b.players[0].hp <= 0) { setTimeout(function () { hostEndBattle(b.players[1].slot, b.players[1].name, 'HPが尽きました'); }, 250); return; }
    if (b.players[1].hp <= 0) { setTimeout(function () { hostEndBattle(b.players[0].slot, b.players[0].name, 'HPが尽きました'); }, 250); return; }
  }

  // 必殺技の視覚演出（オフラインの spec-* 演出を流用）
  function pvpShowSpecFx(specUnit, specType) {
    // ★②修正: 必殺技発動音
    try { AudioFX.playCrit(); } catch (e) { }
    var p = { id: specUnit.id, unit: { name: specUnit.name, special_move: { name: specUnit.specName || '奥義' } } };
    var fx;
    if (specType === 'heal') fx = { healPct: 0.3 };
    else if (specType === 'shield') fx = { shield: 1 };
    else if (specType === 'stun') fx = { stun: [3, 3] };
    else if (specType === 'debuff') fx = { enemyAtkDown: [20, 8] };
    else if (specType === 'buff') fx = { buffAtk: 20 };
    else fx = { dmg: 1 };
    playSpecialMoveShow(p, fx);
    try { createFloatingText('✨ ' + specUnit.name + 'の必殺技!!', el('pvpDuelView'), 'text-amber-300 text-base font-black'); } catch (e) { }
  }

  // 攻撃結果のダメージモーション（オフラインの createFloatingText を対戦パネルに流用）
  function pvpDamageFloats(b, res) {
    if (!b || !res) return;
    var mySide = (b.you === 0 || b.you === 1) ? b.you : -1;
    function fl(panelIdx, txt, cls) {
      var c = el('pvpPanel' + panelIdx);
      if (!c) c = el('pvpDuelView');
      if (!c) return;
      try { createFloatingText(txt, c, cls); } catch (e) { }
    }
    // res.a = 側0の行動 / res.b = 側1の行動
    if (res.a) {
      if (res.a.dmg > 0) fl(1, '-' + res.a.dmg + (res.a.crit ? ' CRITICAL!!' : ''), (mySide === 1 ? 'text-red-400 text-lg font-black' : 'text-amber-300 text-lg font-black'));
      if (res.a.counter > 0) fl(0, '💢 -' + res.a.counter, (mySide === 0 ? 'text-red-300 text-base font-black' : 'text-orange-300 text-base font-black'));
    }
    if (res.b) {
      if (res.b.dmg > 0) fl(0, '-' + res.b.dmg + (res.b.crit ? ' CRITICAL!!' : ''), (mySide === 0 ? 'text-red-400 text-lg font-black' : 'text-amber-300 text-lg font-black'));
      if (res.b.counter > 0) fl(1, '💢 -' + res.b.counter, (mySide === 1 ? 'text-red-300 text-base font-black' : 'text-orange-300 text-base font-black'));
    }
  }

  // ★②修正: 対戦の攻撃ヒット音（ホスト・ゲスト双方で再生。正解攻撃=攻撃音/クリティカル=クリティカル音/被反撃=ダメージ音）
  function pvpPlayRoundSounds(res) {
    try { AudioFX.init(); if (AudioFX.ctx && AudioFX.ctx.state === 'suspended') AudioFX.ctx.resume(); } catch (e) { }
    if (!res) return;
    try {
      if (res.a) {
        if (res.a.dmg > 0) { if (res.a.crit) AudioFX.playCrit(); else AudioFX.playAttack(); }
        if (res.a.counter > 0) AudioFX.playHurt();
      }
      if (res.b) {
        if (res.b.dmg > 0) { if (res.b.crit) AudioFX.playCrit(); else AudioFX.playAttack(); }
        if (res.b.counter > 0) AudioFX.playHurt();
      }
    } catch (e) { }
  }

  // プレイヤー側: 必殺技ボタン
  function fireSpecial(unitIdx) {
    var s = P.state, b = s.battle;
    if (!b || !b.active || !b.isPlayer) return;
    var gs = b.you === 0 ? b.gaugesA : b.gaugesB;
    if (!gs || !(gs[unitIdx] >= 100)) return;
    if (b.specFired && b.specFired[unitIdx]) return;
    if (!b.specFired) b.specFired = [];
    b.specFired[unitIdx] = true;
    if (s.role === 'host') { hostHandleData(s.mySlot, { t: 'special', unitIdx: unitIdx }); }
    else { guestSend({ t: 'special', unitIdx: unitIdx }); }
    renderDuel();
  }

  // ==================== UI: ホーム ====================
  // ==================== 称号システム: 対戦結果の適用 ====================
  function pvpApplyMatchResult(meta) {
    if (!meta) return;
    try { if (typeof state === 'undefined') return; } catch (e) { return; }
    var before = pvpTitleCount();
    var delta = Number(meta.delta) || 0;
    state.pvpPoints = Math.max(0, pvpPoints() + delta); // ★ ポイントは0未満にならない
    var promos = 0;
    while (state.pvpPoints >= PVP_TITLE_COST && pvpTitleCount() < PVP_TITLES.length) {
      state.pvpPoints -= PVP_TITLE_COST;
      state.pvpTitles = pvpTitleCount() + 1;
      promos++;
    }
    if (promos > 0 || delta !== 0) { try { checkAchievements(); } catch (e) {} } // 実績解除
    if (promos > 0) {
      pvpToast('称号昇格！', PVP_TITLES[pvpTitleIndex()].name + ' に到達（' + promos + '段昇格）');
    }
    // ★ 最高ランク（太政大臣=全称号）到達で神キャラ解放
    if (pvpTitleCount() >= PVP_TITLES.length && before < PVP_TITLES.length) {
      var had = false;
      try { had = (state.ownedUnits || []).indexOf(PVP_GOD_UNIT_ID) !== -1; } catch (e) {}
      try { grantOwnedUnit(PVP_GOD_UNIT_ID); } catch (e) {}
      if (!had) pvpToast('神キャラ解放！', '天照大御神 が仲間に加わりました！');
      else pvpToast('神キャラ解放！', '天照大御神 の所持数を確認しました');
    }
    try { saveState(); } catch (e) {}
  }

  function renderHome() {
    pvpClearTimers();
    ['pvpCfgView', 'pvpLobbyView', 'pvpDuelView', 'pvpResultView'].forEach(function (id) { var x = el(id); if (x) x.classList.add('hidden'); });
    P.state.role = '';
    P.state.hostConn = null; P.state.tempConn = null; P.state.guestConns = {};
    P.state.battle = null; P.state.pendingChallenge = null;
    P._roomCreated = false;
    try { P2P.reset(); } catch (e) {} // ★16人対応: メッシュ・集計タイマーを全破棄
    try { if (P.state.peer) { P.state.peer.destroy(); } } catch (e) {}
    try { if (P.state.tempPeer) { P.state.tempPeer.destroy(); } } catch (e) {}
    P.state.peer = null; P.state.tempPeer = null;
    var h = el('pvpHomeView');
    if (!h) return;
    h.classList.remove('hidden');
    pvpSetHeaderClose(false);
    el('pvpRoomCodeBadge').classList.add('hidden');
    h.innerHTML =
      pvpTitlePanelHtml() +
      '<div class="grid md:grid-cols-2 gap-4">' +
      '  <div class="pvp-card-lux p-5">' +
      '    <h3 class="font-mincho text-lg font-bold text-emerald-300 mb-1"><i class="fa-solid fa-crown mr-1.5"></i>ホストとして入る</h3>' +
      '    <p class="text-xs text-gray-400 mb-3">部屋を作って対戦コードを発行します。レベル均一・枠数・ランク制限・敵ギミックを設定できます。</p>' +
      '    <button onclick="PVPROOT.openHostConfig()" class="w-full gold-button px-4 py-3 rounded-xl font-extrabold shadow-lg text-sm">部屋を作成（設定へ）</button>' +
      '  </div>' +
      '  <div class="pvp-card-lux p-5">' +
      '    <h3 class="font-mincho text-lg font-bold text-amber-300 mb-1"><i class="fa-solid fa-user-plus mr-1.5"></i>ゲストとして入る</h3>' +
      '    <p class="text-xs text-gray-400 mb-2">ホストからもらった対戦コードを入力して入室します（最大16人まで）。</p>' +
      '    <div class="flex gap-2">' +
      '      <input id="pvpJoinCode" placeholder="対戦コード（例: A1B2）" maxlength="4" class="flex-1 bg-black/70 border border-heian-gold/50 rounded-lg px-3 py-2.5 text-sm text-yellow-100 font-mono font-bold uppercase focus:outline-none focus:border-heian-gold" />' +
      '      <button onclick="PVPROOT.joinRoom()" class="gold-button px-4 py-2.5 rounded-lg font-extrabold text-sm shadow">入室</button>' +
      '    </div>' +
      '  </div>' +
      '</div>' +
      '<div class="bg-black/50 border border-heian-gold/30 rounded-xl p-4 text-xs text-gray-400 leading-relaxed">' +
      '  <div class="font-bold text-amber-300 mb-1.5"><i class="fa-solid fa-circle-info mr-1"></i>遊び方</div>' +
      '  <div class="pvp-steps">' +
      '    <div class="pvp-step"><b>① 部屋を作成</b><span>ホストが「部屋を作成」→ 設定（または公式設定）→ 部屋を立てる → 対戦コードを共有</span></div>' +
      '    <div class="pvp-step"><b>② ゲスト入室</b><span>コードを入力して入室 → 各プレイヤーは「編成」タブで部隊を整えます</span></div>' +
      '    <div class="pvp-step"><b>③ 対戦申し込み</b><span>部屋のメンバー一覧から「1対1を申し込む」→ 相手が応じると対戦開始</span></div>' +
      '    <div class="pvp-step"><b>④ クイズバトル</b><span>同じ古文単語クイズに双方回答。正解で相手にダメージ／不正解で反撃。片方のHPが0になるまで続く</span></div>' +
      '    <div class="pvp-step"><b>⑤ 再戦・退出</b><span>対戦後は部屋に戻り再戦・設定変更・退出が可能。ホストが抜けたら他のプレイヤーへ権限移譲</span></div>' +
      '  </div>' +
      '  <span class="text-gray-500 block mt-2">※ 通信には PeerJS のクラウドサーバーを使用します。GitHub Pages 等の https 環境でプレイしてください。</span>' +
      '</div>';
  }

  // ==================== UI: ホスト設定 ====================
  function renderCfg() {
    ['pvpHomeView', 'pvpLobbyView', 'pvpDuelView', 'pvpResultView'].forEach(function (id) { var x = el(id); if (x) x.classList.add('hidden'); });
    var v = el('pvpCfgView');
    v.classList.remove('hidden');
    pvpSetHeaderClose(false);
    var st = P.state.settings;
    function num(name, val, disabled) {
      var d = disabled ? ' disabled' : '';
      return '<label class="block"><span class="text-xs text-gray-400 block mb-1">' + name + '</span><input type="number" id="' + val + '" value="' + (st[val] === null ? '' : st[val]) + '" min="0" max="1000" class="w-full bg-black/70 border border-heian-gold/50 rounded-lg px-3 py-2 text-sm text-yellow-100 focus:outline-none focus:border-heian-gold"' + d + '></label>';
    }
    function rankIn(r) {
      var cur = st.rank[r];
      var vv = (cur === null || cur === undefined || cur === '') ? '' : cur;
      return '<label class="block"><span class="text-xs text-gray-400 block mb-1">' + r + 'ランク上限（空=無制限）</span><input type="number" id="pvpCfgRank' + r + '" value="' + vv + '" min="0" max="99" class="w-full bg-black/70 border border-heian-gold/50 rounded-lg px-3 py-2 text-sm text-yellow-100 focus:outline-none focus:border-heian-gold"></label>';
    }
    function gck(id, label, checked) {
      return '<label class="flex items-center gap-2 text-sm text-gray-200 bg-black/40 border border-heian-gold/20 rounded-lg px-3 py-2 cursor-pointer"><input id="' + id + '" type="checkbox" class="w-4.5 h-4.5 accent-purple-500"' + (checked ? ' checked' : '') + '><span>' + label + '</span></label>';
    }
    v.innerHTML =
      '<div class="pvp-card-lux p-5 space-y-4">' +
      '  <div class="flex flex-wrap items-center justify-between gap-2">' +
      '    <h3 class="font-mincho text-lg font-bold text-emerald-300"><i class="fa-solid fa-sliders mr-1.5"></i>ホスト設定</h3>' +
      '    <div class="flex gap-2">' +
      '      <button onclick="PVPROOT.applyOfficial()" class="bg-amber-500 hover:bg-amber-400 text-black px-3 py-1.5 rounded-lg text-xs font-extrabold shadow">⚡ 公式設定を適用</button>' +
      '      <button onclick="PVPROOT.backToHome()" class="bg-gray-700 hover:bg-gray-600 px-3 py-1.5 rounded-lg text-xs text-gray-200">戻る</button>' +
      '    </div>' +
      '  </div>' +
      '  <div class="p-3 bg-amber-500/10 border border-amber-500/40 rounded-xl text-xs text-amber-200"><b>公式設定（ワンクリック）:</b> レベル均一 300 ／ 神1体まで ／ UR3体まで ／ 枠10枠 ／ ギミックなし ／ <span class="text-red-300 font-bold">全回復無効化を載せる</span></div>' +
      '  <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">' +
      '    <label class="block"><span class="text-xs text-gray-400 block mb-1">レベル均一化</span>' +
      '      <select id="pvpCfgEqual" class="w-full bg-black/70 border border-heian-gold/50 rounded-lg px-3 py-2 text-sm text-yellow-100 focus:outline-none focus:border-heian-gold">' +
      '        <option value="1" ' + (st.equalize ? 'selected' : '') + '>ON（レベルを統一）</option>' +
      '        <option value="0" ' + (!st.equalize ? 'selected' : '') + '>OFF（各自の実レベル）</option>' +
      '      </select></label>' +
      '    <label class="block"><span class="text-xs text-gray-400 block mb-1">統一レベル（均一ON時）</span><input type="number" id="pvpCfgLevel" value="' + st.level + '" min="1" max="1000" class="w-full bg-black/70 border border-heian-gold/50 rounded-lg px-3 py-2 text-sm text-yellow-100 focus:outline-none focus:border-heian-gold"></label>' +
      '    <label class="block"><span class="text-xs text-gray-400 block mb-1">枠数（デッキ最大）</span><input type="number" id="pvpCfgSlots" value="' + st.slots + '" min="1" max="12" class="w-full bg-black/70 border border-heian-gold/50 rounded-lg px-3 py-2 text-sm text-yellow-100 focus:outline-none focus:border-heian-gold"></label>' +
      '  </div>' +
      '  <div class="grid grid-cols-2 sm:grid-cols-3 gap-3">' + rankIn('神') + rankIn('UR') + rankIn('SSR') + rankIn('SR') + rankIn('R') + rankIn('N') + '</div>' +
      '  <div>' +
      '    <div class="text-xs text-gray-400 mb-2">敵ギミック（対戦中のハザード。ホストが任意にONにできます）</div>' +
      '    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">' +
      gck('pvpCfgGMon', '🌙 月: レベル半減（35%で与ダメ半減 4問）', st.gimmicks.mon) +
      gck('pvpCfgGTue', '🔥 火: 寝返り（30%で先鋒が敵に加勢）', st.gimmicks.tue) +
      gck('pvpCfgGWed', '🎭 水: 変身（30%で部隊が混乱）', st.gimmicks.wed) +
      gck('pvpCfgGThu', '📜 木: 古語逆引きクイズ', st.gimmicks.thu) +
      gck('pvpCfgGFri', '🎲 金: ランダム編成（30%で相手が強化）', st.gimmicks.fri) +
      gck('pvpCfgGEn', '⚡ 強化: 敵強化モード（毎問10%で環境ダメージ）', st.gimmicks.enrage) +
      '    </div>' +
      '  </div>' +
      '  <div>' +
      '    <div class="text-xs text-gray-400 mb-2">回復ルール（ホストが任意に適用。既定はすべてOFF＝通常どおり回復します）</div>' +
      '    <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">' +
      gck('pvpCfgNoFullHeal', '🚫 全回復無効化（HPを全回復させる効果を封じる）', !!st.noFullHeal) +
      gck('pvpCfgNoHeal', '🩹 回復を全て無効化（すべてのHP回復効果を封じる）', !!st.noHeal) +
      '    </div>' +
      '  </div>' +
      '  <div class="flex justify-end gap-2 pt-1">' +
      '    <button onclick="PVPROOT.createRoom()" class="gold-button px-6 py-2.5 rounded-xl font-extrabold shadow-lg text-sm"><i class="fa-solid fa-tower-broadcast mr-1.5"></i>この設定で部屋を立てる</button>' +
      '  </div>' +
      '</div>';
  }

  // ==================== UI: ロビー ====================
  function renderLobby() {
    ['pvpHomeView', 'pvpCfgView', 'pvpDuelView', 'pvpResultView'].forEach(function (id) { var x = el(id); if (x) x.classList.add('hidden'); });
    var v = el('pvpLobbyView');
    v.classList.remove('hidden');
    pvpSetHeaderClose(false);
    var s = P.state;
    el('pvpRoomCodeBadge').classList.remove('hidden');
    el('pvpRoomCodeBadge').textContent = '対戦コード: ' + s.code;
    var me = s.players.find(function (p) { return p.slot === s.mySlot; }) || { name: s.myName, isHost: s.role === 'host' };
    var isHost = s.role === 'host';
    var myDeckIds = [];
    try { myDeckIds = getCombinedBattleDeckIds(); } catch (e) {}
    var deckValid = pvpValidateDeck(myDeckIds, s.settings).ok;
    var rows = s.players.map(function (p) {
      var self = p.slot === s.mySlot;
      var badges = p.isHost ? '<span class="text-[9px] bg-emerald-500/25 text-emerald-300 border border-emerald-400/40 rounded px-1.5 py-0.5 ml-1.5 font-bold">ホスト</span>' : '<span class="text-[9px] bg-gray-600/40 text-gray-300 border border-gray-500/40 rounded px-1.5 py-0.5 ml-1.5">ゲスト</span>';
      var buttons = '';
      if (!self && !deckValid) buttons = '<span class="text-[9px] text-gray-500">編成が未設定・制限超過</span>';
      else if (pbIsActive()) {
        var pbL = P.state.pointBattle;
        var lp = pbL.livePair;
        if (!self && lp && (lp.a === p.slot || lp.b === p.slot)) buttons = '<span class="text-[10px] text-red-300 font-bold">対戦中</span>';
        else if (!self) buttons = '<span class="text-[10px] text-gray-400">マッチング待機中</span>';
      } else if (!self && !(s.battle && s.battle.active)) buttons = '<button onclick="PVPROOT.challenge(' + p.slot + ')" class="bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold px-3 py-1.5 rounded-lg shadow">1対1を申し込む</button>';
      return '<div class="flex items-center justify-between bg-black/40 border border-heian-gold/20 rounded-xl px-4 py-2.5">' +
        '<div class="flex items-center gap-2 text-sm"><i class="fa-solid fa-user-circle text-amber-300"></i><span class="text-yellow-100 font-bold">' + esc(p.name) + '</span>' + badges + (self ? '<span class="text-[9px] text-cyan-300">（あなた）</span><span class="ml-1 text-[10px] font-black px-1.5 py-0.5 rounded border" style="color:' + PVP_TITLES[pvpTitleIndex()].color + ';border-color:' + PVP_TITLES[pvpTitleIndex()].color + '88;background:' + PVP_TITLES[pvpTitleIndex()].color + '1a">' + PVP_TITLES[pvpTitleIndex()].name + '</span>' : '') + '</div>' +
        '<div class="flex items-center gap-2">' + buttons + '</div></div>';
    }).join('');
    var pending = s.pendingChallenge ? '<div class="flex items-center justify-between bg-amber-500/15 border border-amber-500/40 rounded-xl px-4 py-3">' +
      '<span class="text-sm text-amber-200 font-bold">⚔️ ' + esc(s.pendingChallenge.fromName) + ' から1対1の申込が来ています</span>' +
      '<div class="flex gap-2"><button onclick="PVPROOT.challengeReply(true)" class="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-4 py-2 rounded-lg">受ける</button>' +
      '<button onclick="PVPROOT.challengeReply(false)" class="bg-gray-600 hover:bg-gray-500 text-white text-xs font-bold px-4 py-2 rounded-lg">拒否</button></div></div>' : '';
    var hostCfgBtn = '';
    if (isHost) {
      hostCfgBtn = '<button onclick="PVPROOT.openHostConfig()" class="bg-gray-700 hover:bg-gray-600 text-gray-200 text-xs font-bold px-3 py-2 rounded-lg">⚙ 設定を変更</button>';
    }
    var leaveBtn = '<button onclick="PVPROOT.leaveRoom()" class="bg-red-900 hover:bg-red-800 border border-red-500/50 text-red-200 text-xs font-bold px-3 py-2 rounded-lg"><i class="fa-solid fa-arrow-right-from-bracket mr-1"></i>退出</button>';
    v.innerHTML =
      '<div class="space-y-3">' + pending +
      '  <div class="bg-heian-darkpurple border-2 border-heian-gold/40 rounded-2xl p-4 shadow-xl">' +
      '    <div class="flex flex-wrap items-center justify-between gap-2 mb-3">' +
      '      <h3 class="font-mincho text-base font-bold text-yellow-200"><i class="fa-solid fa-users mr-1.5"></i>対戦部屋（' + s.players.length + '/' + MAX_ROOM + '人）</h3>' +
      '      <div class="flex gap-2">' + hostCfgBtn + leaveBtn + '</div>' +
      '    </div>' +
      '    <div class="space-y-2">' + rows + '</div>' +
      '    <div class="mt-3 flex items-center gap-2 text-[11px] text-gray-400">' +
      '      <span class="bg-black/60 border border-heian-gold/30 rounded px-2 py-1">あなたの編成: ' + (deckValid ? '<span class="text-emerald-300 font-bold">' + myDeckIds.length + '体（OK）</span>' : '<span class="text-red-300 font-bold">未対応</span>') + '</span>' +
      '      <button onclick="PVPROOT.openDeckEdit()" class="bg-purple-800 hover:bg-purple-700 text-purple-100 text-[11px] font-bold px-3 py-1.5 rounded-lg">編成画面を開く</button>' +
      '    </div>' +
      '    <div class="mt-2 text-[11px] text-gray-500">設定: ' + (s.settings.equalize ? 'レベル均一 ' + s.settings.level : '実レベル') + ' ／ 枠' + s.settings.slots + ' ／ 神' + (s.settings.rank['神'] === null || s.settings.rank['神'] === '' ? '∞' : s.settings.rank['神']) + '・UR' + (s.settings.rank['UR'] === null || s.settings.rank['UR'] === '' ? '∞' : s.settings.rank['UR']) + ' ／ ギミック: ' + (Object.keys(s.settings.gimmicks).filter(function (k) { return s.settings.gimmicks[k]; }).join('・') || 'なし') + ' ／ 回復: ' + ((s.settings.noHeal ? '全て無効' : (s.settings.noFullHeal ? '全回復のみ無効' : '通常'))) + '</div>' +
      '  </div>' +
      '<div id="pvpActiveMatchBanner" class="hidden bg-purple-950/80 border border-heian-gold/50 rounded-xl p-3 my-2 flex items-center justify-between gap-2 shadow-lg">' +
        '<div class="flex items-center gap-2 text-xs">' +
          '<span class="animate-pulse text-red-400">⚔️ 対戦中:</span>' +
          '<span id="pvpMatchPlayer1" class="font-bold text-amber-200">プレイヤーA</span>' +
          '<span class="text-gray-400">VS</span>' +
          '<span id="pvpMatchPlayer2" class="font-bold text-amber-200">プレイヤーB</span>' +
        '</div>' +
        '<button onclick="PVPROOT.joinAsSpectator()" class="gold-button text-xs px-3 py-1.5 rounded-lg font-bold shadow">' +
          '<i class="fa-solid fa-eye mr-1"></i> 観戦する' +
        '</button>' +
      '</div>' +
      pbLobbyHtml() +
      '</div>';
    try { pbArmLobbyTimer(); } catch (e) {}
    try { pbArmLobbyDeckRefresh(); } catch (e) {}
    try { updateSpectatorBanner(); } catch (e) {}
  }

  // ==================== UI: 対戦画面 ====================
  // ★修正: 問題エリアのみを組み立てる（次の問題への差し替えで HPバー・ダメージ演出を消さないため）
  function buildQuizHtml() {
    var s = P.state, b = s.battle;
    if (!b) return '';
    var q = '';
    var acting = !!(b.isPlayer && b.word && !b.answered);
    if (b.word) {
      var choices = b.choices || [];
      q =
        '<div class="bg-heian-card border-2 border-heian-gold rounded-2xl p-4 md:p-5 shadow-2xl">' +
        '  <div class="text-center mb-2 bg-black/60 py-1.5 px-2.5 rounded-xl border border-heian-gold/40">' +
        '    <div class="text-xs text-amber-300 font-bold mb-0.5">【' + ((b.myQnum || b.qnum || 1)) + '問目 · HPが尽きるまで対戦】' + (b.kogo ? '「' + esc(b.word) + '」の古語は？' : '次の古文単語の訳を選べ') + '</div>' +
        '    <div class="font-mincho text-xl md:text-2xl font-extrabold gold-gradient-text tracking-wide">' + (b.kogo ? '（上記の意味から）' : esc(b.word)) + '</div>' +
        '  </div>' +
        '  <div class="grid grid-cols-2 md:grid-cols-3 gap-1.5">' +
        choices.map(function (c, i2) {
          var dis = !acting ? ' disabled' : '';
          return '<button id="pvpChoice' + i2 + '" onclick="PVPROOT.answer(' + i2 + ')" class="pvp-choice ' + (b.isPlayer ? 'bg-black/50 hover:bg-purple-900/70 border border-heian-gold/50' : 'bg-black/30 border border-gray-600/40') + ' text-left text-xs text-yellow-100 rounded-xl px-2 py-2 font-bold transition' + dis + '">' + esc(c) + '</button>';
        }).join('') +
        '  </div>' +
        (b.isPlayer ? (b.answered ? '<div class="mt-1.5 text-center text-xs text-emerald-300 font-bold">⚡ 攻撃を反映中…（すぐに次の問題）</div>' : '<div class="mt-1.5 text-center text-[10px] text-gray-500">⚡ 正解すると即攻撃！必殺ゲージ100%でいつでも発動できます。</div>') : '<div class="mt-1.5 text-center text-xs text-gray-400 font-bold">👁 観戦中（回答はできません）</div><div class="mt-2 text-center"><button onclick="PVPROOT.closeSpectateView()" class="bg-gray-700 hover:bg-gray-600 px-3 py-1.5 rounded-lg text-[11px] text-gray-200 font-bold">部屋に戻る</button></div>') +
        '</div>';
    } else if (b.state === 'await') {
      q = '<div class="text-center py-8 text-gray-300 text-sm font-bold">' + (b.isPlayer ? '⚔️ 対戦準備中…' : '👁 対戦を待機中（観戦）…') + '</div>';
    } else {
      q = '<div class="text-center py-6 text-gray-400 text-sm">問題を配信しています…</div>';
    }
    return q;
  }

  // ==================== オンライン対戦: オフライン同一UI・サドンデス（追加実装） ====================
  // ---------- サドンデス定数: 2分(120秒)超で発動、5秒ごとに互いの攻撃力が2倍、背景が徐々に赤くなる ----------
  var PVP_SD_START = 120;
  var PVP_SD_DOUBLE_EVERY = 5;
  var PVP_SD_MAX_MULT = 1048576; // 2^20 上限（発散防止・float安全域）
  function pvpGetSD(b) {
    if (!b.suddenDeath) b.suddenDeath = { active: false, mult: 1, intensity: 0, stage: 0 };
    return b.suddenDeath;
  }
  function pvpUpdateSD() {
    var s = P.state, b = s.battle;
    if (!b || !b.active) return;
    var sd = pvpGetSD(b);
    if (!b._countdownDone) {
      sd.active = false; sd.mult = 1; sd.stage = 0; sd.intensity = 0;
      return;
    }
    if (!b.startedAt) b.startedAt = Date.now();
    var el = (Date.now() - b.startedAt) / 1000;
    var timeUp = (el >= PVP_SD_START);
    var isDraw = !!(b.players && b.players.length === 2 &&
      Math.round(b.players[0].hp) === Math.round(b.players[1].hp));
    var allowSD = !!b._sdAllowed;
    // ★ポイント争奪戦: 20分到達でホストが _forceSDAt を設定 → 試合経過時間・HP差に関係なく既存サドンデス処理を即時適用
    if (allowSD && b._forceSDAt) {
      sd.active = true;
      var stF = Math.floor((Date.now() - b._forceSDAt) / PVP_SD_DOUBLE_EVERY);
      sd.mult = Math.min(PVP_SD_MAX_MULT, Math.pow(2, stF + 1)); // 適用直後から×2スタート
      sd.stage = stF + 1;
      sd.intensity = Math.min(0.9, 0.25 + ((Date.now() - b._forceSDAt) / 150) * 0.65);
    } else if (timeUp && isDraw && allowSD) {
      sd.active = true;
      var st = Math.floor((el - PVP_SD_START) / PVP_SD_DOUBLE_EVERY);
      sd.mult = Math.min(PVP_SD_MAX_MULT, Math.pow(2, st));
      sd.stage = st + 1;
      sd.intensity = Math.min(0.9, 0.25 + ((el - PVP_SD_START) / 150) * 0.65);
    } else {
      sd.active = false; sd.mult = 1; sd.stage = 0; sd.intensity = 0;
    }
  }
  // サドンデス中の攻撃倍率（ホスト側のダメージ計算・反撃・必殺技すべてに適用）
  function pvpSDMult() {
    try {
      var b = P.state && P.state.battle;
      if (b && b.suddenDeath && b.suddenDeath.active) return b.suddenDeath.mult;
    } catch (e) { }
    return 1;
  }
  // 対戦中の定期更新（100ms）: サドンデス判定・HPバー・ゲージ・タイマー・背景
  function pvpArmBattleLoop() {
    if (P._pvpLoop) return;
    P._pvpLoop = __PERF.keepAliveInterval(function () {
      var s = P.state, b = s.battle;
      if (!b || !b.active) { if (P._pvpLoop) { clearInterval(P._pvpLoop); P._pvpLoop = null; } return; }
      pvpUpdateSD();
      pvpRenderStatus();
      var dom = P._pvpDomCache || {};
      var ov = dom.pvpSDOverlay;
      var sd = b.suddenDeath;
      if (ov) {
        if (sd && sd.active) {
          ov.style.display = 'flex';
          ov.style.opacity = sd.intensity;
          var lbl = dom.pvpSDMultLabel;
          if (lbl) lbl.textContent = '攻撃力 \u00d7' + sd.mult + '（5秒ごとに2倍）';
        } else {
          ov.style.display = 'none';
          ov.style.opacity = 0;
        }
      }
    }, 100);
  }
  // HPバー・ダメージ数字・必殺ゲージ・敵攻勢バー・COMBO・サドンデスのみ高速更新（DOM再構築なし）
  function pvpRenderStatus() {
    var s = P.state, b = s.battle;
    if (!b || !b.active) return;
    var dom = P._pvpDomCache;
    if (!dom) {
      dom = P._pvpDomCache = {
        pvpSDOverlay: el('pvpSDOverlay'), pvpSDMultLabel: el('pvpSDMultLabel'),
        pvpPlayerHpBar: el('pvpPlayerHpBar'), pvpPlayerHpText: el('pvpPlayerHpText'),
        pvpEnemyHpBar: el('pvpEnemyHpBar'), pvpEnemyHpText: el('pvpEnemyHpText'),
        pvpEnemyTimerBar: el('pvpEnemyTimerBar'), pvpComboBanner: el('pvpComboBanner'),
        pvpComboCountText: el('pvpComboCountText'), pvpBattleStageTitle: el('pvpBattleStageTitle'),
        myGaugeBars: Array.from(document.querySelectorAll('#pvpPartyRow .pvp-gauge-bar')),
        myGaugeTexts: Array.from(document.querySelectorAll('#pvpPartyRow .pvp-gauge-text')),
        oppGaugeBars: Array.from(document.querySelectorAll('#pvpEnemyRosterRow .pvp-gauge-bar')),
        oppGaugeTexts: Array.from(document.querySelectorAll('#pvpEnemyRosterRow .pvp-gauge-text'))
      };
    }
    var youIdx = b.isPlayer ? b.you : -1;
    var myIdx = youIdx;
    var oppIdx = (youIdx === 0) ? 1 : ((youIdx === 1) ? 0 : 0);
    function w(key, pct) { var x = dom[key]; if (x) x.style.width = Math.max(0, Math.min(100, pct)) + '%'; }
    function t(key, txt) { var x = dom[key]; if (x && x.textContent !== String(txt)) x.textContent = txt; }
    var hpMy = myIdx === 0 ? b.hpA : (myIdx === 1 ? b.hpB : 0);
    var hpOpp = oppIdx === 0 ? b.hpA : b.hpB;
    var mxMy = myIdx === 0 ? b.maxA : (myIdx === 1 ? b.maxB : 1);
    var mxOpp = oppIdx === 0 ? b.maxA : b.maxB;
    w('pvpPlayerHpBar', mxMy > 0 ? hpMy / mxMy * 100 : 0);
    t('pvpPlayerHpText', Math.ceil(hpMy).toLocaleString() + ' / ' + mxMy.toLocaleString());
    w('pvpEnemyHpBar', mxOpp > 0 ? hpOpp / mxOpp * 100 : 0);
    t('pvpEnemyHpText', Math.ceil(hpOpp).toLocaleString() + ' / ' + mxOpp.toLocaleString());
    // 敵攻勢まで（オフラインと同レイアウト）: 問題表示からの経過でチャージ表示
    var qp = 0;
    if (b.state === 'question' && b._qAt) qp = Math.min(100, ((Date.now() - b._qAt) / 5000) * 100);
    w('pvpEnemyTimerBar', qp);
    // 必殺ゲージ（自分側カード / 相手側チップ）
    var gsMy = myIdx === 0 ? (b.gaugesA || []) : (myIdx === 1 ? (b.gaugesB || []) : []);
    var gsOpp = oppIdx === 0 ? (b.gaugesA || []) : (b.gaugesB || []);
    function updGauges(gs, parentId) {
      if (!gs || !gs.length) return;
      var bars = parentId === 'pvpPartyRow' ? dom.myGaugeBars : dom.oppGaugeBars;
      var txts = parentId === 'pvpPartyRow' ? dom.myGaugeTexts : dom.oppGaugeTexts;
      gs.forEach(function (g, i) {
        var pct = Math.max(0, Math.min(100, g));
        if (bars[i]) bars[i].style.width = pct + '%';
        if (txts[i]) txts[i].textContent = Math.floor(g) + '%';
      });
    }
    updGauges(gsMy, 'pvpPartyRow');
    updGauges(gsOpp, 'pvpEnemyRosterRow');
    // COMBO表示（オフラインと同一のバナー）
    var cb = dom.pvpComboBanner, cc = dom.pvpComboCountText;
    var myCombo = myIdx === 0 ? (b.myComboA || 0) : (myIdx === 1 ? (b.myComboB || 0) : 0);
    if (cb) {
      if (myCombo >= 2) { cb.classList.remove('hidden'); if (cc) cc.textContent = myCombo; }
      else { cb.classList.add('hidden'); }
    }
    // サドンデス中はタイトルにも表示
    var sdA = b.suddenDeath;
    var st2 = dom.pvpBattleStageTitle;
    if (st2) {
      if (sdA && sdA.active) {
        var sdTitle = 'ネット対戦 <span class="text-red-400 font-black">\u2620 \u30b5\u30c9\u30f3\u30c7\u30b9\uff01\u653b\u6483\u529b\u00d7' + sdA.mult + '</span>';
        if (st2.innerHTML !== sdTitle) st2.innerHTML = sdTitle;
      } else if (st2.innerHTML !== 'ネット対戦') {
        st2.innerHTML = 'ネット対戦';
      }
    }
  }
  // 自分側のユニットカード（オフラインのパーティUIと同形式: 必殺ボタン/ゲージ/スキル名）
  function pvpMyCards(me, gauges, b) {
    var party = (me && me.party) || [];
    if (!party.length) return '<span class="text-[10px] text-gray-500">\u90e8\u968a\u306a\u3057</span>';
    var hideSkills = !!(typeof state !== 'undefined' && state && state.settings && state.settings.hideBattleSkills);
    return party.map(function (u, i) {
      var g = (gauges && gauges[i] !== undefined) ? Math.max(0, Math.min(100, gauges[i])) : 0;
      var ready = g >= 100;
      var fired = !!(b.specFired && b.specFired[i]);
      var btn = '';
      if (b.active && ready && !fired) {
        btn = '<button onclick="PVPROOT.fireSpecial(' + i + ')" class="w-full py-0.5 text-[9px] font-extrabold rounded special-ready-btn shadow">\u5fc5\u6bba\u767a\u52d5!<span class="block text-[6px] font-mono opacity-80">' + esc((u.specialName || '\u5965\u7fa9')) + '</span></button>';
      } else if (fired) {
        btn = '<div class="w-full my-1 text-center text-[8px] text-emerald-300 font-bold">\ud83d\udcab \u767a\u52d5\u6e08\u307f</div>';
      } else {
        btn = '<div class="w-full bg-gray-900 rounded-full h-1.5 border border-amber-500/40 overflow-hidden"><div class="pvp-gauge-bar bg-gradient-to-r from-amber-500 to-yellow-300 h-full transition-all duration-200" style="width:' + g.toFixed(1) + '%"></div></div><span class="text-[7px] text-amber-300 font-mono font-bold pvp-gauge-text">' + Math.floor(g) + '%</span>';
      }
      return '<div class="p-1.5 rounded-lg border flex flex-col items-center justify-between relative text-center transition bg-black/60 border-heian-gold/40">' +
        '<div class="w-8 h-8 rounded-full bg-heian-purple border border-heian-gold flex items-center justify-center text-heian-gold text-xs my-0.5"><i class="fa-solid ' + (u.icon || 'fa-user') + '"></i></div>' +
        '<span class="text-[9px] font-bold font-mincho text-yellow-100 truncate w-full">' + esc(u.name) + '</span>' +
        (hideSkills ? '' : '<div class="text-[6px] text-cyan-300 truncate w-full leading-tight" title="' + (u.skill ? esc(u.skill.effect || '') : '') + '">' + (u.skill ? esc(u.skill.name) : '') + '</div>') +
        '<div class="w-full my-1">' + btn + '</div></div>';
    }).join('');
  }
  // 相手側の部隊チップ（オフライン金曜ギミックの敵編成パネルと同形式）
  function pvpEnemyChips(party, gauges) {
    var party2 = party || [];
    if (!party2.length) return '<span class="text-[10px] text-gray-500">\u90e8\u968a\u306a\u3057</span>';
    return party2.map(function (u, i) {
      var g = (gauges && gauges[i] !== undefined) ? Math.max(0, Math.min(100, gauges[i])) : 0;
      return '<div class="text-center bg-red-950/60 rounded p-1 border border-red-400/30" title="' + esc(u.name) + ' / Lv.' + (u.lvl || 1) + '">' +
        '<div class="w-8 h-8 mx-auto rounded-full bg-red-900 border border-red-300/60 flex items-center justify-center text-red-200"><i class="fa-solid ' + (u.icon || 'fa-user') + '"></i></div>' +
        '<div class="text-[8px] text-red-100 truncate mt-0.5">' + esc(u.name) + '</div>' +
        '<div class="w-full bg-gray-900 rounded-full h-1 border border-amber-500/40 overflow-hidden mt-0.5"><div class="pvp-gauge-bar bg-gradient-to-r from-amber-500 to-yellow-300 h-full" style="width:' + g.toFixed(1) + '%"></div></div>' +
        '<div class="text-[7px] text-amber-300 font-mono font-bold pvp-gauge-text">' + Math.floor(g) + '%</div></div>';
    }).join('');
  }

  // ==================== UI: 対戦画面（オフラインと同一レイアウトで、敵枠にオンラインの対戦相手を表示） ====================
  function renderDuel() {
    var s = P.state, b = s.battle;
    if (!b) return;
    ['pvpHomeView', 'pvpCfgView', 'pvpLobbyView', 'pvpResultView'].forEach(function (id) { var x = el(id); if (x) x.classList.add('hidden'); });
    var v = el('pvpDuelView');
    v.classList.remove('hidden');
    pvpSetHeaderClose(!!(b.active));
    el('pvpRoomCodeBadge').classList.remove('hidden');
    pvpUpdateSD();
    var pA = b.players[0] || { name: 'A', party: [] };
    var pB = b.players[1] || { name: 'B', party: [] };
    var youIdx = b.isPlayer ? b.you : -1;
    var myIdx = youIdx;
    var oppIdx = (youIdx === 0) ? 1 : ((youIdx === 1) ? 0 : 0);
    var me = myIdx >= 0 ? (myIdx === 0 ? pA : pB) : pA;
    var opp = oppIdx === 0 ? pA : pB;
    var gMy = myIdx === 0 ? (b.gaugesA || []) : (myIdx === 1 ? (b.gaugesB || []) : []);
    var gOpp = oppIdx === 0 ? (b.gaugesA || []) : (b.gaugesB || []);
    var hpMy = myIdx === 0 ? b.hpA : (myIdx === 1 ? b.hpB : 0);
    var hpOpp = oppIdx === 0 ? b.hpA : b.hpB;
    var mxMy = myIdx === 0 ? b.maxA : (myIdx === 1 ? b.maxB : 1);
    var mxOpp = oppIdx === 0 ? b.maxA : b.maxB;
    var mySyn = (me.synCount !== undefined) ? me.synCount : ((me.synText !== undefined) ? me.synText : 0);
    var oppLeader = (opp.party && opp.party[0]) ? opp.party[0] : null;
    var oppIcon = oppLeader ? (oppLeader.icon || 'fa-user') : 'fa-ghost';
    var __specHeader = '' +
      '<div id="pvpSpectatorHeader" class="hidden flex justify-between items-center bg-black/60 p-2 rounded-lg border border-purple-500/40 mb-2">' +
        '<span class="text-xs text-purple-300 font-bold"><i class="fa-solid fa-eye mr-1"></i> 観戦モード中</span>' +
        '<button onclick="PVPROOT.leaveSpectator()" class="text-xs bg-gray-800 hover:bg-gray-700 text-gray-200 border border-gray-500 px-3 py-1 rounded-lg font-bold">' +
          '<i class="fa-solid fa-arrow-left mr-1"></i> 観戦を抜けてロビーへ' +
        '</button>' +
      '</div>';
    v.innerHTML = __specHeader +
      '<div class="bg-heian-darkpurple px-3 py-2 rounded-xl border-2 border-heian-gold/50 shadow-xl flex flex-wrap justify-between items-center gap-2">' +
      '  <div>' +
      '    <span id="pvpBattleStageTitle" class="font-mincho text-sm md:text-base font-bold gold-gradient-text">\u30cd\u30c3\u30c8\u5bfe\u6226</span>' +
      '    <div id="pvpBattleTopSubText" class="text-[10px] md:text-xs text-gray-300">\u53e4\u6587\u5358\u8a9e\u3092\u6b63\u89e3\u3057\u3066\u81ea\u9663\u3092\u9632\u885b\u305b\u3088\uff01\u76f8\u624b\u306f\u30aa\u30f3\u30e9\u30a4\u30f3\u306e\u5bfe\u6226\u76f8\u624b\uff08' + esc(opp.name) + '\uff09</div>' +
      '    <div class="text-[9px] text-amber-300 font-bold mt-0.5">\u2756 \u79f0\u53f7: ' + PVP_TITLES[pvpTitleIndex()].name + ' \uff5c \u5bfe\u6226\u30dd\u30a4\u30f3\u30c8: ' + pvpPoints().toLocaleString() + 'pt \uff5c \u6b21\u306e\u79f0\u53f7\u307e\u3067 \u3042\u3068 ' + pvpPointsToNext().toLocaleString() + 'pt</div>' +
      '  </div>' +
      '  <div class="flex items-center gap-2">' +
      '    <div id="pvpComboBanner" class="hidden bg-gradient-to-r from-amber-500 to-red-600 text-black px-3.5 py-1 rounded-full font-black text-xs md:text-sm shadow-lg animate-bounce"><span id="pvpComboCountText">2</span> COMBO!!</div>' +
      '  </div>' +
      '</div>' +
      '<div class="my-1.5 grid grid-cols-2 gap-2 items-stretch relative">' +
      '  <!-- \u30d7\u30ec\u30a4\u30e4\u30fc\u81ea\u9663: \u30aa\u30d5\u30e9\u30a4\u30f3\u3068\u540c\u4e00UI -->' +
      '  <div id="pvpPlayerSideBox" class="bg-gradient-to-r from-blue-950/70 via-purple-950/50 to-black/80 p-2 rounded-2xl border-2 border-blue-500/40 flex flex-col justify-between relative overflow-hidden shadow-2xl transition-all">' +
      '    <div class="flex justify-between items-center mb-1.5"><span class="text-xs md:text-sm font-bold text-blue-300 flex items-center gap-1.5"><i class="fa-solid fa-shield-halved text-cyan-400"></i> \u30d7\u30ec\u30a4\u30e4\u30fc\u81ea\u9663 (\u9632\u885b\u30e9\u30a4\u30f3)</span><span id="pvpPlayerHpText" class="text-xs md:text-sm font-mono font-bold text-blue-200">' + Math.ceil(hpMy).toLocaleString() + ' / ' + mxMy.toLocaleString() + '</span></div>' +
      '    <div class="w-full bg-gray-900 rounded-full h-2.5 border border-blue-400/50 overflow-hidden mb-2 relative"><div id="pvpPlayerHpBar" class="bg-gradient-to-r from-blue-500 via-cyan-400 to-teal-300 h-full transition-all duration-300" style="width:' + (mxMy > 0 ? Math.max(0, Math.min(100, hpMy / mxMy * 100)) : 0) + '%"></div></div>' +
      '    <div id="pvpPlayerStatusIcons" class="flex flex-wrap gap-1 mb-1 min-h-[16px]"></div>' +
      '    <div class="mb-1.5 p-1.5 bg-black/60 rounded-lg border border-heian-gold/30 flex flex-col gap-1 text-[10px]" id="pvpActiveSynergies"><span class="text-gray-400">\u767a\u52d5\u4e2d\u306e\u30b7\u30ca\u30b8\u30fc: ' + (mySyn > 0 ? '<span class="text-amber-300 font-bold">' + mySyn + '\u4ef6</span>' : '\u306a\u3057') + '</span></div>' +
      '    <div id="pvpPartyRow" class="grid grid-cols-5 gap-1.5 my-0.5">' + pvpMyCards(me, gMy, b) + '</div>' +
      '  </div>' +
      '  <!-- \u6575\u67a0: \u672c\u6765\u306e\u6575\u306e\u5834\u6240\u306b\u30aa\u30f3\u30e9\u30a4\u30f3\u306e\u5bfe\u6226\u76f8\u624b\u3092\u8868\u793a -->' +
      '  <div id="pvpEnemySideBox" class="bg-gradient-to-l from-red-950/70 via-purple-950/50 to-black/80 p-2 rounded-2xl border-2 border-red-500/40 flex flex-col justify-between relative overflow-hidden shadow-2xl transition-all">' +
      '    <div class="flex justify-between items-center mb-1.5"><span id="pvpEnemyNameText" class="text-xs md:text-sm font-bold text-red-300 font-mincho"><i class="fa-solid fa-skull mr-1"></i> ' + esc(opp.name) + '</span><span id="pvpEnemyHpText" class="text-xs md:text-sm font-mono font-bold text-red-200">' + Math.ceil(hpOpp).toLocaleString() + ' / ' + mxOpp.toLocaleString() + '</span></div>' +
      '    <div class="w-full bg-gray-900 rounded-full h-2.5 border border-red-400/50 overflow-hidden mb-2 relative"><div id="pvpEnemyHpBar" class="bg-gradient-to-r from-red-600 via-amber-500 to-yellow-400 h-full transition-all duration-300" style="width:' + (mxOpp > 0 ? Math.max(0, Math.min(100, hpOpp / mxOpp * 100)) : 0) + '%"></div></div>' +
      '    <div id="pvpEnemyStatusIcons" class="flex flex-wrap gap-1 mb-1 min-h-[16px]"></div>' +
      '    <div class="flex-1 flex flex-col items-stretch justify-start p-1 bg-black/30 rounded-lg border border-red-500/20 my-1">' +
      (opp.party && opp.party.length ? '<div class="w-full p-1 rounded-lg bg-black/50 border border-red-400/40"><div class="text-[10px] text-red-200 font-bold mb-1"><i class="fa-solid fa-users mr-1"></i>\u76f8\u624b\u306e\u90e8\u968a\uff08' + opp.party.length + '\u4f53\uff09</div><div class="grid grid-cols-5 gap-0.5" id="pvpEnemyRosterRow">' + pvpEnemyChips(opp.party, gOpp) + '</div></div>' : '') +
      '    </div>' +
      '  </div>' +
      '</div>' +
      '<div id="pvpQuizBox" class="bg-heian-card border-2 border-heian-gold rounded-2xl p-3 shadow-2xl relative transition-all">' + buildQuizHtml() + '</div>' +
      '<div id="pvpSDOverlay" class="fixed inset-0 pointer-events-none z-[70] flex items-center justify-center" style="display:none;background:radial-gradient(circle,rgba(190,30,30,0.55),rgba(130,0,0,0.9));opacity:0;transition:opacity 0.6s">' +
      '  <div class="text-center"><div class="font-mincho text-2xl md:text-3xl font-black text-red-100 drop-shadow-[0_2px_6px_rgba(0,0,0,0.9)] animate-pulse">\u2620 \u30b5\u30c9\u30f3\u30c7\u30b9!!</div><div id="pvpSDMultLabel" class="text-xs text-red-200 font-bold mt-1">\u653b\u6483\u529b \u00d71\uff085\u79d2\u3054\u3068\u306b2\u500d\uff09</div></div>' +
      '</div>';
    P._pvpDomCache = null;
    if (b.isPlayer && b.answered && b.myChoice >= 0) { var qb = el('pvpChoice' + b.myChoice); if (qb) qb.classList.add('bg-emerald-900/60'); }
    // ★修正: 途中で例外が起きても「スタート」カウントダウンが必ず走るよう個別に保護
    try { pvpArmBattleLoop(); } catch (e) {}
    try { pvpRenderStatus(); } catch (e) {}
    try { pvpBeginCountdownIfNeeded(); } catch (e) {}
    try { updateSpectatorHeader(); } catch (e) {}
    try { updateSpectatorBanner(); } catch (e) {}
  }

  function renderDuelQuiz() {
    var s = P.state, b = s.battle;
    if (!b) return;
    b.answered = false; b.myChoice = -1;
    b.specFired = [];
    b._qAt = Date.now();
    // ★修正: クイズ更新時は問題エリアのみ差し替え（HPバー・ダメージ演出を保持したまま即次問へ）
    var qa = el('pvpQuizBox');
    if (qa) {
      qa.innerHTML = buildQuizHtml();
      if (b.isPlayer && b.answered) { var qb = el('pvpChoice' + b.myChoice); if (qb) qb.classList.add('bg-emerald-900/60'); }
      return;
    }
    renderDuel();
  }

  // ==================== UI: 結果 ====================
  function renderResult() {
    var s = P.state, b = s.battle;
    if (!b) return;
    ['pvpHomeView', 'pvpCfgView', 'pvpLobbyView', 'pvpDuelView'].forEach(function (id) { var x = el(id); if (x) x.classList.add('hidden'); });
    var v = el('pvpResultView');
    v.classList.remove('hidden');
    pvpSetHeaderClose(false);
    var iWon = b.isPlayer && (b.winnerSlot === s.mySlot);
    var iAmWinner = iWon;
    var title = b.isPlayer ? (iAmWinner ? '🏆 勝利！' : (b.winnerSlot === null ? '🤝 引き分け' : '💀 敗北…')) : '👁 観戦結果';
    var sub = (b.winnerName ? b.winnerName + ' の勝利（' + (b.reason || 'HP0') + '）' : (b.reason || '')) + ' ／ ' + (b.lastQnum || 0) + '問まで進行';
    var meta = (b.pts && s.mySlot !== undefined && b.pts[s.mySlot]) ? b.pts[s.mySlot] : null;
    var rematchBtn = '';
    if (b.isPlayer && !pbIsActive()) {
      var targetSlot = (s.battle.a === s.mySlot) ? s.battle.b : s.battle.a;
      rematchBtn = '<button onclick="PVPROOT.rematch(' + targetSlot + ')" class="gold-button px-5 py-2.5 rounded-xl font-extrabold shadow-lg text-sm"><i class="fa-solid fa-rotate-right mr-1.5"></i>再戦する</button>';
    }
    v.innerHTML =
      '<div class="bg-heian-darkpurple border-2 border-heian-gold/50 rounded-2xl p-6 text-center shadow-xl max-w-lg mx-auto">' +
      '  <div class="text-3xl font-mincho font-black gold-gradient-text mb-1">' + title + '</div>' +
      '  <div class="text-sm text-gray-300 mb-4">' + esc(sub) + '</div>' +
      (meta ? '  <div class="text-xs mx-auto max-w-sm rounded-xl px-3 py-2 mb-3 ' + (meta.elig ? 'bg-amber-500/10 border border-amber-500/40' : 'bg-gray-700/30 border border-gray-600/40') + '">' + (meta.elig ? '🏯 称号ポイント: <span class="font-mono font-black ' + (meta.delta >= 0 ? 'text-emerald-300' : 'text-red-300') + '">' + (meta.delta > 0 ? '+' : '') + meta.delta + ' pt</span>（' + esc(meta.reason) + '）<br><span class="text-[10px] text-gray-400">現在: ' + PVP_TITLES[pvpTitleIndex()].name + ' ／ ' + pvpPoints().toLocaleString() + 'pt ／ 次称号まで ' + pvpPointsToNext().toLocaleString() + 'pt</span>' : '⚖ 称号ポイント対象外（公式設定・全体正解20問・30秒以上が必要）') + '</div>' : '') +
      '  <div class="grid grid-cols-2 gap-3 mb-5 text-sm">' +
      '    <div class="bg-black/40 border border-red-500/40 rounded-xl py-3"><div class="text-[10px] text-red-300 font-bold">' + esc((b.players && b.players[0] ? b.players[0].name : 'A')) + '</div><div class="font-mono font-black text-red-200">' + Math.max(0, Math.round(b.hpA)).toLocaleString() + ' / ' + b.maxA.toLocaleString() + '</div></div>' +
      '    <div class="bg-black/40 border border-blue-500/40 rounded-xl py-3"><div class="text-[10px] text-blue-300 font-bold">' + esc((b.players && b.players[1] ? b.players[1].name : 'B')) + '</div><div class="font-mono font-black text-blue-200">' + Math.max(0, Math.round(b.hpB)).toLocaleString() + ' / ' + b.maxB.toLocaleString() + '</div></div>' +
      '  </div>' +
      '  <div class="flex justify-center gap-2 flex-wrap">' + rematchBtn +
      '    <button onclick="PVPROOT.backToLobby()" class="bg-gray-700 hover:bg-gray-600 px-5 py-2.5 rounded-xl text-sm text-gray-200 font-bold">部屋に戻る</button>' +
      '  </div>' +
      '</div>';
  }

  // ==================== 操作API ====================
  // ★ 現在の設定が「公式設定」と完全一致するか（一致するときだけ称号ポイント獲得対象）
  function isOfficialSettings(s) {
    if (!s) return false;
    if (s.equalize !== true || Number(s.level) !== 300 || Number(s.slots) !== 10) return false;
    if (!s.rank) return false;
    if (Number(s.rank['神']) !== 1 || Number(s.rank['UR']) !== 3) return false;
    var free = ['SSR', 'SR', 'R', 'N'];
    for (var i = 0; i < free.length; i++) {
      var v = s.rank[free[i]];
      if (v !== null && v !== undefined && String(v) !== '') return false;
    }
    var g = s.gimmicks || {};
    if (g.mon || g.tue || g.wed || g.thu || g.fri || g.enrage) return false;
    if (s.noFullHeal !== true || s.noHeal !== false) return false;
    return true;
  }
  function applySettingsFromUI() {
    var s = P.state.settings;
    s.equalize = (el('pvpCfgEqual').value === '1');
    s.level = Math.max(1, Math.min(1000, parseInt(el('pvpCfgLevel').value, 10) || 300));
    s.slots = Math.max(1, Math.min(12, parseInt(el('pvpCfgSlots').value, 10) || 10));
    RARITY_ORDER.forEach(function (r) {
      var inp = el('pvpCfgRank' + r);
      if (!inp) return;
      var v2 = String(inp.value).trim();
      if (v2 === '' || v2 === null) s.rank[r] = null;
      else s.rank[r] = Math.max(0, Math.min(99, parseInt(v2, 10) || 0));
    });
    s.gimmicks.mon = !!(el('pvpCfgGMon') && el('pvpCfgGMon').checked);
    s.gimmicks.tue = !!(el('pvpCfgGTue') && el('pvpCfgGTue').checked);
    s.gimmicks.wed = !!(el('pvpCfgGWed') && el('pvpCfgGWed').checked);
    s.gimmicks.thu = !!(el('pvpCfgGThu') && el('pvpCfgGThu').checked);
    s.gimmicks.fri = !!(el('pvpCfgGFri') && el('pvpCfgGFri').checked);
    s.gimmicks.enrage = !!(el('pvpCfgGEn') && el('pvpCfgGEn').checked);
    // ★③④修正: 回復無効化トグル
    s.noFullHeal = !!(el('pvpCfgNoFullHeal') && el('pvpCfgNoFullHeal').checked);
    s.noHeal = !!(el('pvpCfgNoHeal') && el('pvpCfgNoHeal').checked);
    s.official = isOfficialSettings(s); // ★ 公式設定と完全一致のときだけ公式扱い（少しでも変えれば対象外）
  }
  function applyOfficial() {
    var s = P.state.settings;
    s.equalize = true; s.level = 300; s.slots = 10;
    s.rank['神'] = 1; s.rank['UR'] = 3; s.rank['SSR'] = null; s.rank['SR'] = null; s.rank['R'] = null; s.rank['N'] = null;
    s.gimmicks = { mon: false, tue: false, wed: false, thu: false, fri: false, enrage: false };
    s.noFullHeal = true; s.noHeal = false; // 公式設定では「全回復無効化」を自動でONにする（部分回復は許可）
    s.official = true; // ★ 称号システム: 公式設定の対戦のみポイント獲得対象
    renderCfg();
    pvpToast('公式設定を適用しました', 'レベル均一 300 ／ 神1体 ／ UR3体 ／ 枠10枠 ／ ギミックなし ／ 全回復無効化ON');
  }

  // ---------- ホスト: 部屋作成 ----------
  function createRoom() {
    // ★軽量改修: PeerJS 未読込なら読み込んでから再実行（オンライン処理の分離）
    if (typeof Peer === 'undefined') { try { __pvpEnsure(createRoom); } catch (e) {} return; }
    // 部屋作成済みなら「設定更新」として扱う（再作成しない）
    if (P._roomCreated && P.state.role === 'host' && P.state.peer) {
      applySettingsFromUI();
      hostBroadcast(playersPayload());
      renderLobby();
      pvpToast('設定を更新しました', P.state.settings.equalize ? 'レベル均一 ' + P.state.settings.level : '実レベル' + ' ／ 枠' + P.state.settings.slots);
      return;
    }
    applySettingsFromUI();
    P._roomCreated = true;
    P.state.role = 'host';
    P.state.code = randCode(4).toUpperCase();
    P.state.mySlot = 0;
    P.state.myName = getName();
    P.state.players = [{ slot: 0, name: P.state.myName, isHost: true, peerId: null }];
    P.state.guestConns = {};
    var pid = 'tk315pvp-' + P.state.code.toLowerCase() + '-h';
    var peer = new Peer(pid, { debug: 1 });
    P.state.peer = peer;
    peer.on('open', function (id) {
      jlog('host peer open', id);
      P.state.players[0].peerId = id;
      // ★16人対応: ホストもトポロジー構築を開始（現時点はホストのみ）
      try { P2P.syncTopology(); } catch (e) {}
      renderLobby();
      pvpToast('部屋を作成しました', '対戦コード: ' + P.state.code + '\nこのコードをゲストに伝えてください。\n（最大16人まで入室できます）');
    });
    // ★16人対応: 既知プレイヤー=メッシュ登録 / 新規ゲスト=従来の入室ハンドシェイクへ自動振分
    peer.on('connection', function (conn) { onPeerConn(conn); });
    peer.on('error', function (err) {
      jlog('host peer err', err.type, err);
      if (err && (err.type === 'unavailable-id' || err.type === 'peer-unavailable')) {
        pvpShowErr('その対戦コードは使用中です。コードを変えて再度お試しください。');
      } else {
        pvpShowErr('通信エラー: ' + (err && err.type ? err.type : '不明') + '\nPeerJS クラウドに接続できない可能性があります。');
      }
    });
    renderCfg(); // 設定画面のまま「部屋を立てる」→ ロビーへ
  }

  // ---------- ゲスト: 入室 ----------
  function joinRoom() {
    // ★軽量改修: PeerJS 未読込なら読み込んでから再実行
    if (typeof Peer === 'undefined') { try { __pvpEnsure(joinRoom); } catch (e) {} return; }
    var code = String(el('pvpJoinCode').value || '').trim().toUpperCase();
    if (!/^[A-Z0-9]{4}$/.test(code)) { pvpToast('対戦コードが不正です', '4文字のコード（例: A1B2）を入力してください。'); return; }
    resetState();
    var s = P.state;
    s.role = 'guest';
    s.code = code;
    s.myName = getName();
    s.players = [];
    s.hostConn = null;
    var tempId = 'tk315pvp-g-' + String(Math.floor(Math.random() * 100000));
    var tp = new Peer(tempId, { debug: 1 });
    s.tempPeer = tp;
    pvpShowErr('');
    tp.on('open', function () {
      jlog('temp peer open');
      var c = tp.connect('tk315pvp-' + code.toLowerCase() + '-h', { reliable: true });
      s.tempConn = c;
      c.on('open', function () { jlog('temp conn open'); c.send({ t: 'join', name: s.myName }); });
      c.on('data', function (d) {
        if (d && d.t === 'welcome') {
          // welcome を受けたら固定IDへ移行（guestHandleData内で実施）
          guestHandleData(d);
        } else if (d && d.t) { guestHandleData(d); }
      });
      c.on('close', function () { if (P.state.tempConn === c) P.state.tempConn = null; if (P.state.role === 'guest' && !P.state.hostConn && !P._welcomeReceived) pvpShowErr('ホストに接続できませんでした。コードが正しいか確認してください。'); });
      c.on('error', function () { pvpShowErr('ホストへの接続に失敗しました。コードを確認してください。'); });
    });
    tp.on('error', function (err) {
      jlog('guest temp peer err', err);
      pvpShowErr('PeerJS クラウドに接続できません。ネットワークと通信環境を確認してください。');
    });
  }

  function pvpShowErr(msg) {
    var e = el('pvpErr');
    if (!e) return;
    if (!msg) { e.classList.add('hidden'); e.textContent = ''; return; }
    e.textContent = msg;
    e.classList.remove('hidden');
  }

  // ---------- 操作 ----------
  function challenge(slot) {
    var s = P.state;
    var ids = [];
    try { ids = getCombinedBattleDeckIds(); } catch (e) {}
    var v = pvpValidateDeck(ids, s.settings);
    if (!v.ok) { pvpToast('編成が制限に違反しています', v.msg + '\n編成タブで調整してください。'); return; }
    if (pbIsActive()) { pvpToast('ポイント争奪戦進行中', '手動申込はできません。自動マッチングをお待ちください。'); return; }
    if (s.battle && s.battle.active) return;
    if (s.role === 'host') { hostHandleData(s.mySlot, { t: 'challenge', targetSlot: slot }); }
    else { guestSend({ t: 'challenge', targetSlot: slot }); }
    pvpToast('対戦を申し込みました', '相手の応答を待っています…');
  }
  function challengeReply(accept) {
    var pc = P.state.pendingChallenge;
    if (!pc) return;
    // ★修正: ホスト自身が応答する場合は hostHandleData 経由で処理（guestSend では自分に届かない）
    if (P.state.role === 'host') {
      hostHandleData(0, { t: 'challengeReply', accept: !!accept, targetSlot: pc.fromSlot });
    } else {
      guestSend({ t: 'challengeReply', accept: !!accept, targetSlot: pc.fromSlot });
    }
    P.state.pendingChallenge = null;
    if (!accept) pvpToast('申込を拒否しました', '');
    renderLobby();
  }
  function answer(idx) {
    var s = P.state, b = s.battle;
    if (!b || !b.active || b.state !== 'question' || !b.isPlayer || b.answered) return;
    b.answered = true; b.myChoice = idx;
    if (s.role === 'host') { hostHandleData(s.mySlot, { t: 'answer', idx: idx }); }
    else { guestSend({ t: 'answer', idx: idx }); }
    renderDuel();
    // ★修正: 即時フィードバック — 選択した瞬間に攻撃の合図を表示
    try {
      var _tIdx = (b.you === 0) ? 1 : 0;
      var _tp = el('pvpPanel' + _tIdx);
      if (_tp) createFloatingText('⚔️ 攻撃!', _tp, 'text-yellow-200 text-sm font-black');
    } catch (e) { }
  }
  function surrender() {
    var s = P.state;
    if (s.battle && s.battle.active) {
      if (s.role === 'host') {
        var loser = s.mySlot;
        var winnerSlot = (loser === s.battle.a) ? s.battle.b : s.battle.a;
        var wn = (s.battle.players.find(function (x) { return x.slot === winnerSlot; }) || {}).name || '相手';
        hostEndBattle(winnerSlot, wn, 'あなたが降参しました');
      } else {
        guestSend({ t: 'surrender' });
        pvpClearTimers();
        s.battle.active = false;
        renderLobby();
      }
    }
  }
  function rematch(targetSlot) {
    var s = P.state;
    if (s.role === 'host') {
      // 直接開始
      s.pendingBattle = { a: s.mySlot, b: targetSlot, decks: {} };
      hostSend(targetSlot, { t: 'askDeck' });
      // ホスト自身のデッキ
      var ids = []; try { ids = getCombinedBattleDeckIds(); } catch (e) {}
      s.pendingBattle.decks[s.mySlot] = { deckIds: ids, levels: (function(){ try { return state.unitLevels || {}; } catch(e){ return {}; } })(), nobleLevel: (function(){ try { return state.noble ? state.noble.level : 1; } catch(e){ return 1; } })() };
      hostTryStartBattle();
    } else {
      guestSend({ t: 'rematch', targetSlot: targetSlot });
    }
  }
  function backToLobby() {
    var s = P.state;
    pvpClearTimers();
    if (s.battle) s.battle = null;
    s.pendingChallenge = null;
    renderLobby();
  }
  function leaveRoom() {
    var s = P.state;
    try {
      if (s.role === 'guest') {
        guestSend({ t: 'leave' });
        try { if (s.hostConn) s.hostConn.close(); } catch (e) {}
        try { if (s.tempConn) s.tempConn.close(); } catch (e) {}
      } else {
        hostBroadcast({ t: 'err', msg: 'ホストが退出しました。対戦コードが変更されている場合があります。' });
      }
    } catch (e) {}
    // オンライン対戦では貴族を外せるため、退出時は通常モード用に貴族を復帰させる
    try {
      var _st = (typeof state !== 'undefined') ? state : (window.state || null);
      var _fn1 = (typeof ensureNobleFixedDeck === 'function') ? ensureNobleFixedDeck : (typeof window.ensureNobleFixedDeck === 'function' ? window.ensureNobleFixedDeck : null);
      var _fn2 = (typeof saveState === 'function') ? saveState : (typeof window.saveState === 'function' ? window.saveState : null);
      if (_st && _fn1 && _fn2) {
        var _deckArr = (_st.deck || []);
        if (_deckArr.indexOf('ch_000') === -1) { _fn1(); _fn2(); }
      }
    } catch (e) { jlog('leaveRoom restore noble err', e); }
    renderHome();
  }

  // ---------- 画面切替 ----------
  // オンライン対戦はDOMを重ねるオーバーレイではなく、メイン画面と排他的に表示する。
  function setPvpScreenVisible(visible) {
    var header = el('appMainHeader');
    var main = el('appMainContent');
    var root = el('pvpRoot');
    if (header) header.classList.toggle('hidden', !!visible);
    if (main) main.classList.toggle('hidden', !!visible);
    if (root) root.classList.toggle('hidden', !visible);
    document.body.style.overflow = visible ? 'hidden' : '';
  }
  function openOverlay() {
    resetState();
    setPvpScreenVisible(true);
    renderHome();
    pvpShowErr('');
  }
  function closeOverlay() {
    var s = P.state;
    if (s.role) {
      if (window.confirm('対戦部屋を退出しますか？')) { leaveRoom(); }
      else return;
    }
    var _rb = el('pvpReturnToRoomBtn'); if (_rb) _rb.classList.add('hidden');
    setPvpScreenVisible(false);
    try { switchTab('pvp'); } catch (e) {}
  }
  function backToHome() { renderHome(); }
  function openHostConfig() {
    P.state.settings = P.state.settings || defaultSettings();
    renderCfg();
  }
  function isInRoom() { return !!P.state.role; }
  function setMyName(nm) {
    nm = String(nm == null ? '' : nm).trim().slice(0, 10) || 'プレイヤー';
    try { localStorage.setItem('kobun_pvp_name', nm); } catch (e) {}
    P.state.myName = nm;
    if (!P.state.role) return;
    var me = myPlayer();
    if (me) me.name = nm;
    if (P.state.role === 'host') { hostBroadcast(playersPayload()); }
    else { guestSend({ t: 'rename', name: nm }); }
  }
  function openDeckEdit() {
    var b = el('pvpReturnToRoomBtn');
    if (b) b.classList.remove('hidden');
    setPvpScreenVisible(false);
    try { switchTab('deck'); } catch (e) { jlog('openDeckEdit err', e); }
  }
  function returnToRoom() {
    var b = el('pvpReturnToRoomBtn');
    if (b) b.classList.add('hidden');
    if (!P.state.role) { setPvpScreenVisible(true); renderHome(); return; }
    setPvpScreenVisible(true);
    pvpShowErr('');
    if (P.state.battle && P.state.battle.active) renderDuel(); else renderLobby();
  }

  function updateSpectatorBanner() {
    try {
      var banner = document.getElementById('pvpActiveMatchBanner');
      if (!banner) return;
      var sP = P.state;
      var cand = sP && sP._spectatorCandidate;
      if (cand && cand.players && cand.players.length >= 2) {
        var p1 = cand.players[0].name;
        var p2 = cand.players[1].name;
        var n1 = document.getElementById('pvpMatchPlayer1');
        var n2 = document.getElementById('pvpMatchPlayer2');
        if (n1) n1.textContent = p1;
        if (n2) n2.textContent = p2;
        banner.classList.remove('hidden');
      } else { banner.classList.add('hidden'); }
    } catch (e) {}
  }
  function updateSpectatorHeader() {
    try {
      var hdr = document.getElementById('pvpSpectatorHeader');
      if (!hdr) return;
      var bP = P.state && P.state.battle;
      if (bP && bP.active && bP.isSpectator) hdr.classList.remove('hidden');
      else hdr.classList.add('hidden');
    } catch (e) {}
  }
  function joinAsSpectatorImpl() {
    var sP = P.state;
    var cand = sP && sP._spectatorCandidate;
    if (!cand) { try { pvpToast('観戦不可', '観戦できる試合が見つかりません。'); } catch (e) {} return; }
    sP.battle = {
      active: true, state: 'spectating', isSpectator: true, isPlayer: false, you: -1,
      a: cand.a, b: cand.b, players: cand.players || [],
      hpA: ((cand.players && cand.players[0] && cand.players[0].maxHp) || 1),
      hpB: ((cand.players && cand.players[1] && cand.players[1].maxHp) || 1),
      maxA: ((cand.players && cand.players[0] && cand.players[0].maxHp) || 1),
      maxB: ((cand.players && cand.players[1] && cand.players[1].maxHp) || 1),
      gaugesA: ((cand.players && cand.players[0] && cand.players[0].party) || []).map(function () { return 0; }),
      gaugesB: ((cand.players && cand.players[1] && cand.players[1].party) || []).map(function () { return 0; }),
      specFired: [], qnum: 0, myQnum: 0, logs: [],
      answered: false, myChoice: -1, startedAt: cand.startedAt || Date.now(),
      suddenDeath: { active: false, mult: 1, intensity: 0 }
    };
    try { renderDuel(); } catch (e) {}
    try { updateSpectatorHeader(); } catch (e) {}
    try { updateSpectatorBanner(); } catch (e) {}
  }
  function leaveSpectatorImpl() {
    var sP = P.state;
    var bP = sP && sP.battle;
    if (bP && bP.isSpectator) {
      try { pvpClearTimers(); } catch (e) {}
      sP.battle = null;
    }
    try { updateSpectatorHeader(); } catch (e) {}
    try { updateSpectatorBanner(); } catch (e) {}
    try { renderLobby(); } catch (e) {}
  }
  window.joinAsSpectatorImpl = joinAsSpectatorImpl;
  window.leaveSpectatorImpl = leaveSpectatorImpl;
  // 公開API
  window.PVPROOT = {
    isInRoom: isInRoom,
    joinAsSpectator: function () { try { return joinAsSpectatorImpl(); } catch (e) { console.error(e); } },
    leaveSpectator: function () { try { return leaveSpectatorImpl(); } catch (e) { console.error(e); } },
    updateSpectatorBanner: updateSpectatorBanner,
    updateSpectatorHeader: updateSpectatorHeader,
    // ★ ホスト設定の枠数を返す（ゲストにもホストと同じ値が同期される）
    roomSlots: function () {
      if (!P.state || !P.state.role) return null;
      return Math.max(1, Math.min(12, parseInt((P.state.settings && P.state.settings.slots), 10) || 10));
    },
    setMyName: setMyName,
    openDeckEdit: openDeckEdit,
    returnToRoom: returnToRoom,
    openOverlay: openOverlay,
    closeOverlay: closeOverlay,
    backToHome: backToHome,
    openHostConfig: openHostConfig,
    applyOfficial: applyOfficial,
    createRoom: createRoom,
    joinRoom: joinRoom,
    challenge: challenge,
    challengeReply: challengeReply,
    answer: function (idx) {
        try {
          var bP = P.state && P.state.battle;
          if (bP && bP.active && bP.isPlayer && bP._acceptAnswer === false) return;
        } catch (e) {}
        try { return answer(idx); } catch (e) { console.error(e); }
      },
    surrender: surrender,
    rematch: rematch,
    backToLobby: backToLobby,
    leaveRoom: leaveRoom,
    fireSpecial: fireSpecial,
    startPointBattle: startPointBattle,
    stopPointBattle: stopPointBattle,
    spectateBattle: spectateBattle,
    closeSpectateView: closeSpectateView
  };

  // 初期化（ゲーム本体の onload 後に実行）
  function pvpInit() {
    try {
      resetState();
      if (typeof Peer === 'undefined') {
        jlog('PeerJS not loaded');
      }
    } catch (e) { jlog('pvp init err', e); }
  }
  // ★軽量改修（オンライン/オフラインの分離）:
  // 従来はページ読み込み時に PeerJS SDK を必ず取得し pvpInit を実行していたが、
  // これを「ネット対戦タブを初めて開いた時」だけの遅延初期化に変更。
  // オフライン・単機プレイでは PeerJS の取得・初期化が一切走らない。
  var _pvpPeerLoaded = false, _pvpEnsureQueue = [];
  function __pvpEnsure(cb) {
    if (typeof Peer !== 'undefined') {
      if (!_pvpPeerLoaded) { _pvpPeerLoaded = true; try { pvpInit(); } catch (e) {} }
      if (cb) { try { cb(); } catch (e) {} }
      return;
    }
    _pvpEnsureQueue.push(cb);
    if (document.getElementById('_pvpPeerScript')) return;
    var _s = document.createElement('script');
    _s.id = '_pvpPeerScript';
    _s.src = 'https://unpkg.com/peerjs@1.5.4/dist/peerjs.min.js';
    _s.onload = function () {
      var _q = _pvpEnsureQueue; _pvpEnsureQueue = [];
      if (!_pvpPeerLoaded) { _pvpPeerLoaded = true; try { pvpInit(); } catch (e) {} }
      for (var i = 0; i < _q.length; i++) { try { _q[i](); } catch (e) {} }
    };
    _s.onerror = function () {
      _pvpEnsureQueue = [];
      try { pvpShowErr('PeerJS SDK の読み込みに失敗しました。通信環境を確認してください。'); } catch (e2) {}
    };
    document.head.appendChild(_s);
  }
  window.__pvpEnsure = function (cb) { __pvpEnsure(cb); };
})();

        window.onload = function () {
            loadState();
            applySmartphoneModeClass();
            renderHeader();
            applyWeekdayGachaTabVisibility();
            if (new URLSearchParams(location.search).get("testown") === "1") { try { ["ge_002","ok_001","ok_002","ok_006","n10_01","wd_mon_01","kaguya_001","br_god_01","butsu_001"].forEach(function(id){ grantOwnedUnit(id); }); } catch (e) {} }
            if (new URLSearchParams(location.search).get("view") === "dex") { try { switchTab("dex"); } catch (e) {} }
            // ★軽量改修: ダンジョン一覧など重い描画は即時には行わず、アイドル時間に分割実行。
            // これにより最初の操作（ステージ選択 → 出撃）が描画タスクにブロックされない。
            var _deferBoot = [
                function () { try { var _g = document.getElementById('dungeonGrid'); if (!_g || !_g.children.length) renderDungeonsView(); } catch (e) {} },
                function () { try { renderBossRushView(); } catch (e) {} },
                function () { try { checkAchievements(); } catch (e) {} }
            ];
            function _runDeferred(i) {
                if (i >= _deferBoot.length) return;
                try { _deferBoot[i](); } catch (e) {}
                if (window.requestIdleCallback) window.requestIdleCallback(function () { _runDeferred(i + 1); }, { timeout: 800 });
                else setTimeout(function () { _runDeferred(i + 1); }, 40);
            }
            _runDeferred(0);
        };
