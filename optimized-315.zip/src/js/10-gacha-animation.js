        // ============================================================
        // ガチャ演出：召喚の儀アニメーション（確率テーブルは不変）
        // UR=落雷＆金色バースト / SSR=金色 / SR=紫 / R=青
        // ============================================================
        function launchGachaSummon(count, results) {
            const hasGod = results.some(u => u.rarity === '神');
            const hasUR = results.some(u => u.rarity === 'UR');
            const hasSSR = results.some(u => u.rarity === 'SSR');
            const hasSR = results.some(u => u.rarity === 'SR');
            const top = hasGod ? '神' : hasUR ? 'UR' : hasSSR ? 'SSR' : hasSR ? 'SR' : 'R';

            document.querySelectorAll('.gacha-overlay').forEach(el => el.remove());
            const root = document.createElement('div');
            root.className = 'gacha-overlay';

            // ① 豪華化：光条・金の環・星屑・ヴィネット（見た目のみ）
            const decoHTML = `
                <div class="gacha-vignette"></div>
                <div class="gacha-ray-a"></div>
                <div class="gacha-ray-b"></div>
                ${Array.from({length: 3}, (_, i) => `<div class="gacha-halo" style="left:${18+i*26}%;top:${i%2?26:44}%;animation-delay:${i*0.8}s"></div>`).join('')}
                ${Array.from({length: 24}, () => `<div class="gacha-star" style="left:${(Math.random()*96+2).toFixed(1)}%;top:${(Math.random()*92+4).toFixed(1)}%;animation-delay:${(Math.random()*2.2).toFixed(2)}s;animation-duration:${(1.6+Math.random()*2).toFixed(2)}s"></div>`).join('')}
            `;
            root.innerHTML = decoHTML + `
                <div class="gacha-seal">
                    <div class="gacha-shine"></div>
                    <div class="gacha-core">
                        <i class="fa-solid fa-wand-magic-sparkles" style="font-size:34px;color:#D4AF37"></i>
                        <div class="gacha-core-text">召 喚</div>
                    </div>
                </div>
                <div class="gacha-summon-text">古典の世界より文人の魂よ、応じよ……</div>
            `;
            document.body.appendChild(root);

            // 中心へ収束する粒子（金・白・紅の三色に増量）
            for (let i = 0; i < 34; i++) {
                const pt = document.createElement('div');
                pt.className = 'gacha-particle';
                const colors = ['#FFD700', '#fff7cc', '#fda4af', '#fde68a'];
                pt.style.background = colors[i % colors.length];
                pt.style.boxShadow = `0 0 12px ${colors[i % colors.length]}`;
                const ang = Math.random() * Math.PI * 2;
                const dist = 24 + Math.random() * 44;
                pt.style.left = `calc(50% + ${Math.cos(ang) * dist}vw)`;
                pt.style.top = `calc(50% + ${Math.sin(ang) * dist}vh)`;
                pt.style.animationDelay = `${Math.random() * 0.4}s`;
                root.appendChild(pt);
            }

            // フェーズ2: レアリティ別バースト演出（豪華化・神対応）
            setTimeout(() => {
                root.querySelectorAll('.gacha-particle').forEach(el => el.remove());
                let c = null;
                if (top === '神') {
                    const fl = document.createElement('div');
                    fl.style.cssText = 'position:fixed;inset:0;background:rgba(255,240,200,.98);z-index:3;pointer-events:none;animation:gacha-thunder-hit .7s ease-in forwards;';
                    root.appendChild(fl);
                    for (let i = 0; i < 9; i++) {
                        const th = document.createElement('div');
                        th.className = 'gacha-thunder';
                        th.style.left = `${3.5 + i * 12.2}%`;
                        th.style.animationDelay = `${i * 0.05}s`;
                        root.appendChild(th);
                    }
                    const b = document.createElement('div');
                    b.className = 'gacha-ur-burst';
                    root.appendChild(b);
                    const b2 = document.createElement('div');
                    b2.className = 'gacha-ur-burst';
                    b2.style.animationDelay = '.28s';
                    b2.style.transform = 'scale(1.4)';
                    root.appendChild(b2);
                    for (let i = 0; i < 46; i++) {
                        const pt = document.createElement('div');
                        pt.className = 'gacha-particle';
                        pt.style.background = i % 4 === 0 ? '#fff' : i % 4 === 1 ? '#fbbf24' : i % 4 === 2 ? '#fde68a' : '#f59e0b';
                        pt.style.boxShadow = '0 0 16px #fbbf24';
                        pt.style.left = `${6 + Math.random() * 88}%`;
                        pt.style.top = `${8 + Math.random() * 84}%`;
                        pt.style.animationDelay = `${Math.random() * 0.55}s`;
                        root.appendChild(pt);
                    }
                } else if (top === 'UR') {
                    const fl = document.createElement('div');
                    fl.style.cssText = 'position:fixed;inset:0;background:rgba(255,255,255,.95);z-index:3;pointer-events:none;animation:gacha-thunder-hit .55s ease-in forwards;';
                    root.appendChild(fl);
                    for (let i = 0; i < 8; i++) {
                        const th = document.createElement('div');
                        th.className = 'gacha-thunder';
                        th.style.left = `${4 + i * 12.5}%`;
                        th.style.animationDelay = `${i * 0.06}s`;
                        root.appendChild(th);
                    }
                    const b = document.createElement('div');
                    b.className = 'gacha-ur-burst';
                    root.appendChild(b);
                    const b2 = document.createElement('div');
                    b2.className = 'gacha-ur-burst';
                    b2.style.animationDelay = '.3s';
                    b2.style.transform = 'scale(1.35)';
                    root.appendChild(b2);
                    for (let i = 0; i < 44; i++) {
                        const pt = document.createElement('div');
                        pt.className = 'gacha-particle';
                        pt.style.background = i % 3 === 0 ? '#fff' : '#fbbf24';
                        pt.style.boxShadow = '0 0 14px #fbbf24';
                        pt.style.left = `${8 + Math.random() * 84}%`;
                        pt.style.top = `${10 + Math.random() * 80}%`;
                        pt.style.animationDelay = `${Math.random() * 0.5}s`;
                        root.appendChild(pt);
                    }
                } else if (top === 'SSR') {
                    const fl = document.createElement('div');
                    fl.style.cssText = 'position:fixed;inset:0;background:rgba(255,215,0,.35);z-index:3;pointer-events:none;animation:gacha-thunder-hit .6s ease-in forwards;';
                    root.appendChild(fl);
                    const b = document.createElement('div');
                    b.className = 'gacha-gold-burst';
                    root.appendChild(b);
                    const b2 = document.createElement('div');
                    b2.className = 'gacha-gold-burst';
                    b2.style.animationDelay = '.25s';
                    b2.style.transform = 'scale(.8)';
                    root.appendChild(b2);
                    for (let i = 0; i < 30; i++) {
                        const pt = document.createElement('div');
                        pt.className = 'gacha-particle';
                        pt.style.background = i % 2 === 0 ? '#fde047' : '#fff7cc';
                        pt.style.boxShadow = '0 0 10px #fde047';
                        pt.style.left = `${10 + Math.random() * 80}%`;
                        pt.style.top = `${15 + Math.random() * 70}%`;
                        pt.style.animationDelay = `${Math.random() * 0.4}s`;
                        root.appendChild(pt);
                    }
                } else {
                    c = top === 'SR' ? '#c084fc' : '#60a5fa';
                    const b = document.createElement('div');
                    b.className = 'gacha-normal-burst';
                    b.style.color = c;
                    root.appendChild(b);
                }
                const txt = document.createElement('div');
                if (top === '神') {
                    txt.className = 'gacha-god-text';
                    txt.innerHTML = '<i class="fa-solid fa-moon" style="margin-right:12px"></i>神 召 喚 成 功<i class="fa-solid fa-moon" style="margin-left:12px"></i>';
                } else if (top === 'UR') {
                    txt.className = 'gacha-ur-text';
                    txt.innerHTML = '<i class="fa-solid fa-bolt" style="margin-right:10px"></i>U R 出 現 !!<i class="fa-solid fa-bolt" style="margin-left:10px"></i>';
                } else if (top === 'SSR') {
                    txt.className = 'gacha-ssr-text';
                    txt.textContent = 'S S R !!';
                } else {
                    txt.className = 'gacha-sr-text';
                    txt.style.color = c;
                    txt.textContent = top === 'SR' ? 'SR 召喚成功' : '召喚成功';
                }
                root.appendChild(txt);
                if (top !== 'R') AudioFX.playCrit();
            }, 950);

            // フェーズ3: 結果モーダル表示（従来と同じカード描画）
            setTimeout(() => {
                root.remove();
                const cardsGrid = document.getElementById("gachaCardsGrid");
                __PERF.setHTML(cardsGrid, "");
                results.forEach(unit => {
                    const card = document.createElement("div");
                    card.className = "p-3 rounded-xl bg-black/70 border-2 border-heian-gold flex flex-col items-center text-center shadow-lg animate-bounce";
                    __PERF.setHTML(card, `
                        <span class="text-[10px] bg-red-600 text-white font-black px-1.5 py-0.5 rounded mb-1">${unit.rarity}</span>
                        <div class="w-12 h-12 rounded-full bg-heian-purple border border-heian-gold flex items-center justify-center text-heian-gold text-2xl my-1">
                            <i class="fa-solid ${unit.icon}"></i>
                        </div>
                        <div class="font-mincho font-bold text-xs text-yellow-100">${unit.name} ${genderMark(unit)}</div>
                    `);
                    cardsGrid.appendChild(card);
                });
                document.getElementById("gachaResultModal").classList.remove("hidden");
            }, 2200);
        }

        
