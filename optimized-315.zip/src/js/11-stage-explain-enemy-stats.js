        // =====================================================================
        // ステージ解説モーダル: ダンジョン選択 → ステージ選択 → 解説表示 → 戦う
        // =====================================================================
        let _explainStageId = null;
        let _explainDungeonId = null;

        // ============================================================
        // ③ 敵の難易度係数（ダンジョン21以降の上昇率をさらに強化）
        // 1〜4: 従来通り / 5〜9: 1.21 乗 / 10〜14: 1.24 乗 / 15〜19: 1.27 乗 / 20: 従来どおり 1.30 乗
        // 21以降: D20の難易度を基準に、上昇率を 1.30 乗 → 1.38 乗 へ強化（ダンジョン1〜20は完全に不変）
        // ============================================================
        function getEnemyDiffMult(dungNum, stageNum) {
            // 曜日ダンジョン（月〜木）は通常ダンジョン25以降を踏破した方向けの強さに調整
            if (isWeekdayDungeon(dungNum) && !isFridayDungeon(dungNum)) {
                return getWeekdayLateGameDiffMult(dungNum, stageNum);
            }
            // 金曜は既存のランダム編成スケールを維持
            if (isWeekdayDungeon(dungNum)) {
                const weekdayProgress = getWeekdayStageProgress(dungNum, stageNum);
                return Math.pow(1.17, 9) * (1 + weekdayProgress * 0.040) * 1.25;
            }
            const stageFactor = (1 + stageNum * 0.11);
            if (dungNum < 5) return Math.pow(1.17, dungNum - 1) * stageFactor * 0.88;
            if (dungNum < 10) return Math.pow(1.21, dungNum - 1) * stageFactor * 0.98;
            if (dungNum < 15) return Math.pow(1.24, dungNum - 1) * stageFactor * 1.02;
            // ③ D15 S12以前はそのまま維持
            // D16 S1 の固定値（旧D15レンジ計算）
            const D16S1_MULT = Math.pow(1.27, 15) * (1 + 1 * 0.11) * 1.06;
            // D30 S5 の固定値（旧D21以降計算・変えない）
            const D30S5_MULT = Math.pow(1.30, 19) * Math.pow(1.38, 10) * (1 + 5 * 0.11) * 1.10;
            // ③ D16 S1 ～ D30 S5 の間: 一次関数（線形補間）
            // 各ステージに一意なインデックスを割り当て
            // D16 S1 = index 0, D16 S12 = index 11, D17 S1 = index 12, ..., D30 S5 = index 172
            // ③ D16 S1 以上 かつ D30 S5 以下の範囲を線形補間
            const _inLinearRange =
                (dungNum > 16 || (dungNum === 16 && stageNum >= 1)) &&
                (dungNum < 30 || (dungNum === 30 && stageNum <= 5));
            if (_inLinearRange) {
                // インデックス計算
                const stagesPerDung = 12;
                let idx;
                if (dungNum === 16) {
                    idx = stageNum - 1; // 0..11
                } else if (dungNum === 30) {
                    idx = (dungNum - 16) * stagesPerDung + (stageNum - 1); // D30 S1=168..S5=172
                } else {
                    idx = (dungNum - 16) * stagesPerDung + (stageNum - 1);
                }
                const totalIdx = 172; // D30 S5のインデックス（最大）
                const frac = Math.min(1, Math.max(0, idx / totalIdx));
                return D16S1_MULT + (D30S5_MULT - D16S1_MULT) * frac;
            }
            // D15 S12以前（D15の残り）
            if (dungNum < 16) return Math.pow(1.27, dungNum - 1) * stageFactor * 1.06;
            if (dungNum < 20) return Math.pow(1.27, dungNum - 1) * stageFactor * 1.06;
            if (dungNum === 20) return Math.pow(1.30, dungNum - 1) * stageFactor * 1.10;
            // D30 S6以降 または D31以降（変えない）
            return Math.pow(1.30, 19) * Math.pow(1.38, dungNum - 20) * stageFactor * 1.10;
        }
        // =====================================================================
        // ★実数値連動改修: 敵ステータスの唯一の算出源（startBattle の実戦計算式と完全同期）
        // 敵HP  = 1300 × 敵難易度倍率 × 世界レベル倍率（金曜ダンジョンは敵編成合計 × ステージ倍率 × 世界レベル倍率）
        // 敵ATK = 120 × 敵難易度倍率 × 世界レベル倍率 × スケール（金曜は敵編成ATK合計 × 0.40 × 各倍率）
        // 推奨戦闘力 = 敵HP + 敵ATK × 5（自部隊戦闘力「HP + ATK×5」と同じ基準で判定・世界レベル連動）
        // =====================================================================
        function getStageEnemyStats(dungNum, stageNum, existingRoster) {
            const worldMult = getWorldLevelMult();
            if (isFridayDungeon(dungNum)) {
                const fridayStageScale = getFridayEnemyStageScale(stageNum, dungNum);
                if (existingRoster && existingRoster.length) {
                    // 戦闘開始時: 実際に生成された敵編成の合計値を使用（実戦値そのもの）
                    const rosterHp = existingRoster.reduce((sum, e) => sum + (e.maxHp || 0), 0);
                    const rosterAtk = existingRoster.reduce((sum, e) => sum + (e.atk || 0), 0);
                    return {
                        hp: Math.max(1, Math.floor(rosterHp * fridayStageScale * worldMult)),
                        atk: Math.max(1, Math.floor(rosterAtk * fridayStageScale * 0.40 * worldMult)),
                        isFriday: true
                    };
                }
                // 戦闘前プレビュー: 敵編成は開始時にランダム決定されるため、
                // 全キャラの平均ステータス × 敵数 から期待値を算出（推定値）
                const fridayCount = getFridayEnemyCount(stageNum, dungNum);
                const enemyLevel = getCurrentFormationMaxLevel();
                const pool = ALL_GACHA_CHARACTERS().filter(Boolean);
                let sumHp = 0, sumAtk = 0;
                pool.forEach(u => { const st = getScaledUnitStatsByLevel(u, enemyLevel); sumHp += st.hp; sumAtk += st.atk; });
                const meanHp = pool.length ? sumHp / pool.length : 0;
                const meanAtk = pool.length ? sumAtk / pool.length : 0;
                return {
                    hp: Math.max(1, Math.floor(fridayCount * meanHp * fridayStageScale * worldMult)),
                    atk: Math.max(1, Math.floor(fridayCount * meanAtk * fridayStageScale * 0.40 * worldMult)),
                    isFriday: true
                };
            }
            const diffMult = getEnemyDiffMult(dungNum, stageNum);
            const enemyAtkScale = (isWeekdayDungeon(dungNum) && !isFridayDungeon(dungNum)) ? 0.58 : (isWeekdayDungeon(dungNum) ? 1.0 : (dungNum >= 20 ? 0.58 : 1));
            return {
                hp: Math.floor(1300 * diffMult * worldMult),
                atk: Math.floor(120 * diffMult * worldMult * enemyAtkScale),
                isFriday: false
            };
        }
        // 推奨戦闘力（世界レベル連動）: 実際の敵HP/ATKから「HP + ATK×5」で算出
        function getStageRecommendedPower(dungNum, stageNum) {
            const est = getStageEnemyStats(dungNum, stageNum);
            return Math.floor(est.hp + est.atk * 5);
        }

        // =====================================================================
        // ★自チーム戦闘力の実数値化: 実戦（startBattle＋正解ダメージ計算）と完全同期
        // 適用順序（実戦の正解ダメージ計算と同一・単一ソース化）:
        //   (1) 個別パッシブ加算: 道隆ok_004×1.3 / 女性に一条ok_007×1.3・桐壺帝ge_001×1.7
        //   (2) 業平so_007: 総ATK×(1+女性人数×0.5)
        //   (3) 道長スタック(michinagaStacks): 総ATK×(1+スタック数×0.02) ※戦闘中のみ・プレビューでは0
        //   (4) シナジー倍率: 1+発動数×0.13+低レア絡み×0.07(+0.10 低レア3体以上)
        //   (5) 道真ok_001: ×1.20
        // 必殺技: メイン枠のみ「atk×成長倍率(3.5+0.7×(Lv-1)、UR/神は6.0+1.2×(Lv-1))×fx.dmg」を
        //   常時発動前提の基礎火力として計上。実戦で条件付きの要素（バフbuffAtk/buffDmgUp・
        //   specPowerBonus・会心・コンボ倍率・道長スタック）は発動状況に依存するため
        //   戦闘力には含めない（二重計上防止）。
        // =====================================================================
        // 総攻撃力のコア算出（正解ダメージ計算と自チーム戦闘力プレビューの唯一の実装）
        function computePartyEffectiveAtk(baseMembers, options) {
            const opts = options || {};
            const hasUnit = id => baseMembers.some(m => m.id === id);
            const femaleCount = baseMembers.filter(m => m.gender === '女性').length;
            let totalPartyAtk = 0;
            baseMembers.forEach(m => {
                let a = m.atk;
                // ⑤ 藤原道隆「豪飲の栄華」: 戦闘中 味方全体の攻撃力を30%増加
                if (hasUnit('ok_004')) a = Math.floor(a * 1.3);
                // ⑤ 一条天皇「文芸の寵愛」: 女性×1.3 / 桐壺帝「無限の偏愛」: 女性×1.7
                if (m.gender === '女性') {
                    if (hasUnit('ok_007')) a = Math.floor(a * 1.3);
                    if (hasUnit('ge_001')) a = Math.floor(a * 1.7);
                }
                totalPartyAtk += a;
            });
            // ⑤⑥ 在原業平「昔男の情熱」: 総攻撃力にバフ（女性1人につき+50%・女性0人ならなし）
            if (hasUnit('so_007') && femaleCount > 0) {
                totalPartyAtk = Math.floor(totalPartyAtk * (1 + femaleCount * 0.5));
            }
            // ⑤ 藤原道長「栄華の極み」: 累積（正解数×2%）※戦闘中のみ
            if (opts.michinagaStacks > 0) {
                totalPartyAtk = Math.floor(totalPartyAtk * (1 + opts.michinagaStacks * 0.02));
            }
            return { totalAtk: totalPartyAtk, femaleCount: femaleCount };
        }
        // シナジー倍率のコア算出（正解ダメージ計算と自チーム戦闘力プレビューの唯一の実装）
        function computePartySynergyMultiplier(partyMembers, activeSynergies) {
            const lowRaritySynergyCount = (activeSynergies || []).reduce((acc, syn) => {
                const participants = [syn.sourceUnit, ...(syn.targetUnits || [])].filter(Boolean);
                return acc + (participants.some(u => u && (u.rarity === 'R' || u.rarity === 'SR')) ? 1 : 0);
            }, 0);
            const activeLowRarityMembers = partyMembers.filter(p => p.unit && (p.unit.rarity === 'R' || p.unit.rarity === 'SR')).length;
            let mult = 1.0 + ((activeSynergies || []).length * 0.13) + (lowRaritySynergyCount * 0.07);
            if (activeLowRarityMembers >= 3) mult += 0.10;
            return mult;
        }
        // 自チーム戦闘力（実戦同期）: メイン＋サブの実戦編成から有効HP・有効ATK・必殺基礎火力を算出
        function computePartyBattlePower(mainIds, subIds) {
            const mainList = (Array.isArray(mainIds) ? mainIds : []).filter(id => id === "ch_000" || state.ownedUnits.includes(id));
            const subList = (Array.isArray(subIds) ? subIds : []).filter(id => id !== "ch_000" && state.ownedUnits.includes(id));
            const partyIds = [...new Set([...mainList, ...subList])];
            const members = [];
            let effHp = 0;
            const buildMember = (uid, isSub) => {
                const unit = getUnit(uid);
                if (!unit) return;
                const st = getUnitStats(uid);
                let hp = st.hp;
                // ⑤⑥ 右大将道綱母「嘆きの蜻蛉」: 男性の味方のHP1.3倍（実戦と同じ）
                if (unit.gender === '男性' && partyIds.includes('so_010')) {
                    hp = Math.floor(hp * 1.3);
                }
                effHp += hp;
                members.push({ id: uid, unit: unit, atk: st.atk, gender: unit.gender, rarity: unit.rarity, isSub: isSub });
            };
            mainList.forEach(uid => buildMember(uid, false));
            subList.forEach(uid => buildMember(uid, true));

            // 発動シナジー（実戦と同じメイン＋サブの部隊IDで判定）
            const activeSynergies = getActiveSynergiesForDeck(partyIds);
            const base = computePartyEffectiveAtk(members.map(m => ({ id: m.id, atk: m.atk, gender: m.gender })), {});
            let synMult = computePartySynergyMultiplier(members, activeSynergies);
            // 菅原道真「至高の学問」: ×1.20（実戦の skillDmgPct+20% と同じ乗算）
            if (members.some(m => m.id === 'ok_001')) synMult *= 1.20;
            const effAtk = Math.floor(base.totalAtk * synMult);

            // 必殺技の基礎火力（メイン枠のみ・手動発動前提。サブ枠は実戦で発動不可のため対象外）
            let totalSpecDmg = 0;
            members.filter(m => !m.isSub).forEach(m => {
                const specLvl = (m.id !== 'ch_000' && state.unitSpecialLevels && state.unitSpecialLevels[m.id]) ? state.unitSpecialLevels[m.id] : 1;
                const fx = SPECIAL_EFFECTS[m.id] || NEW_SPECIAL_EFFECTS[m.id] || m.unit.special_effect || { dmg: 1.0 };
                if (!fx || !fx.dmg) return;
                const _grw = (b, s, lv) => lv <= 50 ? (b + (lv - 1) * s) : (b + 49 * s + (lv - 50) * (Math.max(0.05, s * 0.2) / 1000000));
                let specBase = m.atk * _grw(3.5, 0.7, specLvl);
                if (m.unit.rarity === 'UR' || m.unit.rarity === '神') specBase = m.atk * _grw(6.0, 1.2, specLvl);
                totalSpecDmg += Math.floor(specBase * fx.dmg);
            });
            // 必殺火力をATK換算で計上（基礎ATK→実戦ATKの0.58スケール基準に合わせ換算）
            const SPEC_ATK_RATIO = 0.58;
            const specPower = Math.floor(totalSpecDmg * SPEC_ATK_RATIO);
            const power = Math.floor(effHp + effAtk * 5 + specPower * 5);
            return {
                effHp: Math.floor(effHp),
                effAtk: effAtk,
                specDmg: totalSpecDmg,
                specPower: specPower,
                power: power,
                synergyCount: activeSynergies.length
            };
        }

        function openStageExplain(dung, stgObj) {
            closeModal("stageSelectModal");
            _explainStageId = stgObj.id;
            _explainDungeonId = dung.id;

            const dungNum = dung.id;
            const stageNum = parseInt(stgObj.id.split("_s")[1]) || 1;
            // 推奨戦闘力（実際の敵HP/ATKから算出・世界レベル連動。自部隊「HP+ATK×5」と同じ基準で判定）
            const recPower = getStageRecommendedPower(dungNum, stageNum);
            // 自部隊戦闘力: シナジー・パッシブスキル・必殺技を反映した実戦同期の有効値（単一ソース）
            const currentPower = computePartyBattlePower(state.deck, Array.isArray(state.subDeck) ? state.subDeck : []).power;
            const powerGap = currentPower - recPower;
            const powerLabel =
                powerGap >= recPower * 0.3 ? '<span class="text-green-300">優位</span>' :
                powerGap >= -recPower * 0.4 ? '<span class="text-yellow-300">互角</span>' :
                '<span class="text-red-300">劣勢</span>';

            document.getElementById("stageExplainTitle").innerHTML =
                `<span class="text-amber-300">【${dung.title}】</span><br>` + stgObj.name;
            document.getElementById("stageExplainIcon").innerHTML =
                `<i class="fa-solid ${stgObj.icon || 'fa-scroll'}"></i>`;
            document.getElementById("stageExplainDesc").innerHTML =
                stgObj.description || "（このステージの解説は未登録です）";
            document.getElementById("stageExplainPower").innerHTML =
                `<i class="fa-solid fa-bolt text-amber-400 mr-1"></i>推奨戦闘力 <span class="font-mono font-bold">${recPower.toLocaleString()}</span> ／ 自部隊 <span class="font-mono font-bold">${currentPower.toLocaleString()}</span> (${powerLabel})`;
            document.getElementById("stageExplainSrs").innerHTML =
                `<span class="text-amber-300">Dungeon ${dungNum} ・ Stage ${stageNum} / 全${dung.stages.length}</span>`;

            // 敵のステータスを事前プレビュー（実戦 startBattle と同一の算出源・世界レベル連動）
            const est = getStageEnemyStats(dungNum, stageNum);
            if (est.isFriday) {
                const fridayCountPreview = getFridayEnemyCount(stageNum, dungNum);
                const fridayLevelPreview = getCurrentFormationMaxLevel();
                document.getElementById("stageExplainEnemyPreview").innerHTML =
                    `<i class="fa-solid fa-users text-red-400 mr-1"></i>敵編成 <span class="text-red-300 font-mono font-bold">${fridayCountPreview}体</span> / 全員Lv.<span class="text-red-300 font-mono font-bold">${fridayLevelPreview}</span>（開始時にランダム決定）<br><i class="fa-solid fa-ghost text-red-400 mr-1"></i>敵推定合計 HP <span class="text-red-300 font-mono font-bold">${est.hp.toLocaleString()}</span> / ATK <span class="text-red-300 font-mono font-bold">${est.atk.toLocaleString()}</span>（世界レベル×${getWorldLevelMult()}込み・推定値）`;
            } else {
                document.getElementById("stageExplainEnemyPreview").innerHTML =
                    `<i class="fa-solid fa-ghost text-red-400 mr-1"></i>敵実数値 HP <span class="text-red-300 font-mono font-bold">${est.hp.toLocaleString()}</span> / ATK <span class="text-red-300 font-mono font-bold">${est.atk.toLocaleString()}</span>（世界レベル×${getWorldLevelMult()}込み）`;
            }
            document.getElementById("stageExplainModal").classList.remove("hidden");
            _attachLearnModeToExplain();
            setTimeout(startLearnModeCountdown, 0);
        }
        function closeStageExplain() {
            closeModal("stageExplainModal");
            // ステージ選択モーダルへ戻る
            if (_explainDungeonId !== null) openStageModal(_explainDungeonId);
        }

        function renderFridayEnemyRoster(roster){
            const box=document.getElementById('enemySideBox'); if(!box) return;
            const old=document.getElementById('fridayEnemyRosterPanel'); if(old) old.remove();
            if(!roster || !roster.length) return;
            const panel=document.createElement('div'); panel.id='fridayEnemyRosterPanel'; panel.className='mt-2 p-2 rounded-xl bg-black/50 border border-red-400/40';
            __PERF.setHTML(panel, `<div class="text-[10px] text-red-200 font-bold mb-1"><i class="fa-solid fa-users mr-1"></i>敵編成（${roster.length}体）</div><div class="grid grid-cols-5 gap-1">${roster.map(r=>`<div class="text-center bg-red-950/60 rounded p-1 border border-red-400/30" title="${r.unit.name} / Lv.${r.level}"><div class="w-8 h-8 mx-auto rounded-full bg-red-900 border border-red-300/60 flex items-center justify-center text-red-200"><i class="fa-solid ${r.unit.icon}"></i></div><div class="text-[8px] text-red-100 truncate mt-0.5">${r.unit.name}</div></div>`).join('')}</div>`);
            box.appendChild(panel);
        }

        function startBattle(stageId, reviewMode, options = {}) {
            closeModal("stageSelectModal");
            closeModal("stageExplainModal");
            _explainStageId = null;
            _explainDungeonId = null;

            if (state.deck.length === 0) {
                showCustomAlert("部隊未編成", "出撃するキャラクターが編成されていません。「編成」画面からキャラを選択してください。");
                return;
            }

            if (!isStageUnlocked(stageId) && !options.bossRush) {
                showCustomAlert("ステージ未開放", "このステージはまだ解放されていません。前のステージをクリアしましょう！");
                return;
            }

            const dungNum = parseInt(stageId.substring(1, 3)) || 1;
            const stageNum = parseInt(stageId.split("_s")[1]) || 1;

            // ② 曜日ダンジョンはプレイ1回につき宝玉100個を消費（不足時は出撃不可）
            if (isWeekdayDungeon(dungNum) && !reviewMode) {
                if ((state.gems || 0) < 100) {
                    showCustomAlert("宝玉不足", "曜日ダンジョンをプレイするには宝玉が100個必要です。本編ダンジョンのクリア報酬やガチャで宝玉を集めてください。");
                    return;
                }
                state.gems = Math.max(0, (state.gems || 0) - 100);
                renderHeader();
            }

            const dungObj = DUNGEONS_DATA.find(d => d.id === dungNum);
            const stageObj = dungObj ? dungObj.stages.find(s => s.id === stageId) : null;

            // Scale difficulty exponentially based on dungeon
            const diffMult = getEnemyDiffMult(dungNum, stageNum);
            const worldMult = getWorldLevelMult();
            const fridayEnemyRoster = isFridayDungeon(dungNum) ? buildFridayEnemyRoster(stageNum, dungNum) : [];
            const fridayEnemyLevel = fridayEnemyRoster.length ? fridayEnemyRoster[0].level : 0;
            let baseEnemyHp = Math.floor(1300 * diffMult * worldMult);
            const enemyAtkScale = (isWeekdayDungeon(dungNum) && !isFridayDungeon(dungNum)) ? 0.58 : (isWeekdayDungeon(dungNum) ? 1.0 : (dungNum >= 20 ? 0.58 : 1));
            let baseEnemyAtk = Math.floor(120 * diffMult * worldMult * enemyAtkScale);
            if (isFridayDungeon(dungNum)) {
                const fridayStageScale = getFridayEnemyStageScale(stageNum, dungNum);
                const rosterHp = fridayEnemyRoster.reduce((sum, e) => sum + (e.maxHp || 0), 0);
                const rosterAtk = fridayEnemyRoster.reduce((sum, e) => sum + (e.atk || 0), 0);
                baseEnemyHp = Math.max(1, Math.floor(rosterHp * fridayStageScale * worldMult));
                baseEnemyAtk = Math.max(1, Math.floor(rosterAtk * fridayStageScale * 0.40 * worldMult));
            }
            const enemySpeed = isWeekdayDungeon(dungNum)
                ? Math.max(0.72, 2.15 - (getWeekdayStageProgress(dungNum, stageNum) * 0.018))
                : (dungNum >= 20 ? Math.max(0.42, 1.05 - (dungNum - 20) * 0.018) : Math.max(0.85, 2.4 - (dungNum * 0.045)));

            const subIds = Array.isArray(state.subDeck) ? state.subDeck.filter(id => id !== "ch_000" && state.ownedUnits.includes(id)) : [];
            const partyIds = [...new Set([...state.deck.slice(), ...subIds])];
            const femaleCount = partyIds.reduce((acc, uid) => { const u = getUnit(uid); return acc + ((u && u.gender === '女性') ? 1 : 0); }, 0);
            let partyMaxHp = 0;
            const party = state.deck.map(uid => {
                const unit = getUnit(uid);
                const st = getUnitStats(uid);
                let hp = st.hp;
                // ⑤⑥ 右大将道綱母「嘆きの蜻蛉」: 男性の味方のHP1.3倍
                if (unit && unit.gender === '男性' && partyIds.includes('so_010')) {
                    hp = Math.floor(hp * 1.3);
                }
                partyMaxHp += hp;
                return {
                    id: uid,
                    unit: unit,
                    hp: hp,
                    maxHp: hp,
                    atk: st.atk,
                    gaugePerCorrect: (unit && unit.gaugePerCorrect !== undefined) ? unit.gaugePerCorrect : 15,
                    gaugeNeedsVotes: (unit && unit.gaugeNeedsVotes !== undefined) ? unit.gaugeNeedsVotes : 5,
                    sealedSeconds: 0,
                    specialGauge: 0,
                    isSub: false    // ② サブ枠フラグ
                };
            });
            // ② サブ枠（戦闘画面には表示しない／数値・シナジー計算には参加）
            subIds.forEach(uid => {
                const unit = getUnit(uid);
                const st = getUnitStats(uid);
                if (!unit) return;
                let hp = st.hp;
                if (unit.gender === '男性' && partyIds.includes('so_010')) {
                    hp = Math.floor(hp * 1.3);
                }
                partyMaxHp += hp;
                party.push({
                    id: uid,
                    unit: unit,
                    hp: hp,
                    maxHp: hp,
                    atk: st.atk,
                    gaugePerCorrect: (unit && unit.gaugePerCorrect !== undefined) ? unit.gaugePerCorrect : 15,
                    gaugeNeedsVotes: (unit && unit.gaugeNeedsVotes !== undefined) ? unit.gaugeNeedsVotes : 5,
                    sealedSeconds: 0,
                    specialGauge: 0,
                    isSub: true     // ② サブ枠：手動必殺技発動不可／戦闘画面描画対象外
                });
            });

            battleState = {
                active: true,
                reviewMode: !!reviewMode,
                stageId: stageId,
                dungeonNum: dungNum,
                playerHp: partyMaxHp,
                maxPlayerHp: partyMaxHp,
                enemyHp: baseEnemyHp,
                maxEnemyHp: baseEnemyHp,
                enemyAtk: baseEnemyAtk,
                enemySpeedSec: enemySpeed,
                fridayEnemyRoster: fridayEnemyRoster,
                fridayEnemyLevel: fridayEnemyLevel,
                enemyTimer: 0,
                enemySpecialGauge: 0,
                enemySpecialIndex: 0,
                combo: 0,
                loopInterval: null,
                party: party,
                activeSynergies: [],
                passiveFlags: {},
                buffs: { atk: null, def: null, speed: null, dmg: null, specGain: null, all: null },
                debuffs: { eAtk: null, eSpeed: null },
                stunSec: 0,
                shieldSec: 0,
                missCharges: 0,
                dot: null,
                regen: null,
                specPowerBonus: 1,
                // ② 敵強化モード管理
                enemyPowerUpTimer: 0,
                enemyPowerUpCheckTimer: 0
            };

            const stageName = stageObj ? stageObj.name : stageId;
            const fridayLineup = isFridayDungeon(dungNum) ? getFridayEnemyLineupText(fridayEnemyRoster, 5) : "";
            document.getElementById("battleStageTitle").textContent = battleState.reviewMode ? "間違い単語 復習モード" : stageName;
            if (battleState.reviewMode) {
                document.getElementById("enemyNameText").textContent = "復習のお相手（練習戦）";
            } else if (isFridayDungeon(dungNum)) {
                document.getElementById("enemyNameText").textContent = `金曜ランダム編成 (${fridayEnemyRoster.length}体 / Lv.${fridayEnemyLevel})`;
            } else {
                document.getElementById("enemyNameText").textContent = `敵妖怪 / 武者 (D${dungNum})`;
            }
            const weekdayTag = isMondayDungeon(dungNum) ? " 【月: レベル半減ギミック】" : isTuesdayDungeon(dungNum) ? " 【火: 寝返りギミック】" : isWednesdayDungeon(dungNum) ? " 【水: 変身ギミック】" : isThursdayDungeon(dungNum) ? " 【木: 古語選択】" : isFridayDungeon(dungNum) ? ` 【金: ランダム編成${fridayEnemyRoster.length}体】` : "";
            document.getElementById("enemySubText").textContent = battleState.reviewMode
                ? `間違いリスト ${(state.wrongWords || []).length} 語`
                : (isFridayDungeon(dungNum) ? `${stageName}${weekdayTag} / ${fridayLineup}` : (stageName + weekdayTag));

            const enemyIconEl = document.getElementById("enemyVisualIcon");
            if (enemyIconEl) {
                const iconClass = (stageObj && stageObj.icon) ? stageObj.icon : "fa-ghost";
                __PERF.setHTML(enemyIconEl, `<i class="fa-solid ${iconClass}"></i>`);
            }
            renderFridayEnemyRoster(battleState.fridayEnemyRoster);

            recalculateBattleSynergies();

            // ② 初期必殺ゲージUPシナジー（兼家「藤原氏一族（親子）」30%増加 など）を戦闘開始時にゲージへ反映
            applyInitialGaugeSynergies();

            // ④ パーティのスキルが戦闘中に発揮されることを告知
            const skillAnnounce = [];
            if (partyIds.includes('ok_001')) skillAnnounce.push('菅原道真: 正解時ダメージUP');
            if (partyIds.includes('ok_004')) skillAnnounce.push('藤原道隆: 戦闘中 全員の攻撃力30%UP');
            if (partyIds.includes('ok_005')) skillAnnounce.push('藤原道長: 正解ごとにステータス2%累積');
            if (partyIds.includes('ok_007')) skillAnnounce.push('一条天皇: 女性キャラ全体の能力30%UP');
            if (partyIds.includes('ge_001')) skillAnnounce.push('桐壺帝: 女性キャラの能力70%UP');
            if (partyIds.includes('ge_005')) skillAnnounce.push('夕霧: デバフを60%の確率で無効化');
            if (partyIds.includes('ge_006')) skillAnnounce.push('桐壺更衣: ピンチ時に一度だけHP80%まで回復');
            if (partyIds.includes('so_003')) skillAnnounce.push('阿倍晴明: 本人のみ状態異常無効');
            if (partyIds.includes('so_007')) skillAnnounce.push(`在原業平: 総攻撃力バフ＋${femaleCount * 50}%（女性1人あたり+50%）／女性スキル・シナジーは無効化しない`);
            if (partyIds.includes('so_010')) skillAnnounce.push('右大将道綱母: 男性の味方HP1.3倍');
            if (partyIds.includes('so_002')) skillAnnounce.push('稚児: 15%の確率で味方全員の被ダメージを0にする');
            if (partyIds.some(id => isBossRushGodId(id))) skillAnnounce.push('神ランク: 高速チャージ＋固有神技が発動');
            if (partyIds.includes('br_god_10')) skillAnnounce.push('終ノ神・大和言霊: 3連続正解で全強化、被弾時も70%軽減の可能性');
            if (skillAnnounce.length) {
                setTimeout(() => {
                    createFloatingText(skillAnnounce.join(' / '), document.getElementById("playerSideBox"), "text-cyan-300 text-[9px] font-bold");
                }, 350);
            }
            if (isFridayDungeon(dungNum) && fridayEnemyRoster.length) {
                setTimeout(() => {
                    const eBox = document.getElementById("enemySideBox");
                    if (eBox) createFloatingText(`🎭 敵編成 ${fridayEnemyRoster.length}体 / 全員Lv.${fridayEnemyLevel} / ${getFridayEnemyLineupText(fridayEnemyRoster, 4)}`, eBox, "text-rose-200 text-[10px] font-black");
                }, 220);
            }

            _battlePartySig = ""; _battlePartyEls = null; _battleUiEls = null;
            updateBattleUI();
            generateNewQuiz();

            // Hide Main App UI, reveal Full Screen Dedicated Battle Screen
            document.getElementById("appMainHeader").classList.add("hidden");
            document.getElementById("appMainContent").classList.add("hidden");
            document.getElementById("fullScreenBattleView").classList.remove("hidden");
            fitBattleStage();

            if (battleState.loopInterval) clearInterval(battleState.loopInterval);
            battleState.loopInterval = setInterval(battleGameLoop, 100);
        }

        function startReviewBattle() {
            const list = (state.wrongWords || []).filter(w => w && w.word && w.primary);
            if (list.length === 0) {
                showCustomAlert("復習対象なし", "間違いリストに登録された単語がありません。\nバトルで不正解になった単語が自動で登録されます。");
                return;
            }
            closeModal("stageSelectModal");
            closeModal("stageExplainModal");
            _explainStageId = null;
            _explainDungeonId = null;

            battleState = {
                active: true,
                reviewMode: true,
                stageId: "d00_s00",
                dungeonNum: 0,
                reviewQueue: list.slice().sort(() => Math.random() - 0.5),
                reviewCorrect: 0,
                reviewTotal: list.length,
                reviewStreak: 0,
                playerHp: 1, maxPlayerHp: 1,
                enemyHp: 1, maxEnemyHp: 1,
                loopInterval: null,
                party: [],
                activeSynergies: [],
                buffs: { atk: null, def: null, speed: null, dmg: null, specGain: null, all: null },
                debuffs: { eAtk: null, eSpeed: null },
                stunSec: 0, shieldSec: 0, missCharges: 0, dot: null, regen: null, specPowerBonus: 1
            };

            // 黙々と問題を解く形式：戦闘演出（敵・自陣・コンボ）を非表示にする
            const fridayPanel = document.getElementById('fridayEnemyRosterPanel'); if(fridayPanel) fridayPanel.remove();
            const enemyBox = document.getElementById("enemySideBox");
            const partyRow = document.getElementById("battlePartyRow");
            const synBox = document.getElementById("battleActiveSynergies");
            const comboBanner = document.getElementById("comboBanner");
            if (enemyBox) enemyBox.style.display = "none";
            if (partyRow) partyRow.style.display = "none";
            if (synBox) synBox.style.display = "none";
            if (comboBanner) comboBanner.classList.add("hidden");

            updateReviewHeader();
            updateReviewStats();

            const reviewPanel = document.getElementById("reviewStatsPanel");
            if (reviewPanel) reviewPanel.classList.remove("hidden");

            document.getElementById("appMainHeader").classList.add("hidden");
            document.getElementById("appMainContent").classList.add("hidden");
            document.getElementById("fullScreenBattleView").classList.remove("hidden");
            fitBattleStage();

            generateNewQuiz();
        }

        function updateReviewHeader() {
            const remain = (battleState.reviewQueue || []).length;
            document.getElementById("battleStageTitle").textContent = `復習モード（残り ${remain} 語）`;
            document.getElementById("battleTopSubText").textContent = "敵なし・練習モード：単語を復習して学習の雫を集めよう";
            document.getElementById("enemyNameText").textContent = "（このモードに敵は登場しません）";
            document.getElementById("enemySubText").textContent = `間違いリスト ${(state.wrongWords || []).length} 語`;
        }

        function updateReviewStats() {
            if (!battleState || !battleState.active) return;
            const remain = (battleState.reviewQueue || []).length;
            const total = battleState.reviewTotal || 0;
            const done = Math.max(0, total - remain);
            const pct = total > 0 ? Math.min(100, Math.round(done / total * 100)) : 0;
            const bar = document.getElementById('reviewProgressBar');
            if (bar) bar.style.width = pct + '%';
            const txt = document.getElementById('reviewProgressText');
            if (txt) txt.textContent = `${done} / ${total}（${pct}%）`;
            const cc = document.getElementById('reviewCorrectCount');
            if (cc) cc.textContent = battleState.reviewCorrect || 0;
            const sc = document.getElementById('reviewStreakCount');
            if (sc) sc.textContent = battleState.reviewStreak || 0;
            const rc = document.getElementById('reviewRemainCount');
            if (rc) rc.textContent = remain;
            const sd = document.getElementById('reviewShizukuDisplay');
            if (sd) __PERF.setHTML(sd, `<i class="fa-solid fa-moon mr-1"></i>学習の雫 <span class="font-mono">${(state.reviewPoints||0).toLocaleString()}</span>`);
        }

        function battleGameLoop() {
            if (!battleState.active) return;

            // バフ・デバフ・スタン・毒・バリアの時間経過を更新
            tickStatusTimers(0.1);
            if (!battleState.active) return;

            // ② D20以降: 敵強化モード（前触れなし・毎秒10%／D25〜30は18%の確率で5秒間発動）
            if (battleState.dungeonNum >= 20) {
                // enemyPowerUpTimer: 強化モード残り秒数
                // enemyPowerUpCheckTimer: 次の判定まで残り秒数
                if (typeof battleState.enemyPowerUpTimer !== 'number') battleState.enemyPowerUpTimer = 0;
                if (typeof battleState.enemyPowerUpCheckTimer !== 'number') battleState.enemyPowerUpCheckTimer = 0;

                if (battleState.enemyPowerUpTimer > 0) {
                    battleState.enemyPowerUpTimer = Math.max(0, battleState.enemyPowerUpTimer - 0.1);
                    if (battleState.enemyPowerUpTimer === 0) {
                        // 強化モード終了
                        const eBox2 = document.getElementById('enemySideBox');
                        if (eBox2) eBox2.classList.remove('enemy-power-up');
                        createFloatingText('強化モード解除', document.getElementById('enemySideBox'), 'text-gray-400 text-xs font-bold');
                    }
                } else {
                    // 判定タイマー: 0.1秒ごとに 10%/秒 = 1%/0.1秒 の確率
                    battleState.enemyPowerUpCheckTimer = (battleState.enemyPowerUpCheckTimer || 0) + 0.1;
                    if (battleState.enemyPowerUpCheckTimer >= 1.0) {
                        battleState.enemyPowerUpCheckTimer = 0;
                        const enragePct = battleState.dungeonNum >= 25 ? 0.18 : 0.10;
                        if (Math.random() < enragePct) {
                            battleState.enemyPowerUpTimer = 5.0;
                            // ④ 強化モード発動時: 敵に掛かっていた状態異常を全て解除
                            battleState.stunSec = 0;
                            battleState.dot = null;
                            battleState.missCharges = 0;
                            if (battleState.debuffs) { battleState.debuffs.eAtk = null; battleState.debuffs.eSpeed = null; }
                            const eBox2 = document.getElementById('enemySideBox');
                            if (eBox2) eBox2.classList.add('enemy-power-up');
                            createFloatingText('⚡敵強化！必殺級の攻撃・被ダメージ½・全状態異常無効（5秒）', document.getElementById('enemySideBox'), 'text-orange-300 text-sm font-black');
                            createFloatingText('✨ 状態異常を全て無効化！', document.getElementById('enemySideBox'), 'text-red-200 text-xs font-black');
                        }
                    }
                }
            }

            // 敵の攻撃準備（行動不能＝スタン中はタイマーが進まない）
            // ② D20以降の敵強化モード中はstun無効
            const effectiveStun = (battleState.dungeonNum >= 20 && battleState.enemyPowerUpTimer > 0)
                ? 0
                : battleState.stunSec;
            if (effectiveStun <= 0) {
                battleState.enemyTimer += 0.1;
                const effSpeed = battleState.enemySpeedSec * (1 + ((battleState.debuffs.eSpeed ? battleState.debuffs.eSpeed.pct : 0) / 100));
                const progressPct = Math.min(100, (battleState.enemyTimer / effSpeed) * 100);
                const battleUi = getBattleUiEls();
                if (battleUi.enemyAttackTimerBar) battleUi.enemyAttackTimerBar.style.width = `${progressPct}%`;
                if (battleState.enemyTimer >= effSpeed) {
                    battleState.enemyTimer = 0;
                    applyEnemyAttack();
                    if (!battleState.active) return;
                }
            } else {
                const battleUi = getBattleUiEls();
                if (battleUi.enemyAttackTimerBar) battleUi.enemyAttackTimerBar.style.width = `0%`;
            }

            // 必殺ゲージ蓄積（攻撃速度UP・必殺チャージ加速バフを反映）
            // 金曜敵編成もゲージ満タン到達の瞬間に必殺を発動
            if (isFridayDungeon(battleState.dungeonNum)) {
                battleState.enemySpecialGauge = Math.min(100, battleState.enemySpecialGauge + (100 * 0.1 / 8));
                if (battleState.enemySpecialGauge >= 100) {
                    battleState.enemySpecialGauge = 0;
                    applyFridayEnemySpecial();
                    if (!battleState.active) return;
                }
            }
            let synergyNeedUpdate = false;
            const gainMult = 1 + (buffPct("speed") + buffPct("specGain")) / 100;
            battleState.party.forEach(p => {
                if (p.sealedSeconds > 0) {
                    p.sealedSeconds = Math.max(0, p.sealedSeconds - 0.1);
                    if (p.sealedSeconds === 0) {
                        synergyNeedUpdate = true;
                    }
                } else {
                    p.specialGauge = Math.min(100, p.specialGauge + ((p.gaugePerCorrect !== undefined ? p.gaugePerCorrect * 0.012 : 0.2)) * gainMult);
                    // 仏「悟りの境地」: 毎秒必殺ゲージ+3%（0.1秒ごとに+0.3%）
                    if (p.id === 'butsu_001') p.specialGauge = Math.min(100, p.specialGauge + 0.3);
                    if (isBossRushGodId(p.id)) p.specialGauge = Math.min(100, p.specialGauge + (p.id === 'br_god_10' ? 0.7 : 0.35));
                    // 貴族「執念の位階」: 毎秒必殺ゲージ+1%
                    if (p.id === 'ch_000') p.specialGauge = Math.min(100, p.specialGauge + 0.1);
                }
            });

            if (synergyNeedUpdate) {
                recalculateBattleSynergies();
            }

            updateBattleUI();
        }

        // 稚児「寝たふり」: 敵攻撃時の被ダメージ無効化率（通常攻撃・不正解反撃で共通）
        const CHIGO_DAMAGE_NULLIFY_RATE = 0.15;
