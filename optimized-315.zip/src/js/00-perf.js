/* =============================================================================
 * 00-perf.js — 軽量化ヘルパ（見た目・ゲーム挙動は不変）
 *
 *  1) __PERF.setHTML(el, html)
 *     innerHTML 代入と「同じ描画結果」のまま高速化する:
 *       (a) 直前のDOMを文字列化して比較し、同一ならDOM書き換えを丸ごとスキップ
 *           → 毎tick同じ内容を描き直している箇所のフリーズを解消（差分更新）
 *       (b) 書き換える時は Range#createContextualFragment（= innerHTML と同じ
 *           パース文脈）で1回のパース + replaceChildren にまとめる
 *       ※ 外部からDOMが書き換わっていた場合は innerHTML 比較が不一致になるため
 *         スキップされません（＝取りこぼしが原理的に起きない安全設計）
 *  2) タブ非表示 / ページ非表示の間はゲーム用 setInterval を停止し、
 *     再表示時に同じ間隔でそのまま再開する（CPU負荷の低減）
 *     - ネットワーク同期系のループは setInterval ではなく
 *       __PERF.keepAliveInterval で生成してあり、停止しない（対戦同期の安全のため）
 *     - タイマーIDは不透明トークンとして透過的に扱うため、
 *       既存コードの clearInterval / 真偽判定はそのまま動きます
 *  3) 切替スイッチ（このスクリプトより前の <script> で設定してください）
 *       window.__PERF = { pauseHiddenTimers:false }  // 停止機能を無効化
 *       window.__PERF = { dedupeHtml:false }         // 差分スキップを無効化
 *  4) 計測: __PERF.report() で「スキップした描画回数」などを確認できます
 * ========================================================================== */
(function () {
    'use strict';

    var PERF = window.__PERF = window.__PERF || {};
    PERF.version = '1.0.0';
    if (PERF.pauseHiddenTimers === undefined) PERF.pauseHiddenTimers = true;
    if (PERF.dedupeHtml === undefined) PERF.dedupeHtml = true;
    PERF.stats = { htmlWrites: 0, htmlSkips: 0, timerTicksSkipped: 0 };

    /* ---------------------------------------------------------------- 1) DOM */
    var canFragment = (function () {
        try {
            return typeof Range === 'function' &&
                typeof Range.prototype.createContextualFragment === 'function' &&
                document.createRange().createContextualFragment('<b>x</b>').firstChild.nodeName === 'B';
        } catch (e) { return false; }
    })();

    function setHTML(el, html) {
        if (!el) return;
        html = (html === null || html === undefined) ? '' : String(html);
        try {
            if (PERF.dedupeHtml && el.innerHTML === html) { PERF.stats.htmlSkips++; return; }
        } catch (e) { /* 比較できない要素はそのまま書き換える */ }
        PERF.stats.htmlWrites++;
        if (canFragment) {
            var r = document.createRange();
            r.selectNodeContents(el);
            el.replaceChildren(r.createContextualFragment(html));
        } else {
            el.innerHTML = html;
        }
    }
    PERF.setHTML = setHTML;
    PERF.canFragment = canFragment;

    /* ------------------------------------------------------------- 2) timer */
    var nativeSetInterval = window.setInterval.bind(window);
    var nativeClearInterval = window.clearInterval.bind(window);
    var nativeClearTimeout = window.clearTimeout.bind(window);
    var tokens = new Map();

    function spawnInterval(rec) {
        rec.nativeId = nativeSetInterval(function () {
            if (rec.dead) return;
            if (rec.paused) { PERF.stats.timerTicksSkipped++; return; }
            try { rec.fn.apply(window, rec.args); }
            catch (e) { window.setTimeout(function () { throw e; }, 0); }
        }, rec.delay);
    }

    function keepAliveInterval(fn, delay) {
        var args = Array.prototype.slice.call(arguments, 2);
        return nativeSetInterval(function () { fn.apply(window, args); }, delay);
    }
    PERF.keepAliveInterval = keepAliveInterval;

    if (PERF.pauseHiddenTimers && typeof document !== 'undefined' && 'hidden' in document) {
        window.setInterval = function (fn, delay) {
            if (typeof fn !== 'function') return nativeSetInterval(fn, delay);
            var args = Array.prototype.slice.call(arguments, 2);
            var rec = {
                fn: fn, delay: delay || 0, args: args,
                nativeId: null, dead: false, paused: false
            };
            var token = { __perfTimer: true };
            tokens.set(token, rec);
            if (!document.hidden) spawnInterval(rec);
            else rec.paused = true;
            return token;
        };

        window.clearInterval = function (t) {
            if (t && typeof t === 'object' && tokens.has(t)) {
                var rec = tokens.get(t);
                rec.dead = true;
                if (rec.nativeId !== null) { nativeClearInterval(rec.nativeId); rec.nativeId = null; }
                tokens.delete(t);
                return;
            }
            return nativeClearInterval(t);
        };

        window.clearTimeout = function (t) {
            if (t && typeof t === 'object' && tokens.has(t)) return window.clearInterval(t);
            return nativeClearTimeout(t);
        };

        function pauseAll() {
            tokens.forEach(function (rec) {
                if (rec.dead) return;
                rec.paused = true;
                if (rec.nativeId !== null) { nativeClearInterval(rec.nativeId); rec.nativeId = null; }
            });
        }
        function resumeAll() {
            tokens.forEach(function (rec) {
                if (rec.dead || rec.nativeId !== null) return;
                rec.paused = false;
                spawnInterval(rec);
            });
        }
        PERF.pauseTimers = pauseAll;
        PERF.resumeTimers = resumeAll;
        PERF.liveTimerCount = function () { return tokens.size; };

        document.addEventListener('visibilitychange', function () {
            if (document.hidden) pauseAll(); else resumeAll();
        }, false);
        window.addEventListener('pagehide', pauseAll, false);
        window.addEventListener('pageshow', resumeAll, false);
    }

    /* ------------------------------------------------------------ 3) report */
    PERF.report = function () {
        var s = PERF.stats;
        return {
            innerHTML_書き換え: s.htmlWrites,
            描画スキップ: s.htmlSkips,
            停止中に抑止したタイマー実行: s.timerTicksSkipped,
            稼働中タイマー数: typeof PERF.liveTimerCount === 'function' ? PERF.liveTimerCount() : -1,
            pauseHiddenTimers: PERF.pauseHiddenTimers,
            dedupeHtml: PERF.dedupeHtml,
            DocumentFragment対応: canFragment
        };
    };
})();