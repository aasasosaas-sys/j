        // ============================================================
        // 必殺技演出（ゲームバランス非干渉・視覚演出のみ）
        // 回復系=緑の粒子が上昇 / 雷撃系=落雷 / 攻撃系=閃光＋爆発 / 支援系=金色
        // ============================================================
        function playSpecialMoveShow(p, fx) {
            const isHeal = !!(fx.healPct || fx.healFull || fx.regen);
            const isShield = !!fx.shield && !fx.dmg;
            const isDmg = !!fx.dmg;
            const isThunder = p.id === 'ok_001';
            const isBuff = !!(fx.buffAtk || fx.buffDef || fx.buffAll || fx.buffSpeed || fx.buffSpecGain || fx.buffDmgUp) && !isDmg;

            document.querySelectorAll('.spec-root').forEach(el => el.remove());
            const root = document.createElement('div');
            root.className = 'spec-root';
            document.body.appendChild(root);

            // フラッシュ（種別で色を変える）
            const flash = document.createElement('div');
            flash.className = 'spec-flash';
            if (isThunder) flash.style.background = 'rgba(255,255,255,.95)';
            else if (isHeal) flash.style.background = 'radial-gradient(circle at 50% 55%, rgba(74,222,128,.5), transparent 72%)';
            else if (isShield) flash.style.background = 'radial-gradient(circle at 50% 55%, rgba(103,232,249,.45), transparent 72%)';
            else if (isBuff) flash.style.background = 'radial-gradient(circle at 50% 55%, rgba(250,204,21,.5), transparent 72%)';
            else flash.style.background = 'radial-gradient(circle at 50% 55%, rgba(255,215,0,.65), rgba(220,38,38,.4) 55%, transparent 78%)';
            root.appendChild(flash);

            // 必殺技名タイトル（（）内の注記は省略して大きく表示）
            const rawName = (p.unit.special_move && p.unit.special_move.name) || '奥義';
            const specName = rawName.split('（')[0];
            const title = document.createElement('div');
            title.className = 'spec-title';
            title.style.color = isHeal ? '#a7f3d0' : isShield ? '#a5f3fc' : '#FFE9A8';
            title.textContent = `${p.unit.name}・${specName}!!`;
            root.appendChild(title);

            // エネルギーリング
            const ringCol = isHeal ? '#6ee7b7' : isShield ? '#67e8f9' : isBuff ? '#fde047' : '#fbbf24';
            const ring = document.createElement('div');
            ring.className = 'spec-burst';
            ring.style.background = `radial-gradient(circle, ${ringCol}, transparent 70%)`;
            ring.style.border = `3px solid ${ringCol}`;
            root.appendChild(ring);

            // パーティクル（回復・支援系は下から上へ、攻撃系は中心から放射）
            const colors = isHeal
                ? ['#6ee7b7', '#34d399', '#a7f3d0', '#86efac']
                : isShield ? ['#67e8f9', '#a5f3fc', '#22d3ee']
                : isBuff ? ['#fde047', '#fbbf24', '#fff7cc']
                : ['#fbbf24', '#f87171', '#fde047', '#fb923c'];
            const pCount = isDmg ? 26 : 20;
            for (let i = 0; i < pCount; i++) {
                const pt = document.createElement('div');
                pt.className = 'spec-particle';
                pt.style.background = colors[i % colors.length];
                pt.style.boxShadow = `0 0 10px ${colors[i % colors.length]}`;
                if (isHeal || isShield || isBuff) {
                    pt.style.left = `${8 + Math.random() * 84}%`;
                    pt.style.top = `${82 + Math.random() * 12}%`;
                    pt.style.animation = 'spec-rise 1.1s ease-out forwards';
                    pt.style.animationDelay = `${Math.random() * 0.25}s`;
                    pt.style.width = pt.style.height = `${5 + Math.random() * 9}px`;
                } else {
                    const ang = Math.random() * Math.PI * 2;
                    const dist = 12 + Math.random() * 30;
                    pt.style.left = `calc(50% + ${Math.cos(ang) * dist}vw)`;
                    pt.style.top = `calc(50% + ${Math.sin(ang) * dist}vh)`;
                }
                root.appendChild(pt);
            }

            // 雷撃（菅原道真「東風吹かば」）
            if (isThunder) {
                for (let i = 0; i < 3; i++) {
                    const th = document.createElement('div');
                    th.className = 'spec-thunder';
                    th.style.left = `${28 + i * 22}%`;
                    th.style.animationDelay = `${i * 0.1}s`;
                    root.appendChild(th);
                }
            }

            // 戦闘フィールドのシェイク
            const arena = document.getElementById('battleArena');
            if (arena) {
                arena.classList.add('animate-shake-intense');
                setTimeout(() => arena.classList.remove('animate-shake-intense'), 500);
            }

            setTimeout(() => root.remove(), 1250);
        }

        function updateBattleUI() {
            const playerHpPct = Math.max(0, (battleState.playerHp / battleState.maxPlayerHp) * 100);
            const enemyHpPct = Math.max(0, (battleState.enemyHp / battleState.maxEnemyHp) * 100);
            const ui = getBattleUiEls();
            const playerHpTextValue = `${Math.ceil(battleState.playerHp)} / ${battleState.maxPlayerHp}`;
            const enemyHpTextValue = `${Math.ceil(battleState.enemyHp)} / ${battleState.maxEnemyHp}`;

            if (ui.playerHpBar) {
                const width = `${playerHpPct}%`;
                if (ui.playerHpBar.style.width !== width) ui.playerHpBar.style.width = width;
            }
            if (ui.playerHpText && ui.playerHpText.textContent !== playerHpTextValue) ui.playerHpText.textContent = playerHpTextValue;
            if (ui.enemyHpBar) {
                const width = `${enemyHpPct}%`;
                if (ui.enemyHpBar.style.width !== width) ui.enemyHpBar.style.width = width;
            }
            if (ui.enemyHpText && ui.enemyHpText.textContent !== enemyHpTextValue) ui.enemyHpText.textContent = enemyHpTextValue;

            if (ui.comboBanner) {
                if (battleState.combo >= 2) {
                    if (ui.comboCountText && ui.comboCountText.textContent !== String(battleState.combo)) ui.comboCountText.textContent = battleState.combo;
                    if (ui.comboBanner.classList.contains("hidden")) ui.comboBanner.classList.remove("hidden");
                } else if (!ui.comboBanner.classList.contains("hidden")) {
                    ui.comboBanner.classList.add("hidden");
                }
            }

            updateStatusIndicators();
            updateBattlePartyUI();
        }

        function updateBattlePartyUI() {
            const container = document.getElementById("battlePartyRow");
            if (!container) return;

            // ② 戦闘画面にはサブ枠キャラを表示しない（裏で作動）
            const members = battleState.party.filter(p => !p.isSub);
            const isSPhone = !!(state.settings && state.settings.smartphoneMode);
            const hideSkills = !!(state.settings && state.settings.hideBattleSkills);
            const sig = members.map(p =>
                `${p.id}|${p.unit && p.unit.icon ? p.unit.icon : ''}|${p.defected ? 1 : 0}|${p.sealedSeconds > 0 ? 1 : 0}|${Math.ceil(p.sealedSeconds || 0)}|${Math.ceil(p.defectSec || 0)}|${p.specialGauge >= 100 ? 1 : 0}|${isSPhone ? 1 : 0}|${hideSkills ? 1 : 0}`
            ).join('#');

            // 状態変化のないtickではDOM再構築せずゲージ幅・%表示だけ更新（軽量化）
            if (sig === _battlePartySig && _battlePartyEls) {
                members.forEach((p, idx) => {
                    const c = _battlePartyEls[idx];
                    if (!c) return;
                    const g = Math.max(0, Math.min(100, p.specialGauge));
                    if (c.gaugeBar) c.gaugeBar.style.width = g + '%';
                    if (c.gaugeText) c.gaugeText.textContent = Math.floor(p.specialGauge) + '%';
                });
                return;
            }
            _battlePartySig = sig;
            _battlePartyEls = [];

            __PERF.setHTML(container, "");

            members.forEach((p, idx) => {
                const isSealed = p.sealedSeconds > 0;
                const isReady = p.specialGauge >= 100 && !isSealed && !p.defected;

                const card = document.createElement("div");
                card.className = `p-1.5 rounded-lg border flex flex-col items-center justify-between relative text-center transition ${
                    p.defected ? 'sealed-card border-orange-500 bg-red-950/70' : isSealed ? 'sealed-card border-red-600 bg-red-950/80' : 'bg-black/60 border-heian-gold/40'
                }`;

                __PERF.setHTML(card, `
                    <div class="w-8 h-8 rounded-full bg-heian-purple border border-heian-gold flex items-center justify-center text-heian-gold text-xs my-0.5">
                        <i class="fa-solid ${p.unit.icon}"></i>
                    </div>
                    <span class="text-[9px] font-bold font-mincho text-yellow-100 truncate w-full">${p.unit.name} ${genderMark(p.unit)}</span>
                    ${hideSkills ? '' : `<div class="${isSPhone ? 'text-[7px]' : 'text-[6px]'} text-cyan-300 truncate w-full leading-tight" title="${p.unit.skill ? p.unit.skill.effect : ''}">${p.unit.skill ? p.unit.skill.name : ''}</div>`}
                    ${p.defected ? `<span class="text-[9px] font-black text-orange-400">🔥敵陣営化</span><span class="text-[9px] font-black text-amber-200 font-mono">帰還 ${Math.ceil(p.defectSec || 0)}s</span>` : ''}
                    ${isSealed ? `<span class="text-[9px] font-black text-red-400 font-mono">停止 ${Math.ceil(p.sealedSeconds)}s</span>` : p.defected ? `<div class="w-full my-1 text-[8px] text-orange-200 font-black">5秒後に味方へ復帰</div>` : `
                    <div class="w-full my-1">
                        ${isReady ? `
                        <button onclick="triggerSpecialMove(${idx})" class="w-full ${isSPhone ? 'py-2.5 text-sm' : 'py-0.5 text-[9px]'} font-extrabold rounded special-ready-btn shadow">
                            必殺発動!${isSPhone ? `<span class="block text-[9px] font-mono opacity-80 spec-gauge-btn-text">${Math.floor(p.specialGauge)}%</span>` : ''}
                        </button>` : isSPhone ? `
                        <button onclick="triggerSpecialMove(${idx})" class="w-full py-2.5 text-xs font-extrabold rounded bg-amber-900/50 border border-amber-500/50 text-amber-200 shadow active:scale-95">
                            必殺準備中 <span class="font-mono spec-gauge-btn-text">${Math.floor(p.specialGauge)}%</span>
                        </button>` : `
                        <div class="w-full bg-gray-900 rounded-full h-1.5 border border-amber-500/40 overflow-hidden">
                            <div class="bg-gradient-to-r from-amber-500 to-yellow-300 h-full transition-all duration-200 spec-gauge-bar" style="width: ${p.specialGauge}%"></div>
                        </div>
                        <span class="text-[7px] text-amber-300 font-mono font-bold spec-gauge-text">${Math.floor(p.specialGauge)}%</span>
                        `}
                    </div>`}
                `);
                container.appendChild(card);
                _battlePartyEls[idx] = {
                    gaugeBar: card.querySelector('.spec-gauge-bar'),
                    gaugeText: card.querySelector('.spec-gauge-text, .spec-gauge-btn-text')
                };
            });
        }

        function handleReviewAnswer(isCorrect, btnElement) {
            if (!battleState.active) return;
            const container = document.getElementById("quizChoicesGrid");
            const quizBox = document.getElementById("quizContainerBox");
            [...container.children].forEach(b => { b.disabled = true; });

            if (isCorrect) {
                btnElement.classList.add("bg-green-700", "border-green-400");
                createFloatingText("✅ 正解！", quizBox, "text-green-300 text-sm font-black");
                if (currentQuizQuestion && currentQuizQuestion.word) {
                    const idx = (state.wrongWords || []).findIndex(w => w.word === currentQuizQuestion.word && w.primary === currentQuizQuestion.primary);
                    if (idx !== -1) {
                        state.wrongWords.splice(idx, 1);
                        createFloatingText("✅ 間違いリストから消えた！", quizBox, "text-green-300 text-sm font-black");
                    }
                }
                battleState.reviewCorrect = (battleState.reviewCorrect || 0) + 1;
                battleState.reviewStreak = (battleState.reviewStreak || 0) + 1;
                if (battleState.reviewStreak >= 2) createFloatingText(`🔥 連続正解 ${battleState.reviewStreak} 回！`, quizBox, "text-amber-300 text-xs font-black");
                state.reviewPoints = (state.reviewPoints || 0) + 1;
                createFloatingText("💧 学習の雫 +1", quizBox, "text-pink-300 text-sm font-black");
                saveState();
                updateReviewStats();
                try { AudioFX.playCorrect(); } catch (e) {}
            } else {
                btnElement.classList.add("bg-red-800", "border-red-400");
                [...container.children].forEach(b => {
                    if (b.dataset.correct === "1") b.classList.add("bg-green-700", "border-green-400");
                });
                battleState.reviewStreak = 0;
                createFloatingText("❌ 不正解…", quizBox, "text-red-300 text-sm font-black");
                try { AudioFX.playHurt(); } catch (e) {}
                updateReviewStats();
            }

            setTimeout(() => advanceReviewQuiz(), 1100);
        }

        function advanceReviewQuiz() {
            if (!battleState || !battleState.active) return;
            if ((battleState.reviewQueue || []).length === 0) {
                endBattle(true);
                return;
            }
            generateNewQuiz();
        }

        function endBattle(isWin) {
            battleState.active = false;
            // 曜日ダンジョンの寝返り・レベル半減は戦闘単位の状態。次戦へ持ち越さず全復帰させる
            if (battleState.party) {
                battleState.party.forEach(p => {
                    p.defected = false;
                    p.defectSec = 0;
                    p._defectTransfer = null;
                    p.levelHalved = false;
                    p.levelHalveSec = 0;
                    p._halveLost = null;
                    // 水曜ギミック: 変身中だったキャラを元に戻す
                    if (p._orig) {
                        const o = p._orig;
                        p.id = o.id;
                        p.unit = o.unit;
                        p.maxHp = o.maxHp;
                        p.hp = o.hp;
                        p.atk = o.atk;
                        p.gaugePerCorrect = o.gaugePerCorrect;
                        p.gaugeNeedsVotes = o.gaugeNeedsVotes;
                        p._orig = null;
                    }
                });
                // 変身によるHP変動を編成合計で吸収
                const _sMax = battleState.party.reduce((s, p) => s + (p.maxHp || 0), 0);
                const _sHp = battleState.party.reduce((s, p) => s + (p.hp || 0), 0);
                battleState.maxPlayerHp = Math.max(1, _sMax);
                battleState.playerHp = Math.max(0, _sHp);
            }
            if (battleState.loopInterval) {
                clearInterval(battleState.loopInterval);
                battleState.loopInterval = null;
            }

            if (battleState.reviewMode) {
                const remain = (state.wrongWords || []).length;
                const got = battleState.reviewCorrect || 0;
                const total = battleState.reviewTotal || 0;
                showCustomAlert(
                    remain === 0 ? "復習コンプリート！" : "復習モード終了",
                    remain === 0
                        ? `おめでとうございます！\n${total} 問中 ${got} 問正解！\n間違いリストの単語をすべて当て切りました！`
                        : `お疲れさまでした！\n${total} 問中 ${got} 問正解。\n間違いリストにはまだ ${remain} 語残っています。\n正解するとリストから消えます。`,
                    () => exitBattleView()
                );
                return;
            }

            // 無限ボスラッシュ専用ロジック
            if (battleState.bossRush) {
                const br = ensureBossRush();
                const runWorldLevel = getBossRushRunWorldLevel();
                if (isWin) {
                    br.scoreKills = (br.scoreKills || 0) + 1;
                    const totalStage = (br.round - 1) * 200 + br.stage;
                    if ((state.bossRushBest || 0) < totalStage) state.bossRushBest = totalStage;
                    if (isBossRushFinalStage(br)) {
                        br.active = false;
                        const rewardUnit = grantBossRushReward(runWorldLevel);
                        const rewardAlreadyClaimed = !!(rewardUnit && rewardUnit._alreadyClaimed);
                        markBossRushLevelCleared(runWorldLevel);
                        markAchievementWorld('bossrush', runWorldLevel);
                        bossRushState = null;
                        saveState();
                        checkAchievements();
                        playBossRushClearCeremony(runWorldLevel, rewardUnit, () => {
                            const rewardMsg = rewardAlreadyClaimed
                                ? `神ランク報酬「${rewardUnit ? rewardUnit.name : '？？？'}」は獲得済みのため、今回は再配布されません。`
                                : `神ランクキャラ「${rewardUnit ? rewardUnit.name : '？？？'}」を獲得しました。`;
                            showCustomAlert(
                                `世界Lv.${runWorldLevel} 制覇！`,
                                `三周目・200ステージ目を突破！
${rewardMsg}
世界レベルは消えず、そのまま再挑戦できます。`,
                                () => { exitBattleView(); renderDeckView(); renderBossRushView(); }
                            );
                        });
                        return;
                    }
                    br.playerHp = battleState.playerHp;
                    br.stage += 1;
                    if (br.stage > 200) {
                        br.stage = 1;
                        br.round += 1;
                        if (br.round > 3) br.round = 3;
                    }
                    saveState();
                    enterBossRushBattle();
                    return;
                } else {
                    const defeated = br.scoreKills || 0;
                    const wm = getWorldLevelMult(runWorldLevel);
                    const reward = defeated * 600 * wm;
                    state.coins += reward;
                    const totalStage = (br.round - 1) * 200 + br.stage;
                    if ((state.bossRushBest || 0) < totalStage) { state.bossRushBest = totalStage; }
                    br.active = false;
                    saveState();
                    showCustomAlert(
                        "ボスラッシュ敗北...",
                        `戦線突破。\n撃破数 ${defeated} × 600 = ${(defeated*600).toLocaleString()} × 世界レベル${wm}\n→ +${reward.toLocaleString()}文\n最高到達: ${state.bossRushBest}`,
                        () => { bossRushState = null; saveState(); exitBattleView(); renderBossRushView(); }
                    );
                    return;
                }
            }

            if (isWin) {
                const wasReincarnationUnlocked = hasReincarnationUnlock();
                state.clearedStages[battleState.stageId] = true;
                const clearDungeon = DUNGEONS_DATA.find(d => d.id === battleState.dungeonNum);
                const clearStageIndex = clearDungeon ? clearDungeon.stages.findIndex(st => st.id === battleState.stageId) : -1;
                const clearWorld = getWorldLevel();
                if (clearDungeon && clearStageIndex === clearDungeon.stages.length - 1) {
                    if (clearDungeon.id === 30) markAchievementWorld('dungeon30', clearWorld);
                    if (getWeekdayKeyByDungeonNum(clearDungeon.id)) markAchievementWeekdayWorld(clearWorld, clearDungeon.id);
                }
                const worldMultReward = getWorldLevelMult();
                const weekdayKey = getWeekdayKeyByDungeonNum(battleState.dungeonNum);
                const isWeekdayBattle = !!weekdayKey;
                const rewardCoins = isWeekdayBattle ? 0 : (300 + battleState.dungeonNum * 150) * worldMultReward;
                const rewardGems = isWeekdayBattle ? 0 : (10 + battleState.dungeonNum * 5);
                state.coins += rewardCoins;
                state.gems += rewardGems;
                const weekdayReward = weekdayKey ? (250 + stageNumFromId(battleState.stageId) * 50) : 0;
                if (weekdayKey) { if(!state.weekdayPoints) state.weekdayPoints={}; state.weekdayPoints[weekdayKey]=(state.weekdayPoints[weekdayKey]||0)+weekdayReward; }
                saveState();
                checkAchievements();

                const unlockedShukkeNow = !wasReincarnationUnlocked && hasReincarnationUnlock();
                const weekdayPointName = weekdayKey && WEEKDAY_GACHA_BANNERS[weekdayKey] ? WEEKDAY_GACHA_BANNERS[weekdayKey].pointName : '曜日ポイント';
                const rewardMessage = isWeekdayBattle
                    ? `見事に敵を討ち果たしました！

【獲得報酬】
${weekdayPointName}: +${weekdayReward.toLocaleString()}`
                    : `見事に敵を討ち果たしました！

【獲得報酬】
銭: +${rewardCoins.toLocaleString()}文
宝玉: +${rewardGems}`;
                const rewardMessageFinal = isWeekdayBattle
                    ? `見事に最後のステージを制覇しました！

【獲得報酬】
${weekdayPointName}: +${weekdayReward.toLocaleString()}`
                    : `見事に最後のステージを制覇しました！

【獲得報酬】
銭: +${rewardCoins.toLocaleString()}文
宝玉: +${rewardGems}`;
                const reincarnationMessage = `見事にダンジョン30・ステージ5を制覇しました！

【獲得報酬】
銭: +${rewardCoins.toLocaleString()}文
宝玉: +${rewardGems}`;

                showCustomAlert(
                    "合戦勝利！",
                    unlockedShukkeNow ? reincarnationMessage : ((clearDungeon && clearStageIndex === clearDungeon.stages.length - 1) ? rewardMessageFinal : rewardMessage),
                    () => {
                        if (unlockedShukkeNow && !shukkePromptedThisSession) {
                            shukkePromptedThisSession = true;
                            promptShukke();
                        } else {
                            exitBattleView();
                        }
                    }
                );
            } else {
                showCustomAlert(
                    "合戦敗北...",
                    "自陣の防衛ラインが突破されてしまいました。\n部隊編成や装束・レベルを強化して再挑戦しましょう！",
                    () => exitBattleView()
                );
            }
        }

        function exitBattleView() {
            document.getElementById("fullScreenBattleView").classList.add("hidden");
            document.getElementById("appMainHeader").classList.remove("hidden");
            document.getElementById("appMainContent").classList.remove("hidden");
            const enemyBox = document.getElementById("enemySideBox");
            const partyRow = document.getElementById("battlePartyRow");
            const synBox = document.getElementById("battleActiveSynergies");
            if (enemyBox) enemyBox.style.display = "";
            if (partyRow) partyRow.style.display = "";
            if (synBox) synBox.style.display = "";
            const reviewPanel = document.getElementById("reviewStatsPanel");
            if (reviewPanel) reviewPanel.classList.add("hidden");
            renderHeader();
            renderDungeonsView();
            renderWeekdayDungeonsView();
            renderBossRushView();
        }

        function showCustomAlert(title, message, onOk) {
            document.getElementById("customDialogTitle").textContent = title;
            document.getElementById("customDialogBody").textContent = message;
            document.getElementById("customDialogOkBtn").textContent = "OK";
            document.getElementById("customDialogCancelBtn").textContent = "キャンセル";
            document.getElementById("customDialogCancelBtn").classList.add("hidden");

            const okBtn = document.getElementById("customDialogOkBtn");
            okBtn.onclick = () => {
                closeModal("customDialogModal");
                if (onOk) onOk();
            };

            document.getElementById("customDialogModal").classList.remove("hidden");
        }

        function showCustomConfirm(title, message, onConfirm) {
            document.getElementById("customDialogTitle").textContent = title;
            document.getElementById("customDialogBody").textContent = message;

            document.getElementById("customDialogOkBtn").textContent = "OK";
            const cancelBtn = document.getElementById("customDialogCancelBtn");
            cancelBtn.textContent = "キャンセル";
            cancelBtn.classList.remove("hidden");
            cancelBtn.onclick = () => closeModal("customDialogModal");

            const okBtn = document.getElementById("customDialogOkBtn");
            okBtn.onclick = () => {
                closeModal("customDialogModal");
                if (onConfirm) onConfirm();
            };

            document.getElementById("customDialogModal").classList.remove("hidden");
        }

        function getShukkeCarryCandidateIds() {
            return (Array.isArray(state.ownedUnits) ? state.ownedUnits : [])
                .filter(id => id && id !== 'ch_000' && getUnit(id));
        }
        function escapeHtml(str) {
            return String(str || '')
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#39;');
        }

        function promptShukke() {
            if (!hasReincarnationUnlock()) return;
            const body = document.getElementById("customDialogBody");
            const title = document.getElementById("customDialogTitle");
            const okBtn = document.getElementById("customDialogOkBtn");
            const cancelBtn = document.getElementById("customDialogCancelBtn");
            const candidates = getShukkeCarryCandidateIds();
            title.textContent = "出家しますか？";
            __PERF.setHTML(body, `
                <div class="text-left space-y-3">
                    <div>ダンジョン30・ステージ5を制覇しました！<br>出家すると進行状況はリセットされますが、<span class="text-amber-300 font-bold">貴族の現在状態</span>と<span class="text-pink-300 font-bold">任意の1体</span>を次の世界へ引き継げます。</div>
                    <div class="bg-black/40 border border-heian-gold/30 rounded-lg p-3">
                        <div class="text-[11px] text-gray-300 mb-1">引き継ぎキャラ 1体</div>
                        <select id="shukkeCarrySelect" class="w-full bg-black/70 border border-heian-gold/40 rounded px-2 py-2 text-sm text-yellow-100">
                            <option value="">引き継がない</option>
                            ${candidates.map(id => { const unit = getUnit(id); const lv = (state.unitLevels && state.unitLevels[id]) || 1; return `<option value="${escapeHtml(id)}">${escapeHtml(unit ? unit.name : id)} / Lv.${lv}</option>`; }).join('')}
                        </select>
                    </div>
                    <div class="text-[11px] text-gray-400">※ 2回目の出家で解放される仏や、神ランク保持仕様もそのまま残ります。</div>
                </div>`);
            okBtn.textContent = "出家する";
            cancelBtn.textContent = "まだ遊ぶ";
            cancelBtn.classList.remove("hidden");
            okBtn.onclick = () => {
                const sel = document.getElementById('shukkeCarrySelect');
                const selectedCarryId = sel ? sel.value : '';
                closeModal("customDialogModal");
                performShukke(selectedCarryId);
            };
            cancelBtn.onclick = () => { closeModal("customDialogModal"); };
            document.getElementById("customDialogModal").classList.remove("hidden");
        }

        function performShukke(selectedCarryId = '') {
            state.shukkeCount = (state.shukkeCount || 0) + 1;
            const permanent = Array.isArray(state.permanentOwned) ? state.permanentOwned.slice() : [];
            const prevOwned = Array.isArray(state.ownedUnits) ? state.ownedUnits.slice() : [];
            const prevOwnershipCounts = (state.unitOwnershipCounts && typeof state.unitOwnershipCounts === 'object') ? JSON.parse(JSON.stringify(state.unitOwnershipCounts)) : {};
            const prevNoble = (state.noble && typeof state.noble === 'object') ? JSON.parse(JSON.stringify(state.noble)) : { level: 1, outfits: {} };
            let granted = false;
            if (state.shukkeCount >= 2 && !permanent.includes("butsu_001")) {
                permanent.push("butsu_001");
                granted = true;
            }
            state.permanentOwned = permanent;

            const isGodId = (id) => {
                if (id === 'kaguya_001' || id === 'butsu_001' || id === 'amaterasu_001' || isBossRushGodId(id)) return true;
                const u = getUnit(id);
                return !!(u && u.rarity === '神');
            };
            const carryOwnedSet = new Set(prevOwned.filter(isGodId));
            if (selectedCarryId && prevOwned.includes(selectedCarryId)) carryOwnedSet.add(selectedCarryId);
            permanent.forEach(pid => carryOwnedSet.add(pid));

            const carryLevels = {}, carrySpecLevels = {};
            Array.from(carryOwnedSet).forEach(id => {
                if (state.unitLevels && typeof state.unitLevels[id] === 'number') carryLevels[id] = state.unitLevels[id];
                if (state.unitSpecialLevels && typeof state.unitSpecialLevels[id] === 'number') carrySpecLevels[id] = state.unitSpecialLevels[id];
            });

            state.coins = 1000;
            state.gems = 100;
            state.deck = ["ch_000"];
            state.subDeck = [];
            state.ownedUnits = ["ch_000"];
            state.noble = JSON.parse(JSON.stringify(prevNoble));
            if (typeof state.noble.level !== 'number' || state.noble.level < 1) state.noble.level = 1;
            state.unitLevels = {};
            state.unitSpecialLevels = {};
            state.unitOwnershipCounts = { "ch_000": 1 };
            state.clearedStages = {};
            state.wrongWords = [];
            state.bossRushBest = 0;
            state.bossRushProgress = null;
            bossRushState = null;
            state.weekdayPoints = { mon:0, tue:0, wed:0, thu:0, fri:0 };
            state.reviewPoints = 0;
            state.reviewGachaPityCount = 0;
            state.gachaUnlocks = {};

            state.godPreserved = { owned: Array.from(carryOwnedSet), levels: carryLevels, specLevels: carrySpecLevels };
            Array.from(carryOwnedSet).forEach(id => {
                if (!state.ownedUnits.includes(id)) state.ownedUnits.push(id);
                state.unitOwnershipCounts[id] = Math.max(1, Math.floor(Number(prevOwnershipCounts[id]) || 1));
                if (Object.prototype.hasOwnProperty.call(carryLevels, id)) state.unitLevels[id] = carryLevels[id];
                if (Object.prototype.hasOwnProperty.call(carrySpecLevels, id)) state.unitSpecialLevels[id] = Math.min(50, carrySpecLevels[id]);
            });
            if (permanent.length) {
                state.ownedUnits = ["ch_000", ...state.ownedUnits.filter(id => id !== "ch_000")];
                if (permanent.includes("butsu_001") && !state.deck.includes("butsu_001") && state.deck.length < getMaxDeckSize()) {
                    state.deck.push("butsu_001");
                }
            }
            if (selectedCarryId && state.ownedUnits.includes(selectedCarryId) && !state.deck.includes(selectedCarryId) && state.deck.length < getMaxDeckSize()) {
                state.deck.push(selectedCarryId);
            }
            ensureNobleFixedDeck();
            saveState();

            const carryName = selectedCarryId && getUnit(selectedCarryId) ? getUnit(selectedCarryId).name : 'なし';
            showCustomAlert(
                granted ? "悟りを開きました！" : "出家しました",
                granted
                    ? `進行状況をリセットし、貴族と「${carryName}」を引き継ぎました。
さらに、最強キャラ『仏』を永久所持しました！`
                    : `進行状況をリセットし、貴族と「${carryName}」を引き継ぎました。
（出家 ${state.shukkeCount} 回目）
あと一度出家すると、最強キャラ『仏』を永久所持できます。`,
                () => location.reload()
            );
        }

