        // ============================================================
        // 曜日ダンジョン（仮実装）: 月曜「レベル半減」・火曜「寝返り」・水曜「変身」・木曜「古語」・金曜「ランダム編成」
        // ※ 通常ダンジョンの「スキル・必殺無効化（機能停止）」は曜日では発生しない
        // ※ 強化モード（D20以降の敵強化）は継続して発動する
        // ============================================================
        const WEEKDAY_MON = [31, 32, 33, 34, 35, 36, 37, 38, 39, 40];
        const WEEKDAY_TUE = [41, 42, 43, 44, 45, 46, 47, 48, 49, 50];
        const WEEKDAY_WED = [51, 52, 53, 54, 55, 56, 57, 58, 59, 60];
        const WEEKDAY_THU = [61, 62, 63, 64, 65, 66, 67, 68, 69, 70];
        const WEEKDAY_FRI = [71, 72, 73, 74, 75, 76, 77, 78, 79, 80];
        const WEEKDAY_DUNGEON_IDS = [...WEEKDAY_MON, ...WEEKDAY_TUE, ...WEEKDAY_WED, ...WEEKDAY_THU, ...WEEKDAY_FRI];
        // ── 本日の曜日（端末ローカル時刻）─ ①曜日ダンジョンと②曜日ガチャが同じ値を使う ──
        const WEEKDAY_KEY_BY_JSDAY = ['sun','mon','tue','wed','thu','fri','sat'];
        function getTodayWeekdayKey() {
            const d = new Date().getDay(); // 0=日 1=月 ... 5=金 6=土
            return (d >= 1 && d <= 5) ? WEEKDAY_KEY_BY_JSDAY[d] : null;
        }
        function getTodayWeekdayLabel() {
            const k = getTodayWeekdayKey();
            return k ? ({mon:'月曜日',tue:'火曜日',wed:'水曜日',thu:'木曜日',fri:'金曜日'})[k] : '（月〜金のみ開催）';
        }
        const TODAY_WEEKDAY_IDS = (() => {
            const k = getTodayWeekdayKey();
            if (!k) return [];
            return ({ mon: WEEKDAY_MON, tue: WEEKDAY_TUE, wed: WEEKDAY_WED, thu: WEEKDAY_THU, fri: WEEKDAY_FRI })[k] || [];
        })();
        const MONDAY_HALVE_CHANCE = 0.35;   // 敵攻撃時にレベル半減が発動する確率
        const MONDAY_HALVE_SEC = 5.0;       // 半減継続時間（秒）
        const TUESDAY_DEFECT_CHANCE = 0.30; // 敵攻撃時に寝返りが発動する確率
        const TUESDAY_MAX_DEFECTS = 3;      // 戦闘中の寝返り上限（体）
        const TUESDAY_RETURN_SEC = 5.0;     // 寝返り継続時間（秒）

        function isWeekdayDungeon(dn) { return WEEKDAY_DUNGEON_IDS.includes(dn); }
        function isMondayDungeon(dn) { return WEEKDAY_MON.includes(dn); }
        function isTuesdayDungeon(dn) { return WEEKDAY_TUE.includes(dn); }
        function isWednesdayDungeon(dn) { return WEEKDAY_WED.includes(dn); }
        function isThursdayDungeon(dn) { return WEEKDAY_THU.includes(dn); }
        function isFridayDungeon(dn) { return WEEKDAY_FRI.includes(dn); }
        function getWeekdayKeyByDungeonNum(dn) {
            if (isMondayDungeon(dn)) return 'mon';
            if (isTuesdayDungeon(dn)) return 'tue';
            if (isWednesdayDungeon(dn)) return 'wed';
            if (isThursdayDungeon(dn)) return 'thu';
            if (isFridayDungeon(dn)) return 'fri';
            return null;
        }
        function getWeekdayLocalIndex(dn) {
            if (isMondayDungeon(dn)) return WEEKDAY_MON.indexOf(dn) + 1;
            if (isTuesdayDungeon(dn)) return WEEKDAY_TUE.indexOf(dn) + 1;
            if (isWednesdayDungeon(dn)) return WEEKDAY_WED.indexOf(dn) + 1;
            if (isThursdayDungeon(dn)) return WEEKDAY_THU.indexOf(dn) + 1;
            if (isFridayDungeon(dn)) return WEEKDAY_FRI.indexOf(dn) + 1;
            return 0;
        }
        function getWeekdayStageProgress(dn, stageNum) {
            const local = getWeekdayLocalIndex(dn);
            if (!local) return stageNum || 1;
            return (local - 1) * 5 + (stageNum || 1);
        }
        function getWeekdayDungeonListByKey(key) {
            return ({ mon: WEEKDAY_MON, tue: WEEKDAY_TUE, wed: WEEKDAY_WED, thu: WEEKDAY_THU, fri: WEEKDAY_FRI })[key] || [];
        }
        function getWeekdayLateGameDiffMult(dungNum, stageNum) {
            const D16S1_MULT = Math.pow(1.27, 15) * (1 + 1 * 0.11) * 1.06;
            const D30S5_MULT = Math.pow(1.30, 19) * Math.pow(1.38, 10) * (1 + 5 * 0.11) * 1.10;
            const normalLinearMult = (d, s) => {
                const idx = (d === 16) ? (s - 1) : ((d - 16) * 12 + (s - 1));
                const frac = Math.min(1, Math.max(0, idx / 172));
                return D16S1_MULT + (D30S5_MULT - D16S1_MULT) * frac;
            };
            const startMult = normalLinearMult(25, 1);
            const endMult = normalLinearMult(30, 5);
            const progress = getWeekdayStageProgress(dungNum, stageNum);
            const t = Math.min(1, Math.max(0, (progress - 1) / 49));
            return startMult + (endMult - startMult) * t;
        }

        function getUnitLevelValue(id) {
            if (id === 'ch_000') return (state.noble && state.noble.level) ? state.noble.level : 1;
            return (state.unitLevels && state.unitLevels[id]) ? state.unitLevels[id] : 1;
        }

        function getCurrentFormationMaxLevel() {
            const ids = getCombinedBattleDeckIds();
            if (!ids.length) return 1;
            return ids.reduce((mx, id) => Math.max(mx, getUnitLevelValue(id)), 1);
        }

        function getScaledUnitStatsByLevel(unit, lvl) {
            if (!unit) return { hp: 200, atk: 20 };
            let rarityMult = 0.90;
            if (unit.rarity === '神') rarityMult = 3.25;
            else if (unit.rarity === 'UR') rarityMult = 2.35;
            else if (unit.rarity === 'SSR') rarityMult = 1.38;
            else if (unit.rarity === 'SR') rarityMult = 1.08;
            else if (unit.rarity === 'R') rarityMult = 0.90;
            return {
                hp: Math.floor((300 + lvl * 700) * rarityMult),
                atk: Math.floor((30 + lvl * 4) * rarityMult)
            };
        }

        function getFridayEnemyCount(stageNum, dungNum) {
            const weekdayProgress = getWeekdayStageProgress(dungNum, stageNum);
            if (weekdayProgress <= 10) return 5;
            if (weekdayProgress <= 20) return 6;
            if (weekdayProgress <= 30) return 7;
            if (weekdayProgress <= 40) return 8;
            if (weekdayProgress <= 45) return 9;
            return 10;
        }

        function getFridayEnemyStageScale(stageNum, dungNum) {
            return 0.92 + getWeekdayStageProgress(dungNum, stageNum) * 0.018;
        }

        function buildFridayEnemyRoster(stageNum, dungNum) {
            const count = getFridayEnemyCount(stageNum, dungNum);
            const enemyLevel = getCurrentFormationMaxLevel();
            const pool = ALL_GACHA_CHARACTERS().filter(Boolean).slice().sort(() => Math.random() - 0.5).slice(0, count);
            return pool.map(unit => {
                const st = getScaledUnitStatsByLevel(unit, enemyLevel);
                return { id: unit.id, unit: unit, hp: st.hp, maxHp: st.hp, atk: st.atk, level: enemyLevel };
            });
        }

        function getFridayEnemyLineupText(roster, limit = 6) {
            const names = (roster || []).map(r => (r && r.unit ? r.unit.name : (r ? r.id : '???')));
            if (!names.length) return '編成未設定';
            return names.slice(0, limit).join('・') + (names.length > limit ? ` ほか${names.length - limit}体` : '');
        }


        // ============================================================
        // 水曜ギミック: 敵攻撃ごとに確率でメイン編成の1体を
        // ランダムなキャラへ変身させる（対象数に上限なし・貴族も対象・戦闘終了で復帰）
        // ============================================================
        const WEDNESDAY_MORPH_CHANCE = 0.30; // 敵攻撃時に変身が発動する確率
        function applyWednesdayMorph() {
            if (Math.random() >= WEDNESDAY_MORPH_CHANCE) return;
            const targets = battleState.party.filter(p => p && !p.isSub && !p.defected && p.sealedSeconds <= 0);
            if (targets.length === 0) return;
            const t = targets[Math.floor(Math.random() * targets.length)];
            // 変身先候補: 全キャラ（貴族含む・神・かぐや姫・仏も対象）から現キャラを除外
            const candidates = ALL_GACHA_CHARACTERS().filter(u => u && u.id !== t.id);
            if (t.id !== 'ch_000') candidates.push(getUnit('ch_000'));
            if (candidates.length === 0) return;
            const chosen = candidates[Math.floor(Math.random() * candidates.length)];
            if (!chosen) return;
            // 元の状態を保存（戦闘終了時に復元）
            if (!t._orig) {
                t._orig = { id: t.id, unit: t.unit, maxHp: t.maxHp, hp: t.hp, atk: t.atk, gaugePerCorrect: t.gaugePerCorrect, gaugeNeedsVotes: t.gaugeNeedsVotes };
            }
            const oldName = t.unit ? t.unit.name : t.id;
            const newStats = getUnitStats(chosen.id);
            const hpBefore = t.hp;
            const ratio = t.maxHp > 0 ? t.hp / t.maxHp : 1;
            const hpDiff = newStats.hp - t.maxHp;
            t.id = chosen.id;
            t.unit = chosen;
            t.maxHp = newStats.hp;
            t.hp = Math.max(1, Math.floor(newStats.hp * ratio));
            t.atk = newStats.atk;
            t.gaugePerCorrect = (chosen.gaugePerCorrect !== undefined) ? chosen.gaugePerCorrect : 15;
            t.gaugeNeedsVotes = (chosen.gaugeNeedsVotes !== undefined) ? chosen.gaugeNeedsVotes : 5;
            battleState.maxPlayerHp = Math.max(1, battleState.maxPlayerHp + hpDiff);
            battleState.playerHp = Math.max(0, battleState.playerHp + (t.hp - hpBefore));
            recalculateBattleSynergies();
            const pBox = document.getElementById("playerSideBox");
            createFloatingText(`🃏 ${oldName}が ${chosen.name} に変化した！`, pBox, "text-fuchsia-400 text-sm font-black");
            updateBattleUI();
            if (battleState.playerHp <= 0) endBattle(false);
        }

        // ============================================================
        // 木曜ギミック: 現代の意味（日本語）から古語を選ぶ逆引き出題
        // ※ 古語は確実に現代語訳が対応するもののみ収録
        // ============================================================
        const KOGO_REVERSE_QUIZ = [
            { word: "～（する）とすぐに・～ので・～につれて", primary: "〜ままに", kogoMode: true, synonymous: [] },
            { word: "～（する）とすぐに", primary: "〜やおそきと", kogoMode: true, synonymous: [] },
            { word: "つまらない・なんとなく", primary: "あいなし", kogoMode: true, synonymous: [] },
            { word: "明るい", primary: "あかし〔明かし〕", kogoMode: true, synonymous: [] },
            { word: "満足しない・飽きることがない", primary: "あかず〔飽かず〕", kogoMode: true, synonymous: [] },
            { word: "満足していないのに・名残惜しいのに", primary: "あかなくに〔飽かなくに〕", kogoMode: true, synonymous: [] },
            { word: "ほんのちょっと", primary: "あからさまなり", kogoMode: true, synonymous: [] },
            { word: "よそ見もしない", primary: "あからめもせず", kogoMode: true, synonymous: [] },
            { word: "明らかにする", primary: "あきらむ〔明らむ〕", kogoMode: true, synonymous: [] },
            { word: "途方に暮れる", primary: "あきる〔呆る〕", kogoMode: true, synonymous: [] },
            { word: "満足する・飽きる", primary: "あく〔飽く〕", kogoMode: true, synonymous: [] },
            { word: "（魂が体から）さまよい出る・浮かれ歩く", primary: "あくがる", kogoMode: true, synonymous: [] },
            { word: "驚くほどだ・あきれるほどだ・情けない", primary: "あさまし", kogoMode: true, synonymous: [] },
            { word: "驚く・あきれる", primary: "あさむ", kogoMode: true, synonymous: [] },
            { word: "悪い", primary: "あし", kogoMode: true, synonymous: [] },
            { word: "朝・翌朝", primary: "あした〔朝〕", kogoMode: true, synonymous: [] },
            { word: "（何かを）なさる", primary: "あそばす〔遊ばす〕", kogoMode: true, synonymous: [] },
            { word: "管弦の遊び", primary: "あそび〔遊び〕", kogoMode: true, synonymous: [] },
            { word: "管弦を楽しむ", primary: "あそぶ", kogoMode: true, synonymous: [] },
            { word: "惜しむべき・惜しいことに", primary: "あたら", kogoMode: true, synonymous: [] },
            { word: "惜しい", primary: "あたらし〔惜し〕", kogoMode: true, synonymous: [] },
            { word: "不誠実だ・浮気だ", primary: "あだあだし", kogoMode: true, synonymous: [] },
            { word: "はかない・浮気だ", primary: "あだなり〔徒なり〕", kogoMode: true, synonymous: [] },
            { word: "おもしろくない・つまらない", primary: "あぢきなし", kogoMode: true, synonymous: [] },
            { word: "面倒を見る・もてあます", primary: "あつかふ〔扱ふ〕", kogoMode: true, synonymous: [] },
            { word: "高貴である・上品である", primary: "あてなり〔貴なり〕", kogoMode: true, synonymous: [] },
            { word: "高貴だ・上品だ", primary: "あてやかなり", kogoMode: true, synonymous: [] },
            { word: "決して（～するな）", primary: "あなかしこ（～禁止）", kogoMode: true, synonymous: [] },
            { word: "ああ、うるさい・静かに", primary: "あなかま", kogoMode: true, synonymous: [] },
            { word: "強引だ・むやみに", primary: "あながちなり〔強ちなり〕", kogoMode: true, synonymous: [] },
            { word: "向こう", primary: "あなた", kogoMode: true, synonymous: [] },
            { word: "ああ", primary: "あはれ", kogoMode: true, synonymous: [] },
            { word: "しみじみと心に深く感じられる", primary: "あはれなり", kogoMode: true, synonymous: [] },
            { word: "結婚する", primary: "あふ〔合（会・逢）ふ〕", kogoMode: true, synonymous: [] },
            { word: "〈打消を伴い〉耐えられない・〈動詞につき、打消を伴い〉～きれない", primary: "あふ〔敢ふ〕", kogoMode: true, synonymous: [] },
            { word: "落胆している・はかない", primary: "あへなし〔敢へ無し〕", kogoMode: true, synonymous: [] },
            { word: "不思議だ", primary: "あやし〔怪し〕", kogoMode: true, synonymous: [] },
            { word: "身分が低い・粗末だ", primary: "あやし〔賤し〕", kogoMode: true, synonymous: [] },
            { word: "わけがわからない", primary: "あやなし〔文無し〕", kogoMode: true, synonymous: [] },
            { word: "意地が悪い・あいにくだ", primary: "あやにくなり", kogoMode: true, synonymous: [] },
            { word: "（物事の）道理", primary: "あやめ〔文目〕", kogoMode: true, synonymous: [] },
            { word: "別の", primary: "あらぬ", kogoMode: true, synonymous: [] },
            { word: "まる見えである", primary: "あらはなり〔顕なり〕", kogoMode: true, synonymous: [] },
            { word: "予想・期待", primary: "あらまし", kogoMode: true, synonymous: [] },
            { word: "望ましい", primary: "あらまほし", kogoMode: true, synonymous: [] },
            { word: "ある・いる・（ものごとを）する", primary: "あり", kogoMode: true, synonymous: [] },
            { word: "生き続けて・結局", primary: "ありありて", kogoMode: true, synonymous: [] },
            { word: "めったにない・すばらしい", primary: "ありがたし", kogoMode: true, synonymous: [] },
            { word: "出歩く・～しまわる・～続ける", primary: "ありく〔歩く〕", kogoMode: true, synonymous: [] },
            { word: "以前の・あの", primary: "ありし", kogoMode: true, synonymous: [] },
            { word: "先程の", primary: "ありつる", kogoMode: true, synonymous: [] },
            { word: "主人", primary: "あるじ〔主〕", kogoMode: true, synonymous: [] },
            { word: "もてなし", primary: "あるじ〔饗〕", kogoMode: true, synonymous: [] },
            { word: "優れている・優雅である", primary: "いうなり〔優なり〕", kogoMode: true, synonymous: [] },
            { word: "寝坊だ", primary: "いぎたなし", kogoMode: true, synonymous: [] },
            { word: "さあいらっしゃい", primary: "いざさせ給へ", kogoMode: true, synonymous: [] },
            { word: "さあ、いらっしゃい", primary: "いざ給へ", kogoMode: true, synonymous: [] },
            { word: "さあ、～分からない", primary: "いざ～知らず", kogoMode: true, synonymous: [] },
            { word: "準備", primary: "いそぎ〔急ぎ〕", kogoMode: true, synonymous: [] },
            { word: "準備する", primary: "いそぐ〔急ぐ〕", kogoMode: true, synonymous: [] },
            { word: "すばらしい・ひどい・はなはだしく・〈いたく（う）の形で打消を伴って〉それほど", primary: "いたし〔甚し・痛し〕", kogoMode: true, synonymous: [] },
            { word: "役に立たない・むなしい", primary: "いたづらなり〔徒らなり〕", kogoMode: true, synonymous: [] },
            { word: "病気で苦しむ・苦労する", primary: "いたはる", kogoMode: true, synonymous: [] },
            { word: "摂政・関白", primary: "いちのひと〔一の人〕", kogoMode: true, synonymous: [] },
            { word: "いつ（疑問）", primary: "いつ", kogoMode: true, synonymous: [] },
            { word: "いつの間にか・（できるだけ）早く（～してほしい）", primary: "いつしか", kogoMode: true, synonymous: [] },
            { word: "どれ", primary: "いづれ", kogoMode: true, synonymous: [] },
            { word: "気の毒だ", primary: "いとおし", kogoMode: true, synonymous: [] },
            { word: "ますます", primary: "いとど", kogoMode: true, synonymous: [] },
            { word: "いっそうはなはだしい・いよいよ著しい", primary: "いとどし", kogoMode: true, synonymous: [] },
            { word: "暇・（仕事を）休むこと", primary: "いとま〔暇〕", kogoMode: true, synonymous: [] },
            { word: "子どもっぽい", primary: "いはけなし", kogoMode: true, synonymous: [] },
            { word: "言ってもかいがない・つまらない・取るに足りない", primary: "いふかひなし", kogoMode: true, synonymous: [] },
            { word: "うっとうしい・気がかりだ", primary: "いぶせし", kogoMode: true, synonymous: [] },
            { word: "すぐに・もう", primary: "いま〔今〕", kogoMode: true, synonymous: [] },
            { word: "不吉だ", primary: "いまいまいし〔忌ま忌まし〕", kogoMode: true, synonymous: [] },
            { word: "当世風だ", primary: "いまめかし", kogoMode: true, synonymous: [] },
            { word: "すばらしい・ひどい・とても", primary: "いみぢ", kogoMode: true, synonymous: [] },
            { word: "親しいあなた", primary: "いも〔妹〕", kogoMode: true, synonymous: [] },
            { word: "身分が低い・みすぼらしい", primary: "いやし", kogoMode: true, synonymous: [] },
            { word: "答える", primary: "いらふ〔答ふ〕", kogoMode: true, synonymous: [] },
            { word: "つらい・いやだ", primary: "うし〔憂し〕", kogoMode: true, synonymous: [] },
            { word: "安心だ", primary: "うしろやすし", kogoMode: true, synonymous: [] },
            { word: "いやな感じに・異様に怪しく", primary: "うたて", kogoMode: true, synonymous: [] },
            { word: "いやだ", primary: "うたてし", kogoMode: true, synonymous: [] },
            { word: "宮中・帝", primary: "うち〔内裏・内〕", kogoMode: true, synonymous: [] },
            { word: "にわかだ・軽率だ", primary: "うちつけなり", kogoMode: true, synonymous: [] },
            { word: "くつろぐ・油断する", primary: "うちとく", kogoMode: true, synonymous: [] },
            { word: "現実・正気", primary: "うつつ〔現〕", kogoMode: true, synonymous: [] },
            { word: "色あせる", primary: "うつろふ〔移ろふ〕", kogoMode: true, synonymous: [] },
            { word: "（心の内を）包み隠すことがない", primary: "うらなし〔心なし〕", kogoMode: true, synonymous: [] },
            { word: "煩わしい・立派だ", primary: "うるさし", kogoMode: true, synonymous: [] },
            { word: "賢い・巧みだ", primary: "うるせし", kogoMode: true, synonymous: [] },
            { word: "きちんとしている・美しい", primary: "うるはし", kogoMode: true, synonymous: [] },
            { word: "（嘆き）訴える", primary: "うれふ〔愁ふ・憂ふ〕", kogoMode: true, synonymous: [] },
            { word: "訴え", primary: "うれへ〔愁へ・憂へ〕", kogoMode: true, synonymous: [] },
            { word: "〈下に打消を伴い〉（～する）ことができない", primary: "え～（打消）", kogoMode: true, synonymous: [] },
            { word: "決めておく・指図する", primary: "おきつ〔掟つ〕", kogoMode: true, synonymous: [] },
            { word: "先立たれる", primary: "おくる〔後る・遅る〕", kogoMode: true, synonymous: [] },
            { word: "およこす", primary: "おこす", kogoMode: true, synonymous: [] },
            { word: "（過失の）おわび・謝罪", primary: "おこたり", kogoMode: true, synonymous: [] },
            { word: "病気が治る", primary: "おこたる〔怠る〕", kogoMode: true, synonymous: [] },
            { word: "仏道修行", primary: "おこない〔行ひ〕", kogoMode: true, synonymous: [] },
            { word: "仏道修行をする", primary: "おこなふ〔行ふ〕", kogoMode: true, synonymous: [] },
            { word: "妹", primary: "おとうと・をとと〔弟〕", kogoMode: true, synonymous: [] },
            { word: "思慮分別がある・主だっている", primary: "おとなし〔大人し〕", kogoMode: true, synonymous: [] },
            { word: "大げさだ・気味が悪い", primary: "おどろおどろし", kogoMode: true, synonymous: [] },
            { word: "起こす・（はっと）気づかせる", primary: "おどろかす", kogoMode: true, synonymous: [] },
            { word: "目を覚ます・（はっと）気づく", primary: "おどろく〔驚く〕", kogoMode: true, synonymous: [] },
            { word: "朝廷・帝", primary: "おほけや〔公〕", kogoMode: true, synonymous: [] },
            { word: "（世間の）評判・寵愛されること", primary: "おぼえ〔覚へ〕", kogoMode: true, synonymous: [] },
            { word: "身のほど知らずだ", primary: "おぼけなし", kogoMode: true, synonymous: [] },
            { word: "はっきりしない・気がかりだ・待ち遠しい", primary: "おぼつかなし〔覚束無し〕", kogoMode: true, synonymous: [] },
            { word: "思われる・思い出される・似る", primary: "おぼゆ〔覚ゆ〕", kogoMode: true, synonymous: [] },
            { word: "並ひととおりだ・並ひととおりではない", primary: "おぼろげなり", kogoMode: true, synonymous: [] },
            { word: "思いがけない・不満だ", primary: "おもほえずなり", kogoMode: true, synonymous: [] },
            { word: "成長する・大人びる", primary: "およすく・およすぐ", kogoMode: true, synonymous: [] },
            { word: "いい加減だ・並ひととおりだ", primary: "おろかなり〔疎かなり〕", kogoMode: true, synonymous: [] },
            { word: "あの人・あれ", primary: "か", kogoMode: true, synonymous: [] },
            { word: "のぞき見", primary: "かいまみ〔垣間見〕", kogoMode: true, synonymous: [] },
            { word: "のぞき見る", primary: "かいまみる〔垣間見る〕", kogoMode: true, synonymous: [] },
            { word: "こうである", primary: "かかり", kogoMode: true, synonymous: [] },
            { word: "こうしているうちに", primary: "かかるほどに", kogoMode: true, synonymous: [] },
            { word: "こうではあるが", primary: "かかれど", kogoMode: true, synonymous: [] },
            { word: "こうであるので", primary: "かかれば", kogoMode: true, synonymous: [] },
            { word: "空を暗くする・悲しみにくれる", primary: "かきくらす〔掻き暗す〕", kogoMode: true, synonymous: [] },
            { word: "限界・限度・臨終・すべて", primary: "かぎり〔限り〕", kogoMode: true, synonymous: [] },
            { word: "このように", primary: "かく", kogoMode: true, synonymous: [] },
            { word: "光・姿", primary: "かげ〔影〕", kogoMode: true, synonymous: [] },
            { word: "日陰・光の当たらない所", primary: "かげ〔陰〕", kogoMode: true, synonymous: [] },
            { word: "嘆く", primary: "かこつ〔託つ〕", kogoMode: true, synonymous: [] },
            { word: "言い訳・恨み言", primary: "かごと〔託言〕", kogoMode: true, synonymous: [] },
            { word: "恨みがましい", primary: "かごとがまし", kogoMode: true, synonymous: [] },
            { word: "おそれ多い・優れている・うまい具合に", primary: "かしこし〔畏し・賢し〕", kogoMode: true, synonymous: [] },
            { word: "恐縮する・恐縮して正座する", primary: "かしこまる〔畏まる〕", kogoMode: true, synonymous: [] },
            { word: "大切に育てる・大切にお世話をする", primary: "かしづく", kogoMode: true, synonymous: [] },
            { word: "おそれ多い・面目ない", primary: "かたじけなし〔忝し〕", kogoMode: true, synonymous: [] },
            { word: "きまり悪い・苦々しい・気の毒だ", primary: "かたはらいたし", kogoMode: true, synonymous: [] },
            { word: "半分・傍ら・仲間", primary: "かたへ〔片方〕", kogoMode: true, synonymous: [] },
            { word: "不完全だ・未熟だ", primary: "かたほなり", kogoMode: true, synonymous: [] },
            { word: "互いに", primary: "かたみに〔互に〕", kogoMode: true, synonymous: [] },
            { word: "語り合う・親しく交際する・（男女が）契る・説得する", primary: "かたらふ〔語らふ〕", kogoMode: true, synonymous: [] },
            { word: "一方では・すぐに", primary: "かつ", kogoMode: true, synonymous: [] },
            { word: "かぶる・（貴人からほうびとして）いただく", primary: "かづくA〔被く〕", kogoMode: true, synonymous: [] },
            { word: "（貴人がほうびとして）与える", primary: "かづくB〔被く〕", kogoMode: true, synonymous: [] },
            { word: "ほうびの品物", primary: "かづけもの", kogoMode: true, synonymous: [] },
            { word: "いとしい", primary: "かなし", kogoMode: true, synonymous: [] },
            { word: "かわいがる", primary: "かなしうす", kogoMode: true, synonymous: [] },
            { word: "あちら", primary: "かなた", kogoMode: true, synonymous: [] },
            { word: "決して（～ない・～するな）・なんとかして", primary: "かまへて（～打消・禁止）", kogoMode: true, synonymous: [] },
            { word: "ほんの一時的である", primary: "かりそめなり", kogoMode: true, synonymous: [] },
            { word: "離れる", primary: "かる〔離る〕", kogoMode: true, synonymous: [] },
            { word: "あの人", primary: "かれ", kogoMode: true, synonymous: [] },
            { word: "身分", primary: "きは〔際〕", kogoMode: true, synonymous: [] },
            { word: "繰り返し同じことを言う・意中を訴える", primary: "くどく〔口説く〕", kogoMode: true, synonymous: [] },
            { word: "不都合ではない・差し支えない", primary: "くるしからず", kogoMode: true, synonymous: [] },
            { word: "ため・せい・わけ", primary: "け〔故〕", kogoMode: true, synonymous: [] },
            { word: "不気味だ・寂しい・疎遠だ", primary: "けうとし", kogoMode: true, synonymous: [] },
            { word: "異様だ", primary: "けし〔怪し・異し〕", kogoMode: true, synonymous: [] },
            { word: "様子・機嫌・意向", primary: "けしき〔気色〕", kogoMode: true, synonymous: [] },
            { word: "遠慮・けじめ・区別", primary: "けぢめ", kogoMode: true, synonymous: [] },
            { word: "いよいよ・ますます", primary: "けに", kogoMode: true, synonymous: [] },
            { word: "際立っている・すばらしい・異様だ", primary: "けやけし", kogoMode: true, synonymous: [] },
            { word: "（実際）本当に", primary: "げに〔実に〕", kogoMode: true, synonymous: [] },
            { word: "この人・これ", primary: "こ", kogoMode: true, synonymous: [] },
            { word: "疲れる", primary: "こうず〔困ず〕", kogoMode: true, synonymous: [] },
            { word: "このわたし・こちら", primary: "ここ", kogoMode: true, synonymous: [] },
            { word: "気の毒だ・気がかりだ", primary: "こころぐるし〔心苦し〕", kogoMode: true, synonymous: [] },
            { word: "愛情・お礼の贈り物", primary: "こころざし〔心ざし・志〕", kogoMode: true, synonymous: [] },
            { word: "気にくわない", primary: "こころづきなし", kogoMode: true, synonymous: [] },
            { word: "もの思いをすること", primary: "こころづくし〔心尽くし〕", kogoMode: true, synonymous: [] },
            { word: "奥ゆかしい", primary: "こころにくし", kogoMode: true, synonymous: [] },
            { word: "気だて・心づかい・趣", primary: "こころばへ", kogoMode: true, synonymous: [] },
            { word: "かすかだ・不安だ・じれったい", primary: "こころもとなし〔心許なし〕", kogoMode: true, synonymous: [] },
            { word: "満足する・気が晴れる", primary: "こころゆく", kogoMode: true, synonymous: [] },
            { word: "なだめすかす・説得する", primary: "こしらふ", kogoMode: true, synonymous: [] },
            { word: "こちら", primary: "こち", kogoMode: true, synonymous: [] },
            { word: "（噂や評判が）うるさい・大げさだ・はなはだしい", primary: "こちたし", kogoMode: true, synonymous: [] },
            { word: "不作法だ・無骨だ", primary: "こちなし", kogoMode: true, synonymous: [] },
            { word: "言葉・和歌", primary: "こと〔言〕", kogoMode: true, synonymous: [] },
            { word: "大げさだ", primary: "ことごととし", kogoMode: true, synonymous: [] },
            { word: "異なっている・格別だ", primary: "ことなり〔異なり〕", kogoMode: true, synonymous: [] },
            { word: "特に・とりわけ", primary: "ことに〔殊に〕", kogoMode: true, synonymous: [] },
            { word: "道理", primary: "ことわり〔理〕", kogoMode: true, synonymous: [] },
            { word: "もっともである・当然である", primary: "ことわりなり", kogoMode: true, synonymous: [] },
            { word: "（道理に従って）判断・説明する", primary: "ことわる", kogoMode: true, synonymous: [] },
            { word: "兄・姉・年長者", primary: "このかみ〔兄〕", kogoMode: true, synonymous: [] },
            { word: "もの足りない", primary: "さうざうし", kogoMode: true, synonymous: [] },
            { word: "比べるものがない", primary: "さうなし〔双無し〕", kogoMode: true, synonymous: [] },
            { word: "優れている・しっかりしている・こざかしい", primary: "さかし〔賢し〕", kogoMode: true, synonymous: [] },
            { word: "利口ぶること・こざかしさ", primary: "さかしら", kogoMode: true, synonymous: [] },
            { word: "意地が悪い・いたずらだ", primary: "さがなし", kogoMode: true, synonymous: [] },
            { word: "そうはいってもやはり・なんといってもやはり", primary: "さすがに", kogoMode: true, synonymous: [] },
            { word: "たいした", primary: "させる", kogoMode: true, synonymous: [] },
            { word: "きっと（～だろう）", primary: "さだめて〔定めて〕（～推量）", kogoMode: true, synonymous: [] },
            { word: "そのまま・そのほか", primary: "さて〔然て〕", kogoMode: true, synonymous: [] },
            { word: "そのまま・すべて", primary: "さながら〔然ながら〕", kogoMode: true, synonymous: [] },
            { word: "支障", primary: "さはり〔障り〕", kogoMode: true, synonymous: [] },
            { word: "差し支える・妨げられる", primary: "さはる〔障る〕", kogoMode: true, synonymous: [] },
            { word: "様子・方法・方角", primary: "さま〔様〕", kogoMode: true, synonymous: [] },
            { word: "そうでないならば", primary: "さらじ", kogoMode: true, synonymous: [] },
            { word: "そうでなくて・それ以外で", primary: "さらで", kogoMode: true, synonymous: [] },
            { word: "そうでなくてさえ・ただでさえ", primary: "さらでだに", kogoMode: true, synonymous: [] },
            { word: "そうでなくては・そうでなかったら", primary: "さらでは", kogoMode: true, synonymous: [] },
            { word: "そうでなくても", primary: "さらでも", kogoMode: true, synonymous: [] },
            { word: "そうではない", primary: "さらぬ〔然らぬ〕", kogoMode: true, synonymous: [] },
            { word: "避けられない", primary: "さらぬ〔避らぬ〕", kogoMode: true, synonymous: [] },
            { word: "そうであるといって・だからといって", primary: "さりとて", kogoMode: true, synonymous: [] },
            { word: "そうではあっても・いくらなんでも", primary: "さりとて", kogoMode: true, synonymous: [] },
            { word: "そうではあるが", primary: "さりながら", kogoMode: true, synonymous: [] },
            { word: "（その時に）なる", primary: "さる〔去る〕", kogoMode: true, synonymous: [] },
            { word: "しかるべき・立派な", primary: "さる〔然る〕", kogoMode: true, synonymous: [] },
            { word: "避ける", primary: "さる〔避る〕", kogoMode: true, synonymous: [] },
            { word: "そうなるはずの前世からの因縁であったのだろうか", primary: "さるべきにや（ありけむ）", kogoMode: true, synonymous: [] },
            { word: "そうしているうちに", primary: "さるほどに", kogoMode: true, synonymous: [] },
            { word: "そうであるから", primary: "されば", kogoMode: true, synonymous: [] },
            { word: "そっくりそのまま・すべて", primary: "しかしながら", kogoMode: true, synonymous: [] },
            { word: "そうであるならば", primary: "しからば", kogoMode: true, synonymous: [] },
            { word: "そうであるけれども", primary: "しかれども", kogoMode: true, synonymous: [] },
            { word: "（何かが）多い", primary: "しげし〔繁し・茂し〕", kogoMode: true, synonymous: [] },
            { word: "順序", primary: "しだい〔次第〕", kogoMode: true, synonymous: [] },
            { word: "怠慢だ・気楽だ", primary: "しどけなし", kogoMode: true, synonymous: [] },
            { word: "身分・気品", primary: "しな〔品〕", kogoMode: true, synonymous: [] },
            { word: "がまんする・人目につかないようにする", primary: "しのぶA〔忍ぶ〕", kogoMode: true, synonymous: [] },
            { word: "思い出す", primary: "しのぶB〔偲ぶ〕", kogoMode: true, synonymous: [] },
            { word: "涙を流す", primary: "しほたる〔潮垂る〕", kogoMode: true, synonymous: [] },
            { word: "はっきりと分かる・～（の）とおりに", primary: "しるし〔著し〕", kogoMode: true, synonymous: [] },
            { word: "効き目・ご利益・きざし", primary: "しるし〔験・徴〕", kogoMode: true, synonymous: [] },
            { word: "知っていらっしゃる・お治めになる", primary: "しろしめす", kogoMode: true, synonymous: [] },
            { word: "気味が悪い・さびしい・（ぞっとするほど）すばらしい", primary: "すごし〔凄し〕", kogoMode: true, synonymous: [] },
            { word: "慰みごと", primary: "すさびごと", kogoMode: true, synonymous: [] },
            { word: "（何かに）興じる・気の向くままに（何かを）する", primary: "すさぶ〔荒ぶ・進ぶ・遊ぶ〕", kogoMode: true, synonymous: [] },
            { word: "興ざめだ・殺風景だ", primary: "すさまじ", kogoMode: true, synonymous: [] },
            { word: "抵抗する・断る", primary: "すまふ〔争ふ・辞ふ〕", kogoMode: true, synonymous: [] },
            { word: "兄", primary: "せうと〔兄人〕", kogoMode: true, synonymous: [] },
            { word: "（涙などを）せき止めきれない", primary: "せきあへず〔塞き敢へず〕", kogoMode: true, synonymous: [] },
            { word: "切実である・大切である", primary: "せちなり〔切なり〕", kogoMode: true, synonymous: [] },
            { word: "強いて・ひどく", primary: "せめて", kogoMode: true, synonymous: [] },
            { word: "その人・それ", primary: "そ", kogoMode: true, synonymous: [] },
            { word: "何ということもない", primary: "そこはかとなし", kogoMode: true, synonymous: [] },
            { word: "そちら", primary: "そち", kogoMode: true, synonymous: [] },
            { word: "その当時", primary: "そのかみ", kogoMode: true, synonymous: [] },
            { word: "これということもなく", primary: "そのこととなく", kogoMode: true, synonymous: [] },
            { word: "横目で見る・軽く見る", primary: "そばめにかく", kogoMode: true, synonymous: [] },
            { word: "嘘", primary: "そらごと〔空言・虚言〕", kogoMode: true, synonymous: [] },
            { word: "だ・だれ", primary: "それがし", kogoMode: true, synonymous: [] },
            { word: "もってのほかだ・不都合だ", primary: "たいだいし", kogoMode: true, synonymous: [] },
            { word: "（四段）添う・（下二段）添わせる", primary: "たぐふ", kogoMode: true, synonymous: [] },
            { word: "懐妊する", primary: "ただならずなる", kogoMode: true, synonymous: [] },
            { word: "手段・手がかり", primary: "たづき〔方便〕", kogoMode: true, synonymous: [] },
            { word: "裕福だ", primary: "たのし", kogoMode: true, synonymous: [] },
            { word: "あてにすること・期待", primary: "たのみ", kogoMode: true, synonymous: [] },
            { word: "あてにする", primary: "たのむA〔頼む〕", kogoMode: true, synonymous: [] },
            { word: "あてにさせる", primary: "たのむB〔頼む〕", kogoMode: true, synonymous: [] },
            { word: "あてにさせること", primary: "たのめ", kogoMode: true, synonymous: [] },
            { word: "工夫する・だます", primary: "たばかる〔謀る〕", kogoMode: true, synonymous: [] },
            { word: "お与えになる", primary: "たまはす〔給はす・賜はす〕", kogoMode: true, synonymous: [] },
            { word: "いただく", primary: "たまはる〔賜はる・給はる〕", kogoMode: true, synonymous: [] },
            { word: "先例", primary: "ためし〔例〕", kogoMode: true, synonymous: [] },
            { word: "気持ちを静める", primary: "ためらふ", kogoMode: true, synonymous: [] },
            { word: "よりどころ・つて・よい機会", primary: "たより〔頼り・便り〕", kogoMode: true, synonymous: [] },
            { word: "約束・宿縁", primary: "ちぎり〔契り〕", kogoMode: true, synonymous: [] },
            { word: "序列・機会", primary: "ついで〔序〕", kogoMode: true, synonymous: [] },
            { word: "（人や物を）おやりになる", primary: "つかはす〔遣はす〕", kogoMode: true, synonymous: [] },
            { word: "お仕え申し上げる・（何かを）し申し上げる・（お）～申し上げる", primary: "つかまつる〔仕まつる〕", kogoMode: true, synonymous: [] },
            { word: "数か月（の間）", primary: "つきごろ〔月頃〕", kogoMode: true, synonymous: [] },
            { word: "似つかわしい", primary: "つきづきし〔付き付きし〕", kogoMode: true, synonymous: [] },
            { word: "ふさわしくない", primary: "つきなし", kogoMode: true, synonymous: [] },
            { word: "遠慮される・気がひける", primary: "つつまし", kogoMode: true, synonymous: [] },
            { word: "遠慮する", primary: "つつむ〔慎む〕", kogoMode: true, synonymous: [] },
            { word: "早朝・翌朝", primary: "つとめて", kogoMode: true, synonymous: [] },
            { word: "夫", primary: "つま〔夫・妻〕", kogoMode: true, synonymous: [] },
            { word: "はし・端緒", primary: "つま〔端〕", kogoMode: true, synonymous: [] },
            { word: "涙がちだ", primary: "つゆけし〔露けし〕", kogoMode: true, synonymous: [] },
            { word: "少しも（～ない）", primary: "つゆ（～打消）", kogoMode: true, synonymous: [] },
            { word: "薄情だ", primary: "つらし〔辛し〕", kogoMode: true, synonymous: [] },
            { word: "退屈である・ものさびしい", primary: "つれづれなり〔徒然なり〕", kogoMode: true, synonymous: [] },
            { word: "平然としている・冷淡だ", primary: "つれなし", kogoMode: true, synonymous: [] },
            { word: "あのように", primary: "と", kogoMode: true, synonymous: [] },
            { word: "あれこれと", primary: "とかく", kogoMode: true, synonymous: [] },
            { word: "欠点・罪", primary: "とが〔咎・科〕", kogoMode: true, synonymous: [] },
            { word: "ほかに時もあろうに・よりによってこんな時に", primary: "ときしもあれ", kogoMode: true, synonymous: [] },
            { word: "ちょうどよい時期に出会う・時流に乗って栄える", primary: "ときにあふ", kogoMode: true, synonymous: [] },
            { word: "寵愛する", primary: "ときめかす", kogoMode: true, synonymous: [] },
            { word: "寵愛を受ける・栄える", primary: "ときめく〔時めく〕", kogoMode: true, synonymous: [] },
            { word: "よい地位を得る・得意になる", primary: "ところう〔所得〕", kogoMode: true, synonymous: [] },
            { word: "窮屈だ", primary: "ところせし〔所狭し〕", kogoMode: true, synonymous: [] },
            { word: "早い", primary: "とし〔疾し〕", kogoMode: true, synonymous: [] },
            { word: "長年", primary: "としごろ〔年頃・年比・年来〕", kogoMode: true, synonymous: [] },
            { word: "ちょっとの間・しばらく", primary: "とばかり", kogoMode: true, synonymous: [] },
            { word: "訪ねる・見舞う", primary: "とぶらふA〔訪ふ〕", kogoMode: true, synonymous: [] },
            { word: "弔う", primary: "とぶらふB〔弔ふ〕", kogoMode: true, synonymous: [] },
            { word: "急だ", primary: "とみなり〔頓なり〕", kogoMode: true, synonymous: [] },
            { word: "急に・すぐに", primary: "とみに", kogoMode: true, synonymous: [] },
            { word: "（～する）な・（～し）てはならない", primary: "な〜そ", kogoMode: true, synonymous: [] },
            { word: "中途半端だ・かえってしないほうがよい・かえってないほうがましだ", primary: "なかなかかなり〔中々かなり〕", kogoMode: true, synonymous: [] },
            { word: "もの思いに沈む", primary: "ながむA〔眺む〕", kogoMode: true, synonymous: [] },
            { word: "（漢詩や和歌を）口ずさむ", primary: "ながむB〔詠む〕", kogoMode: true, synonymous: [] },
            { word: "親しみ深い", primary: "なつかし", kogoMode: true, synonymous: [] },
            { word: "並ひととおりだ・いい加減だ・並ひととおりではない", primary: "なのめなり〔斜めなり〕", kogoMode: true, synonymous: [] },
            { word: "一般に・並ひととおり", primary: "なべて", kogoMode: true, synonymous: [] },
            { word: "なんといってもやはり・それでもやはり", primary: "なほ〔猶〕", kogoMode: true, synonymous: [] },
            { word: "本気でない・いい加減だ", primary: "なほざりなり", kogoMode: true, synonymous: [] },
            { word: "上品だ・若々しい", primary: "なまめかし", kogoMode: true, synonymous: [] },
            { word: "落ち着いて上品だ・若くみずみずしい", primary: "なまめく", kogoMode: true, synonymous: [] },
            { word: "無礼だ", primary: "なめし", kogoMode: true, synonymous: [] },
            { word: "病気になる", primary: "なやむ〔悩む〕", kogoMode: true, synonymous: [] },
            { word: "習慣", primary: "ならひ〔慣らひ〕", kogoMode: true, synonymous: [] },
            { word: "慣れる・なじむ", primary: "ならふ〔慣らふ・馴らふ〕", kogoMode: true, synonymous: [] },
            { word: "気にくわない・いやだ", primary: "にくし", kogoMode: true, synonymous: [] },
            { word: "美しい色つや・香り", primary: "にほひ", kogoMode: true, synonymous: [] },
            { word: "美しく映える", primary: "にほふ〔匂ふ〕", kogoMode: true, synonymous: [] },
            { word: "くやしい", primary: "ねたし〔妬し〕", kogoMode: true, synonymous: [] },
            { word: "年をとる・大人びる", primary: "ねぶ", kogoMode: true, synonymous: [] },
            { word: "我慢する", primary: "ねんず〔念ず〕", kogoMode: true, synonymous: [] },
            { word: "大声で騒ぐ・評判になる・羽振りをきかす", primary: "ののしる", kogoMode: true, synonymous: [] },
            { word: "頼りない・ちょっとしたことだ", primary: "はかなし", kogoMode: true, synonymous: [] },
            { word: "しっかりしている・はっきりしている", primary: "はかばかし", kogoMode: true, synonymous: [] },
            { word: "企てる・だます", primary: "はかる", kogoMode: true, synonymous: [] },
            { word: "（いたたまれないほど）そっけない・激しい・きまり悪い", primary: "はしたなし", kogoMode: true, synonymous: [] },
            { word: "恥ずかしい思いをさせる", primary: "はしたなむ", kogoMode: true, synonymous: [] },
            { word: "また・やはり", primary: "はた", kogoMode: true, synonymous: [] },
            { word: "立派だ", primary: "はづかし〔恥づかし〕", kogoMode: true, synonymous: [] },
            { word: "（貴人の側に）お仕え申し上げる・あります・～（でござい）ます", primary: "はべり〔侍り〕", kogoMode: true, synonymous: [] },
            { word: "兄弟", primary: "はらから〔同胞〕", kogoMode: true, synonymous: [] },
            { word: "間違い", primary: "ひがこと・ひがごと〔僻事〕", kogoMode: true, synonymous: [] },
            { word: "ひねくれている・風流心がない", primary: "ひがひがし", kogoMode: true, synonymous: [] },
            { word: "数日（の間）", primary: "ひごろ〔日頃〕", kogoMode: true, synonymous: [] },
            { word: "他人のせいで（ある）・自分のせいで（ある）", primary: "ひとやりならず", kogoMode: true, synonymous: [] },
            { word: "みっともない", primary: "ひとわろし〔人悪し〕", kogoMode: true, synonymous: [] },
            { word: "すき間・合間", primary: "ひま〔隙・暇〕", kogoMode: true, synonymous: [] },
            { word: "なじみの土地・（家を離れた人にとって）わが家", primary: "ふるさと〔古里・故郷〕", kogoMode: true, synonymous: [] },
            { word: "かねてからの願い", primary: "ほい〔本意〕", kogoMode: true, synonymous: [] },
            { word: "障害となるもの", primary: "ほだし〔絆〕", kogoMode: true, synonymous: [] },
            { word: "ころ・広さ・身分・様子", primary: "ほど〔程〕", kogoMode: true, synonymous: [] },
            { word: "用意する", primary: "まうく〔設く〕", kogoMode: true, synonymous: [] },
            { word: "用意・もてなし", primary: "まうけ", kogoMode: true, synonymous: [] },
            { word: "皇太子", primary: "まうけの君", kogoMode: true, synonymous: [] },
            { word: "参上する", primary: "まうづ〔詣づ〕", kogoMode: true, synonymous: [] },
            { word: "真実", primary: "まこと〔真〕", kogoMode: true, synonymous: [] },
            { word: "完全だ", primary: "またし", kogoMode: true, synonymous: [] },
            { word: "次の", primary: "またの", kogoMode: true, synonymous: [] },
            { word: "早くも", primary: "まだき", kogoMode: true, synonymous: [] },
            { word: "まだ早い", primary: "まだし〔未し〕", kogoMode: true, synonymous: [] },
            { word: "迷う・ひどく（～する）", primary: "まどふ〔惑ふ〕", kogoMode: true, synonymous: [] },
            { word: "まねる・（見聞きした物事をそのまま）伝える", primary: "まねぶ〔学ぶ〕", kogoMode: true, synonymous: [] },
            { word: "まぶしい・（まばゆいほど）美しい・恥ずかしい・見ていられない", primary: "まばゆし", kogoMode: true, synonymous: [] },
            { word: "完全である", primary: "まほなり", kogoMode: true, synonymous: [] },
            { word: "まじめだ・実用的だ", primary: "まめまめし", kogoMode: true, synonymous: [] },
            { word: "参上する・（貴人に何かをして）差し上げる・召し上がる", primary: "まゐる〔参る〕", kogoMode: true, synonymous: [] },
            { word: "ひそかに", primary: "みそかなり〔密かなり〕", kogoMode: true, synonymous: [] },
            { word: "わたし・その人自身", primary: "みづから〔自ら〕", kogoMode: true, synonymous: [] },
            { word: "見た目・容貌", primary: "みめ〔見目〕", kogoMode: true, synonymous: [] },
            { word: "気味が悪い・恐ろしい・無骨だ・ひどい・ひどく", primary: "むくつけし", kogoMode: true, synonymous: [] },
            { word: "ひどい・ひどく", primary: "むげなり〔無下なり〕", kogoMode: true, synonymous: [] },
            { word: "できる", primary: "むすぶA〔結ぶ〕", kogoMode: true, synonymous: [] },
            { word: "（両手で水などを）すくう", primary: "むすぶB〔掬ぶ〕", kogoMode: true, synonymous: [] },
            { word: "不快に思う", primary: "むつかる", kogoMode: true, synonymous: [] },
            { word: "気にくわない・すばらしい", primary: "めざまし〔目覚まし〕", kogoMode: true, synonymous: [] },
            { word: "愛する・感嘆する", primary: "めづ〔愛づ〕", kogoMode: true, synonymous: [] },
            { word: "（見た目の）感じがよい", primary: "めやすし〔目安し〕", kogoMode: true, synonymous: [] },
            { word: "振る舞う・取り扱う", primary: "もてなす", kogoMode: true, synonymous: [] },
            { word: "正気を失ったようだ", primary: "ものぐるほし", kogoMode: true, synonymous: [] },
            { word: "不快だ・見苦しい", primary: "ものし", kogoMode: true, synonymous: [] },
            { word: "（ものごとを）する・いらっしゃる", primary: "ものす〔物す〕", kogoMode: true, synonymous: [] },
            { word: "様子・理由・方法・～ことには", primary: "やう〔様〕", kogoMode: true, synonymous: [] },
            { word: "（ある状態が）そのまま・（時間的に）すぐに", primary: "やがて", kogoMode: true, synonymous: [] },
            { word: "優美だ・上品だ・殊勝だ", primary: "やさし〔恥し・優し〕", kogoMode: true, synonymous: [] },
            { word: "質素にする・出家する", primary: "やす", kogoMode: true, synonymous: [] },
            { word: "かいがない・むだだ", primary: "やすくなし〔益なし〕", kogoMode: true, synonymous: [] },
            { word: "ためらう・立ち止まる", primary: "やすらふ〔休らふ〕", kogoMode: true, synonymous: [] },
            { word: "目立たない服装（様子）になる", primary: "やする", kogoMode: true, synonymous: [] },
            { word: "（そのまま）終わる", primary: "やむ〔止む〕", kogoMode: true, synonymous: [] },
            { word: "～であろうか", primary: "やらん", kogoMode: true, synonymous: [] },
            { word: "破る", primary: "やる〔破る〕", kogoMode: true, synonymous: [] },
            { word: "（物を）送る・～きれない", primary: "やる〔遣る〕", kogoMode: true, synonymous: [] },
            { word: "見たい・聞きたい・知りたい・心ひかれる", primary: "ゆかし", kogoMode: true, synonymous: [] },
            { word: "突然だ", primary: "ゆくりなし", kogoMode: true, synonymous: [] },
            { word: "不吉だ・すばらしい・はなはだしく", primary: "ゆゆし", kogoMode: true, synonymous: [] },
            { word: "理由・風情・由緒", primary: "ゆゑ〔故〕", kogoMode: true, synonymous: [] },
            { word: "身分が高い・教養がある・よい", primary: "よし", kogoMode: true, synonymous: [] },
            { word: "風情・由緒・手立て・こと", primary: "よし〔由〕", kogoMode: true, synonymous: [] },
            { word: "由緒・教養がある・風情がある", primary: "よしあり", kogoMode: true, synonymous: [] },
            { word: "つまらない・関係がない", primary: "よしなし〔由無し〕", kogoMode: true, synonymous: [] },
            { word: "つまらないこと", primary: "よしなしごと", kogoMode: true, synonymous: [] },
            { word: "呼び続ける・求婚する", primary: "よばふ〔呼ばふ〕", kogoMode: true, synonymous: [] },
            { word: "まさか（～ないだろう）", primary: "よも（～打消推量）", kogoMode: true, synonymous: [] },
            { word: "（昇進・任官の）お礼・お礼を申し上げること", primary: "よろこび〔喜び〕", kogoMode: true, synonymous: [] },
            { word: "お礼を申し上げること", primary: "よろこび申し", kogoMode: true, synonymous: [] },
            { word: "悪くはない・普通だ", primary: "よろし", kogoMode: true, synonymous: [] },
            { word: "さまざま・何ごとにつけても", primary: "よろづ〔万〕", kogoMode: true, synonymous: [] },
            { word: "騒がしい・乱雑だ", primary: "らうがはし", kogoMode: true, synonymous: [] },
            { word: "かわいらしい", primary: "らうたげなり", kogoMode: true, synonymous: [] },
            { word: "巧みだ・上品だ", primary: "らうらうじ〔労労じ〕", kogoMode: true, synonymous: [] },
            { word: "ほうび", primary: "ろく〔禄〕", kogoMode: true, synonymous: [] },
            { word: "理解しがたい", primary: "わきがたし", kogoMode: true, synonymous: [] },
            { word: "理解する", primary: "わく〔分く〕", kogoMode: true, synonymous: [] },
            { word: "こと・葬儀", primary: "わざ〔業〕", kogoMode: true, synonymous: [] },
            { word: "わざと・特に・（下に「の」を伴い）正式な", primary: "わざと", kogoMode: true, synonymous: [] },
            { word: "ことさらではない", primary: "わざとならず", kogoMode: true, synonymous: [] },
            { word: "移す", primary: "わたす", kogoMode: true, synonymous: [] },
            { word: "通る・いらっしゃる・～続ける・一面に（～する）", primary: "わたる〔渡る〕", kogoMode: true, synonymous: [] },
            { word: "苦しむ・～しかねる", primary: "わづらふ", kogoMode: true, synonymous: [] },
            { word: "苦しい", primary: "わびし〔侘びし〕", kogoMode: true, synonymous: [] },
            { word: "困る・嘆く・～かねる", primary: "わぶ〔侘ぶ〕", kogoMode: true, synonymous: [] },
            { word: "ひどい・どうしようもない・苦しい", primary: "わりなし", kogoMode: true, synonymous: [] },
            { word: "座る・～ている", primary: "ゐるA〔居る〕", kogoMode: true, synonymous: [] },
            { word: "連れる", primary: "ゐるA〔率る〕", kogoMode: true, synonymous: [] },
            { word: "すばらしい・滑稽だ", primary: "をかし", kogoMode: true, synonymous: [] },
            { word: "愚かなこと", primary: "をこ", kogoMode: true, synonymous: [] },
            { word: "ばかばかしい", primary: "をこがまし", kogoMode: true, synonymous: [] },
            { word: "愚かだ・ばかばかしい", primary: "をこなり〔痴なり・烏滸なり・尾籠なり〕", kogoMode: true, synonymous: [] },
            { word: "しっかりしている", primary: "をさをさし〔長長し〕", kogoMode: true, synonymous: [] },
            { word: "ほとんど（～ない）", primary: "をさをさ（～打消）", kogoMode: true, synonymous: [] },
            { word: "この世に生きている・世間に認められている", primary: "世にあり", kogoMode: true, synonymous: [] },
            { word: "まったく（～ない）・（打消を伴わないで）実に", primary: "世に（～打消）", kogoMode: true, synonymous: [] },
            { word: "一人前になる・正気にする・正気に戻る", primary: "人となる", kogoMode: true, synonymous: [] },
            { word: "お言葉・ご命令", primary: "仰せ", kogoMode: true, synonymous: [] },
            { word: "（女のもとに）通う", primary: "住む", kogoMode: true, synonymous: [] },
            { word: "いつもではない・体調がいつもどおりでない", primary: "例ならず", kogoMode: true, synonymous: [] },
            { word: "いつものように・いつもの", primary: "例の", kogoMode: true, synonymous: [] },
            { word: "どうしようもない・しかたない・どうにもならない", primary: "力なし", kogoMode: true, synonymous: [] },
            { word: "差し上げる・（お）～申し上げる", primary: "参らす", kogoMode: true, synonymous: [] },
            { word: "（人を側に）お呼びになる・（物を取り寄せに）お取り寄せになる・お召しになる・お乗りになる", primary: "召す", kogoMode: true, synonymous: [] },
            { word: "評判", primary: "名", kogoMode: true, synonymous: [] },
            { word: "（中宮・東宮に）申し上げる", primary: "啓す", kogoMode: true, synonymous: [] },
            { word: "殺す", primary: "失ふ", kogoMode: true, synonymous: [] },
            { word: "差し上げる・（お）～申し上げる・お召しになる・召し上がる・お乗りになる", primary: "奉る", kogoMode: true, synonymous: [] },
            { word: "（帝・上皇・法皇に）申し上げる", primary: "奏す", kogoMode: true, synonymous: [] },
            { word: "平仮名", primary: "女手", kogoMode: true, synonymous: [] },
            { word: "風流の道に熱中すること・色好み", primary: "好き", kogoMode: true, synonymous: [] },
            { word: "風流だ・好色だ", primary: "好き好きし", kogoMode: true, synonymous: [] },
            { word: "風流を好む", primary: "好く", kogoMode: true, synonymous: [] },
            { word: "寝る", primary: "寝を寝", kogoMode: true, synonymous: [] },
            { word: "探し求める", primary: "尋ぬ", kogoMode: true, synonymous: [] },
            { word: "あれこれ考えない・決着がつかない", primary: "左右なし", kogoMode: true, synonymous: [] },
            { word: "現在・その時", primary: "当時", kogoMode: true, synonymous: [] },
            { word: "（神仏や貴人の）お側", primary: "御前", kogoMode: true, synonymous: [] },
            { word: "上皇のお出まし", primary: "御幸", kogoMode: true, synonymous: [] },
            { word: "御覧になる", primary: "御覧ず", kogoMode: true, synonymous: [] },
            { word: "御覧に入れる・お目に掛ける", primary: "御覧ぜず", kogoMode: true, synonymous: [] },
            { word: "心の迷い・分別を失った親心", primary: "心の闇", kogoMode: true, synonymous: [] },
            { word: "心積もり", primary: "心まうけ", kogoMode: true, synonymous: [] },
            { word: "病気・気分（の悪さ）", primary: "心地", kogoMode: true, synonymous: [] },
            { word: "字・演奏法", primary: "手名", kogoMode: true, synonymous: [] },
            { word: "習字・心に浮かぶ歌などを書き流すこと", primary: "手習ひ", kogoMode: true, synonymous: [] },
            { word: "（漢学・漢詩文の）教養・（和歌・音楽などの）才能", primary: "才", kogoMode: true, synonymous: [] },
            { word: "お受けする・お聞きする", primary: "承る", kogoMode: true, synonymous: [] },
            { word: "手紙・漢詩", primary: "文・書", kogoMode: true, synonymous: [] },
            { word: "ため", primary: "料", kogoMode: true, synonymous: [] },
            { word: "亡くなった人・昔の知人", primary: "昔の人", kogoMode: true, synonymous: [] },
            { word: "内容・事情・取り次ぎ", primary: "案内", kogoMode: true, synonymous: [] },
            { word: "探す", primary: "求む", kogoMode: true, synonymous: [] },
            { word: "評議・裁き・命令・噂", primary: "沙汰", kogoMode: true, synonymous: [] },
            { word: "さっぱりとして美しい", primary: "清げなり", kogoMode: true, synonymous: [] },
            { word: "潜る", primary: "潜く", kogoMode: true, synonymous: [] },
            { word: "世間話", primary: "物語", kogoMode: true, synonymous: [] },
            { word: "気配り", primary: "用意", kogoMode: true, synonymous: [] },
            { word: "男子が元服して一人前になる", primary: "男になる", kogoMode: true, synonymous: [] },
            { word: "漢字", primary: "畏手", kogoMode: true, synonymous: [] },
            { word: "まぶしいほど立派だ", primary: "目もあやなり", kogoMode: true, synonymous: [] },
            { word: "親しく付き合う・男女の交際をする・治める", primary: "知る", kogoMode: true, synonymous: [] },
            { word: "個人的なこと", primary: "私", kogoMode: true, synonymous: [] },
            { word: "（時間が）たつ・（場所を）通る", primary: "経", kogoMode: true, synonymous: [] },
            { word: "お与えになる・下さる・～なさる・お～になる", primary: "給ふA", kogoMode: true, synonymous: [] },
            { word: "～（ており）ます", primary: "給ふB", kogoMode: true, synonymous: [] },
            { word: "噂・評判", primary: "聞こえ", kogoMode: true, synonymous: [] },
            { word: "お聞きになる・召し上がる", primary: "聞こし召す", kogoMode: true, synonymous: [] },
            { word: "聞こえる・評判になる・分かる", primary: "聞こゆ", kogoMode: true, synonymous: [] },
            { word: "（こらえきれず）表情に出る", primary: "色に出づ", kogoMode: true, synonymous: [] },
            { word: "帝のお出まし", primary: "行幸", kogoMode: true, synonymous: [] },
            { word: "見える・思われる・見せる・（女性が）結婚する", primary: "見ゆ", kogoMode: true, synonymous: [] },
            { word: "思う・（男女の）関係を結ぶ・面倒を見る", primary: "見る", kogoMode: true, synonymous: [] },
            { word: "（貴人に）お目にかかる・（貴人に）お目にかける", primary: "見参に入る", kogoMode: true, synonymous: [] },
            { word: "言いようもない・何とも言いようがない", primary: "言ふばかりなし", kogoMode: true, synonymous: [] },
            { word: "美しく落ち着いた色つや・香り", primary: "鈍色", kogoMode: true, synonymous: [] },
            { word: "この上ない", primary: "限りなし", kogoMode: true, synonymous: [] },
            { word: "陰・くま", primary: "隈", kogoMode: true, synonymous: [] },
            { word: "陰がない・なんでも知っている", primary: "隈なし〔隈無し〕", kogoMode: true, synonymous: [] },
            { word: "宮中・天空・はるか遠く", primary: "雲居", kogoMode: true, synonymous: [] },
            { word: "噂に聞く", primary: "音に聞く", kogoMode: true, synonymous: [] },
            { word: "頼みになる・裕福だ", primary: "頼もし", kogoMode: true, synonymous: [] },
            { word: "添う・添わせる", primary: "（動詞＋）さす", kogoMode: true, synonymous: [] },
            { word: "～のもとへ", primary: "～のがり", kogoMode: true, synonymous: [] },
            { word: "～ならともかく（実際はそうではない）", primary: "～ばこそあらめ", kogoMode: true, synonymous: [] },
            { word: "言うとかえってよくない・言わないほうがましだ", primary: "～（と）いふもなかなかなり", kogoMode: true, synonymous: [] },
        ];
        const BALANCE_BREAK_RATE_CAP = 0.70;
        const BALANCE_BREAK_PCT_CAP = 70;
        function capRate(v) {
            return Math.max(0, Math.min(BALANCE_BREAK_RATE_CAP, typeof v === 'number' ? v : 0));
        }
        function capPct(v) {
            return Math.max(0, Math.min(BALANCE_BREAK_PCT_CAP, Math.round(typeof v === 'number' ? v : 0)));
        }
        function applyMitigationCap(amount, label, container, pct = BALANCE_BREAK_RATE_CAP) {
            const cut = capRate(pct);
            const reduced = Math.max(0, Math.floor(amount * (1 - cut)));
            if (container) createFloatingText(`${label} ${Math.round(cut * 100)}%軽減！`, container, "text-cyan-300 text-sm font-black");
            return reduced;
        }
        function applyAbsoluteNullify(label, container) {
            if (container) createFloatingText(`${label} ダメージ無効！`, container, "text-cyan-300 text-sm font-black");
            return 0;
        }

        const FRIDAY_ENEMY_FULL_HEAL_COEFFICIENT = 0.35;
        function applyFridayEnemySpecial() {
            if (!battleState || !battleState.active || !isFridayDungeon(battleState.dungeonNum)) return;
            const roster = battleState.fridayEnemyRoster || [];
            if (!roster.length) return;
            const foe = roster[battleState.enemySpecialIndex % roster.length];
            battleState.enemySpecialIndex = (battleState.enemySpecialIndex + 1) % roster.length;
            const unit = foe && foe.unit ? foe.unit : null;
            const enemyBox = document.getElementById('enemySideBox');
            const playerBox = document.getElementById('playerSideBox');
            const move = unit && unit.special_move ? unit.special_move : {name:'編成奥義',effect:'敵全体への強撃'};
            createFloatingText(`⚡ ${unit ? unit.name : '敵'}の必殺「${move.name}」発動！`, enemyBox, 'text-orange-200 text-sm font-black');
            const fullHeal = /全回復|全快|HP.*回復/.test(move.effect || '');
            if (fullHeal) {
                const heal = Math.max(1, Math.floor(battleState.maxEnemyHp * FRIDAY_ENEMY_FULL_HEAL_COEFFICIENT));
                battleState.enemyHp = Math.min(battleState.maxEnemyHp, battleState.enemyHp + heal);
                createFloatingText(`💢 敵回復弱体化！ +${heal}（本来の全回復を35%に抑制）`, enemyBox, 'text-rose-300 text-sm font-black');
            } else {
                let damage = Math.max(1, Math.floor(battleState.enemyAtk * 1.65));
                if (battleState.shieldSec > 0) damage = 0;
                battleState.playerHp = Math.max(0, battleState.playerHp - damage);
                createFloatingText(`💥 必殺ダメージ -${damage}`, playerBox, 'text-red-300 text-lg font-black');
                if (damage > 0) AudioFX.playHurt();
                if (playerBox) { playerBox.classList.add('flash-red','animate-shake-intense'); setTimeout(() => playerBox.classList.remove('flash-red','animate-shake-intense'), 350); }
            }
            updateBattleUI();
            if (battleState.playerHp <= 0) endBattle(false);
        }

        function applyEnemyAttack() {
            const playerBox = document.getElementById("playerSideBox");

            let mitigationApplied = false;
            if (battleState.missCharges > 0) {
                battleState.missCharges--;
                battleState._pendingMitigationLabel = "✖️ 見切り！";
                mitigationApplied = true;
            }

            try {
                const hasKaguya = battleState.party.some(p => p.id === 'kaguya_001' && p.sealedSeconds <= 0 && !p.defected);
                const hasButsu = battleState.party.some(p => p.id === 'butsu_001' && p.sealedSeconds <= 0 && !p.defected);
                const hasFinalGod = battleState.party.some(p => p.id === 'br_god_10' && p.sealedSeconds <= 0 && !p.defected);
                if (!mitigationApplied && hasKaguya && hasButsu && (state.kaguyaCount || 0) >= 5 && Math.random() < capRate(0.30)) {
                    battleState._pendingMitigationLabel = "🌙🙏 月仏共鳴！";
                    mitigationApplied = true;
                }
                if (!mitigationApplied && hasFinalGod && Math.random() < capRate(0.70)) {
                    battleState._pendingMitigationLabel = "👑 終ノ神の理！";
                    mitigationApplied = true;
                }
            } catch(e) {}

            if (!mitigationApplied && battleState.shieldSec > 0) {
                battleState._pendingMitigationLabel = "🔰 結界";
                mitigationApplied = true;
            }

            if (!mitigationApplied && battleState.party.some(p => p.id === 'so_002' && p.sealedSeconds <= 0 && !p.defected) && Math.random() < capRate(CHIGO_DAMAGE_NULLIFY_RATE)) {
                battleState._pendingMitigationLabel = "🙏 稚児の寝たふり！";
                mitigationApplied = true;
            }

            // 敵攻撃力DOWNデバフ・味方防御UPバフを反映
            let atk = battleState.enemyAtk;
            if (battleState.debuffs.eAtk) atk = Math.floor(atk * (1 - battleState.debuffs.eAtk.pct / 100));
            const defPct = buffPct("def");
            if (defPct > 0) atk = Math.floor(atk * 100 / (100 + defPct));

            // ④ 敵強化モード中: 敵は必殺級の攻撃（攻撃力1.5倍）を放つ
            if (battleState.dungeonNum >= 20 && battleState.enemyPowerUpTimer > 0) {
                atk = Math.floor(atk * 1.5);
            }

            // ④ ダンジョン20以降: 敵が攻撃するたびに30%の確率で受けるダメージを軽減
            if (battleState.dungeonNum >= 20 && Math.random() < capRate(0.30)) {
                atk = applyMitigationCap(atk, "🛡️ 必殺技ガード！", playerBox);
            }
            if (mitigationApplied) {
                const mitigationLabel = battleState._pendingMitigationLabel || "🛡️ 防御";
                atk = mitigationLabel.indexOf("稚児の寝たふり") >= 0
                    ? applyAbsoluteNullify(mitigationLabel, playerBox)
                    : applyMitigationCap(atk, mitigationLabel, playerBox);
                battleState._pendingMitigationLabel = null;
            }

            battleState.playerHp = Math.max(0, battleState.playerHp - atk);
            triggerNewGachaSkill('afterHit');
            triggerNewGachaSkill('lowHpHit');
            AudioFX.playHurt();

            if (playerBox) {
                playerBox.classList.add("flash-red", "animate-shake-intense");
                setTimeout(() => playerBox.classList.remove("flash-red", "animate-shake-intense"), 350);
            }
            createFloatingText(`-${atk}`, playerBox, "text-red-400 text-sm font-bold");

            // ===== 曜日ダンジョンのギミック発動（敵の攻撃のたびに判定） =====
            if (isMondayDungeon(battleState.dungeonNum)) applyMondayLevelHalve();
            if (isTuesdayDungeon(battleState.dungeonNum)) applyTuesdayDefection();
            if (isWednesdayDungeon(battleState.dungeonNum)) applyWednesdayMorph();
            if (!battleState.active) return;

            // Character sealing in higher dungeons（曜日ダンジョンではスキル・必殺無効化は発生しない）
            // ⑤ 夕霧「真面目なる誠実」: 60%の確率で無効化 / 阿倍晴明「陰陽の道」: 本人は常時無効
            if (!isWeekdayDungeon(battleState.dungeonNum) && battleState.dungeonNum >= 10 && Math.random() < (battleState.dungeonNum >= 20 ? 0.72 : 0.40)) {
                const yugiriBlock = battleState.party.some(p => p.id === 'ge_005' && p.sealedSeconds <= 0 && !p.defected) && Math.random() < 0.6;
                if (yugiriBlock) {
                    createFloatingText("🛡️ 夕霧のスキルでデバフを無効化！", playerBox, "text-cyan-300 text-sm font-black");
                } else {
                    const sealableUnits = battleState.party.filter(p => p.sealedSeconds <= 0 && p.id !== 'so_003');
                    if (sealableUnits.length > 0) {
                        const target = sealableUnits[Math.floor(Math.random() * sealableUnits.length)];
                        target.sealedSeconds = 6.0;
                        AudioFX.playSeal();
                        recalculateBattleSynergies();
                        createFloatingText("機能停止！", playerBox, "text-red-500 font-black");
                    }
                }
            }

            updateBattleUI();
            checkKiritsuboRevive();

            if (battleState.playerHp <= 0) {
                // ⑤ 建礼門院「諸行無常の祈り」: 建礼門院(so_008)がパーティにいれば、一度だけプレイヤー部隊をHP1で踏みとどまらせる
                const hasKenreimonin = battleState.party.some(p => p.id === 'so_008' && p.sealedSeconds <= 0 && !p.defected);
                const kenKey = 'kenreimoninUsed_' + (battleState.stageId || 'stage');
                if (hasKenreimonin && !battleState.passiveFlags[kenKey]) {
                    if (!battleState.passiveFlags) battleState.passiveFlags = {};
                    battleState.passiveFlags[kenKey] = true;
                    battleState.playerHp = 1;
                    const playerBox2 = document.getElementById("playerSideBox");
                    if (playerBox2) {
                        createFloatingText("🛡️ 建礼門院の祈り！パーティ全員踏みとどまり！", playerBox2, "text-cyan-300 text-base font-black animate-bounce");
                    }
                    updateBattleUI();
                    return;
                }
                endBattle(false);
            }
        }

        // ============================================================
        // 月曜ギミック: 敵攻撃ごとに確率でランダムな味方1体のレベルを
        // 5秒間だけ半分にする（対象数に上限なし・復帰タイマーは個別管理）
        // ============================================================
        function applyMondayLevelHalve() {
            if (Math.random() >= MONDAY_HALVE_CHANCE) return;
            const targets = battleState.party.filter(p => p && !p.isSub && !p.defected && p.sealedSeconds <= 0 && !p.levelHalved);
            if (targets.length === 0) return;
            const t = targets[Math.floor(Math.random() * targets.length)];
            // レベル半分相当として 最大HP・現在HP・攻撃力を半減
            const lostMax = Math.floor(t.maxHp / 2);
            const lostHp = Math.floor(t.hp / 2);
            const lostAtk = Math.floor(t.atk / 2);
            t._halveLost = { maxHp: lostMax, hp: lostHp, atk: lostAtk };
            t.maxHp -= lostMax;
            t.hp -= lostHp;
            t.atk -= lostAtk;
            t.levelHalved = true;
            t.levelHalveSec = MONDAY_HALVE_SEC;
            battleState.maxPlayerHp = Math.max(1, battleState.maxPlayerHp - lostMax);
            battleState.playerHp = Math.max(0, battleState.playerHp - lostHp);
            const pBox = document.getElementById("playerSideBox");
            createFloatingText(`🌙 ${t.unit.name}のレベルが半減した！（5秒）`, pBox, "text-indigo-300 text-sm font-black");
            updateBattleUI();
            if (battleState.playerHp <= 0) endBattle(false);
        }

        // ============================================================
        // 火曜ギミック: 敵攻撃ごとに確率でランダムな味方1体を敵陣営へ。
        // 寝返ったキャラの攻撃力・HPは敵側へ移る。上限3体（5秒後に自動帰還）
        // ============================================================
        function restoreTuesdayDefectedUnit(p, reason = 'auto') {
            if (!p || !p.defected || !p._defectTransfer) return;
            const tr = p._defectTransfer;
            const ratio = battleState.maxEnemyHp > 0 ? Math.max(0, Math.min(1, battleState.enemyHp / battleState.maxEnemyHp)) : 0;
            const returnHp = Math.max(1, Math.min(tr.maxHp, Math.floor(tr.maxHp * ratio)));
            battleState.enemyAtk = Math.max(1, battleState.enemyAtk - tr.atk);
            battleState.maxEnemyHp = Math.max(1, battleState.maxEnemyHp - tr.maxHp);
            battleState.enemyHp = Math.min(battleState.maxEnemyHp, Math.max(0, battleState.enemyHp - returnHp));
            battleState.maxPlayerHp += tr.maxHp;
            battleState.playerHp = Math.min(battleState.maxPlayerHp, battleState.playerHp + returnHp);
            p.defected = false;
            p.defectSec = 0;
            p._defectTransfer = null;
            const pBox = document.getElementById("playerSideBox");
            const eBox = document.getElementById("enemySideBox");
            if (reason !== 'endBattle') {
                if (pBox) createFloatingText(`🛡️ ${p.unit.name}が味方に戻った！`, pBox, "text-emerald-300 text-sm font-black");
                if (eBox) createFloatingText(`↩️ ${p.unit.name}が敵陣営から離脱！`, eBox, "text-cyan-200 text-xs font-black");
            }
            recalculateBattleSynergies();
            updateBattleUI();
        }

        function applyTuesdayDefection() {
            if (Math.random() >= TUESDAY_DEFECT_CHANCE) return;
            const defectedCount = battleState.party.filter(p => p.defected).length;
            if (defectedCount >= TUESDAY_MAX_DEFECTS) return;
            const targets = battleState.party.filter(p => p && !p.isSub && !p.defected && p.sealedSeconds <= 0);
            if (targets.length === 0) return;
            const t = targets[Math.floor(Math.random() * targets.length)];
            t.defected = true;
            t.defectSec = TUESDAY_RETURN_SEC;
            t._defectTransfer = { atk: t.atk, maxHp: t.maxHp, hp: t.hp };
            // 攻撃力・HPを敵陣営へ移譲（敵HP・敵攻撃力が増加）
            battleState.enemyAtk += t.atk;
            battleState.maxEnemyHp += t.maxHp;
            battleState.enemyHp = Math.min(battleState.maxEnemyHp, battleState.enemyHp + t.hp);
            battleState.maxPlayerHp = Math.max(1, battleState.maxPlayerHp - t.maxHp);
            battleState.playerHp = Math.max(0, battleState.playerHp - t.hp);
            const pBox = document.getElementById("playerSideBox");
            const eBox = document.getElementById("enemySideBox");
            createFloatingText(`🔥 ${t.unit.name}が敵陣営に寝返った！ 5秒後に帰還 (${defectedCount + 1}/${TUESDAY_MAX_DEFECTS})`, pBox, "text-orange-400 text-sm font-black");
            if (eBox) createFloatingText(`⏳ ${t.unit.name}が5秒間だけ加勢！`, eBox, "text-orange-300 text-xs font-black");
            recalculateBattleSynergies();
            updateBattleUI();
            if (battleState.playerHp <= 0) endBattle(false);
        }

        function recalculateBattleSynergies() {
            // 在原業平がいても女性キャラのシナジーは無効化しない（最後まで有効のまま）
            const activeIds = battleState.party
                .filter(p => p.sealedSeconds <= 0 && !p.defected)
                .map(p => p.id);

            battleState.activeSynergies = getActiveSynergiesForDeck(activeIds);

            const container = document.getElementById("battleActiveSynergies");
            if (!container) return;
            const isSPhone = !!(state.settings && state.settings.smartphoneMode);
            const hideBattleSynergies = !!(state.settings && state.settings.hideBattleSynergies) || isSPhone;
            container.style.display = hideBattleSynergies ? "none" : "";
            if (hideBattleSynergies) return;
            __PERF.setHTML(container, "");

            if (battleState.activeSynergies.length === 0) {
                __PERF.setHTML(container, `<span class="text-gray-400">発動シナジー: なし (機能停止中または不成立)</span>`);
            } else if (isSPhone) {
                // スマホモード: シナジー表示をとても簡略化（件数とタイトルのみ。効果詳細は省略）
                const countBadge = document.createElement("div");
                countBadge.className = "bg-amber-500/25 text-amber-300 border border-amber-500/40 px-2 py-1 rounded text-[11px] font-bold text-center";
                __PERF.setHTML(countBadge, `⚡ 発動シナジー ${battleState.activeSynergies.length}件`);
                container.appendChild(countBadge);
                battleState.activeSynergies.forEach(syn => {
                    const targetsStr = syn.targetUnits.map(u => u.name).join('＆');
                    const badge = document.createElement("div");
                    badge.className = "bg-amber-500/10 text-amber-200/90 border border-amber-500/30 px-2 py-0.5 rounded text-[9px] truncate";
                    __PERF.setHTML(badge, `<span>⚡${syn.sourceUnit.name}×${targetsStr} ${syn.title}</span>`);
                    container.appendChild(badge);
                });
            } else {
                battleState.activeSynergies.forEach(syn => {
                    const targetsStr = syn.targetUnits.map(u => u.name).join('＆');
                    const badge = document.createElement("div");
                    badge.className = "bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2 py-0.5 rounded text-[10px] font-bold flex justify-between";
                    __PERF.setHTML(badge, `<span>⚡【${syn.sourceUnit.name} × ${targetsStr}】${syn.title}</span> <span>${syn.effect}</span>`);
                    container.appendChild(badge);
                });
            }
        }

        // ② 初期必殺ゲージUPシナジー（「初期必殺ゲージX%増加」「大幅増加」等の effect 文言）を戦闘開始時にゲージへ反映する
        function applyInitialGaugeSynergies() {
            if (!battleState || !battleState.activeSynergies) return;
            let gaugeBoost = 0;
            battleState.activeSynergies.forEach(syn => {
                const eff = syn.effect || '';
                if (eff.indexOf('初期必殺ゲージ大幅増加') >= 0) {
                    gaugeBoost += 50;
                } else if (eff.indexOf('初期必殺ゲージ') >= 0) {
                    const m = eff.match(/初期必殺ゲージ(\d+)?%?増加/);
                    gaugeBoost += (m && m[1]) ? parseInt(m[1], 10) : 25;
                }
            });
            if (gaugeBoost > 0) {
                battleState.party.forEach(p => {
                    if (p.sealedSeconds <= 0) p.specialGauge = Math.min(100, p.specialGauge + gaugeBoost);
                });
                const playerBox = document.getElementById("playerSideBox");
                if (playerBox) createFloatingText(`⚡ 初期必殺ゲージシナジー発動！ +${gaugeBoost}%`, playerBox, "text-amber-300 text-xs font-black");
            }
        }
        function generateNewQuiz() {
            let currentQuestion;
            let pool = [];
            if (battleState && battleState.reviewMode) {
                const q = (battleState.reviewQueue || []);
                if (q.length === 0) {
                    if (battleState.active) endBattle(true);
                    return;
                }
                currentQuestion = q.shift();
                updateReviewHeader();
                pool = currentQuestion.kogoMode ? KOGO_REVERSE_QUIZ : KOBUN_WORDS;
            } else if (battleState && isThursdayDungeon(battleState.dungeonNum)) {
                pool = KOGO_REVERSE_QUIZ;
                currentQuestion = pickBalancedQuizQuestion(pool, quizBalanceBucket(true, false));
            } else {
                pool = KOBUN_WORDS;
                currentQuestion = pickBalancedQuizQuestion(pool, quizBalanceBucket(false, false));
            }
            if (!currentQuestion) return;
            currentQuizQuestion = currentQuestion;
            const built = buildQuizChoicesFromPool(currentQuestion, pool);
            const targetAnswer = built.targetAnswer;
            const allChoices = built.allChoices;

            document.getElementById("quizWordDisplay").textContent = currentQuestion.kogoMode
                ? `「${currentQuestion.word}」の古語は？`
                : currentQuestion.word;
            const container = document.getElementById("quizChoicesGrid");
            __PERF.setHTML(container, "");

            allChoices.forEach(choice => {
                const isCorrect = choice === targetAnswer;
                const btn = document.createElement("button");
                btn.className = "p-3 rounded-xl bg-heian-purple/40 border border-heian-gold/40 text-xs md:text-sm font-semibold hover:border-heian-gold hover:bg-heian-purple transition text-left active:scale-95 duration-100";
                let choiceLabel = choice;
                if (currentQuestion.kogoMode) {
                    const yomiF = KOGO_REVERSE_QUIZ.find(x => x.primary === choice);
                    if (yomiF && yomiF.yomi) choiceLabel = `${choice}（${yomiF.yomi}）`;
                }
                btn.textContent = choiceLabel;
                btn.dataset.correct = isCorrect ? "1" : "0";
                btn.onclick = () => handleQuizAnswer(isCorrect, btn);
                container.appendChild(btn);
            });
        }

        function handleQuizAnswer(isCorrect, btnElement) {
            if (!battleState.active) return;

            if (battleState.reviewMode) {
                handleReviewAnswer(isCorrect, btnElement);
                return;
            }

            const enemyBox = document.getElementById("enemySideBox");

            if (isCorrect) {
                battleState.combo += 1;
                // ⑤ 藤原道長「栄華の極み」: 正解ごとに全ステータス2%累積
                if (battleState.party.some(p => p.id === 'ok_005' && !p.defected)) {
                    if (!battleState.passiveFlags) battleState.passiveFlags = {};
                    battleState.passiveFlags.michinagaStacks = (battleState.passiveFlags.michinagaStacks || 0) + 1;
                }
                if (currentQuizQuestion && currentQuizQuestion.word && state.wrongWords && state.wrongWords.length) {
                    const idx = state.wrongWords.findIndex(w => w.word === currentQuizQuestion.word && w.primary === currentQuizQuestion.primary);
                    if (idx !== -1) {
                        state.wrongWords.splice(idx, 1);
                        saveState();
                        if (battleState.reviewMode) {
                            createFloatingText("✅ 間違いリストから消えた！", document.getElementById("playerSideBox"), "text-green-300 text-sm font-black");
                        }
                    }
                }
                AudioFX.playCorrect();

                const gainMult = 1 + (buffPct("speed") + buffPct("specGain")) / 100;
                // ⑤ 必殺チャージ改訂：単語を正解するたび「一定確率」で各キャラの必殺ゲージが+1/7貯まる（最低7回答で満タン）
                // 確率ゆえ、理論上は100問正解しても1度も増えないこともあり得る
                const SPECIAL_CHARGE_PROB = 0.5;            // 正解1回につき各キャラ50%で発動
                const SPECIAL_CHARGE_PER_PROC = 100 / 7;    // 発動1回 = 必要量の1/7（全発動なら7回答で100%）
                battleState.party.forEach(p => {
                    if (p.sealedSeconds <= 0 && !p.defected && Math.random() < SPECIAL_CHARGE_PROB) {
                        p.specialGauge = Math.min(100, p.specialGauge + SPECIAL_CHARGE_PER_PROC * gainMult);
                    }
                });

                const partySkill = getPartySkillState();
                triggerNewGachaSkill('correct');
                triggerNewGachaSkill('combo3');
                triggerNewGachaSkill('lowHpCorrect');
                triggerNewGachaSkill('highGaugeCorrect');
                triggerNewGachaSkill('sameRarityCorrect');
                // ★単一ソース化: 個別パッシブ→業平→道長スタック→シナジー の順序は
                // computePartyEffectiveAtk / computePartySynergyMultiplier に集約（プレビューと完全同期）
                const michinagaStacks = (battleState.passiveFlags && battleState.passiveFlags.michinagaStacks) || 0;
                const liveMembers = battleState.party.filter(p => p.sealedSeconds <= 0 && !p.defected);
                const totalPartyAtk = computePartyEffectiveAtk(
                    liveMembers.map(p => ({ id: p.id, atk: p.atk, gender: p.unit ? p.unit.gender : null })),
                    { michinagaStacks: michinagaStacks }
                ).totalAtk;
                const synergyMultiplier = computePartySynergyMultiplier(liveMembers, battleState.activeSynergies);
                let skillDmgPct = 0;
                // 菅原道真「至高の学問」: 正解時の与ダメージ倍率上昇
                if (partySkill.active('ok_001')) skillDmgPct += 20;

                let comboMultiplier = 1.0 + (battleState.combo * 0.10);
                // 攻撃力UP・与ダメUPバフをダメージ計算に反映
                const atkUpPct = buffPct("atk");
                const dmgUpPct = buffPct("dmg");
                let dealDamage = Math.floor(totalPartyAtk * (1 + atkUpPct / 100) * (1 + dmgUpPct / 100) * synergyMultiplier * comboMultiplier * (1 + skillDmgPct / 100));

                const isCrit = battleState.combo >= 3 || Math.random() < 0.25;
                if (isCrit) {
                    dealDamage = Math.floor(dealDamage * 1.5);
                    AudioFX.playCrit();
                    if (enemyBox) {
                        enemyBox.classList.add("animate-shake-intense");
                        setTimeout(() => enemyBox.classList.remove("animate-shake-intense"), 400);
                    }
                } else if (enemyBox) {
                    enemyBox.classList.add("animate-shake-light");
                    setTimeout(() => enemyBox.classList.remove("animate-shake-light"), 250);
                }

                // ④ 敵強化モード中: 敵が受けるダメージを一律半分（通常攻撃・必殺・毒など全ダメージに適用）
                if (battleState.dungeonNum >= 20 && battleState.enemyPowerUpTimer > 0) {
                    dealDamage = Math.floor(dealDamage / 2);
                    createFloatingText('🛡️ 強化の障壁！受けるダメージ½', enemyBox, 'text-orange-300 text-xs font-black');
                }

                // ③ 出家5回以降: 当該ダンジョン最終ステージ（ボス）なら、初回正解で敵を一括撃破
                let bossOneShotted = false;
                if ((state.shukkeCount || 0) >= 5 && battleState.dungeonNum) {
                    const dungObj = DUNGEONS_DATA.find(d => d.id === battleState.dungeonNum);
                    const stageObj = dungObj ? dungObj.stages.find(s => s.id === battleState.stageId) : null;
                    if (dungObj && stageObj && stageObj === dungObj.stages[dungObj.stages.length - 1]) {
                        bossOneShotted = true;
                        battleState.enemyHp = 0;
                        if (enemyBox) {
                            enemyBox.classList.add('animate-shake-intense');
                            setTimeout(() => enemyBox && enemyBox.classList.remove('animate-shake-intense'), 400);
                        }
                    }
                }
                if (!bossOneShotted) {
                    battleState.enemyHp = Math.max(0, battleState.enemyHp - dealDamage);
                } else {
                    // 演出用の表示
                    if (typeof AudioFX !== 'undefined' && AudioFX.playCrit) { try { AudioFX.playCrit(); } catch(e){} }
                }

                createFloatingText(bossOneShotted ? '⚔ ボス一括撃破！' : (`-${dealDamage}${isCrit ? ' CRITICAL!' : ''}`), enemyBox, bossOneShotted ? "text-orange-300 text-xl font-black" : (isCrit ? "text-amber-300 text-xl font-black" : "text-yellow-400 text-lg"));

                if (battleState.enemyHp <= 0) {
                    endBattle(true);
                    return;
                }
            } else {
                battleState.combo = 0;

                if (currentQuizQuestion && currentQuizQuestion.word && currentQuizQuestion.primary) {
                    if (!state.wrongWords) state.wrongWords = [];
                    const already = state.wrongWords.some(w => w.word === currentQuizQuestion.word && w.primary === currentQuizQuestion.primary);
                    if (!already) {
                        state.wrongWords.push({
                            word: currentQuizQuestion.word,
                            primary: currentQuizQuestion.primary,
                            synonymous: currentQuizQuestion.synonymous || [],
                            group: currentQuizQuestion.group || "",
                            kogoMode: currentQuizQuestion.kogoMode || false,
                            yomi: currentQuizQuestion.yomi || ""
                        });
                        saveState();
                    }
                }

                battleState.party.forEach(p => {
                    if (p.sealedSeconds <= 0 && !p.defected) {
                        p.specialGauge = Math.min(100, p.specialGauge + ((p.gaugePerCorrect !== undefined ? p.gaugePerCorrect : 15) * 0.6));
                    }
                });

                // 反撃ダメージ（ダンジョン10制覇後は自チーム総攻撃力×2）
                const dungeon10Cleared = DUNGEONS_DATA.find(d => d.id === 10)
                    .stages.every(s => !!state.clearedStages[s.id]);
                let counterAtk;
                if (dungeon10Cleared && battleState.dungeonNum >= 10) {
                    counterAtk = Math.max(1, Math.floor(battleState.party
                        .filter(p => p.sealedSeconds <= 0 && !p.defected)
                        .reduce((sum, p) => sum + p.atk, 0) * 2 * (1 + buffPct("atk") / 100)));
                } else {
                    counterAtk = Math.floor(battleState.enemyAtk * 0.8);
                    if (battleState.debuffs.eAtk) counterAtk = Math.floor(counterAtk * (1 - battleState.debuffs.eAtk.pct / 100));
                    const defUpPct = buffPct("def");
                    if (defUpPct > 0) counterAtk = Math.floor(counterAtk * 100 / (100 + defUpPct));
                }

                const playerBox = document.getElementById("playerSideBox");
                let counterMitigationLabel = null;
                if (battleState.missCharges > 0) {
                    battleState.missCharges--;
                    counterMitigationLabel = "✖️ 見切り！";
                } else if (battleState.shieldSec > 0) {
                    counterMitigationLabel = "🔰 結界";
                } else if (battleState.party.some(p => p.id === 'so_002' && p.sealedSeconds <= 0) && Math.random() < capRate(CHIGO_DAMAGE_NULLIFY_RATE)) {
                    counterMitigationLabel = "🙏 稚児の寝たふり！";
                } else if (battleState.party.some(p => p.id === 'br_god_10' && p.sealedSeconds <= 0) && Math.random() < capRate(0.70)) {
                    counterMitigationLabel = "👑 終ノ神の理！";
                } else if (battleState.dungeonNum >= 20 && Math.random() < capRate(0.30)) {
                    counterMitigationLabel = "🛡️ 必殺技ガード！";
                }
                if (counterMitigationLabel) {
                    counterAtk = counterMitigationLabel.indexOf("稚児の寝たふり") >= 0
                        ? applyAbsoluteNullify(counterMitigationLabel, playerBox)
                        : applyMitigationCap(counterAtk, counterMitigationLabel, playerBox);
                }
                battleState.playerHp = Math.max(0, battleState.playerHp - counterAtk);
                if (counterAtk > 0) AudioFX.playHurt();
                if (playerBox && counterAtk > 0) {
                    playerBox.classList.add("flash-red", "animate-shake-intense");
                    setTimeout(() => playerBox.classList.remove("flash-red", "animate-shake-intense"), 350);
                }

                createFloatingText("不正解!", playerBox, "text-red-400 text-sm font-bold");
                checkKiritsuboRevive();

                if (battleState.playerHp <= 0) {
                    endBattle(false);
                    return;
                }
            }

            _battlePartySig = ""; _battlePartyEls = null; _battleUiEls = null;
            updateBattleUI();
            generateNewQuiz();
        }

        // =========================================================================
        // 必殺技の効果定義（【文言通り】攻撃・回復・バフ・デバフ・スタン・毒・バリア）
        // =========================================================================
        const SPECIAL_EFFECTS = {
            ch_000: { dmg: 1.0 },                                            // 平安貴族の一撃: 敵単体に強烈な打撃
            ok_001: { dmg: 1.9, crit: 0.15 },                                // 東風吹かば: 敵全体に特大の雷撃ダメージ
            ok_002: { stun: [4, 7] },                                        // 左遷の罠: 敵単体の行動を一定時間停止
            ok_003: { buffAll: [20, 12] },                                   // 権力掌握の謀略: 味方全体の全ステータスを大アップ
            ok_004: { buffSpeed: [50, 12] },                                 // 中関白家の酒宴: 攻撃速度を大きく上げる(必殺チャージ加速)
            ok_005: { dmg: 2.4, healPct: 0.55 },                              // 望月の歌: 全敵に超絶ダメージ＋味方HP55%回復
            ok_006: { dmg: 1.4, crit: 0.35 },                                // 長徳の変: 敵単体に強力な物理ダメージ
            ok_007: { buffSpecGain: [60, 15] },                              // 二后並立: 全味方の必殺チャージ速度短縮
            ok_008: { shield: 8 },                                           // 月夜の陰謀落飾: 敵の攻撃を引きつけるバリア
            ge_001: { healPct: 0.35 },                                       // 桐壺への追慕: 味方女性キャラのHPを35%回復
            ge_002: { dmg: 1.8, stun: [3, 6] },                              // 須磨の秋思: 全敵ダメージ＋『魅了』行動不能
            ge_003: { healPct: 0.45 },                                       // 朱雀院の譲位: 最もHPが低い味方を45%回復
            ge_004: { dmg: 2.2, crit: 0.5 },                                 // 密約の即位: 敵単体に特大光属性ダメージ
            ge_005: { buffDef: [60, 15] },                                   // 大学寮の勉学: 味方全体の防御力を固定大幅増
            ge_006: { healPct: 0.25 },                                       // いとあはれなる面影: 味方単体のHPを25%回復
            ge_007: { enemyAtkDown: [25, 12], enemySpeedDown: [30, 10] },    // 後宮の圧迫: 敵全体の攻撃力とすばやさ低下
            ge_008: { shield: 8 },                                           // 出家の決意: 味方全体にダメージ無効バリア
            ge_009: { dot: [8, 0.06] },                                      // 物の怪の憑依: 敵単体に呪い持続ダメージ
            se_001: { cleanse: true, buffAtk: [40, 12] },                    // 滝の音は絶えても: 味方デバフ解除＋攻撃バフ
            se_002: { buffAtk: [55, 12] },                                   // 香炉峰の雪: 味方全体の攻撃力大幅アップ
            se_003: { healPct: 0.55, shield: 6 },                            // 若宮のご誕生: 味方HP55%回復＋強固なバリア
            se_004: { dmg: 1.3, enemySpeedDown: [35, 8] },                   // 春はあけぼの: 敵全体に風攻撃＋すばやさ低下
            se_005: { enemyAtkDown: [30, 10], buffDmgUp: [30, 10] },         // 源氏物語執筆: 敵攻撃低下＋味方与ダメ上昇
            so_001: { healPct: 0.2, failChance: 0.3 },                       // かいもちひの誘惑: 自身を回復(時折失敗)
            so_002: { dmg: 1.6, crit: 0.4 },                                 // いざ、おどろかされん: 不意打ち物理ダメージ
            so_003: { dmg: 2.4 },                                            // 急々如律令: 式神召喚で敵全体連続属性攻撃
            so_004: { miss: 2 },                                             // 月下の笛の音: 敵全体の攻撃判定をミスに
            so_005: { dmg: 2.8, selfDmgPct: 0.1 },                           // あつちの怪異: 敵全火属性超絶ダメ＋自傷
            so_006: { specPowerUp: 0.25 },                                   // 毎月抄の指南: 味方のスキル威力を恒久アップ
            so_007: { dmg: 1.8, crit: 1.0 },                                 // ちはやぶる神代も聞かず: 単体に超大クリティカル攻撃
            so_008: { healPct: 0.18, regen: [6, 0.03] },                     // 大原御幸の落飾: 味方HP回復＋リジェネ付与
            so_009: { confuse: [4, 7], chance: 0.6 },                        // 花の色は移りにけりな: 敵全体を確率で混乱デバフ
            so_010: { dot: [10, 0.09] },                                     // 嘆きつつひとりぬる夜の: 敵単体に強力な持続ダメージ
            butsu_001: { dmg: 2.0, healPct: 0.60 },  // ① dmg調整（他キャラと同等レベル）
            kaguya_001: { dmg: 2.5, healPct: 0.70, stun: [4, 4] },  // ① dmg調整+④ stun固定4秒
            br_god_01: { dmg: 2.4, healPct: 0.20, buffAll: [35, 12] },
            br_god_02: { dmg: 2.7, crit: 0.4, dot: [7, 0.06] },
            br_god_03: { dmg: 2.35, stun: [4, 6], enemyAtkDown: [30, 10] },
            br_god_04: { healPct: 0.35, buffDef: [35, 12], buffDmgUp: [25, 12] },
            br_god_05: { dmg: 2.1, healPct: 0.22, buffDef: [45, 12], regen: [6, 0.02] },
            br_god_06: { dmg: 2.5, buffAtk: [35, 12], buffSpecGain: [35, 12], buffDmgUp: [35, 12] },
            br_god_07: { dmg: 2.55, buffAtk: [35, 12], buffDef: [45, 12], shield: 5 },
            br_god_08: { dmg: 2.65, stun: [5, 7], enemySpeedDown: [45, 12] },
            br_god_09: { dmg: 2.2, healPct: 0.4, enemyAtkDown: [35, 12], regen: [7, 0.02], cleanse: true },
            br_god_10: { dmg: 3.6, healPct: 0.70, stun: [7, 7], shield: 7, cleanse: true, buffAll: [70, 15], buffSpecGain: [70, 15], enemyAtkDown: [70, 15], enemySpeedDown: [70, 15], regen: [7, 0.025] },
            amaterasu_001: { dmg: 3.2, healPct: 0.70, stun: [6, 6], shield: 6, regen: [8, 0.02], cleanse: true, buffAll: [65, 15], buffSpecGain: [50, 15], enemyAtkDown: [40, 12], enemySpeedDown: [40, 12] }
        };

        // ===== ダンジョン10・20解放ガチャの必殺技（② 工夫を凝らした複合効果） =====
        const NEW_SPECIAL_EFFECTS = {
            n10_01: { dmg: 3.2, buffDmgUp: [30, 12] },                       // 花ぞ昔の香
            n10_02: { dmg: 2.4, stun: [2.5, 4.5] },                          // 千早振る神代も聞かず
            n10_03: { dmg: 2.3, enemyAtkDown: [30, 10] },                    // 恋は松を時雨
            n10_04: { dmg: 2.2, buffSpecGain: [45, 12] },                    // 鶯の谷渡り
            n10_05: { confuse: [3, 5], chance: 0.8, buffDmgUp: [20, 10] },   // 黒髪のみだれ心
            n10_06: { buffAtk: [35, 12], buffDef: [25, 12] },                // 世の中は憂きものか
            n10_07: { dmg: 1.7, healPct: 0.12 },                             // いにしへの奈良の八重桜
            n10_08: { dmg: 1.8, stun: [2, 3.5] },                            // 逢ふことの絶え間なく
            n10_09: { healPct: 0.18, regen: [4, 0.02] },                     // 物語に耽る心
            n10_10: { enemyAtkDown: [35, 12] },                              // 蜻蛉日記の恨み
            n10_11: { buffSpecGain: [50, 10] },                              // 父娘の歌才
            n10_12: { dmg: 2.1, crit: 0.5 },                                 // 白妙の衣
            n10_13: { dmg: 1.3, cleanse: true },                             // 春たてば花の香
            n10_14: { dmg: 1.2, buffSpeed: [30, 10] },                       // 撰集の筆
            n10_15: { dmg: 1.5 },                                            // 花の散り際
            n10_16: { dmg: 1.4, stun: [1.5, 3] },                            // 陸奥の嵐
            n10_17: { dmg: 1.2, enemySpeedDown: [25, 8] },                   // 秋来ぬと目にはさやかに
            n10_18: { confuse: [2, 4], chance: 0.7 },                        // 笑いの歌
            n10_19: { healPct: 0.15 },                                       // 法華の祈り
            n10_20: { shield: 4 },                                           // 宇治山の隠遁
            n10_21: { dmg: 1.2, buffDef: [30, 10] },                         // 神祇の祝詞
            n10_22: { dmg: 1.45 },                                           // 歌枕の旅路
            n10_23: { healPct: 0.12, regen: [3, 0.015] },                    // 春のうらら
            n10_24: { buffSpeed: [40, 10] },                                 // 雅楽の調べ
            n10_25: { dmg: 1.2, buffAtk: [20, 10] },                         // 空より花の降る
            n10_26: { dmg: 1.2, dot: [4, 0.05] },                            // 恋の焦がれ
            n10_27: { dmg: 2.1, crit: 0.4 },                                 // 朽ちもせぬその名
            n10_28: { buffAll: [25, 12], buffSpecGain: [30, 10] },           // 三舟の才・管弦
            n10_29: { dmg: 2.3, healPct: 0.18 },                             // 若紫の巻・垣間見
            n10_30: { dmg: 2.3, enemySpeedDown: [40, 10] },                  // 春はあけぼの・暁
            n10_31: { healPct: 0.2, shield: 3 },                             // 母の筆のあと
            n10_32: { dmg: 3.4, healPct: 0.3, shield: 2 },                   // この世をば我が世
            n20_01: { dmg: 3.4, buffAtk: [40, 12] },                         // 八艘飛び・壇ノ浦の逆撃
            n20_02: { dmg: 3.0, shield: 5 },                                 // 見るべき程の事は見つ
            n20_03: { dmg: 2.3, buffSpeed: [35, 12] },                       // 東国の総攻め
            n20_04: { buffAll: [25, 12], healPct: 0.12 },                    // 尼将軍の檄
            n20_05: { dmg: 2.8, crit: 0.5 },                                 // 大太刀の一閃
            n20_06: { dmg: 2.2, confuse: [3, 5], chance: 0.85 },             // 青葉の笛
            n20_07: { healPct: 0.22, shield: 3 },                            // 往生院の祈り
            n20_08: { dmg: 2.3, crit: 1.0 },                                 // 扇の的・屋島の一矢
            n20_09: { dmg: 2.0 },                                            // 旭将軍の蹴散らし
            n20_10: { buffSpeed: [45, 12], enemyAtkDown: [20, 8] },          // 白拍子の舞
            n20_11: { healPct: 0.15, regen: [5, 0.02] },                     // 大原寂光院の回向
            n20_12: { dmg: 2.2, buffSpecGain: [40, 10] },                    // 承久の斜め
            n20_13: { dmg: 1.8, enemyAtkDown: [25, 10] },                    // ゆく河の流れ
            n20_14: { cleanse: true, buffAtk: [30, 10] },                    // 徒然なるままに
            n20_15: { dmg: 2.4, healPct: 0.22 },                             // 願はくは花の下にて
            n20_16: { healPct: 0.15 },                                       // 南無阿弥陀仏の踊り
            n20_17: { enemyAtkDown: [25, 10] },                              // 星読みの暦
            n20_18: { buffSpecGain: [45, 12], buffSpeed: [25, 8] },          // 長秋卿の秘曲
            n20_19: { dmg: 2.8, stun: [2.5, 4.5] },                          // 羅生門の鬼腕斬り
            n20_20: { dmg: 2.2, dot: [6, 0.07] },                            // 泰山府君祭
            n20_21: { dmg: 2.1, confuse: [3, 5], chance: 0.85 },             // 花の色は移りにけりな
            n20_22: { dmg: 1.5 },                                            // 立田の橋
            n20_23: { dmg: 1.3, dot: [3, 0.05] },                            // 異界の博士
            n20_24: { healPct: 0.12 },                                       // 宇治の姫君の面影
            n20_25: { healPct: 0.18, regen: [4, 0.02] },                     // 横川の僧都の助け
            n20_26: { dmg: 2.0, crit: 0.5 },                                 // 薫りの御方
            n20_27: { confuse: [2.5, 4.5], chance: 0.8, enemySpeedDown: [20, 8] }, // 匂ふ宮の恋
            n20_28: { dmg: 1.8, buffDef: [25, 10] },                         // 夕霧の雲居
            n20_29: { dmg: 2.3, buffDmgUp: [25, 10] },                       // 拾遺愚草・恋の三首
            n20_30: { healPct: 0.25 },                                       // 花の下にて春死なむ
            n20_31: { dmg: 1.3, buffSpecGain: [25, 8] },                     // 歌学の舟
            n20_32: { dmg: 2.4, crit: 0.5, stun: [1.5, 3] }                  // 幽玄の心
        };

        function rnd(a, b) { return a + Math.random() * (b - a); }

        // 指定キーのバフ%を取得（「全ステータスUP」バフも合算）
        function buffPct(key) {
            if (!battleState || !battleState.buffs) return 0;
            const b = battleState.buffs;
            return (b[key] ? b[key].pct : 0) + (b.all ? b.all.pct : 0);
        }

        // ④ パーティのスキル状態を返す（戦闘中のスキル発揮用）
        function getPartySkillState() {
            const members = (battleState && battleState.party) ? battleState.party : [];
            const ids = members.filter(p => !p.defected).map(p => p.id);
            return {
                ids: ids,
                femaleCount: members.filter(p => !p.defected && p.unit && p.unit.gender === '女性').length,
                active: function(id) { return this.ids.includes(id); }
            };
        }

        // 新ガチャキャラの条件付きスキルを既存のバフ/デバフ/ミス処理で発動
        function triggerNewGachaSkill(trigger) {
            if (!battleState || !battleState.active || !battleState.party) return;
            battleState.party.forEach(p => {
                if (!p.unit || !p.unit.skill || p.sealedSeconds > 0 || p.defected) return;
                const skill = p.unit.skill;
                if (skill.trigger !== trigger) return;
                if (!battleState.passiveFlags) battleState.passiveFlags = {};
                const onceKey = `newSkill_${p.id}_${trigger}`;
                if ((trigger === 'afterHit' || trigger === 'lowHpHit') && battleState.passiveFlags[onceKey]) return;
                if (trigger === 'lowHpCorrect' && battleState.playerHp > battleState.maxPlayerHp * 0.5) return;
                if (trigger === 'highGaugeCorrect' && p.specialGauge < 80) return;
                if (trigger === 'sameRarityCorrect') {
                    const hasSameRarity = battleState.party.some(other => other !== p && other.sealedSeconds <= 0 && other.unit && other.unit.rarity === p.unit.rarity);
                    if (!hasSameRarity) return;
                }
                if (trigger === 'combo3' && battleState.combo !== 3) return;
                if (skill.fx) applySpecialEffects(p, 1, skill.fx);
                if (trigger === 'afterHit' || trigger === 'lowHpHit') battleState.passiveFlags[onceKey] = true;
            });
        }

        // 回復割合はシナジーで上昇するが、発動しきい値30%は固定
        function getKiritsuboRecoveryPct() {
            const recoverySynergyCount = (battleState.activeSynergies || []).filter(syn => /回復/.test(syn.effect || '')).length;
            return Math.min(0.70, 0.80 + recoverySynergyCount * 0.05);
        }

        // ⑤ 桐壺更衣「儚き運命」: HPが30%以下になった時、一度だけHPを80%〜95%まで回復
        function checkKiritsuboRevive() {
            if (!battleState || !battleState.party || !battleState.active) return false;
            if (!battleState.party.some(p => p.id === 'ge_006' && p.sealedSeconds <= 0 && !p.defected)) return false;
            if (battleState.passiveFlags && battleState.passiveFlags.kiritsuboUsed) return false;
            if (battleState.playerHp <= 0) return false;
            const threshold = battleState.maxPlayerHp * 0.3;
            if (battleState.playerHp <= threshold) {
                if (!battleState.passiveFlags) battleState.passiveFlags = {};
                battleState.passiveFlags.kiritsuboUsed = true;
                const recoveryPct = getKiritsuboRecoveryPct();
                battleState.playerHp = Math.floor(battleState.maxPlayerHp * recoveryPct);
                createFloatingText(`🌸 桐壺更衣のスキル発動！HPを${Math.round(recoveryPct * 100)}%まで回復`, document.getElementById("playerSideBox"), "text-green-300 text-sm font-black");
                updateBattleUI();
                return true;
            }
            return false;
        }

        // ③ 回復量アップ系シナジー・効果を回復量へ反映（上限+60%）
        function getRecoveryBuffPct() {
            let pct = 0;
            (battleState && battleState.activeSynergies || []).forEach(syn => {
                const eff = syn.effect || '';
                if (eff.indexOf('回復') >= 0) pct += 5;
            });
            return Math.min(60, pct);
        }

        // 必殺技の効果を文言通りに適用する
        function applySpecialEffects(p, specLvl, fx) {
            const enemyBox = document.getElementById("enemySideBox");
            const playerBox = document.getElementById("playerSideBox");
            const specMoveName = p.unit.special_move ? p.unit.special_move.name : "秘技奥義";
            // ④ 敵強化モード中（被ダメージ½・状態異常無効）
            const powerEnraged = battleState.dungeonNum >= 20 && battleState.enemyPowerUpTimer > 0;

            // 基礎威力（必殺技Lvで上昇）※Lv50までは従来どおり、Lv51以降は現在の成長率の100万分の1
            const _grw = (base, step, lv) => lv <= 50
                ? (base + (lv - 1) * step)
                : (base + 49 * step + (lv - 50) * (Math.max(0.05, step * 0.2) / 1000000));
            let specBase = p.atk * _grw(3.5, 0.7, specLvl);
            if (p.unit.rarity === 'UR' || p.unit.rarity === '神') specBase = p.atk * _grw(6.0, 1.2, specLvl);
            // ① 神レア度（かぐや姫・仏）は他キャラと同じ上昇率（UR準拠）を適用

            // ① ダメージ系
            if (fx.dmg) {
                let dmg = Math.floor(specBase * fx.dmg * battleState.specPowerBonus * (1 + (buffPct("atk") + buffPct("dmg")) / 100));
                let isCrit = false;
                if (fx.crit && Math.random() < capRate(fx.crit)) { dmg = Math.floor(dmg * 1.8); isCrit = true; }
                // ④ 敵強化モード中: 敵が受けるダメージを一律半分
                if (powerEnraged) { dmg = Math.floor(dmg / 2); createFloatingText('🛡️ 強化の障壁！受けるダメージ½', enemyBox, 'text-orange-300 text-xs font-black'); }
                battleState.enemyHp = Math.max(0, battleState.enemyHp - dmg);
                if (enemyBox) {
                    enemyBox.classList.add("animate-shake-intense");
                    setTimeout(() => enemyBox.classList.remove("animate-shake-intense"), 500);
                }
                createFloatingText(`【${specMoveName} Lv.${specLvl}】`, enemyBox, "text-amber-300 text-xs font-black font-mincho");
                createFloatingText(`${isCrit ? '💥会心!! ' : ''}-${dmg}`, enemyBox, isCrit ? "text-red-300 text-xl font-black" : "text-yellow-300 text-lg font-black");
            }

            // ② 自傷（平清盛「あつちの怪異」）
            if (fx.selfDmgPct) {
                const sd = Math.floor(battleState.maxPlayerHp * fx.selfDmgPct);
                battleState.playerHp = Math.max(0, battleState.playerHp - sd);
                createFloatingText(`-${sd} 自傷...`, playerBox, "text-red-400 text-sm font-bold");
            }

            // ③ 回復系（失敗確率のある回復は失敗時発動しない）
            const failed = fx.failChance && Math.random() < capRate(fx.failChance);
            if (fx.healPct && !failed) {
                const healUpPct = getRecoveryBuffPct();
                const amt = Math.floor(battleState.maxPlayerHp * capRate(fx.healPct) * (1 + healUpPct / 100));
                battleState.playerHp = Math.min(battleState.maxPlayerHp, battleState.playerHp + amt);
                createFloatingText(`+${amt} HP回復`, playerBox, "text-green-400 text-sm font-bold");
            } else if (fx.healPct && failed) {
                createFloatingText("回復に失敗…！", playerBox, "text-gray-400 text-sm font-bold");
            }
            if (fx.healFull) {
                const amt = Math.floor(battleState.maxPlayerHp - battleState.playerHp);
                battleState.playerHp = battleState.maxPlayerHp;
                createFloatingText(`HP全回復 (+${amt})`, playerBox, "text-green-300 text-base font-black");
            }

            // ④ スタン／魅了／混乱（敵が数秒間動けなくなる＝攻撃タイマー停止）※強化モード中は無効
            if (fx.stun) {
                if (powerEnraged) { createFloatingText('🌀 強化モード：行動不能が無効化！', enemyBox, "text-orange-300 text-xs font-black"); }
                else {
                const dur = rnd(fx.stun[0], fx.stun[1]);
                battleState.stunSec = Math.max(battleState.stunSec, dur);
                createFloatingText(`🌀『行動不能』 ${dur.toFixed(1)}秒!`, enemyBox, "text-purple-300 text-lg font-black");
                AudioFX.playSeal();
                }
            }
            if (fx.confuse && Math.random() < capRate(fx.chance !== undefined ? fx.chance : 1)) {
                if (powerEnraged) { createFloatingText('💫 強化モード：混乱が無効化！', enemyBox, "text-orange-300 text-xs font-black"); }
                else {
                const dur = rnd(fx.confuse[0], fx.confuse[1]);
                battleState.stunSec = Math.max(battleState.stunSec, dur);
                createFloatingText(`💫『混乱』 ${dur.toFixed(1)}秒!`, enemyBox, "text-fuchsia-300 text-lg font-black");
                AudioFX.playSeal();
                }
            }

            // ⑤ バリア（ダメージ無効）
            if (fx.shield) {
                battleState.shieldSec = Math.min(7, fx.shield);
                createFloatingText(`🔰 結界 ${battleState.shieldSec}秒!`, playerBox, "text-cyan-300 text-sm font-black");
            }

            // ⑥ 味方バフ
            if (fx.buffAtk) { const pct = capPct(fx.buffAtk[0]); battleState.buffs.atk = { pct: pct, sec: fx.buffAtk[1] }; createFloatingText(`⚔️ 攻撃力UP! ${pct}% (${fx.buffAtk[1]}秒)`, playerBox, "text-red-300 text-sm font-black"); }
            if (fx.buffDef) { const pct = capPct(fx.buffDef[0]); battleState.buffs.def = { pct: pct, sec: fx.buffDef[1] }; createFloatingText(`🛡️ 防御力UP! ${pct}% (${fx.buffDef[1]}秒)`, playerBox, "text-blue-300 text-sm font-black"); }
            if (fx.buffAll) { const pct = capPct(fx.buffAll[0]); battleState.buffs.all = { pct: pct, sec: fx.buffAll[1] }; createFloatingText(`✨ 全ステータスUP! ${pct}% (${fx.buffAll[1]}秒)`, playerBox, "text-amber-300 text-sm font-black"); }
            if (fx.buffSpeed) { const pct = capPct(fx.buffSpeed[0]); battleState.buffs.speed = { pct: pct, sec: fx.buffSpeed[1] }; createFloatingText(`💨 攻撃速度UP! ${pct}% (${fx.buffSpeed[1]}秒)`, playerBox, "text-yellow-300 text-sm font-black"); }
            if (fx.buffSpecGain) { const pct = capPct(fx.buffSpecGain[0]); battleState.buffs.specGain = { pct: pct, sec: fx.buffSpecGain[1] }; createFloatingText(`⚡ 必殺チャージ加速! ${pct}% (${fx.buffSpecGain[1]}秒)`, playerBox, "text-yellow-300 text-sm font-black"); }
            if (fx.buffDmgUp) { const pct = capPct(fx.buffDmgUp[0]); battleState.buffs.dmg = { pct: pct, sec: fx.buffDmgUp[1] }; createFloatingText(`💥 与ダメージUP! ${pct}% (${fx.buffDmgUp[1]}秒)`, playerBox, "text-orange-300 text-sm font-black"); }
            if (fx.cleanse) {
                battleState.party.forEach(pp => { pp.sealedSeconds = 0; });
                createFloatingText("✨ 味方のデバフを解除！", playerBox, "text-green-300 text-sm font-black");
            }

            // ⑦ 敵デバフ
            if (fx.enemyAtkDown) {
                if (powerEnraged) { createFloatingText('⬇️ 強化モード：デバフが無効化！', enemyBox, "text-orange-300 text-xs font-black"); }
                else { const pct = capPct(fx.enemyAtkDown[0]); battleState.debuffs.eAtk = { pct: pct, sec: fx.enemyAtkDown[1] }; createFloatingText(`⬇️ 敵の攻撃力DOWN ${pct}% (${fx.enemyAtkDown[1]}秒)`, enemyBox, "text-blue-300 text-sm font-black"); }
            }
            if (fx.enemySpeedDown) {
                if (powerEnraged) { createFloatingText('🐢 強化モード：デバフが無効化！', enemyBox, "text-orange-300 text-xs font-black"); }
                else { const pct = capPct(fx.enemySpeedDown[0]); battleState.debuffs.eSpeed = { pct: pct, sec: fx.enemySpeedDown[1] }; createFloatingText(`🐢 敵すばやさDOWN ${pct}% (${fx.enemySpeedDown[1]}秒)`, enemyBox, "text-cyan-300 text-sm font-black"); }
            }

            // ⑧ 持続効果（毒・リジェネ・ミス・恒久強化）
            if (fx.dot) {
                if (powerEnraged) { createFloatingText('☠️ 強化モード：呪い・毒が無効化！', enemyBox, "text-orange-300 text-xs font-black"); }
                else { battleState.dot = { dps: fx.dot[1], sec: fx.dot[0] }; createFloatingText(`☠️ 呪いの持続ダメージ ${fx.dot[0]}秒`, enemyBox, "text-purple-300 text-sm font-black"); }
            }
            if (fx.regen) { const healUpPct = getRecoveryBuffPct(); battleState.regen = { hps: Math.max(1, Math.floor(battleState.maxPlayerHp * fx.regen[1] * (1 + healUpPct / 100))), sec: fx.regen[0] }; createFloatingText(`💚 リジェネ ${fx.regen[0]}秒`, playerBox, "text-green-300 text-sm font-black"); }
            if (fx.miss) {
                if (powerEnraged) { createFloatingText('✖️ 強化モード：ミス化が無効化！', enemyBox, "text-orange-300 text-xs font-black"); }
                else { battleState.missCharges = fx.miss; createFloatingText(`✖️ 敵の攻撃をミス化 ×${fx.miss}`, enemyBox, "text-cyan-300 text-sm font-black"); }
            }
            if (fx.specPowerUp) {
                battleState.specPowerBonus += fx.specPowerUp;
                createFloatingText(`📜 スキル威力 恒久UP (+${Math.round(fx.specPowerUp * 100)}%)`, playerBox, "text-amber-300 text-base font-black");
            }
        }

        // バフ・デバフ・スタン・毒・バリアの残り時間を更新する
        function tickStatusTimers(dt) {
            const b = battleState.buffs, d = battleState.debuffs;
            ["atk", "def", "speed", "dmg", "specGain", "all"].forEach(k => {
                if (b[k]) { b[k].sec -= dt; if (b[k].sec <= 0) b[k] = null; }
            });
            ["eAtk", "eSpeed"].forEach(k => {
                if (d[k]) { d[k].sec -= dt; if (d[k].sec <= 0) d[k] = null; }
            });
            if (battleState.stunSec > 0) battleState.stunSec = Math.max(0, battleState.stunSec - dt);
            if (battleState.shieldSec > 0) battleState.shieldSec = Math.max(0, battleState.shieldSec - dt);
            // 月曜ギミック: レベル半減の復帰タイマー（個別管理・復帰時にステータスを戻す）
            // 火曜ギミック: 寝返りの復帰タイマー（5秒後に味方へ戻る）
            (battleState.party || []).forEach(p => {
                if (p.levelHalved && p.levelHalveSec > 0 && !p.defected) {
                    p.levelHalveSec -= dt;
                    if (p.levelHalveSec <= 0) {
                        p.levelHalved = false;
                        p.levelHalveSec = 0;
                        if (p._halveLost) {
                            p.maxHp += p._halveLost.maxHp;
                            p.hp = Math.min(p.maxHp, p.hp + p._halveLost.hp);
                            p.atk += p._halveLost.atk;
                            battleState.maxPlayerHp += p._halveLost.maxHp;
                            battleState.playerHp = Math.min(battleState.maxPlayerHp, battleState.playerHp + p._halveLost.hp);
                            p._halveLost = null;
                            const pBox = document.getElementById("playerSideBox");
                            if (pBox) createFloatingText(`🌤 ${p.unit.name}のレベルが元に戻った！`, pBox, "text-emerald-300 text-xs font-black");
                        }
                    }
                }
                if (p.defected && p.defectSec > 0) {
                    p.defectSec = Math.max(0, p.defectSec - dt);
                    if (p.defectSec === 0) {
                        restoreTuesdayDefectedUnit(p);
                    }
                }
            });
            // ⑧ enemyPowerUpTimer はbattleGameLoop内で管理しているためここでは不要（二重減算防止）

            const enemyBox = document.getElementById("enemySideBox");
            const playerBox = document.getElementById("playerSideBox");

            // 毒・呪い（敵へ持続ダメージ）※④ 強化モード中は状態異常無効のため毒は作用しない
            if (battleState.dot && battleState.dot.sec > 0) {
                if (battleState.dungeonNum >= 20 && battleState.enemyPowerUpTimer > 0) {
                    battleState.dot = null;
                    createFloatingText('✨ 強化モード：毒が無効化された！', enemyBox, 'text-orange-300 text-xs font-bold');
                } else {
                    battleState.dot.sec -= dt;
                    const dotDmg = Math.max(1, Math.floor(battleState.maxEnemyHp * battleState.dot.dps * dt));
                    battleState.enemyHp = Math.max(0, battleState.enemyHp - dotDmg);
                    battleState._dotAcc = (battleState._dotAcc || 0) + dt;
                    if (battleState._dotAcc >= 0.5) { battleState._dotAcc = 0; createFloatingText(`-${dotDmg} 毒`, enemyBox, "text-purple-300 text-xs font-bold"); }
                    if (battleState.dot.sec <= 0) battleState.dot = null;
                }
            }
            // リジェネ（味方HP回復）
            if (battleState.regen && battleState.regen.sec > 0) {
                battleState.regen.sec -= dt;
                battleState.playerHp = Math.min(battleState.maxPlayerHp, battleState.playerHp + battleState.regen.hps * dt);
                battleState._regenAcc = (battleState._regenAcc || 0) + dt;
                if (battleState._regenAcc >= 0.5) { battleState._regenAcc = 0; createFloatingText("💚 回復中", playerBox, "text-green-400 text-xs font-bold"); }
                if (battleState.regen.sec <= 0) battleState.regen = null;
            }

            if (battleState.enemyHp <= 0) { endBattle(true); return; }
        }

        // 画面にバフ/デバフ/スタン等の状態アイコンを表示（上昇中が一目で分かる）
        let _statusSig = "";
        let _battlePartySig = "";
        let _battlePartyEls = null;
        function updateStatusIndicators() {
            if (!battleState || !battleState.buffs) return;
            const pBox = document.getElementById("playerStatusIcons");
            const eBox = document.getElementById("enemyStatusIcons");
            const playerBox = document.getElementById("playerSideBox");
            const enemyBox = document.getElementById("enemySideBox");
            if (!pBox || !eBox) return;

            const b = battleState.buffs, d = battleState.debuffs;
            const sig = [
                b.atk ? Math.ceil(b.atk.sec) : 0, b.def ? Math.ceil(b.def.sec) : 0, b.all ? Math.ceil(b.all.sec) : 0,
                b.speed ? Math.ceil(b.speed.sec) : 0, b.specGain ? Math.ceil(b.specGain.sec) : 0, b.dmg ? Math.ceil(b.dmg.sec) : 0,
                Math.ceil(battleState.shieldSec), battleState.regen ? Math.ceil(battleState.regen.sec) : 0,
                Math.round((battleState.specPowerBonus - 1) * 100),
                Math.ceil(battleState.stunSec), battleState.dot ? Math.ceil(battleState.dot.sec) : 0,
                d.eAtk ? Math.ceil(d.eAtk.sec) : 0, d.eSpeed ? Math.ceil(d.eSpeed.sec) : 0,
                battleState.missCharges
            ].join("|");
            if (sig === _statusSig) return;
            _statusSig = sig;

            __PERF.setHTML(pBox, "");
            __PERF.setHTML(eBox, "");

            function chip(icon, text, cls) {
                const el = document.createElement("span");
                el.className = `status-chip ${cls}`;
                __PERF.setHTML(el, `<span>${icon}</span>${text}`);
                return el;
            }
            const secTxt = s => `${Math.ceil(s)}秒`;

            if (b.atk) pBox.appendChild(chip("⚔️↑", `攻撃UP ${secTxt(b.atk.sec)}`, "chip-red"));
            if (b.def) pBox.appendChild(chip("🛡️↑", `防御UP ${secTxt(b.def.sec)}`, "chip-blue"));
            if (b.all) pBox.appendChild(chip("✨↑", `全ステUP ${secTxt(b.all.sec)}`, "chip-gold"));
            if (b.speed) pBox.appendChild(chip("💨", `攻撃速度UP ${secTxt(b.speed.sec)}`, "chip-yellow"));
            if (b.specGain) pBox.appendChild(chip("⚡", `必殺加速 ${secTxt(b.specGain.sec)}`, "chip-yellow"));
            if (b.dmg) pBox.appendChild(chip("💥", `与ダメUP ${secTxt(b.dmg.sec)}`, "chip-orange"));
            if (battleState.shieldSec > 0) pBox.appendChild(chip("🔰", `バリア ${secTxt(battleState.shieldSec)}`, "chip-cyan"));
            if (battleState.regen) pBox.appendChild(chip("💚", `リジェネ ${secTxt(battleState.regen.sec)}`, "chip-green"));
            if (battleState.specPowerBonus > 1) pBox.appendChild(chip("📜", `技威力+${Math.round((battleState.specPowerBonus - 1) * 100)}%`, "chip-purple"));

            if (battleState.stunSec > 0) eBox.appendChild(chip("🌀", `行動不能 ${secTxt(battleState.stunSec)}`, "chip-purple"));
            if (battleState.dot) eBox.appendChild(chip("☠️", `毒 ${secTxt(battleState.dot.sec)}`, "chip-purple"));
            if (d.eAtk) eBox.appendChild(chip("⬇️", `攻撃低下 ${secTxt(d.eAtk.sec)}`, "chip-blue"));
            if (d.eSpeed) eBox.appendChild(chip("🐢", `すばやさ低下 ${secTxt(d.eSpeed.sec)}`, "chip-blue"));
            if (battleState.missCharges > 0) eBox.appendChild(chip("✖️", `攻撃ミス×${battleState.missCharges}`, "chip-cyan"));

            if (playerBox) playerBox.classList.toggle("battle-buff-glow", pBox.childElementCount > 0);
            if (enemyBox) enemyBox.classList.toggle("enemy-stunned", battleState.stunSec > 0);
            if (enemyBox) enemyBox.classList.toggle('enemy-power-up', !!(battleState.enemyPowerUpTimer > 0));
        }

        function triggerSpecialMove(partyIdx) {
            if (!battleState.active) return;
            const p = battleState.party[partyIdx];
            if (!p || p.specialGauge < 100 || p.sealedSeconds > 0 || p.defected) return;
            // ② サブ枠キャラは手動必殺技発動ボタンを持たない（押せない）
            if (p.isSub) return;

            p.specialGauge = 0;
            AudioFX.playCrit();

            const specLvl = (p.id !== 'ch_000' && state.unitSpecialLevels && state.unitSpecialLevels[p.id]) ? state.unitSpecialLevels[p.id] : 1;
            const fx = SPECIAL_EFFECTS[p.id] || NEW_SPECIAL_EFFECTS[p.id] || p.unit.special_effect || { dmg: 1.0 };
            playSpecialMoveShow(p, fx);
            applySpecialEffects(p, specLvl, fx);

            updateBattleUI();

            if (battleState.enemyHp <= 0) {
                endBattle(true);
            }
        }

