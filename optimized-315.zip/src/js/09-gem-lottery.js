        // ============================================================
        // ⑧ 宝玉くじ（お金もステータスも増えない「ただのくじ」）
        // ============================================================
        const GEM_LOTTERY_RESULTS = [
            { rank: "大吉", emoji: "🎉", msg: "平安の空に虹がかかった！今日は良い日になりそう。" },
            { rank: "吉", emoji: "🌤️", msg: "まずまずの運勢。古典の神様が微笑んでいる。" },
            { rank: "中吉", emoji: "☁️", msg: "悪くない運勢。気長にいこう。" },
            { rank: "小吉", emoji: "🍃", msg: "小さな幸運が舞い込むかも。" },
            { rank: "末吉", emoji: "🌙", msg: "もう一歩。焦らずじっくりと。" },
            { rank: "凶", emoji: "☔", msg: "ご用心。今日は大人しく古文でも読もう。" }
        ];
        function performGemLottery(count) {
            const cost = count * 10;
            if (state.gems < cost) {
                showCustomAlert("宝玉不足", `くじに必要な宝玉（${cost}個）が足りません。`);
                return;
            }
            state.gems -= cost;
            state.gemLotteryDraws = Math.max(0, Math.floor(Number(state.gemLotteryDraws) || 0)) + count;
            saveState();
            renderHeader();
            const draw = Array.from({ length: count }, () => GEM_LOTTERY_RESULTS[Math.floor(Math.random() * GEM_LOTTERY_RESULTS.length)]);
            const ta = document.getElementById("gemLotteryResult");
            if (ta) ta.innerHTML = draw.map(d => `<span class="inline-block bg-purple-950/80 border border-purple-500/40 rounded px-2 py-1 mr-1 mb-1">${d.emoji} ${d.rank}</span>`).join("");
            if (count === 1) {
                showCustomAlert("宝玉くじ 結果", `${draw[0].emoji} ${draw[0].rank}！
${draw[0].msg}

（お金やステータスには一切影響しません。ただのくじです。）`);
            } else {
                const counts = {};
                draw.forEach(d => { counts[d.rank] = (counts[d.rank] || 0) + 1; });
                const summary = Object.keys(counts).map(k => `${k}×${counts[k]}`).join('  ');
                showCustomAlert("宝玉くじ 結果", `${summary}

（お金やステータスには一切影響しません。ただのくじです。）`);
            }
        }

                function renderNewGachaPanels(tabId) {
            const container = document.getElementById('newGachaPanels');
            if (!container) return;
            __PERF.setHTML(container, "");
            if (!tabId) return;
            const banner = NEW_GACHA_BANNERS[tabId];
            if (!banner || !isNewGachaUnlocked(tabId)) return;
            const isD10 = tabId === 'd10', isD20 = tabId === 'd20';
            const themeCls = isD10 ? 'gacha-banner-d10' : isD20 ? 'gacha-banner-d20' : '';
            const emblemIcon = isD10 ? 'fa-scroll' : isD20 ? 'fa-shield-halved' : 'fa-ticket';
            const titleCls = isD10 ? 'text-purple-200' : isD20 ? 'text-red-200' : 'text-yellow-100';
            const units = banner.units || [];
            const order = {UR:0, SSR:1, SR:2, R:3};
            const featured = [...units].sort((a,x)=>order[a.rarity]-order[x.rarity]).slice(0,4);
            const featCls = (r)=> (r==='UR' ? 'gacha-featured-ur' : 'gacha-featured-ssr');
            const badgeCls = (r)=> (r==='UR' ? 'bg-gradient-to-r from-red-600 to-amber-500 text-white' : 'bg-gradient-to-r from-amber-500 to-yellow-300 text-black');
            const short = (s)=>{ s=(s||''); return s.length>15 ? s.slice(0,15)+'…' : s; };
            const rates = [
                ['UR','0.2%','text-red-400','border-red-500/60','bg-red-950/80'],
                ['SSR','10.0%','text-amber-400','border-amber-500/60','bg-amber-950/80'],
                ['SR','20.0%','text-purple-300','border-purple-500/60','bg-purple-950/80'],
                ['R','69.8%','text-gray-400','border-gray-600','bg-gray-900']
            ];
            const panel = document.createElement('div');
            panel.className = `gacha-banner-panel ${themeCls} p-6 rounded-2xl border-2 text-center shadow-xl relative`; panel.dataset.bannerId = banner.id;
            __PERF.setHTML(panel, `
                <div class="gacha-shine"></div>
                <div class="relative z-10">
                    <div class="text-[10px] tracking-[0.35em] text-emerald-300 font-bold mb-1">ダンジョン${banner.unlockDungeon} 完全攻略報酬・解放済</div>
                    <h3 class="font-mincho text-2xl md:text-3xl font-extrabold gacha-title-gradient mb-1"><i class="fa-solid ${emblemIcon} mr-2 text-amber-300"></i>${banner.title}</h3>
                    <div class="gacha-ornament my-2">◆ ◇ ◆</div>
                    <p class="text-xs text-gray-300 mt-1 mb-4">${banner.description}</p>
                    <div class="max-w-2xl mx-auto mb-6 bg-black/60 p-3 rounded-xl border border-heian-gold/40 text-xs">
                        <div class="flex justify-between items-center mb-2 pb-1 border-b border-heian-purple/60">
                            <span class="font-bold text-amber-300 flex items-center gap-1.5"><i class="fa-solid fa-chart-pie"></i> 提供割合（排出率）</span>
                            <button onclick="openGachaRatesModal('${banner.id}')" class="text-[11px] bg-heian-purple hover:bg-heian-purple/80 text-yellow-200 border border-heian-gold/40 px-2.5 py-1 rounded font-bold transition"><i class="fa-solid fa-list-check mr-1"></i> 排出対象・個別確率一覧</button>
                        </div>
                        <div class="grid grid-cols-4 gap-2 text-center font-bold">
                            ${rates.map(r=>`<div class="${r[4]} border ${r[3]} p-2 rounded"><div class="text-[10px] ${r[2]}">${r[0]}</div><div class="text-sm text-amber-300 font-mono mt-0.5">${r[1]}</div></div>`).join('')}
                        </div>
                    </div>
                    <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-3xl mx-auto mb-6">
                        ${featured.map(u=>`<div class="gacha-featured-card ${featCls(u.rarity)}">
                            <span class="text-[10px] ${badgeCls(u.rarity)} font-bold px-2 py-0.5 rounded-full shadow">${u.rarity==='UR'?'最強 UR':u.rarity}</span>
                            <div class="w-10 h-10 mx-auto mt-1.5 rounded-full bg-gradient-to-br from-purple-500/40 to-amber-400/30 border border-amber-400/70 flex items-center justify-center text-amber-200 text-lg"><i class="fa-solid ${u.icon}"></i></div>
                            <div class="font-mincho font-bold text-amber-300 text-sm mt-1">${u.name}</div>
                            <div class="text-[10px] text-gray-300 leading-snug">${short(u.skill.effect)}</div>
                        </div>`).join('')}
                    </div>
                    <div class="flex flex-wrap justify-center gap-4">
                        <button onclick="performGacha(1, '${banner.id}')" class="gacha-summon-btn gold-button px-6 py-2.5 rounded-xl text-xs"><i class="fa-solid fa-ticket"></i> 1回（${banner.cost.toLocaleString()}文）</button>
                        <button onclick="performGacha(10, '${banner.id}')" class="gacha-summon-btn gacha-summon-btn-10 vermilion-gradient text-white font-bold px-6 py-2.5 rounded-xl text-xs border border-red-400"><i class="fa-solid fa-arrows-spin"></i> 10連（${(banner.cost * 10).toLocaleString()}文）</button>
                    </div>
                </div>`);
            container.appendChild(panel);
        }


                function renderWeekdayGachaPanel(dayId){
            const c=document.getElementById('newGachaPanels'); if(!c) return;
            const b=WEEKDAY_GACHA_BANNERS[dayId]; if(!b) return;
            const pts=(state.weekdayPoints&&state.weekdayPoints[dayId])||0;
            const units=b.units||[];
            const order={UR:0,SSR:1,SR:2,R:3};
            const featured=[...units].sort((a,x)=>order[a.rarity]-order[x.rarity]).slice(0,4);
            const featCls=(r)=>(r==='UR'?'gacha-featured-ur':'gacha-featured-ssr');
            const badgeCls=(r)=>(r==='UR'?'bg-gradient-to-r from-red-600 to-amber-500 text-white':'bg-gradient-to-r from-amber-500 to-yellow-300 text-black');
            const short=(s)=>{ s=(s||''); return s.length>15 ? s.slice(0,15)+'…' : s; };
            const rates=[
                ['UR','2.0%','text-red-400','border-red-500/60','bg-red-950/80'],
                ['SSR','15.0%','text-amber-400','border-amber-500/60','bg-amber-950/80'],
                ['SR','30.0%','text-purple-300','border-purple-500/60','bg-purple-950/80'],
                ['R','53.0%','text-gray-400','border-gray-600','bg-gray-900']
            ];
            __PERF.setHTML(c, `
            <div class="gacha-banner-panel gacha-banner-d10 p-6 rounded-2xl border-2 text-center shadow-xl relative">
                <div class="gacha-shine"></div>
                <div class="relative z-10">
                    <div class="text-[10px] tracking-[0.35em] text-emerald-300 font-bold mb-1">${b.pointName}で引く独立ガチャ・本日開催</div>
                    <h3 class="font-mincho text-2xl md:text-3xl font-extrabold gacha-title-gradient mb-1"><i class="fa-solid ${b.icon} mr-2 text-amber-300"></i>${b.title}<i class="fa-solid ${b.icon} ml-2 text-amber-300"></i></h3>
                    <div class="gacha-ornament my-2">◆ ◇ ◆</div>
                    <p class="text-xs md:text-sm text-yellow-100/90 mt-1 mb-4">ステージクリアで${b.pointName}を獲得。${b.pointName}1000で1回、10000で10連召喚できる。</p>
                    <div class="max-w-2xl mx-auto mb-6 bg-black/60 p-3 rounded-xl border border-heian-gold/40 text-xs">
                        <div class="flex justify-between items-center mb-2 pb-1 border-b border-heian-purple/60">
                            <span class="font-bold text-amber-300 flex items-center gap-1.5"><i class="fa-solid fa-chart-pie"></i> 提供割合（排出率）</span>
                            <button onclick="openGachaRatesModal('${dayId}')" class="text-[11px] bg-heian-purple hover:bg-heian-purple/80 text-yellow-200 border border-heian-gold/40 px-2.5 py-1 rounded font-bold transition"><i class="fa-solid fa-list-check mr-1"></i> 排出対象・個別確率一覧</button>
                        </div>
                        <div class="grid grid-cols-4 gap-2 text-center font-bold">
                            ${rates.map(r=>`<div class="${r[4]} border ${r[3]} p-2 rounded"><div class="text-[10px] ${r[2]}">${r[0]}</div><div class="text-sm text-amber-300 font-mono mt-0.5">${r[1]}</div></div>`).join('')}
                        </div>
                    </div>
                    <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-3xl mx-auto mb-6">
                        ${featured.map(u=>`<div class="gacha-featured-card ${featCls(u.rarity)}">
                            <span class="text-[10px] ${badgeCls(u.rarity)} font-bold px-2 py-0.5 rounded-full shadow">${u.rarity==='UR'?'最強 UR':u.rarity}</span>
                            <div class="w-10 h-10 mx-auto mt-1.5 rounded-full bg-gradient-to-br from-purple-500/40 to-amber-400/30 border border-amber-400/70 flex items-center justify-center text-amber-200 text-lg"><i class="fa-solid ${u.icon}"></i></div>
                            <div class="font-mincho font-bold text-amber-300 text-sm mt-1">${u.name}</div>
                            <div class="text-[10px] text-gray-300 leading-snug">${short(u.skill.effect)}</div>
                        </div>`).join('')}
                    </div>
                    <div class="text-sm text-yellow-200 mb-3">所持：<span class="font-mono font-bold">${pts.toLocaleString()}</span> ${b.pointName}<br><span class="text-xs text-gray-300">次の1回まで <span class="font-mono">${Math.max(0,1000-pts).toLocaleString()}</span> / 次の10連まで <span class="font-mono">${Math.max(0,10000-pts).toLocaleString()}</span></span></div>
                    <div class="flex flex-wrap justify-center gap-2">
                        <button onclick="performWeekdayGacha('${dayId}', 1)" class="gacha-summon-btn gold-button px-8 py-3 rounded-xl text-sm"><i class="fa-solid fa-ticket mr-1"></i>1回引く（${b.pointName}1000）</button>
                        <button onclick="performWeekdayGacha('${dayId}', 10)" class="gacha-summon-btn gacha-summon-btn-10 vermilion-gradient text-white font-bold px-8 py-3 rounded-xl text-sm shadow-xl hover:brightness-110 flex items-center gap-2 border border-red-400"><i class="fa-solid fa-arrows-spin"></i>10連召喚 <span class="text-[10px] opacity-90">(${b.pointName}10000)</span></button>
                    </div>
                    <div id="weekdayGachaResult" class="mt-3 text-sm text-yellow-200"></div>
                </div>
            </div>`);
        }

        function performWeekdayGacha(dayId, count=1){
            const b=WEEKDAY_GACHA_BANNERS[dayId]; if(!b) return;
            if(!state.weekdayPoints) state.weekdayPoints={};
            const drawCount = count === 10 ? 10 : 1;
            const need = drawCount * 1000;
            if((state.weekdayPoints[dayId]||0)<need){showCustomAlert(`${b.pointName}不足`,`ステージをクリアして${b.pointName}を集めてください。`);return;}
            state.weekdayPoints[dayId]-=need;
            const pool=b.units||[];
            const results=[];
            for(let i=0;i<drawCount;i++){
                const rand=Math.random();
                let r=rand<.02?'UR':rand<.17?'SSR':rand<.47?'SR':'R';
                const same=pool.filter(u=>u.rarity===r);
                const pickPool=same.length?same:pool;
                const u=pickPool[Math.floor(Math.random()*pickPool.length)];
                results.push(u);
                grantOwnedUnit(u.id);
            }
            if (!state.gachaCounts) state.gachaCounts = {};
            state.gachaCounts[dayId] = (state.gachaCounts[dayId] || 0) + drawCount;
            saveState(); renderHeader(); renderWeekdayGachaPanel(dayId);
            checkAchievements();
            launchGachaSummon(drawCount, results);
        }

        function applyWeekdayGachaTabVisibility() {
            const todayKey = getTodayWeekdayKey();
            document.querySelectorAll('.gacha-subtab').forEach(function(bt){
                const t = bt.dataset.gachaTab;
                if (t && WEEKDAY_GACHA_BANNERS[t]) bt.style.display = (t === todayKey) ? '' : 'none';
            });
        }
        function showGachaSubtab(tab) {
            applyWeekdayGachaTabVisibility();
            const base=document.getElementById('gachaBaseArea'), review=document.getElementById('gachaReviewArea');
            if(base) base.classList.toggle('hidden', tab !== 'base');
            if(review) review.classList.toggle('hidden', tab !== 'review');
            document.querySelectorAll('.gacha-subtab').forEach(b=>b.classList.toggle('active', b.dataset.gachaTab === tab));
            if(tab==='review') renderReviewGacha();
            if(WEEKDAY_GACHA_BANNERS[tab]) {
                applyWeekdayGachaTabVisibility();
                const ng=document.getElementById('newGachaPanels'); if(!ng) return;
                if(tab !== getTodayWeekdayKey()){
                    const todayK = getTodayWeekdayKey();
                    ng.classList.remove('hidden');
                    __PERF.setHTML(ng, `<div class="bg-black/50 border-2 border-heian-gold/40 rounded-2xl p-8 text-center"><div class="text-4xl mb-3"><i class="fa-solid fa-moon text-pink-300"></i></div><h3 class="font-mincho text-xl font-bold text-pink-200 mb-2">今日はこの曜日ガチャの開催日ではありません</h3><p class="text-xs text-gray-300">曜日ガチャは毎週月曜〜金曜の開催です（本日：${todayK ? getTodayWeekdayLabel()+' 開催中' : 'お休み'}）。</p></div>`);
                    document.querySelectorAll('.gacha-subtab').forEach(b=>b.classList.toggle('active', b.dataset.gachaTab === 'base'));
                    return;
                }
                ng.classList.remove('hidden');
                renderWeekdayGachaPanel(tab);
                return;
            }
            const ng=document.getElementById('newGachaPanels');
            if(!ng) return;
            if(tab==='base' || tab==='review'){
                ng.classList.add('hidden');
                __PERF.setHTML(ng, "");
            } else {
                ng.classList.remove('hidden');
                const b=NEW_GACHA_BANNERS[tab];
                if(b && !isNewGachaUnlocked(tab)){ __PERF.setHTML(ng, ""); showCustomAlert('ガチャ未解放','指定されたダンジョンを完全攻略すると解放されます。'); }
                else renderNewGachaPanels(tab); // ⑥ 選択中のガチャだけを1枚表示（重複表示を解消）
            }
        }
        function renderReviewGacha(){
            const e=document.getElementById('reviewPointDisplay');
            if(e)e.textContent=(state.reviewPoints||0).toLocaleString();
            const pityEl=document.getElementById('reviewGachaPityRemaining');
            if(pityEl){
                const pityCount=(typeof state.reviewGachaPityCount === 'number' && state.reviewGachaPityCount >= 0) ? state.reviewGachaPityCount : 0;
                const remain=Math.max(1, 100 - pityCount);
                pityEl.textContent=`天井まで残り：${remain}回`;
            }
        }
        function performReviewGacha(){
            if((state.reviewPoints||0)<30){showCustomAlert('学習の雫不足','復習モードで正解して学習の雫を集めてください。');return;}
            // 天井カウンタは種別ごとに永続化（セーブ/ロードで消えない）
            state.reviewGachaPityCount = (typeof state.reviewGachaPityCount === 'number' && state.reviewGachaPityCount >= 0) ? state.reviewGachaPityCount : 0;
            const guaranteedKaguya = state.reviewGachaPityCount >= 99;
            const gotKaguya = guaranteedKaguya || Math.random()<0.005;
            state.reviewPoints-=30;
            state.kaguyaCount = (state.kaguyaCount || 0) + (gotKaguya ? 1 : 0);
            let resultMsg;
            if(gotKaguya){
                grantOwnedUnit('kaguya_001');
                if(!state.deck.includes('kaguya_001') && state.deck.length<getMaxDeckSize()) state.deck.push('kaguya_001');
                state.reviewGachaPityCount = 0;
                resultMsg = guaranteedKaguya ? '🌙 天井発動！ かぐや姫（神）を召喚！' : '🌙 かぐや姫（神）を召喚！';
            } else {
                state.reviewGachaPityCount += 1;
                state.gems=(state.gems||0)+1000;
                resultMsg = '💎 はずれ：宝玉1000個を獲得！';
            }
            if (!state.gachaCounts) state.gachaCounts = {};
            state.gachaCounts.review = (state.gachaCounts.review || 0) + 1;
            saveState(); renderHeader(); renderReviewGacha();
            checkAchievements();
            launchKaguyaSummon(gotKaguya, guaranteedKaguya, resultMsg);
        }

        // ── ④ かぐや姫ガチャ専用演出「月夜の召喚」（確率・報酬ロジックは不変） ──
        function launchKaguyaSummon(gotKaguya, guaranteed, resultMsg) {
            document.querySelectorAll('.gacha-overlay, .kaguya-overlay').forEach(el => el.remove());
            const root = document.createElement('div');
            root.className = 'kaguya-overlay';
            __PERF.setHTML(root, `
                <div class="kaguya-ray"></div>
                ${Array.from({length: 3}, (_, i) => `<div class="kaguya-bamboo" style="left:${10 + i * 26}%;animation-delay:${i * 0.35}s"></div>`).join('')}
                ${Array.from({length: 30}, () => `<div class="kaguya-spark" style="left:${(Math.random() * 96 + 2).toFixed(1)}%;top:${(Math.random() * 92 + 4).toFixed(1)}%;animation-delay:${(Math.random() * 2).toFixed(2)}s"></div>`).join('')}
                <div class="kaguya-moon"></div>
                ${Array.from({length: 14}, () => `<div class="kaguya-dango" style="left:${(Math.random() * 84 + 8).toFixed(1)}%;top:${(42 + Math.random() * 28).toFixed(1)}%;width:${(10 + Math.random() * 10).toFixed(0)}px;height:${(10 + Math.random() * 10).toFixed(0)}px;animation-delay:${(Math.random() * 0.9).toFixed(2)}s"></div>`).join('')}
                <div class="kaguya-title">${gotKaguya ? (guaranteed ? '天 井 発 動' : 'か ぐ や 姫 出 現') : '月 夜 の 扉'}</div>
                <div class="kaguya-sub">${gotKaguya ? '月より降り立つ、天つ乙女の気配……' : '今夜は月が美しい。もう一度、試みて……'}</div>
            `);
            document.body.appendChild(root);
            setTimeout(() => {
                root.remove();
                const el = document.getElementById('reviewGachaResult');
                if (el) el.textContent = resultMsg;
                if (gotKaguya) { try { AudioFX.playCrit(); } catch (e) {} }
            }, 2200);
        }

        function performGacha(count, bannerId = 'base') {
            const banner = bannerId === 'base' ? { id: 'base', title: '平安文人 招集', cost: 1000, units: GACHA_CHARACTERS } : NEW_GACHA_BANNERS[bannerId];
            if (!banner || (bannerId !== 'base' && !isNewGachaUnlocked(bannerId))) {
                showCustomAlert('ガチャ未解放', '指定されたダンジョンを完全攻略すると解放されます。');
                return;
            }
            const cost = count * banner.cost;
            if (state.coins < cost) {
                showCustomAlert("銭不足", `召喚に必要な銭（${cost.toLocaleString()}文）が足りません。`);
                return;
            }

            state.coins -= cost;
            if (!state.gachaCounts) state.gachaCounts = {};
            state.gachaCounts[bannerId] = (state.gachaCounts[bannerId] || 0) + count;
            const results = [];

            for (let i = 0; i < count; i++) {
                const rand = Math.random();
                let rarity = 'R';
                if (rand < 0.002) rarity = 'UR';
                else if (rand < 0.102) rarity = 'SSR';
                else if (rand < 0.302) rarity = 'SR';

                const pool = banner.units.filter(c => c.rarity === rarity);
                const selected = pool.length ? pool[Math.floor(Math.random() * pool.length)] : banner.units[Math.floor(Math.random() * banner.units.length)];

                grantOwnedUnit(selected.id);
                results.push(selected);
            }

            saveState();
            renderHeader();
            checkAchievements();

            // 演出（召喚の儀）を再生してから結果モーダルを表示
            launchGachaSummon(count, results);
        }

