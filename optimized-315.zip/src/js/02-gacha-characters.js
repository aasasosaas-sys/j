        // =========================================================================
        // FULL 27 GACHA CHARACTERS DATABASE
        // =========================================================================
        const GACHA_CHARACTERS = [
            // Category 1: 『大鏡』政治・権力争い
            { id: "ok_001", name: "菅原道真", gender: "男性", rarity: "SSR", icon: "fa-graduation-cap", description: "平安初期の右大臣・超優秀な学者。", skill: { name: "至高の学問", effect: "正解時の与ダメージ倍率上昇" }, special_move: { name: "東風吹かば（天満天神）", effect: "敵全体に特大の雷撃ダメージを与える" }, gaugePerCorrect: 25, gaugeNeedsVotes: 4, synergies: [{ target_id: "ok_002", title: "政敵ライバル", effect: "攻撃力20%アップ" }] },
            { id: "ok_002", name: "藤原時平", gender: "男性", rarity: "SR", icon: "fa-user-secret", description: "平安初期の左大臣。道真の政治的ライバル。", skill: { name: "讒言の謀略", effect: "敵全体の攻撃力を15%低下" }, special_move: { name: "左遷の罠", effect: "敵単体の行動を一定時間停止" }, gaugePerCorrect: 18, gaugeNeedsVotes: 5, synergies: [{ target_id: "ok_001", title: "政敵ライバル", effect: "クリティカル率アップ" }] },
            { id: "ok_003", name: "藤原兼家", gender: "男性", rarity: "SSR", icon: "fa-building-columns", description: "摂政・関白。道隆・道長・道兼の父親。", skill: { name: "摂関の礎", effect: "味方全体の防御力を固定上昇" }, special_move: { name: "権力掌握の謀略", effect: "味方全体の全ステータスを大アップ" }, gaugePerCorrect: 22, gaugeNeedsVotes: 4, synergies: [{ target_ids: ["ok_004", "ok_005"], title: "藤原氏一族（親子）", effect: "初期必殺ゲージ30%増加" }, { target_id: "so_010", title: "夫婦（嫉妬と葛藤）", effect: "与ダメージ上昇" }] },
            { id: "ok_004", name: "藤原道隆", gender: "男性", rarity: "SR", icon: "fa-wine-glass", description: "関白。兼家の長男で定子・伊周の父。", skill: { name: "豪飲の栄華", effect: "戦闘中 味方全体の攻撃力を30%増加" }, special_move: { name: "中関白家の酒宴", effect: "味方全体の攻撃速度を大きく上げる" }, gaugePerCorrect: 22, gaugeNeedsVotes: 4, synergies: [{ target_id: "ok_006", title: "父子", effect: "会心ダメージアップ" }, { target_id: "se_002", title: "父娘", effect: "必殺技必要正解数低下" }] },
            { id: "ok_005", name: "藤原道長", gender: "男性", rarity: "UR", icon: "fa-crown", description: "摂政・太政大臣。『大鏡』の主人公格。", skill: { name: "栄華の極み", effect: "正解ごとに全ステータスが2%累積上昇" }, special_move: { name: "この世をば我が世とぞ思う（望月の歌）", effect: "全敵に超絶ダメージ＋味方HP全回復" }, gaugePerCorrect: 35, gaugeNeedsVotes: 2, synergies: [{ target_id: "ok_006", title: "叔父・甥（権力抗争）", effect: "攻撃力25%アップ" }, { target_id: "se_003", title: "父娘", effect: "HP上限アップ" }] },
            { id: "ok_006", name: "藤原伊周", gender: "男性", rarity: "R", icon: "fa-person-rifle", description: "内大臣。道隆の息子で定子の兄。", skill: { name: "長徳の焦燥", effect: "クリティカル率を上昇" }, special_move: { name: "長徳の変（不意の射撃）", effect: "敵単体に強力な物理ダメージ" }, gaugePerCorrect: 23, gaugeNeedsVotes: 4, synergies: [{ target_id: "ok_005", title: "ライバル（叔父・甥）", effect: "攻撃力アップ" }] },
            { id: "ok_007", name: "一条天皇", gender: "男性", rarity: "SSR", icon: "fa-landmark", description: "第66代天皇。定子と彰子の2人を后に持った。", skill: { name: "文芸の寵愛", effect: "女性キャラクター全体の能力を30%増加" }, special_move: { name: "二后並立（至高のサロン）", effect: "全味方の必殺チャージ速度短縮" }, gaugePerCorrect: 24, gaugeNeedsVotes: 4, synergies: [{ target_ids: ["se_002", "se_003"], title: "両后の並立（夫婦）", effect: "全員の回復量と防御力特大アップ" }] },
            { id: "ok_008", name: "花山院", gender: "男性", rarity: "SR", icon: "fa-torii-gate", description: "第65代天皇。出家させられて譲位した。", skill: { name: "寛和の出家", effect: "HPが減るほど味方防御上昇" }, special_move: { name: "月夜の陰謀落飾", effect: "敵の攻撃を引きつけるバリア" }, gaugePerCorrect: 17, gaugeNeedsVotes: 5, synergies: [] },

            // Category 2: 『源氏物語』
            { id: "ge_001", name: "桐壺帝", gender: "男性", rarity: "SR", icon: "fa-feather", description: "光源氏の父親である天皇。", skill: { name: "無限の偏愛", effect: "女性キャラのステータス70%増" }, special_move: { name: "桐壺への追慕", effect: "味方女性キャラのHPを大幅回復" }, gaugePerCorrect: 17, gaugeNeedsVotes: 5, synergies: [{ target_id: "ge_006", title: "最愛の夫婦", effect: "回復効果アップ" }, { target_id: "ge_008", title: "面影の夫婦", effect: "防御力アップ" }] },
            { id: "ge_002", name: "光源氏", gender: "男性", rarity: "UR", icon: "fa-wand-magic-sparkles", description: "物語の主人公。容姿・才能ともに完璧な貴公子。", skill: { name: "光の貴公子", effect: "味方全体の攻撃速度と回避率を増加" }, special_move: { name: "須磨の秋思（絶世の麗人）", effect: "全敵ダメージ＋『魅了』行動不能" }, gaugePerCorrect: 32, gaugeNeedsVotes: 3, synergies: [{ target_id: "ge_008", title: "秘密の恋", effect: "双方の攻撃力・会心率大幅増" }, { target_id: "ge_009", title: "夫婦のすれ違い", effect: "攻撃力アップ" }] },
            { id: "ge_003", name: "朱雀帝", gender: "男性", rarity: "SR", icon: "fa-sun", description: "桐壺帝の第一皇子。光源氏の異母兄。", skill: { name: "兄帝の思いやり", effect: "味方の状態異常耐性アップ" }, special_move: { name: "朱雀院の譲位", effect: "最もHPが低い味方を全回復" }, gaugePerCorrect: 18, gaugeNeedsVotes: 5, synergies: [{ target_id: "ge_007", title: "母子", effect: "防御力アップ" }] },
            { id: "ge_004", name: "冷泉帝", gender: "男性", rarity: "SSR", icon: "fa-ankh", description: "光源氏と藤壺の宮の秘密の皇子。", skill: { name: "出生の宿世", effect: "自身と光源氏の必殺加速" }, special_move: { name: "密約の即位", effect: "敵単体に特大光属性ダメージ" }, gaugePerCorrect: 26, gaugeNeedsVotes: 3, synergies: [{ target_id: "ge_002", title: "実の父子（隠匿）", effect: "全攻撃に特効付与" }] },
            { id: "ge_005", name: "夕霧", gender: "男性", rarity: "SR", icon: "fa-shield-halved", description: "光源氏と葵の上の間に生まれた長男。", skill: { name: "真面目なる誠実", effect: "味方全体に60%の確率でデバフ・状態異常を無効化" }, special_move: { name: "大学寮の勉学", effect: "味方全体の防御力を固定大幅増" }, gaugePerCorrect: 17, gaugeNeedsVotes: 5, synergies: [{ target_id: "ge_002", title: "父子", effect: "スキル回転率アップ" }, { target_id: "ge_009", title: "母子", effect: "HP上限増加" }] },
            { id: "ge_006", name: "桐壺更衣", gender: "女性", rarity: "R", icon: "fa-heart-crack", description: "光源氏の生母。病死した儚い妃。", skill: { name: "儚き運命", effect: "HPが30%以下になった時、一度だけHPを80%まで回復" }, special_move: { name: "いとあはれなる面影", effect: "味方単体のHPを回復" }, synergies: [{ target_id: "ge_007", title: "天敵（後宮の嫉妬）", effect: "被ダメージ軽減バフ獲得" }] },
            { id: "ge_007", name: "弘徽殿女御", gender: "女性", rarity: "SR", icon: "fa-mask", description: "右大臣の娘。朱雀帝の母。", skill: { name: "強権なる激怒", effect: "敵全体に持続ダメージ" }, special_move: { name: "後宮の圧迫", effect: "敵全体の攻撃力とすばやさ低下" }, synergies: [{ target_id: "ge_006", title: "天敵（後宮の嫉妬）", effect: "攻撃力アップ" }] },
            { id: "ge_008", name: "藤壺の宮", gender: "女性", rarity: "SSR", icon: "fa-spa", description: "桐壺帝の中宮。亡き更衣に瓜二つ。", skill: { name: "面影の罪", effect: "味方の回復効果を1.5倍" }, special_move: { name: "出家の決意", effect: "味方全体にダメージ無効バリア" }, synergies: [{ target_id: "ge_004", title: "母子", effect: "回復力・防御力アップ" }] },
            { id: "ge_009", name: "葵の上", gender: "女性", rarity: "SR", icon: "fa-gem", description: "光源氏の最初の正妻。左大臣の娘。", skill: { name: "気高き誇り", effect: "単体ダメージを大幅軽減" }, special_move: { name: "物の怪の憑依", effect: "敵単体に呪い持続ダメージ" }, synergies: [{ target_id: "ge_005", title: "母子", effect: "防御力アップ" }] },

            // Category 3: 日記・随筆・宮廷文化人
            { id: "se_001", name: "藤原公任", gender: "男性", rarity: "SSR", icon: "fa-music", description: "最高峰の教養人。『三舟の才』。", skill: { name: "三舟の才", effect: "正解時に獲得する必殺ゲージ増" }, special_move: { name: "滝の音は絶えても", effect: "味方デバフ解除＋攻撃バフ" }, gaugePerCorrect: 25, gaugeNeedsVotes: 4, synergies: [{ target_ids: ["se_002", "se_004"], title: "定子サロンの風流", effect: "必殺技威力倍増" }, { target_ids: ["se_003", "se_005"], title: "彰子サロンの風流", effect: "正解ダメージアップ" }] },
            { id: "se_002", name: "藤原定子", gender: "女性", rarity: "SSR", icon: "fa-fan", description: "一条天皇の皇后。『枕草子』の主君。", skill: { name: "華やぎのサロン", effect: "味方女性のスキルチャージ短縮" }, special_move: { name: "香炉峰の雪", effect: "味方全体の攻撃力大幅アップ" }, synergies: [{ target_id: "se_004", title: "主従関係", effect: "全ステータス20%アップ" }] },
            { id: "se_003", name: "藤原彰子", gender: "女性", rarity: "SSR", icon: "fa-layer-group", description: "一条天皇の中宮。『紫式部日記』の主君。", skill: { name: "重厚なるサロン", effect: "味方全体の最大HPと防御力底上げ" }, special_move: { name: "若宮のご誕生", effect: "味方HP全回復＋強固なバリア" }, gaugePerCorrect: 18, gaugeNeedsVotes: 5, synergies: [{ target_id: "se_005", title: "主従関係", effect: "全ステータス20%アップ" }] },
            { id: "se_004", name: "清少納言", gender: "女性", rarity: "SR", icon: "fa-pen-nib", description: "『枕草子』著者。定子に仕えた女房。", skill: { name: "「をかし」の感性", effect: "攻撃が敵防御力を無視" }, special_move: { name: "春はあけぼの", effect: "敵全体に風攻撃＋すばやさ低下" }, gaugePerCorrect: 18, gaugeNeedsVotes: 5, synergies: [{ target_id: "se_005", title: "ライバル作家", effect: "クリティカル率アップ" }] },
            { id: "se_005", name: "紫式部", gender: "女性", rarity: "SR", icon: "fa-book-open", description: "『源氏物語』『紫式部日記』著者。", skill: { name: "「あはれ」の観察", effect: "弱点属性ダメージ増加" }, special_move: { name: "源氏物語執筆", effect: "敵攻撃低下＋味方与ダメ上昇" }, synergies: [{ target_id: "se_004", title: "ライバル作家", effect: "攻撃力アップ" }] },

            // Category 4: 説話・軍記・評論・日記
            { id: "so_001", name: "和尚／聖", gender: "男性", rarity: "R", icon: "fa-hands-praying", description: "説話に登場する高僧。", skill: { name: "説話のオチ役", effect: "被撃時確率で敵を混乱" }, special_move: { name: "かいもちひの誘惑", effect: "自身を回復（時折失敗）" }, gaugePerCorrect: 12, gaugeNeedsVotes: 8, synergies: [{ target_id: "so_002", title: "師弟（知恵比べ）", effect: "スキル再使用時間短縮" }] },
            { id: "so_002", name: "稚児", gender: "男性", rarity: "R", icon: "fa-child", description: "寺院の少年。『ぼたもち』の説話。", skill: { name: "寝たふり", effect: "15%の確率で味方全員の受けるダメージを0にする" }, special_move: { name: "いざ、おどろかされん", effect: "敵単体に不意打ち物理ダメージ" }, gaugePerCorrect: 13, gaugeNeedsVotes: 7, synergies: [{ target_id: "so_001", title: "師弟（知恵比べ）", effect: "回避率上昇" }] },
            { id: "so_003", name: "阿倍晴明", gender: "男性", rarity: "SSR", icon: "fa-hat-wizard", description: "伝説の陰陽師。式神を操る。", skill: { name: "陰陽の道", effect: "本人は常時デバフ・状態異常を無効化" }, special_move: { name: "急々如律令（式神召喚）", effect: "式神召喚で敵全体連続属性攻撃" }, gaugePerCorrect: 26, gaugeNeedsVotes: 3, synergies: [] },
            { id: "so_004", name: "藤原保昌", gender: "男性", rarity: "SR", icon: "fa-user-ninja", description: "『今昔物語集』の風流武者。", skill: { name: "隙なき歩み", effect: "敵の攻撃回避率上昇" }, special_move: { name: "月下の笛の音", effect: "敵全体の攻撃判定をミスに" }, gaugePerCorrect: 18, gaugeNeedsVotes: 5, synergies: [] },
            { id: "so_005", name: "平清盛", gender: "男性", rarity: "SSR", icon: "fa-fire", description: "『平家物語』平家の絶対権力者。", skill: { name: "おごれる者", effect: "序盤30秒間の攻撃爆発上昇" }, special_move: { name: "あつちの怪異（熱病の猛火）", effect: "敵全火属性超絶ダメ＋自傷" }, gaugePerCorrect: 24, gaugeNeedsVotes: 4, synergies: [{ target_id: "so_008", title: "父娘", effect: "攻撃力アップ" }] },
            { id: "so_006", name: "藤原定家", gender: "男性", rarity: "SR", icon: "fa-pen-fancier", description: "『新古今和歌集』の選者。", skill: { name: "美の選者", effect: "正解時必殺ゲージ追加獲得" }, special_move: { name: "毎月抄の指南", effect: "味方のスキル威力を恒久アップ" }, gaugePerCorrect: 17, gaugeNeedsVotes: 5, synergies: [] },
            { id: "so_007", name: "在原業平", gender: "男性", rarity: "SSR", icon: "fa-heart", description: "『伊勢物語』の昔男。絶世の伊達男。", skill: { name: "昔男の情熱", effect: "パーティの総攻撃力をバフ（女性キャラ1人につき攻撃力+50%）。女性キャラのスキル・シナジーは無効化しない" }, special_move: { name: "ちはやぶる神代も聞かず", effect: "単体に超大クリティカル攻撃" }, gaugePerCorrect: 25, gaugeNeedsVotes: 4, synergies: [{ target_id: "so_009", title: "六歌仙の共鳴", effect: "会心ダメージアップ" }] },
            { id: "so_008", name: "建礼門院", gender: "女性", rarity: "SR", icon: "fa-water", description: "平清盛の娘。『平家物語』ヒロイン。", skill: { name: "諸行無常の祈り", effect: "味方倒れた時HP1踏みとどまり" }, special_move: { name: "大原御幸の落飾", effect: "味方HP回復＋リジェネ付与" }, gaugePerCorrect: 17, gaugeNeedsVotes: 5, synergies: [{ target_id: "so_005", title: "父娘", effect: "被ダメージ軽減" }] },
            { id: "so_009", name: "小野小町", gender: "女性", rarity: "SR", icon: "fa-seedling", description: "絶世の美女歌人。六歌仙の一人。", skill: { name: "移ろふ色", effect: "敵全体の防御力を少しずつ低下" }, special_move: { name: "花の色は移りにけりな", effect: "敵全体を確率で混乱デバフ" }, synergies: [{ target_id: "so_007", title: "六歌仙の共鳴", effect: "すばやさアップ" }] },
            { id: "so_010", name: "右大将道綱母", gender: "女性", rarity: "SR", icon: "fa-scroll", description: "『蜻蛉日記』の著者。兼家の妻。", skill: { name: "嘆きの蜻蛉", effect: "男性の味方のHPを1.3倍にする" }, special_move: { name: "嘆きつつひとりぬる夜の", effect: "敵単体に強力な持続ダメージ" }, synergies: [{ target_id: "ok_003", title: "夫婦（嫉妬と葛藤）", effect: "与ダメージ大幅アップ" }] }
        ];

        // 追加ガチャ（既存ガチャの32体構成・同じレア度判定/シナジー形式）
        const NEW_GACHA_BANNERS = {
            d10: { id: 'd10', title: '古典作者・王朝絵巻', unlockDungeon: 10, cost: 5000, description: 'ダンジョン10完全攻略で解放。古典の名著を生んだ作者と宮廷の人物。', units: [] },
            d20: { id: 'd20', title: '軍記・説話の英傑', unlockDungeon: 20, cost: 10000, description: 'ダンジョン20完全攻略で解放。軍記・説話・歌謡を彩る強者たち。', units: [] }
        };
        const NEW_GACHA_SPEC = {
            d10: [
                ['紀貫之','男性','UR','fa-feather-pointed'],['在原業平（歌仙）','男性','SSR','fa-heart'],['伊勢','女性','SSR','fa-scroll'],['大伴家持','男性','SSR','fa-pen-nib'],['和泉式部','女性','SSR','fa-heart'],['赤染衛門','女性','SR','fa-pen'],['伊勢大輔','女性','SR','fa-fan'],['相模','女性','SR','fa-seedling'],['菅原孝標女','女性','SR','fa-book-open'],['道綱母','女性','SR','fa-scroll'],['清原元輔','男性','SR','fa-feather'],['大江千里','男性','SR','fa-music'],['凡河内躬恒','男性','R','fa-feather-pointed'],['壬生忠岑','男性','R','fa-pen'],['坂上是則','男性','R','fa-mountain-sun'],['源重之','男性','R','fa-wind'],['藤原敏行','男性','R','fa-feather'],['文屋康秀','男性','R','fa-leaf'],['僧正遍昭','男性','R','fa-hands-praying'],['喜撰法師','男性','R','fa-scroll'],['大中臣頼基','男性','R','fa-pen-nib'],['源順','男性','R','fa-book'],['紀友則','男性','R','fa-feather'],['藤原興風','男性','R','fa-music'],['清原深養父','男性','R','fa-mountain'],['藤原道信','男性','R','fa-envelope'],['藤原実方','男性','SR','fa-horse'],['藤原公任（歌壇）','男性','SSR','fa-crown'],['紫式部（若紫）','女性','SSR','fa-book-open'],['清少納言（春暁）','女性','SSR','fa-pen-nib'],['大弐三位','女性','SR','fa-fan'],['藤原道長（望月）','男性','UR','fa-crown']
            ],
            d20: [
                ['源義経','男性','UR','fa-horse'],['平知盛','男性','UR','fa-shield-halved'],['源頼朝','男性','SSR','fa-landmark'],['北条政子','女性','SSR','fa-crown'],['巴御前','女性','SSR','fa-person-rifle'],['平敦盛','男性','SSR','fa-music'],['熊谷直実','男性','SR','fa-shield'],['那須与一','男性','SR','fa-bullseye'],['木曾義仲','男性','SR','fa-horse'],['静御前','女性','SR','fa-music'],['建礼門院（大原）','女性','SR','fa-water'],['後鳥羽院','男性','SSR','fa-landmark'],['鴨長明','男性','SR','fa-house'],['兼好法師','男性','SR','fa-scroll'],['西行','男性','SSR','fa-person-walking'],['一遍','男性','R','fa-hands-praying'],['安倍泰親','男性','R','fa-hat-wizard'],['源博雅','男性','SR','fa-music'],['渡辺綱','男性','SSR','fa-dragon'],['安倍晴明','男性','SSR','fa-hat-wizard'],['小野小町（歌仙）','女性','SSR','fa-seedling'],['在原行平','男性','R','fa-ship'],['紀長谷雄','男性','R','fa-feather'],['宇治の大君','女性','R','fa-fan'],['浮舟','女性','SR','fa-water'],['薫','男性','SR','fa-wind'],['匂宮','男性','SR','fa-sparkles'],['夕霧（源氏）','男性','SR','fa-shield-halved'],['藤原定家（新古今）','男性','SSR','fa-pen-fancier'],['西行法師','男性','SR','fa-person-walking'],['源俊頼','男性','R','fa-book'],['藤原俊成','男性','SSR','fa-feather-pointed']
            ]
        };

        // ダンジョン10・20解放キャラの戦略型スキル（既存戦闘パターンに合わせた条件付き・リスク報酬型）
        const NEW_SKILL_PATTERNS = [
            ["連歌の起点", "正解が3問続くと、次の8秒間は与ダメージ35%アップ", { trigger: 'combo3', fx: { buffDmgUp: [35, 8] } }],
            ["歌枕の読み替え", "敵の攻撃を受けた直後、次の攻撃を1回だけ無効化", { trigger: 'afterHit', fx: { miss: 1 } }],
            ["才女の機知", "HPが50%以下の時、正解時の必殺チャージ速度35%アップ", { trigger: 'lowHpCorrect', fx: { buffSpecGain: [35, 6] } }],
            ["武者の構え", "正解時、敵の攻撃力を20%低下させる（5秒）", { trigger: 'correct', fx: { enemyAtkDown: [20, 5] } }],
            ["因果の一矢", "必殺ゲージが80%以上の時、次の正解の与ダメージ25%アップ", { trigger: 'highGaugeCorrect', fx: { buffDmgUp: [25, 6] } }],
            ["無常の見切り", "HPが40%以下になった時、敵の攻撃を1回だけ無効化", { trigger: 'lowHpHit', fx: { miss: 1 } }],
            ["詞華の連携", "同じレア度の味方がいる時、正解時の必殺チャージ20%アップ", { trigger: 'sameRarityCorrect', fx: { buffSpecGain: [20, 5] } }],
            ["奥義の布石", "正解時、次の必殺技の威力を25%高める（5秒）", { trigger: 'correct', fx: { buffDmgUp: [25, 5] } }]
        ];

        // ダンジョン10・20解放ガチャ専用の必殺技定義［名前, 効果文］（既存の必殺技効果キーに沿った複合効果）
        const NEW_SPECIAL_DEFS = {
            d10: [
                ["花ぞ昔の香（ふるさとの花）", "敵全体に超絶の風属性ダメージ＋味方全体の与ダメージアップ"],
                ["千早振る神代も聞かず（竜田川）", "敵全体に特大ダメージ＋『魅了』で行動不能にする"],
                ["恋は松を時雨", "敵単体に特大ダメージ＋敵の攻撃力を大幅低下"],
                ["鶯の谷渡り", "敵全体に特大ダメージ＋味方の必殺チャージを加速"],
                ["黒髪のみだれ心", "敵全体を高確率で混乱させ行動不能に＋味方の与ダメージアップ"],
                ["世の中は憂きものか", "味方全体の攻撃力と防御力を大アップ"],
                ["いにしへの奈良の八重桜", "敵全体に大ダメージ＋味方全体のHPを12%回復"],
                ["逢ふことの絶え間なく", "敵単体に大ダメージ＋短時間行動不能にする"],
                ["物語に耽る心", "味方全体のHPを18%回復＋継続回復を付与"],
                ["蜻蛉日記の恨み", "敵全体の攻撃力を大低下させる"],
                ["父娘の歌才", "味方全体の必殺チャージを大加速"],
                ["白妙の衣", "敵単体に大ダメージ＋高確率で会心"],
                ["春たてば花の香", "敵全体に標準ダメージ＋味方のデバフを解除"],
                ["撰集の筆", "敵単体に標準ダメージ＋味方の攻撃速度アップ"],
                ["花の散り際", "敵全体に標準ダメージ"],
                ["陸奥の嵐", "敵単体に標準ダメージ＋短時間行動不能"],
                ["秋来ぬと目にはさやかに", "敵全体に標準ダメージ＋敵のすばやさ低下"],
                ["笑いの歌", "敵を混乱させて行動不能にする"],
                ["法華の祈り", "味方全体のHPを15%回復"],
                ["宇治山の隠遁", "味方全体にダメージ無効バリアを張る"],
                ["神祇の祝詞", "敵単体に標準ダメージ＋味方の防御力アップ"],
                ["歌枕の旅路", "敵全体に標準ダメージ"],
                ["春のうらら", "味方全体のHPを12%回復＋継続回復"],
                ["雅楽の調べ", "味方全体の攻撃速度をアップ"],
                ["空より花の降る", "敵全体に標準ダメージ＋味方の攻撃力アップ"],
                ["恋の焦がれ", "敵単体に標準ダメージ＋呪いの持続ダメージ"],
                ["朽ちもせぬその名", "敵全体に大ダメージ＋高確率で会心"],
                ["三舟の才・管弦", "味方全体の全ステータスを大アップ＋必殺チャージ加速"],
                ["若紫の巻・垣間見", "敵全体に特大ダメージ＋味方全体のHPを18%回復"],
                ["春はあけぼの・暁", "敵全体に特大ダメージ＋敵のすばやさを大低下"],
                ["母の筆のあと", "味方全体のHPを20%回復＋ダメージ無効バリア"],
                ["この世をば我が世（望月の満願）", "敵全体に超絶ダメージ＋味方HP30%回復＋バリア付与"]
            ],
            d20: [
                ["八艘飛び・壇ノ浦の逆撃", "敵全体に超絶ダメージ＋味方全体の攻撃力を大幅アップ"],
                ["見るべき程の事は見つ", "敵全体に超絶ダメージ＋味方全体にダメージ無効バリア"],
                ["東国の総攻め", "敵全体に特大ダメージ＋味方の攻撃速度アップ"],
                ["尼将軍の檄", "味方全体の全ステータスを大アップ＋HP12%回復"],
                ["大太刀の一閃", "敵単体に特大ダメージ＋高確率で会心"],
                ["青葉の笛（無常の調べ）", "敵全体に特大ダメージ＋高確率で混乱"],
                ["往生院の祈り", "味方全体のHPを22%回復＋バリア付与"],
                ["扇の的・屋島の一矢", "敵単体に大ダメージ＋必ず会心"],
                ["旭将軍の蹴散らし", "敵全体に大ダメージ"],
                ["白拍子の舞（吉野山）", "味方の攻撃速度を大アップ＋敵の攻撃力を低下"],
                ["大原寂光院の回向", "味方全体のHPを15%回復＋継続回復を付与"],
                ["承久の斜め（御製の念力）", "敵全体に特大ダメージ＋味方の必殺チャージ加速"],
                ["ゆく河の流れ", "敵全体に大ダメージ＋敵の攻撃力を低下"],
                ["徒然なるままに", "味方全体のデバフを解除＋攻撃力アップ"],
                ["願はくは花の下にて", "敵全体に特大ダメージ＋味方全体のHP22%回復"],
                ["南無阿弥陀仏の踊り", "味方全体のHPを15%回復"],
                ["星読みの暦", "敵全体の攻撃力を低下させる"],
                ["長秋卿の秘曲（流泉）", "味方の必殺チャージを大加速＋攻撃速度アップ"],
                ["羅生門の鬼腕斬り", "敵単体に特大ダメージ＋行動不能にする"],
                ["泰山府君祭", "敵全体に特大ダメージ＋呪いの持続ダメージ"],
                ["花の色は移りにけりな", "敵全体に特大ダメージ＋高確率で混乱"],
                ["立田の橋", "敵全体に標準ダメージ"],
                ["異界の博士", "敵単体に標準ダメージ＋呪いの持続ダメージ"],
                ["宇治の姫君の面影", "味方全体のHPを12%回復"],
                ["横川の僧都の助け", "味方全体のHPを18%回復＋継続回復を付与"],
                ["薫りの御方", "敵単体に大ダメージ＋高確率で会心"],
                ["匂ふ宮の恋", "敵全体を混乱させ行動不能に＋敵のすばやさ低下"],
                ["夕霧の雲居", "敵全体に大ダメージ＋味方の防御力アップ"],
                ["拾遺愚草・恋の三首", "敵全体に特大ダメージ＋味方の与ダメージアップ"],
                ["花の下にて春死なむ", "味方全体のHPを25%回復"],
                ["歌学の舟", "敵全体に標準ダメージ＋味方の必殺チャージ加速"],
                ["幽玄の心（千載集）", "敵全体に特大ダメージ＋会心発生＋短時間行動不能"]
            ]
        };

        function buildNewGachaUnits(bannerId, specs) {
            const prefix = bannerId === 'd10' ? 'n10_' : 'n20_';
            return specs.map((s, i) => {
                const id = prefix + String(i + 1).padStart(2, '0');
                const power = s[2] === 'UR' ? '超絶' : s[2] === 'SSR' ? '特大' : s[2] === 'SR' ? '大' : '標準';
                const supportText = s[2] === 'R' ? '低レア連携を支える' : '所属ガチャの文芸・戦闘特性を強化する';
                return {
                    id,
                    name: s[0],
                    gender: s[1],
                    rarity: s[2],
                    icon: s[3],
                    description: `${s[0]}。古典に名を残す${s[1]}の人物。`,
                    skill: (() => { const pat = NEW_SKILL_PATTERNS[i % NEW_SKILL_PATTERNS.length]; return { name: pat[0], effect: `${pat[1]}（${supportText}）`, trigger: pat[2].trigger, fx: pat[2].fx }; })(),
                    special_move: (NEW_SPECIAL_DEFS[bannerId] && NEW_SPECIAL_DEFS[bannerId][i])
                        ? { name: NEW_SPECIAL_DEFS[bannerId][i][0], effect: NEW_SPECIAL_DEFS[bannerId][i][1] }
                        : { name: `${s[0]}・必殺の一手`, effect: `敵に${power}ダメージを与え、味方の戦況を有利にする` },
                    gaugePerCorrect: s[2] === 'UR' ? 35 : s[2] === 'SSR' ? 26 : s[2] === 'SR' ? 20 : 16,
                    gaugeNeedsVotes: s[2] === 'UR' ? 3 : s[2] === 'SSR' ? 4 : s[2] === 'SR' ? 5 : 6,
                    synergies: []
                };
            });
        }

        function getNewBannerUnitsFlat() {
            return Object.values(NEW_GACHA_BANNERS).flatMap(b => b.units || []);
        }

        function getAllDefinedUnitsForLookup() {
            let weekday = [];
            try { weekday = getWeekdayUnitsFlat(); } catch (e) {}
            let extra = [];
            try { extra = [KAGUYA_UNIT, BUTSU_UNIT, AMATERASU_UNIT, ...BOSS_RUSH_GOD_UNITS_LIST]; } catch (e) {}
            return [...GACHA_CHARACTERS, ...getNewBannerUnitsFlat(), ...weekday, ...extra];
        }
        function resolveUnitRef(ref) {
            if (!ref) return null;
            const all = getAllDefinedUnitsForLookup();
            const direct = all.find(u => u.id === ref);
            if (direct) return direct.id;
            const byName = all.find(u => u.name === ref);
            return byName ? byName.id : null;
        }

        function appendSynergy(sourceRef, payload) {
            const sourceId = resolveUnitRef(sourceRef);
            if (!sourceId) return;
            const source = getAllDefinedUnitsForLookup().find(u => u.id === sourceId);
            if (!source) return;
            if (!source.synergies) source.synergies = [];
            const targetIds = payload.target_ids ? payload.target_ids.slice() : (payload.target_id ? [payload.target_id] : []);
            if (targetIds.length === 0) return;
            const exists = source.synergies.some(s => {
                const existingTargets = s.target_ids ? s.target_ids.slice() : (s.target_id ? [s.target_id] : []);
                return s.title === payload.title && JSON.stringify(existingTargets) === JSON.stringify(targetIds);
            });
            if (exists) return;
            source.synergies.push(payload.target_ids ? { target_ids: targetIds, title: payload.title, effect: payload.effect } : { target_id: targetIds[0], title: payload.title, effect: payload.effect });
        }

        function addPairSynergy(aRef, bRef, title, effectA, effectB = effectA, reverseTitle = title) {
            const aId = resolveUnitRef(aRef);
            const bId = resolveUnitRef(bRef);
            if (!aId || !bId) return;
            appendSynergy(aId, { target_id: bId, title, effect: effectA });
            appendSynergy(bId, { target_id: aId, title: reverseTitle, effect: effectB });
        }

        function addMultiSynergy(sourceRef, targetRefs, title, effect) {
            const sourceId = resolveUnitRef(sourceRef);
            const targetIds = targetRefs.map(resolveUnitRef).filter(Boolean);
            if (!sourceId || targetIds.length !== targetRefs.length) return;
            appendSynergy(sourceId, { target_ids: targetIds, title, effect });
        }

        Object.keys(NEW_GACHA_BANNERS).forEach(key => {
            NEW_GACHA_BANNERS[key].units = buildNewGachaUnits(key, NEW_GACHA_SPEC[key]);
        });

        // ダンジョン10・20の新ガチャ内シナジーを強化
        addPairSynergy('紀貫之', '大伴家持', '歌壇の双璧', '正解ダメージ35%アップ', '必殺技ダメージ25%アップ');
        addPairSynergy('和泉式部', '赤染衛門', '女房歌人の共鳴', '女性の必殺ゲージ加速', '女性の与ダメージ20%アップ');
        addPairSynergy('伊勢大輔', '相模', '宮廷女房の機知', 'SR以上の回避率アップ', '女性の会心率アップ');
        addPairSynergy('菅原孝標女', '紫式部（若紫）', '物語耽読の系譜', 'スキル回転率アップ', '弱点ダメージ30%アップ');
        addPairSynergy('清少納言（春暁）', '紫式部（若紫）', '新ガチャの才女競演', '会心率・弱点ダメージアップ', '与ダメージ20%アップ');
        addPairSynergy('藤原公任（歌壇）', '藤原道長（望月）', '歌壇と栄華の中枢', '全ステータス20%アップ', '初期必殺ゲージ25%増加');
        addPairSynergy('凡河内躬恒', '紀友則', '古今集撰者の連携', 'R/SRの攻撃力25%アップ', 'R/SRの被ダメージ15%軽減');
        addPairSynergy('壬生忠岑', '坂上是則', '技巧派歌人の応酬', 'Rキャラの会心率20%アップ', '正解時ゲージ獲得量アップ');
        addPairSynergy('僧正遍昭', '喜撰法師', '六歌仙の法師組', 'Rキャラの防御力20%アップ', '回復効果アップ');
        addPairSynergy('源重之', '藤原敏行', '古今の余情', 'R/SRの速度15%アップ', '継続ダメージ強化');
        addPairSynergy('文屋康秀', '藤原興風', '滑稽と管弦', 'Rキャラのスキル威力アップ', '敵攻撃力低下');
        addPairSynergy('藤原道信', '大中臣頼基', '若き恋歌の交歓', 'RキャラのHP20%アップ', '単体火力アップ');
        addPairSynergy('藤原実方', '清少納言（春暁）', '宮廷機知の応酬', 'SRキャラの与ダメージ25%アップ', 'デバフ命中率アップ');
        addPairSynergy('大弐三位', '紫式部（若紫）', '母娘の筆脈', '回復量と状態異常耐性アップ', 'SSR以上の防御力アップ');
        addPairSynergy('道綱母', '藤原道長（望月）', '摂関家の余波', '男性味方HP上昇量強化', '継戦能力アップ');
        addMultiSynergy('在原業平（歌仙）', ['紀貫之', '凡河内躬恒'], '古今集の華', '会心ダメージ40%アップ');
        addMultiSynergy('清原元輔', ['伊勢大輔', '大弐三位'], '親子歌才', 'SRキャラの必殺威力30%アップ');

        addPairSynergy('源義経', '源頼朝', '源氏兄弟の宿命', '攻撃力35%アップ', '初期必殺ゲージ20%増加');
        addPairSynergy('平知盛', '建礼門院（大原）', '平家終焉の祈り', '被ダメージ25%軽減', '踏みとどまり効果強化');
        addPairSynergy('巴御前', '木曾義仲', '木曾軍の疾駆', '会心率と速度アップ', '女性味方の攻撃力20%アップ');
        addPairSynergy('巴御前', '静御前', '乱世の舞と剣', '女性キャラの速度・会心率アップ', 'SRキャラの回避率アップ');
        addPairSynergy('熊谷直実', '平敦盛', '一ノ谷の哀話', '被ダメージ20%軽減', '味方全体の回復量アップ');
        addPairSynergy('那須与一', '源義経', '屋島の一矢', '単体火力35%アップ', '会心発生率アップ');
        addPairSynergy('後鳥羽院', '藤原定家（新古今）', '新古今勅撰', '正解ダメージ30%アップ', '必殺ゲージ獲得量アップ');
        addPairSynergy('藤原定家（新古今）', '藤原俊成', '俊成・定家親子', 'SSR以上の与ダメージアップ', '味方全体の歌才バフ');
        addPairSynergy('安倍晴明', '源博雅', '陰陽と管弦', '状態異常無効＋必殺加速', 'デバフ成功率アップ');
        addPairSynergy('西行', '兼好法師', '隠遁者の美学', '回復量と防御力アップ', '長期戦で攻撃力上昇');
        addPairSynergy('一遍', '西行法師', '漂泊の僧', 'R/SRの継続回復付与', 'Rキャラの防御力アップ');
        addPairSynergy('在原行平', '小野小町（歌仙）', '歌仙の余韻', 'R/SRの会心ダメージ25%アップ', '敵防御低下効果強化');
        addPairSynergy('宇治の大君', '浮舟', '宇治の悲恋', 'R/SRの回避率20%アップ', '被ダメージ軽減');
        addPairSynergy('薫', '匂宮', '宇治十帖の対照', 'SRキャラの攻撃力20%アップ', 'SRキャラの速度20%アップ');
        addPairSynergy('夕霧（源氏）', '薫', '源氏血脈の継承', '防御力とHP上限アップ', 'デバフ耐性アップ');
        addPairSynergy('紀長谷雄', '源俊頼', '歌学の地脈', 'Rキャラの正解ダメージ20%アップ', 'Rキャラのゲージ獲得量アップ');
        addMultiSynergy('渡辺綱', ['安倍晴明', '安倍泰親'], '退魔の連携', '敵全体への特効ダメージ付与');
        addMultiSynergy('建礼門院（大原）', ['平知盛', '平敦盛'], '平家の記憶', 'SRキャラの踏みとどまり・回復量強化');
        addMultiSynergy('浮舟', ['薫', '匂宮'], '宇治十帖の渦', 'SRキャラの与ダメージと回避率アップ');

        // ガチャを跨いだシナジーを追加
        addPairSynergy('藤原道長（望月）', 'ok_005', '望月の双璧', '同名別装の共鳴で全ステータス上昇', '初期必殺ゲージ増加');
        addPairSynergy('藤原公任（歌壇）', 'se_001', '三舟の才・再演', '正解時ゲージ増加量アップ', '必殺技威力アップ');
        addPairSynergy('紫式部（若紫）', 'se_005', '物語作者の二重奏', '弱点ダメージ35%アップ', 'デバフ成功率アップ');
        addPairSynergy('清少納言（春暁）', 'se_004', '春はあけぼの・再詠', '会心率30%アップ', '敵防御無視効果強化');
        addPairSynergy('在原業平（歌仙）', 'so_007', '昔男・異伝共鳴', '会心ダメージ40%アップ', '女性編成時の攻撃力上昇');
        addPairSynergy('小野小町（歌仙）', 'so_009', '六歌仙の華・再会', '敵防御低下量アップ', '速度アップ');
        addPairSynergy('建礼門院（大原）', 'so_008', '平家物語の残響', 'SRキャラの被ダメージ20%軽減', '回復量アップ');
        addPairSynergy('夕霧（源氏）', 'ge_005', '父子の後日譚', '防御力・状態異常耐性アップ', 'HP上限アップ');
        addPairSynergy('藤原定家（新古今）', 'so_006', '新古今選者の継承', '正解時ゲージ獲得量アップ', '必殺技威力アップ');
        addPairSynergy('紀貫之', 'so_009', '六歌仙と古今集', 'R/SRの会心率25%アップ', '敵全体の防御低下');
        addPairSynergy('和泉式部', 'se_002', '宮廷恋歌の艶', '女性キャラの与ダメージ25%アップ', '必殺チャージ短縮');
        addPairSynergy('伊勢', 'ge_008', '宮廷の面影', '回復量アップ', '防御力アップ');
        addPairSynergy('大伴家持', 'ok_001', '学問と歌才', '正解ダメージ25%アップ', '雷撃必殺の威力アップ');
        addPairSynergy('鴨長明', 'so_010', '無常観の対話', '継続ダメージ強化', '男性味方HP上昇効果強化');
        addPairSynergy('西行', 'ge_002', '旅とあはれ', '回避率アップ', '全体与ダメージ上昇');
        addPairSynergy('北条政子', 'ok_003', '政の求心力', '味方全体の防御力アップ', '全ステータス上昇');
        addPairSynergy('源義経', 'so_004', '武芸の冴え', '攻撃ミス無効化率上昇', '速度アップ');
        addPairSynergy('巴御前', 'so_008', '乱世を生きる女傑', '女性キャラの踏みとどまり強化', '女性キャラの攻撃力上昇');
        addMultiSynergy('紫式部（若紫）', ['浮舟', '薫', '匂宮'], '宇治十帖の継承', 'SRキャラの与ダメージ・回復量アップ');
        addMultiSynergy('清少納言（春暁）', ['se_002', 'ok_007'], '定子サロンの再臨', '女性キャラの全ステータスアップ');
        addMultiSynergy('藤原道長（望月）', ['ok_003', 'ok_005'], '摂関栄華の三極', '初期必殺ゲージ大幅増加');
        addMultiSynergy('後鳥羽院', ['藤原定家（新古今）', '藤原俊成'], '院政和歌壇', 'SSR以上の正解ダメージと必殺威力アップ');

        // 曜日ガチャ: 月〜日の独立ポイント・独立10体（各キャラは通常ガチャと同じ戦闘フィールド）
        const WEEKDAY_GACHA_SPEC = {
            mon: [['末摘花','女性','UR','fa-fan'],['朧月夜','女性','SSR','fa-moon'],['六条御息所','女性','SSR','fa-mask'],['明石の君','女性','SSR','fa-water'],['空蝉','女性','SR','fa-feather'],['夕顔','女性','SR','fa-seedling'],['花散里','女性','SR','fa-flower'],['朝顔の姫君','女性','R','fa-sun'],['女三宮','女性','R','fa-crown'],['明石の姫君','女性','R','fa-child']],
            tue: [['源為朝','男性','UR','fa-bullseye'],['平重衡','男性','SSR','fa-fire'],['千手前','女性','SSR','fa-person-rifle'],['斎藤実盛','男性','SSR','fa-horse'],['源範頼','男性','SR','fa-bullseye'],['佐々木高綱','男性','SR','fa-horse'],['梶原景時','男性','SR','fa-shield-halved'],['平宗盛','男性','R','fa-landmark'],['平維盛','男性','R','fa-feather'],['平知康','男性','R','fa-drum']],
            wed: [['石作皇子','男性','UR','fa-gem'],['車持皇子','男性','SSR','fa-cart-shopping'],['阿倍御主人','男性','SSR','fa-coins'],['大伴御行','男性','SSR','fa-dragon'],['石上麻呂','男性','SR','fa-mountain'],['竜田姫','女性','SR','fa-leaf'],['天探女','女性','SR','fa-eye'],['翁（竹取）','男性','R','fa-person'],['嫗（竹取）','女性','R','fa-house'],['帝（竹取）','男性','R','fa-landmark']],
            thu: [['本居宣長','男性','UR','fa-book-open-reader'],['契沖','男性','SSR','fa-book'],['荷田春満','男性','SSR','fa-scroll'],['賀茂真淵','男性','SSR','fa-pen-nib'],['上田秋成','男性','SR','fa-feather-pointed'],['大江匡房','男性','SR','fa-graduation-cap'],['源経信','男性','SR','fa-music'],['藤原清輔','男性','R','fa-pen'],['顕昭','男性','R','fa-hands-praying'],['頓阿','男性','R','fa-book']],
            fri: [['藤原秀郷','男性','UR','fa-dragon'],['源頼信','男性','SSR','fa-shield-halved'],['源頼義','男性','SSR','fa-horse'],['碓井貞光','男性','SSR','fa-khanda'],['俵藤太','男性','SR','fa-bullseye'],['平将門','男性','SR','fa-crown'],['源仲綱','男性','SR','fa-horse'],['賀茂保憲','男性','R','fa-hat-wizard'],['平貞盛','男性','R','fa-shield'],['滝口入道','男性','R','fa-user-ninja']],
        };
        const WEEKDAY_CHARACTER_DETAILS = {
          mon: [['鼻高き姫君','異形をものともせず、正解時に自身の会心率を6秒間30%上げる。','末摘花・紅梅の袖','敵全体に超絶の冷気ダメージ＋自身に会心強化'],['朧月の誘い','女性味方が2人以上なら必殺チャージ量20%アップ。','朧月夜・艶やかな挑発','敵単体に特大ダメージ＋魅了'],['生霊の気配','被ダメージ時、敵の攻撃力を5秒間15%下げる。','六条御息所・車争いの怨','敵全体に特大呪詛＋速度低下'],['明石の祈り','HPが50%以下の味方を回復すると効果量25%増。','明石の君・入道の浜風','味方全体を大回復＋継続回復'],['身を隠す薄衣','敵の攻撃を受けた直後、次の被弾を1回無効化。','空蝉・薄衣の脱出','敵単体に大ダメージ＋自身に回避'],['夕顔の露','正解が2回続くと、味方全体の与ダメージを8秒間18%上げる。','夕顔・夕露の消散','敵全体に大ダメージ＋敵の命中率低下'],['花散里の和み','正解時、味方全体のHPを3%回復する。','花散里・橘の慰め','味方全体を回復＋デバフ解除'],['朝顔の一途','HPが30%以下になると一度だけ防御力を大幅上昇。','朝顔・槿の再会','敵単体に標準ダメージ＋防御強化'],['三宮の祈願','R味方がいる時、味方の状態異常耐性を15%上げる。','女三宮・落飾の白衣','味方全体に状態異常無効を短時間付与'],['姫君の継承','正解時、最もHPの低い味方の必殺ゲージを少量補う。','明石姫君・東宮の輿入れ','味方全体の必殺チャージを大加速']],
          tue: [['鎮西八郎の剛弓','正解時、敵の防御力を5秒間20%下げる。','鎮西八郎・豪弓一矢','敵単体に超絶ダメージ＋必ず会心'],['南都焼討の猛火','敵を倒すたび、次の攻撃の与ダメージが20%上がる。','重衡・南都炎上','敵全体に特大火属性ダメージ＋火傷'],['坂東の女武者','女性味方の速度を15%上げ、会心時に追加ダメージ。','千手前・木曾谷の薙刀','敵単体に特大ダメージ＋女性味方を鼓舞'],['白髪の老将','HPが減るほど被ダメージを軽減（最大25%）。','実盛・錦秋の最期','敵全体に特大ダメージ＋踏みとどまり付与'],['屋島の射手','必殺ゲージ80%以上で、次の正解が必ず会心。','与一・扇の的','敵単体に大ダメージ＋必中会心'],['名馬の先駆','正解が3回続くと味方全体の速度を8秒間20%上げる。','高綱・宇治川渡河','敵全体に大ダメージ＋味方速度上昇'],['梶原の讒言','敵が強化状態の時、与ダメージが25%増える。','景時・逆櫓の計','敵単体に大ダメージ＋敵バフ解除'],['都落ちの総帥','R味方1体につき防御力を8%上げる。','宗盛・西海落日','敵全体に標準ダメージ＋味方防御上昇'],['維盛の桜狩','HPが50%以上の時、正解ダメージが20%増える。','維盛・富士川の花影','敵単体に標準ダメージ＋魅了'],['鼓判官の調べ','正解時、敵の行動ゲージをわずかに遅らせる。','知康・鼓判官','敵全体に標準ダメージ＋短時間スタン']],
          wed: [['石作の虚飾','正解時、味方の与ダメージを5秒間15%上げる。','石作皇子・仏の御石の鉢','敵全体に超絶ダメージ＋敵防御低下'],['車持の偽装','敵の攻撃を1回だけ反射するバリアを張る。','車持皇子・蓬莱の玉の枝','敵単体に特大ダメージ＋反射障壁'],['右大臣の財','宝玉くじの所持量ではなく戦闘中の獲得ゲージを15%増やす。','阿倍御主人・火鼠の皮衣','味方全体の必殺ゲージを大加速'],['龍首の玉','3連続正解で敵全体に追加の水属性ダメージ。','大伴御行・龍の首の玉','敵全体に特大水属性ダメージ＋速度低下'],['石上の誠','被ダメージ時、20%で受けるダメージを半減。','石上麻呂・燕の子安貝','味方全体に大バリア＋防御上昇'],['竜田の紅葉','正解時、敵に付与したデバフの残り時間を延長。','竜田姫・錦繍の舞','敵全体に大ダメージ＋継続ダメージ'],['天探女の見抜き','敵の強化効果を無視してダメージを与える。','天探女・天の羽衣','敵全体の強化解除＋混乱'],['翁の竹籠','HPが40%以下の味方を一度だけHP30%で蘇生。','竹取翁・輝く竹の記憶','味方全体を回復＋蘇生準備'],['嫗の養い','正解時、最も低いHPの味方を4%回復。','竹取嫗・かぐやの養い','味方全体に継続回復＋状態異常解除'],['帝の勅命','味方の女性数に応じて必殺威力が上がる。','帝・月への御使い','敵全体に標準ダメージ＋味方全体強化']],
          thu: [['もののあはれの眼','弱点属性への正解ダメージを30%上げる。','宣長・もののあはれ','敵全体に超絶ダメージ＋弱点耐性低下'],['釈義の慧眼','正解時、敵の防御力を10%低下（累積3回）。','契沖・万葉代匠記','敵単体に特大ダメージ＋防御破砕'],['古道の起点','味方全体のスキル再使用時間を10%短縮。','荷田春満・古学の灯','味方全体の必殺チャージ加速＋デバフ解除'],['賀茂の訓読','同じ属性の味方がいると正解ゲージを20%増やす。','真淵・語釈の槌','敵全体に特大ダメージ＋味方ゲージ加速'],['雨月の幻想','被ダメージ時、敵に5秒間の呪いを返す。','秋成・雨月物語','敵全体に大ダメージ＋呪い'],['匡房の兵法','敵の攻撃力を正解ごとに3%下げる（最大30%）。','匡房・狐の変化','敵全体に大ダメージ＋攻撃力低下'],['桂花の詠','正解時、味方女性の会心率を5秒間上げる。','経信・桂花の管弦','味方全体の速度上昇＋会心強化'],['清輔の歌学','同じレア度の味方が3人以上ならスキル威力20%増。','清輔・袋草紙','敵単体に標準ダメージ＋味方スキル強化'],['歌論の結界','戦闘開始時、味方全体に小バリア。','顕昭・古今注釈','味方全体に標準バリア＋状態異常耐性'],['頓阿の連歌','正解が2回続くと必殺ゲージを追加獲得。','頓阿・草庵の付合','敵全体に標準ダメージ＋必殺加速']],
          fri: [['百足退治の矢','敵が毒・呪い状態なら与ダメージ35%増。','秀郷・三上山百足退治','敵全体に超絶ダメージ＋毒・呪い'],['東国の棟梁','味方全体のHP上限を15%上げる。','頼信・平忠常追討','味方全体に特大バリア＋攻撃強化'],['前九年の陣','正解時、味方の防御力を5秒間25%上げる。','頼義・阿久利川の陣','敵全体に特大ダメージ＋防御強化'],['羅生門の鬼腕','敵の攻撃を回避すると次の攻撃が必ず会心。','綱・鬼女の腕','敵単体に特大ダメージ＋スタン'],['俵藤太の弓勢','必殺ゲージが満タンに近いほど会心威力上昇。','俵藤太・三上山一矢','敵単体に大ダメージ＋必中会心'],['将門の新皇','HPが50%以下になると一度だけ全能力を上げる。','将門・王城の逆賊','敵全体に大ダメージ＋自身強化'],['仲綱の名馬','味方が倒れた時、全員の速度を8秒間上げる。','仲綱・木曾の名馬','敵全体に大ダメージ＋味方速度上昇'],['泰親の星読','敵の必殺ゲージを少し減少させる。','保憲・泰山府君祭','敵全体に標準ダメージ＋ゲージ減少'],['貞盛の鎮守','戦闘開始時、味方全体の被ダメージを10%軽減。','貞盛・将門追討','味方全体に標準回復＋防御強化'],['保昌の風雅','正解時、敵の攻撃を短時間ミスさせることがある。','滝口入道・月下の笛','敵単体に標準ダメージ＋攻撃力低下']]
        };
        const WEEKDAY_GACHA_BANNERS = {
            mon:{id:'mon',title:'月曜・月影の守護者',pointName:'月影ポイント',icon:'fa-moon'}, tue:{id:'tue',title:'火曜・火焔の英傑',pointName:'火焔ポイント',icon:'fa-fire'}, wed:{id:'wed',title:'水曜・水鏡の幻影',pointName:'水鏡ポイント',icon:'fa-water'}, thu:{id:'thu',title:'木曜・本居宣長',pointName:'古語ポイント',icon:'fa-scroll'}, fri:{id:'fri',title:'金曜・鏡像の英傑',pointName:'鏡像ポイント',icon:'fa-clone'}
        };
        const WEEKDAY_SKILL_PATTERNS = [
            ['暁月の先触れ','3連続正解で、次の8秒間は与ダメージ35%アップ。','combo3',{buffDmgUp:[35,8]}],
            ['炎心の構え','正解時、敵の攻撃力を20%低下（5秒）。','correct',{enemyAtkDown:[20,5]}],
            ['水鏡の機知','HP50%以下で正解すると、必殺チャージ速度35%アップ（6秒）。','lowHpCorrect',{buffSpecGain:[35,6]}],
            ['古語の連歌','同じレア度の味方がいる時、必殺チャージ20%アップ（5秒）。','sameRarityCorrect',{buffSpecGain:[20,5]}],
            ['鏡像の見切り','敵の攻撃を受けた直後、次の攻撃を1回だけ無効化。','afterHit',{miss:1}],
            ['王朝の余光','必殺ゲージ80%以上で正解すると、与ダメージ25%アップ（6秒）。','highGaugeCorrect',{buffDmgUp:[25,6]}],
            ['曜日の守り','正解時、味方の防御力を25%アップ（6秒）。','correct',{buffDef:[25,6]}],
            ['歌合の鼓舞','3連続正解で、味方の攻撃力と必殺加速を上げる。','combo3',{buffAtk:[25,8],buffSpecGain:[25,8]}]
        ];
        const WEEKDAY_SPECIAL_PATTERNS = [
            ['月影・満ち欠けの舞',{dmg:2.4,stun:[2,4],buffDmgUp:[25,10]}],
            ['火焔・紅蓮一閃',{dmg:2.5,crit:0.4,enemyAtkDown:[25,10]}],
            ['水鏡・千波返し',{dmg:2.2,healPct:0.18,regen:[4,0.02]}],
            ['古語・万葉の結び',{dmg:2.0,buffSpecGain:[40,10],cleanse:true}],
            ['鏡像・反照の刃',{dmg:2.3,crit:0.5,enemySpeedDown:[30,8]}],
            ['歌合・判詞の雷',{dmg:1.8,stun:[1.5,3],buffAtk:[25,8]}],
            ['管弦・雅楽の調べ',{buffSpeed:[40,10],buffDef:[25,10]}],
            ['朝夕・継承の祈り',{healPct:0.22,shield:3,regen:[4,0.02]}]
        ];
        function buildWeekdayGachaUnits(bannerId, specs){
            return specs.map((x,i)=>{
                const rarity=x[2], d=WEEKDAY_CHARACTER_DETAILS[bannerId][i];
                return {id:`wd_${bannerId}_${String(i+1).padStart(2,'0')}`,name:x[0],gender:x[1],rarity,icon:x[3],description:`${x[0]}。『${bannerId==='mon'?'源氏物語':bannerId==='tue'?'平家物語':bannerId==='wed'?'竹取物語':bannerId==='thu'?'古典注釈・歌論':'平安軍記・説話'}』に連なる古典の人物。`,skill:{name:d[0],effect:d[1],trigger:'correct',fx:{buffDmgUp:[15,5]}},special_move:{name:d[2],effect:d[3]},special_effect:{dmg:rarity==='UR'?2.4:rarity==='SSR'?2.2:rarity==='SR'?2.0:1.8,healPct:0,shield:0},gaugePerCorrect:rarity==='UR'?35:rarity==='SSR'?26:rarity==='SR'?20:16,gaugeNeedsVotes:rarity==='UR'?3:rarity==='SSR'?4:rarity==='SR'?5:6,synergies:[]};
            });
        }
        Object.keys(WEEKDAY_GACHA_BANNERS).forEach(k=>WEEKDAY_GACHA_BANNERS[k].units=buildWeekdayGachaUnits(k,WEEKDAY_GACHA_SPEC[k]));
        const getWeekdayUnitsFlat=()=>Object.values(WEEKDAY_GACHA_BANNERS).flatMap(b=>b.units||[]);
        addPairSynergy('末摘花','朧月夜','源氏・異形と艶','女性味方の会心率25%アップ','敵の魅了成功率アップ');
        addPairSynergy('六条御息所','夕顔','生霊と夕露','呪いダメージ35%アップ','回避率20%アップ');
        addPairSynergy('源為朝','那須与一','弓取の系譜','必中率アップ','会心ダメージ35%アップ');
        addPairSynergy('平重衡','斎藤実盛','炎と老将','火傷ダメージ強化','被ダメージ20%軽減');
        addPairSynergy('石作皇子','車持皇子','五人の貴公子・虚実','敵防御低下','反射バリア強化');
        addPairSynergy('大伴御行','石上麻呂','龍玉と子安貝','必殺チャージ加速','防御力25%アップ');
        addPairSynergy('本居宣長','契沖','古典解釈の先達','弱点ダメージ35%アップ','デバフ命中率アップ');
        addPairSynergy('荷田春満','賀茂真淵','国学の継承','味方全体の必殺威力アップ','正解ゲージ増加');
        addPairSynergy('藤原秀郷','平将門','百足と新皇','毒・呪い特効','HP上限20%アップ');
        addPairSynergy('源頼信','源頼義','東国棟梁の継承','防御力20%アップ','攻撃力20%アップ');
        addMultiSynergy('末摘花',['空蝉','夕顔','花散里'],'源氏の女君たち','女性味方の回復量と回避率アップ');
        addMultiSynergy('本居宣長',['契沖','荷田春満','賀茂真淵'],'国学四家の連環','古典系キャラの全ステータスアップ');
        addMultiSynergy('藤原秀郷',['源頼信','源頼義','平貞盛'],'東国武者の鎮め','敵全体への特効＋味方防御強化');

        const ALL_GACHA_CHARACTERS = () => [...GACHA_CHARACTERS, ...getNewBannerUnitsFlat(), ...getWeekdayUnitsFlat(), KAGUYA_UNIT, ...BOSS_RUSH_GOD_UNITS_LIST];

        const DUNGEONS_DATA = [
    {
        id: 1,
        title: "ダンジョン1: 月の異名（旧暦12ヶ月）",
        recommendedPower: "1,200〜2,800",
        icon: "fa-calendar-days",
        stages: [
            {
                id: "d01_s01",
                name: "ステージ1: 睦月（1月）",
                recommendedPower: "1,200",
                icon: "fa-calendar-days",
                description: "【睦月（むつき）の深掘り解説】旧暦1月。正月に親族集まり「睦び親しむ（仲良くする）」ことが語源とされる。新春を祝い、年神を迎える神聖な月。『子日の遊び（ねのひのあそび）』として野に出て小松を引き、若菜を摘んで長寿を祈る宮廷行事も行われた。和歌では「初春」「新春」「子日」などの季語と結びつく。"
            },
            {
                id: "d01_s02",
                name: "ステージ2: 如月（2月）",
                recommendedPower: "1,350",
                icon: "fa-snowflake",
                description: "【如月（きさらぎ）の深掘り解説】旧暦2月。寒さが残るため着物をさらに重ね着する「衣更着（きさらぎ）」が語源とされる。また草木が生え始める「生更木」の説もある。梅の開花とともに春の訪れを感じさせる月であり、和歌では残雪と梅の対比、鶯の初音（はつね）などが好んで詠まれた。"
            },
            {
                id: "d01_s03",
                name: "ステージ3: 弥生（3月）",
                recommendedPower: "1,500",
                icon: "fa-seedling",
                description: "【弥生（やよい）の深掘り解説】旧暦3月。「いやおい（草木がいよいよ生い茂る）」が変化した語。春の終わりの月で、桜が咲き誇り散っていく儚さが和歌の中心テーマとなる。3月3日には「上巳の節句（曲水の宴・ひいな遊び）」が行われ、水辺で祓い（はらい）をして穢れを流す風習があった。"
            },
            {
                id: "d01_s04",
                name: "ステージ4: 卯月（4月）",
                recommendedPower: "1,650",
                icon: "fa-clover",
                description: "【卯月（うづき）の深掘り解説】旧暦4月。白く美しい「卯の花（ウツギ）」が咲く月が語源。初夏（旧暦4・5・6月が夏）の始まり。賀茂神社の大祭「賀茂祭（葵祭）」が行われる月であり、平安貴族にとって最も華やかな見物行事の一つであった。衣服も冬物から夏物へ改める「更衣（ころもがえ）」の月。"
            },
            {
                id: "d01_s05",
                name: "ステージ5: 皐月（5月）",
                recommendedPower: "1,800",
                icon: "fa-wheat-awn",
                description: "【皐月（さつき）の深掘り解説】旧暦5月。田植えをする「早苗月（さなえづき）」の略とされる。5月5日の「端午の節句」では、軒に菖蒲（しょうぶ）や蓬（よもぎ）を挿して邪気を祓った。長く続く雨「五月雨（さみだれ）」の時期であり、物思いに沈む情景として古文に多用される。"
            },
            {
                id: "d01_s06",
                name: "ステージ6: 水無月（6月）",
                recommendedPower: "1,950", icon: "fa-droplet",
                description: "【水無月（みなづき）の深掘り解説】旧暦6月。「無」は和歌における助詞「の」の意味で「水の月（田に水を注ぐ月）」を意味する。夏の終わりの月。6月30日には半年間の穢れを祓い清める「夏越の祓（なつこしのはらい）」が行われ、人形（ひとがた）を川に流した。"
            },
            {
                id: "d01_s07",
                name: "ステージ7: 文月（7月）",
                recommendedPower: "2,100",
                icon: "fa-pen-fancier",
                description: "【文月（ふみづき）の深掘り解説】旧暦7月。7月7日の七夕行事（乞巧奠：きっこうでん）で、詩歌や文字の上達を祈って梶の葉に和歌を書いた「書文（ふみ）」が語源。初秋の訪れを告げる月であり、七夕における織女・牽牛の星の逢瀬は王朝恋歌の重要なモチーフ。"
            },
            {
                id: "d01_s08",
                name: "ステージ8: 葉月（8月）",
                recommendedPower: "2,250",
                icon: "fa-leaf",
                description: "【葉月（はづき）の深掘り解説】旧暦8月。紅葉が始まり「葉が落ちる月（葉落ち月）」が変化したとされる。秋の中央（仲秋）。8月15日の「十五夜（中秋の名月）」には満月を愛でる観月の宴が催され、管弦を奏で和歌を詠み交わした。"
            },
            {
                id: "d01_s09",
                name: "ステージ9: 長月（9月）",
                recommendedPower: "2,400",
                icon: "fa-cloud-moon",
                description: "【長月（ながつき）の深掘り解説】旧暦9月。秋が深まり「夜が長くなる月（夜長月）」の略。晩秋のしんみりとした情趣が漂う。9月9日の「重陽の節句」では菊の露を染み込ませた真綿（菊の綿）で肌を拭い、不老長寿を祈った。雁の来航や時雨（しぐれ）が詠まれる。"
            },
            {
                id: "d01_s10",
                name: "ステージ10: 神無月（10月）",
                recommendedPower: "2,550",
                icon: "fa-torii-gate",
                description: "【神無月（かんなづき）の深掘り解説】旧暦10月。全国の神々が出雲大社に集まるため各地の神が不在になるという俗説が有名だが、本来は「神の月（醸造や収穫を祝う神事の月）」の意味。初冬の始まりであり、時雨が降り落葉が舞う寂しさが古文の美意識と結びつく。"
            },
            {
                id: "d01_s11",
                name: "ステージ11: 霜月（11月）",
                recommendedPower: "2,700",
                icon: "fa-temperature-low",
                description: "【霜月（しもつき）の深掘り解説】旧暦11月。霜が降りる「霜降り月」の略。仲冬の厳しい寒さが本格化する。新穀を神に捧げる最高儀礼「新嘗祭（にいなめさい）」や、宮中の「五節の舞姫」の披露など重要な国家神事が行われた月でもある。"
            },
            {
                id: "d01_s12",
                name: "ステージ12: 師走（しわす）",
                recommendedPower: "2,800",
                icon: "fa-person-running",
                description: "【師走（しわす）の深掘り解説】旧暦12月。年末の法要（仏名会など）のために「師（僧侶）」が忙しく走り回る「師馳せ（しはせ）」が語源とされる。一年の締めくくりであり、大晦日（おおつごもり）には夜通し起きて年神を迎える。鬼を追い払う「追儺（ついな）」の行事も行われた。"
            }
        ]
    },
    {
        id: 2,
        title: "ダンジョン2: 方位と十二支（全12方角）",
        recommendedPower: "2,900〜4,500",
        icon: "fa-compass",
        stages: [
            {
                id: "d02_s01",
                name: "ステージ1: 子（北）",
                recommendedPower: "2,900",
                icon: "fa-compass",
                description: "【子（ね）：北】方位の基準であり真北（0度）を示す。時刻では午後11時〜午前1時（子の刻：深夜24時中心）。陰陽五行説では「水」の気を持ち、最も陰気が極まる位置。子午線（しごせん）の「子」は北を意味する。"
            },
            {
                id: "d02_s02",
                name: "ステージ2: 丑（北北東）",
                recommendedPower: "3,050",
                icon: "fa-cow",
                description: "【丑（うし）：北北東】北から東へ30度傾いた方角。時刻は午前1時〜3時（丑の刻）。東北（丑と寅の間）は「艮（うしとら）」と呼ばれ、凶兆や鬼が出入りする「鬼門（きもん）」として恐れられた。"
            },
            {
                id: "d02_s03",
                name: "ステージ3: 寅（東北東・鬼門）",
                recommendedPower: "3,200",
                icon: "fa-ghost",
                description: "【寅（とら）：東北東】東へ傾いた北東。時刻は午前3時〜5時（寅の刻：明け方）。艮（鬼門）の方向にあるため、平安貴族は建築や移動の際にこの方角への禁忌（方位の吉凶）を強く意識した。"
            },
            {
                id: "d02_s04",
                name: "ステージ4: 卯（東）",
                recommendedPower: "3,350",
                icon: "fa-sun",
                description: "【卯（う）：東】真東（90度）を示す。時刻は午前5時〜7時（卯の刻：日の出）。五行では「木」の気。太陽が昇る方位として生命や物事の始まりを象徴し、宮中の東側施設（春宮・東宮など）と関わる。"
            },
            {
                id: "d02_s05",
                name: "ステージ5: 辰（東南東）",
                recommendedPower: "3,500",
                icon: "fa-dragon",
                description: "【辰（たつ）：東南東】東から南へ30度傾いた方角。時刻は午前7時〜9時（辰の刻）。東南（辰と巳の間）は「巽（たつみ）」と呼ばれ、風の通り道であり爽やかな気の流れる吉方とされる。"
            },
            {
                id: "d02_s06",
                name: "ステージ6: 巳（南南東）",
                recommendedPower: "3,650",
                icon: "fa-staff-snake",
                description: "【巳（み）：南南東】南へ傾いた東南。時刻は午前9時〜11時（巳の刻）。陽気が高まる時間帯であり、脱皮を繰り返す蛇（巳）の生命力から不老再生や財福の象徴とされる。"
            },
            {
                id: "d02_s07",
                name: "ステージ7: 午（南）",
                recommendedPower: "3,800",
                icon: "fa-horse",
                description: "【午（うま）：南】真南（180度）を示す。時刻は午前11時〜午後1時（午の刻：正午）。陽気が最も盛んな位置。内裏の南門を「朱雀門」、南の大路を「朱雀大路」と呼び、君主は南面して政治を行った。"
            },
            {
                id: "d02_s08",
                name: "ステージ8: 未（南南西）",
                recommendedPower: "3,950",
                icon: "fa-cloud",
                description: "【未（ひつじ）：南南西】南から西へ30度傾いた方角。時刻は午後1時〜3時（未の刻）。西南（未と申の間）は「坤（ひつじさる）」と呼ばれ、鬼門の反対側に位置する「裏鬼門（うらきもん）」とされる。"
            },
            {
                id: "d02_s09",
                name: "ステージ9: 申（西南西）",
                recommendedPower: "4,100",
                icon: "fa-mountain",
                description: "【申（さる）：西南西】西へ傾いた西南。時刻は午後3時〜5時（申の刻：夕方）。日が傾き始める刻限であり、鬼門（艮）を打ち払う神聖な霊獣として「猿（申）」が重宝された。"
            },
            {
                id: "d02_s10",
                name: "ステージ10: 酉（西）",
                recommendedPower: "4,250",
                icon: "fa-feather",
                description: "【酉（とり）：西】真西（270度）を示す。時刻は午後5時〜7時（酉の刻：日没）。五行では「金」の気。日没の方角である西は、仏教の「西方極楽浄土」と深く結びつき、臨終の際の祈りの方向となった。"
            },
            {
                id: "d02_s11",
                name: "ステージ11: 戌（西北西）",
                recommendedPower: "4,400",
                icon: "fa-shield-dog",
                description: "【戌（いぬ）：西北西】西から北へ30度傾いた方角。時刻は午後7時〜9時（戌の刻：宵の口）。西北（戌と亥の間）は「乾（いぬい）」と呼ばれ、天や主君、重厚さを象徴する方角とされる。"
            },
            {
                id: "d02_s12",
                name: "ステージ12: 亥（北北西）",
                recommendedPower: "4,500",
                icon: "fa-person-hiking",
                description: "【亥（い）：北北西】北へ傾いた西北。時刻は午後9時〜11時（亥の刻：夜深し）。10月最初の亥の日・亥の刻に食べる「亥の子餅（いのこもち）」は無病息災や子孫繁栄、無火災を祈る行事として有名。"
            }
        ]
    },
    {
        id: 3,
        title: "ダンジョン3: 平安の刻限（十二時刻）",
        recommendedPower: "4,600〜6,200",
        icon: "fa-clock",
        stages: [
            {
                id: "d03_s01",
                name: "ステージ1: 子の刻（24時頃）",
                recommendedPower: "4,600",
                icon: "fa-moon",
                description: "【子の刻（ねのこく）：午後11時〜午前1時頃】深夜24時を中心とする時間帯。夜が最も深まる時刻で、古文では通い婚の男が女のもとを訪れて密会する刻限、あるいは怪異や物の怪が活動する最高潮の時間として描かれる。"
            },
            {
                id: "d03_s02",
                name: "ステージ2: 丑の刻（2時頃）",
                recommendedPower: "4,750",
                icon: "fa-skull",
                description: "【丑の刻（うしのこく）：午前1時〜午前3時頃】草木も眠る丑三つ時（午前2時〜2時半頃）。陰気が極まる恐ろしい時刻とされ、鬼の出現や怨霊の祟り、呪詛（丑の刻参り）の描写で古文中に頻出する。"
            },
            {
                id: "d03_s03",
                name: "ステージ3: 寅の刻（4時頃）",
                recommendedPower: "4,900",
                icon: "fa-cloud-sun",
                description: "【寅の刻（とらのこく）：午前3時〜午前5時頃】夜明け直前の時間帯。男が女のもとから立ち去らなければならない「後朝（きぬぎぬ）」の準備の時間。東の空がほのぼのと明け始める『東の生気』を感じさせる刻限。"
            },
            {
                id: "d03_s04",
                name: "ステージ4: 卯の刻（6時頃）",
                recommendedPower: "5,050",
                icon: "fa-sun",
                description: "【卯の刻（うのこく）：午前5時〜午前7時頃】日の出の時刻。「明けていく」時間であり、朝の開門や宮中への参内が始まる。男が女の部屋を辞して帰るギリギリの時刻であり、別れの切なさが和歌（後朝の歌）に詠まれる。"
            },
            {
                id: "d03_s05",
                name: "ステージ5: 辰の刻（8時頃）",
                recommendedPower: "5,200",
                icon: "fa-bell",
                description: "【辰の刻（たつのこく）：午前7時〜午前9時頃】朝食や朝の政務（朝政）が本格化する時刻。宮中では蔵人や弁官が動き回り、書状の行き交い（朝一番に贈る後朝の絹や手紙）が盛んに行われる。"
            },
            {
                id: "d03_s06",
                name: "ステージ6: 巳の刻（10時頃）",
                recommendedPower: "5,350",
                icon: "fa-hourglass-start",
                description: "【巳の刻（みのこく）：午前9時〜午前11時頃】昼前の活気あふれる時間帯。貴族たちの対面、儀式の準備、訪問などの社会活動が中心的に行われる。光が十分に差し込み部屋のしつらいが美しく映える時刻。"
            },
            {
                id: "d03_s07",
                name: "ステージ7: 午の刻（12時頃）",
                recommendedPower: "5,500",
                icon: "fa-sun",
                description: "【午の刻（うまのこく）：午前11時〜午後1時頃】正午（12時）を中心とする時間。太陽が天頂に達し影が最も短くなる。宮中の昼食（昼の御膳）が運ばれ、一日の政務が一区切りつく時刻。"
            },
            {
                id: "d03_s08",
                name: "ステージ8: 未の刻（14時頃）",
                recommendedPower: "5,650",
                icon: "fa-hourglass-half",
                description: "【未の刻（ひつじのこく）：午後1時〜午後3時頃】未の刻は午後の穏やかな時間。暑さがピークを過ぎ、貴族たちが詩歌の詠進、盤上遊戯（碁や双六）、読書などの風流な趣味に興じる時間帯。"
            },
            {
                id: "d03_s09",
                name: "ステージ9: 申の刻（16時頃）",
                recommendedPower: "5,800",
                icon: "fa-cloud-sun",
                description: "【申の刻（さるのこく）：午後3時〜午後5時頃】夕方が近づく刻限。日が西に傾きはじめ、「黄昏（たそがれ：誰そ彼）」の予感が漂う。夕方の勤行（夕勤）の鐘が響き、旅人が宿を探し始める時間。"
            },
            {
                id: "d03_s10",
                name: "ステージ10: 酉の刻（18時頃）",
                recommendedPower: "5,950",
                icon: "fa-sunset",
                description: "【酉の刻（とりのこく）：午後5時〜午後7時頃】日没の時刻。昼と夜の境界。宮中では「点灯（ともしび）」の儀が行われ、灯籠に火が点される。通い婚の男たちが意中の女性のもとへ出発する時間帯。"
            },
            {
                id: "d03_s11",
                name: "ステージ11: 戌の刻（20時頃）",
                recommendedPower: "6,100",
                icon: "fa-smog",
                description: "【戌の刻（いぬのこく）：午後7時〜午後9時頃】宵の口。夜の闇が深まり、人通りが途絶える。男が女の屋敷に到着して忍び込み、部屋の御簾（みす）をくぐって会話を交わすロマンチックかつ緊迫した時間帯。"
            },
            {
                id: "d03_s12",
                name: "ステージ12: 亥の刻（22時頃）",
                recommendedPower: "6,200",
                icon: "fa-bed",
                description: "【亥の刻（いのこく）：午後9時〜午後11時頃】夜深し（よふかし）。人々の就寝時間。寝殿造の暗闇の中で静寂が広がり、風の音や蟲の声、遠くの寺の鐘の音が強調され、物語の情景描写を際立たせる。"
            }
        ]
    },
    {
        id: 4,
        title: "ダンジョン4: 旧暦の四季と季節感",
        recommendedPower: "6,300〜7,500",
        icon: "fa-tree",
        stages: [
            {
                id: "d04_s01",
                name: "ステージ1: 初春（1月）",
                recommendedPower: "6,300",
                icon: "fa-fan",
                description: "【初春（しょしゅん）：旧暦1月】旧暦の春は1・2・3月。まだ雪が残り寒さが厳しいが、暦の上では春。「立つ春」「初浅緑」「若菜」など、極寒の中に芽生えるかすかな生命の兆しを喜ぶのが古文の美意識。"
            },
            {
                id: "d04_s02",
                name: "ステージ2: 仲春（2月）",
                recommendedPower: "6,500",
                icon: "fa-spa",
                description: "【仲春（ちゅうしゅん）：旧暦2月】春の中央。気候が和らぎ、梅の花が満開を迎える。春霞（はるがすみ）が立ち込め、鶯の鳴き声が響く。自然全体が華やかさを増し、貴族たちの宴が開かれる。"
            },
            {
                id: "d04_s03",
                name: "ステージ3: 晩春（3月）",
                recommendedPower: "6,700",
                icon: "fa-seedling",
                description: "【晩春（ばんしゅん）：旧暦3月】春の終わり。「行く春」「惜春」の情調。桜の花が散る景色が中心となり、散る花を惜しむ和歌が数多く詠まれる。藤の花やヤマブキが咲き始め、夏の予感が漂う。"
            },
            {
                id: "d04_s04",
                name: "ステージ4: 初夏（4月）",
                recommendedPower: "6,900",
                icon: "fa-sun",
                description: "【初夏（しょか）：旧暦4月】旧暦の夏は4・5・6月。新緑（若葉・薫風）の季節。卯の花が咲き、霍公鳥（ほととぎす）が初鳴きする。ホトトギスは冥土からの使者ともされ、その声を待つ和歌が非常に多い。"
            },
            {
                id: "d04_s05",
                name: "ステージ5: 盛夏（5月）",
                recommendedPower: "7,100",
                icon: "fa-fire",
                description: "【盛夏（せいか）：旧暦5月】夏の中央（仲夏）。五月雨（さみだれ）が降り続く長雨の時期。橘（たちばな）の花が咲き、その香りが昔馴染みの人の袖の香りを思い出させるという伝統的イメージ（昔をしのぶ草）がある。"
            },
            {
                id: "d04_s06",
                name: "ステージ6: 晩夏（6月）",
                recommendedPower: "7,200",
                icon: "fa-water",
                description: "【晩夏（ばんか）：旧暦6月】夏の終わり。厳しい暑さ（夏深し）。涼を求めて水辺（川狩り・泉水）で過ごす。「打ち水」や「氷室（ひむろ）の氷」が貴重とされ、6月30日の大祓（おおはらえ）で夏が終わる。"
            },
            {
                id: "d04_s07",
                name: "ステージ7: 初秋（7月）",
                recommendedPower: "7,300",
                icon: "fa-wind",
                description: "【初秋（しょしゅう）：旧暦7月】旧暦の秋は7・8・9月。立秋を迎え、秋風（初風）が吹き始める。「秋来ぬと目にはさやかに見えねども風の音にぞ驚かれぬる」の歌のように、風の涼しさで微かな秋を感じ取る。"
            },
            {
                id: "d04_s08",
                name: "ステージ8: 中秋（8月）",
                recommendedPower: "7,400",
                icon: "fa-moon",
                description: "【中秋（ちゅうしゅう）：旧暦8月】秋の盛り（仲秋）。空が澄み渡り、月が最も美しく見える季節。十五夜の月、萩（はぎ）の花、鈴虫や松虫など蟲の音が情緒を高め、王朝文学の最も美しく寂しい情景を形作る。"
            },
            {
                id: "d04_s09",
                name: "ステージ9: 晩秋（9月）",
                recommendedPower: "7,450",
                icon: "fa-leaf",
                description: "【晩秋（ばんしゅう）：旧暦9月】秋の終わり。草木が枯れゆく「哀れ」の最高潮。時雨（しぐれ）が降り、紅葉が散り乱れる。霜が降りて旅人は袖を濡らし、人々の恋心も冷めやすくなるとされる滅びの美学の季節。"
            },
            {
                id: "d04_s10",
                name: "ステージ10: 厳冬（12月）",
                recommendedPower: "7,500",
                icon: "fa-icicles",
                description: "【厳冬（げんとう）：旧暦12月】旧暦の冬は10・11・12月。その総決算。氷が張り、激しい雪が降る。「冴ゆ（さゆ）」「凍つ（いつ）」などの言葉が使われ、冬の静寂と静けさの中で新しい春（新年）を待つ緊張感が漂う。"
            }
        ]
    },
    {
        id: 5,
        title: "ダンジョン5: 和歌の修辞法（基本掛詞）",
        recommendedPower: "7,600〜8,500",
        icon: "fa-feather-pointed",
        stages: [
            {
                id: "d05_s01",
                name: "ステージ1: ふる（降る・経る）",
                recommendedPower: "7,600",
                icon: "fa-cloud-showers-heavy",
                description: "【掛詞「ふる」の深掘り解説】「雨や雪が『降る』」という自然現象と、「時が『経る（年をとる・時が過ぎる）』」という人間の情念・年月の経過を重ね合わせる。例：「長雨の降る＝物思いに耽りつつ歳月が経る」。二重の意味を一つの音に持たせる和歌最大の技法。"
            },
            {
                id: "d05_s02",
                name: "ステージ2: かれ（枯れ・離れ）",
                recommendedPower: "7,800",
                icon: "fa-plant-wilt",
                description: "【掛詞「かれ」の深掘り解説】「植物が『枯れる』」と「人が『離れる（疎遠になる）』」を掛ける。秋から冬への自然の衰退（草木が枯れる）と、男の足が遠のいて愛が冷めていく悲しみ（離る）を一致させる絶妙な修辞。"
            },
            {
                id: "d05_s03",
                name: "ステージ3: ひのき（日・木）",
                recommendedPower: "8,000",
                icon: "fa-tree",
                description: "【掛詞「ひのき」の深掘り解説】樹木の「檜（ヒノキ）」と「日の気（太陽の光）」あるいは「一言（ひときわ）」などを重ねる。地名（飛騨の檜原など）と掛けて、豊かな自然と恋の鬱屈した情念を表現する際に用いられる。"
            },
            {
                id: "d05_s04",
                name: "ステージ4: ながめ（長雨・眺め）",
                recommendedPower: "8,200",
                icon: "fa-eye",
                description: "【掛詞「ながめ」の深掘り解説】「長雨（降り続く雨）」と「眺め（物思いに沈んでぼんやり遠くを見ること）」を掛ける。小野小町の「花の色はうつりにけりないづらへに我が身世にふるながめせしまに」が超有名。雨景色と物思いのシンクロ。"
            },
            {
                id: "d05_s05",
                name: "ステージ5: あき（秋・飽き）",
                recommendedPower: "8,400",
                icon: "fa-heart-crack",
                description: "【挂詞「あき」の深掘り解説】季節の「秋」と「飽き（嫌気がさす・飽きる）」を掛ける。「秋風が吹く」という表現の中に「相手の心が自分に飽きて離れていく（秋風＝厭き風）」という意味を忍ばせる、切ない恋歌の定番。"
            },
            {
                id: "d05_s06",
                name: "ステージ6: あふみ（近江・会ふ身）",
                recommendedPower: "8,500",
                icon: "fa-handshake",
                description: "【掛詞「あふみ」の深掘り解説】地名の「近江（滋賀県・近江の海＝琵琶湖）」と「会ふ身（男女がめぐり逢う運命の身）」を掛ける。旅の途中の景観と、逢いたい人になかなか逢えない恋の苦しさを重ね合わせる歌枕（地名）掛詞。"
            }
        ]
    },
    {
        id: 6,
        title: "ダンジョン6: 枕詞の基本と導き語",
        recommendedPower: "8,600〜9,800",
        icon: "fa-book-bookmark",
        stages: [
            {
                id: "d06_s01",
                name: "ステージ1: あしひきの（山）",
                recommendedPower: "8,600",
                icon: "fa-mountain",
                description: "【枕詞「あしひきの」の深掘り解説】原則5音で特定の語を導く慣用表現（訳さないことが多い）。「山」「峰」「岩」「もみじ」などに掛かる。語源は「足引き（足を引きずりながら登る険しい山）」とされる。「あしひきの山どり……」など。"
            },
            {
                id: "d06_s02",
                name: "ステージ2: ぬばたまの（夜・黒）",
                recommendedPower: "8,800",
                icon: "fa-moon",
                description: "【枕詞「ぬばたまの」の深掘り解説】ヒオウギの植物の種子（黒く光る実）が「ぬばたま」。「夜」「黒」「髪」「夢」「月」など、黒や夜に関連する言葉を導く。漆黒の闇の深さと詩的な情緒を喚起する。"
            },
            {
                id: "d06_s03",
                name: "ステージ3: ひさかたの（光・天）",
                recommendedPower: "9,000",
                icon: "fa-sun",
                description: "【枕詞「ひさかたの」の深掘り解説】「天（天）」「光」「月」「日」「空」「雨」など天空に関する言葉に掛かる。語源は「久しく光り輝く」または「日射す方」など諸説あり、壮大でスケールの大きい情景を創り出す。"
            },
            {
                id: "d06_s04",
                name: "ステージ4: ちはやぶる（神）",
                recommendedPower: "9,200",
                icon: "fa-torii-gate",
                description: "【枕詞「ちはやぶる」の深掘り解説】「神」「社」「宇治」などに掛かる。「千早振る」は荒々しく強大な神の勢威を表す形容詞が固定化したもの。在原業平の「ちはやぶる神代も聞かず竜田川……」で超有名。"
            },
            {
                id: "d06_s05",
                name: "ステージ5: からころも（着る）",
                recommendedPower: "9,400",
                icon: "fa-shirt",
                description: "【枕詞「からころも」の深掘り解説】唐（中国）から渡来した優美な衣服「唐衣」。「着る」「裾（すそ）」「裁つ」「返る（着物を裏返す）」など、衣服に関連する動作や言葉を導く。旅の衣や裁断のイメージと結びつく。"
            },
            {
                id: "d06_s06",
                name: "ステージ6: あずさゆみ（引く・春）",
                recommendedPower: "9,600",
                icon: "fa-bullseye",
                description: "【枕詞「あずさゆみ」の深掘り解説】梓の木で作った弓。「引く」「張る（春）」「射る」「音」「寄る」などに掛かる。弓を『引き寄せる』ことから「寄る」、弦を『張る』ことから同音の「春」を導くなどテクニカルな展開を見せる。"
            },
            {
                id: "d06_s07",
                name: "ステージ7: たまもかる（沖・海）",
                recommendedPower: "9,700",
                icon: "fa-water",
                description: "【枕詞「たまもかる」の深掘り解説】「玉藻（美しい海藻）を刈り取る」景色から、「沖」「海」「辛荷（かるに）」「敏馬（みぬめ）」などの海辺や水に関わる言葉を導く。万葉集などの古代的な歌風によく見られる。"
            },
            {
                id: "d06_s08",
                name: "ステージ8: しきしまの（大和）",
                recommendedPower: "9,800",
                icon: "fa-landmark",
                description: "【枕詞「しきしまの」の深掘り解説】「大和（日本の国・奈良県）」に掛かる。崇神天皇の宮殿「磯城島（しきしま）宮」に由来し、日本の国柄や和歌の心（敷島の道＝歌道）そのものを表す尊い枕詞として用いられた。"
            }
        ]
    },
    {
        id: 7,
        title: "ダンジョン7: 男性・女性の伝統装束",
        recommendedPower: "9,900〜11,000",
        icon: "fa-vest",
        stages: [
            {
                id: "d07_s01",
                name: "ステージ1: 束帯（儀式正装）",
                recommendedPower: "9,900",
                icon: "fa-crown",
                description: "【束帯（そくたい）の深掘り解説】男性貴族の最も格式高い超第一級の正装。宮中での公式儀式や公務で着用。冠（かんむり）をかぶり、袍（ほう：上着）、石帯（せきたい：宝石つきの革ベルト）、袴を履き、手に笏（しゃく）を持つ。色で位階（官位）が定められていた。"
            },
            {
                id: "d07_s02",
                name: "ステージ2: 直衣（普段着）",
                recommendedPower: "10,100",
                icon: "fa-user-tie",
                description: "【直衣（のうし）の深掘り解説】貴族男性の日常の私服（普段着）。「直（なお）に着る」から命名。束帯よりゆったりとして着心地が良く、色柄も自由に選べた。ただし天皇や公卿（上級貴族）は直衣で特別な許し（直衣昇殿）を得れば宮中でも着られた。"
            },
            {
                id: "d07_s03",
                name: "ステージ3: 狩衣（野外着）",
                recommendedPower: "10,300",
                icon: "fa-person-hiking",
                description: "【狩衣（かりぎぬ）の深掘り解説】もとは鷹狩りなどの野外活動・スポーツ用の運動着。袖ぐりが開いており動きやすい。平安中期以降、貴族の気軽な外出着・日常着として大流行した。頭には烏帽子（えぼし）を合わせる。"
            },
            {
                id: "d07_s04",
                name: "ステージ4: 水干（武士・庶民）",
                recommendedPower: "10,500",
                icon: "fa-vest",
                description: "【水干（すいかん）の深掘り解説】庶民や下級役人・武士の作業着・日常着。晴れ着として水で洗って乾かして使ったことが語源。首元を紐で結ぶ。後に鎌倉時代にかけて武士の公式衣服（袴腰）へと発展していく。"
            },
            {
                id: "d07_s05",
                name: "ステージ5: 十二単（唐衣・裳）",
                recommendedPower: "10,700",
                icon: "fa-wand-magic-sparkles",
                description: "【十二単（じゅうにひとえ：五衣唐衣裳）の深掘り解説】女性宮廷装束の最高正装。一番上に「唐衣（からぎぬ）」、後ろに長い「裳（も）」を引き、何枚も重ねた「五衣（いつつぎぬ）」の襟元や袖口からグラデーション（かさねの色目）を見せて美を競った。"
            },
            {
                id: "d07_s06",
                name: "ステージ6: 烏帽子と檜扇",
                recommendedPower: "10,850", icon: "fa-hat-wizard",
                description: "【烏帽子（えぼし）と檜扇（ひおうぎ）の深掘り解説】成人男性が頭を隠す黒い帽子「烏帽子」。平安男性は人前で裸頭を晒すことを「耐えがたい恥」とした。「檜扇」は薄い檜板を重ねた扇で、儀礼用・メモ帳・顔を隠す道具として男女ともに所持した。"
            },
            {
                id: "d07_s07",
                name: "ステージ7: 袿と小袿",
                recommendedPower: "11,000",
                icon: "fa-layer-group",
                description: "【袿（うちき）と小袿（こうちき）の深掘り解説】女性の日常着および準正装。十二単から一番上の唐衣と裳を取り脱いだ形が「袿姿」。日常のリラックスした姿であり、男が垣間見（かいまみ）で目撃する姫君の優美な衣裳の代表格。"
            }
        ]
    },
    {
        id: 8,
        title: "ダンジョン8: 位階と官職（身分秩序）",
        recommendedPower: "11,200〜12,500",
        icon: "fa-ranking-star",
        stages: [
            {
                id: "d08_s01",
                name: "ステージ1: 地下と殿上人",
                recommendedPower: "11,200",
                icon: "fa-user-shield",
                description: "【地下（じげ）と殿上人（てんじょうびと）の深掘り解説】平安時代の天と地ほどの格差。三位以上の公卿および五位以上の限られた者（四位・五位の蔵人など）が「清涼殿の殿上の間に昇る（昇殿）」を許された「殿上人（上人）」。許されない五位以下を「地下（じげ）」と呼び差別された。"
            },
            {
                id: "d08_s02",
                name: "ステージ2: 国司と受領",
                recommendedPower: "11,400",
                icon: "fa-coins",
                description: "【国司（こくし）と受領（ずりょう）の深掘り解説】地方行政官。国司の長官（守）や次官（介）のうち、実際に現地へ赴任して税収管理を行う最高責任者を「受領（ずりょう）」と呼ぶ。凄まじい財力を蓄え「受領は倒れる所に土をつかめ」と称されるほどたくましく富を貪った。"
            },
            {
                id: "d08_s03",
                name: "ステージ3: 蔵人頭と弁官",
                recommendedPower: "11,600",
                icon: "fa-scroll",
                description: "【蔵人頭（くろうんどのとう）と弁官（べんかん）の深掘り解説】実務のエリートコース。「蔵人頭」は天皇の秘書官長で定員2名。政界の登竜門。「弁官」は太政官の政務実務（八省の統括）を担う実務官僚。両者を兼ねる「頭弁（とうのべん）」は超超エリートとされる。"
            },
            {
                id: "d08_s04",
                name: "ステージ4: 参議（宰相）",
                recommendedPower: "11,800",
                icon: "fa-building-columns",
                description: "【参議（さんぎ／さいしょう）の深掘り解説】太政官の最高首脳会議（陣の定め）に参加できる審議官。「宰相（さいしょう）」とも呼ばれる。四位から三位に上り詰め、貴族の最高峰「公卿（くぎょう）」の仲間入りを果たす境界線の最重要官職。"
            },
            {
                id: "d08_s05",
                name: "ステージ5: 中納言・大納言",
                recommendedPower: "12,000",
                icon: "fa-chess-knight",
                description: "【中納言・大納言の深掘り解説】大臣に次ぐ太政官の重要幹部。大臣の補佐や国政の審議を行う。「大納言」は正三位・従二位クラスの最高級貴族であり、摂関家に次ぐ勢力家系（公家）の当主たちが就任した。"
            },
            {
                id: "d08_s06",
                name: "ステージ6: 三公（太政・左右大臣）",
                recommendedPower: "12,200",
                icon: "fa-chess-queen",
                description: "【三公（さんこう）：太政大臣・左大臣・右大臣】政府の最高権力職。「太政大臣」は師範的・名誉職。「左大臣」が実質的な内閣総理大臣（政務の最高責任者）。「右大臣」は左大臣に次ぐナンバー2。"
            },
            {
                id: "d08_s07",
                name: "ステージ7: 摂政・関白",
                recommendedPower: "12,400",
                icon: "fa-chess-king",
                description: "【摂政（せっしょう）・関白（かんぱく）の深掘り解説】「摂政」は幼少・女性の天皇に代わって全権を代行する職。「関白」は成人の天皇の政務を最終決定前にすべて事前閲覧・決済する職。藤原北家（摂関家）がこれを独占し「摂関政治」を行なった。"
            },
            {
                id: "d08_s08",
                name: "ステージ8: 天皇と上皇",
                recommendedPower: "12,500",
                icon: "fa-crown",
                description: "【天皇（てんのう）と上皇（じょうこう：院）】国の最高権威。天皇が位を譲ると「太上天皇（上皇）」となり、出家すると「法皇」と呼ばれる。平安後期（白河上皇以降）は、上皇が「院庁」を開いて自ら政務を行う「院政」が始まり、皇室が最強の権力を握った。"
            }
        ]
    },
    {
        id: 9,
        title: "ダンジョン9: 平安京の地理と内裏の殿舎",
        recommendedPower: "12,700〜14,000",
        icon: "fa-kaaba",
        stages: [
            {
                id: "d09_s01",
                name: "ステージ1: 紫宸殿（正殿）",
                recommendedPower: "12,700",
                icon: "fa-monument",
                description: "【紫宸殿（ししんでん／南殿）の深掘り解説】内裏（皇居）の最も重要な正殿。即位の礼や節会（せちえ）など国家的公式儀式を行う。南庭には東に「右近の橘」、西に「左近の桜」が植えられている（天皇から見て左右）。"
            },
            {
                id: "d09_s02",
                name: "ステージ2: 清涼殿（御所）",
                recommendedPower: "12,900",
                icon: "fa-house-chimney-window",
                description: "【清涼殿（せいりょうでん）の深掘り解説】天皇が日常の生活を送り、日常政務（奏上や執務）を行う御所。「昼の御座（ひるのおまし）」や「御湯殿」「御溝水（みみず）」などがあり、『枕草子』や『源氏物語』の主要な舞台。"
            },
            {
                id: "d09_s03",
                name: "ステージ3: 弘徽殿（后妃の局）",
                recommendedPower: "13,100",
                icon: "fa-door-closed",
                description: "【弘徽殿（こきでん）の深掘り解説】後宮（后妃たちの住む後宮七殿五舎）の中で最も格式が高い殿舎。清涼殿の北西に位置し、勢力のある第一位の女御・中宮が住んだ（例：『源氏物語』の弘徽殿女御）。"
            },
            {
                id: "d09_s04",
                name: "ステージ4: 藤壺（飛香舎）",
                recommendedPower: "13,300",
                icon: "fa-spa",
                description: "【藤壺（ふじつぼ／飛香舎：ひぎょうしゃ）の深掘り解説】庭に美しい藤の花が植えられていることから「藤壺」と呼ばれる。中宮や有力な妃の居所とされることが多く、『源氏物語』の藤壺の宮（光源氏の憧れの人）で余りにも有名。"
            },
            {
                id: "d09_s05",
                name: "ステージ5: 登花殿・淑景舎",
                recommendedPower: "13,500",
                icon: "fa-archway",
                description: "【登花殿（とうかでん）・淑景舎（しげいしゃ／桐壺）の深掘り解説】淑景舎は庭に桐が植えられており「桐壺」と呼ばれる（光源氏の母・桐壺更衣の居所）。清涼殿から最も遠く不便な位置にあったため、身分の低い更衣が充てられた。"
            },
            {
                id: "d09_s06",
                name: "ステージ6: 朱雀大路と羅城門",
                recommendedPower: "13,800",
                icon: "fa-road",
                description: "【朱雀大路（すざくおおじ）と羅城門（らじょうもん）】平安京の中央を南北に貫く幅約84メートルの大メインストリート。北端に朱雀門（内裏の正門）、南端に都の玄関口「羅城門」（芥川龍之介『羅生門』の舞台）が位置した。"
            },
            {
                id: "d09_s07",
                name: "ステージ7: 賀茂川と鳥羽",
                recommendedPower: "14,000",
                icon: "fa-water",
                description: "【賀茂川（かもがわ）と鳥羽（とば）】都の東を流れる「鴨川（賀茂川）」は出水・洪水を繰り返し、白河法皇をして「天下の三不如意（賀茂川の水・双六の賽・山法師）」と言わしめた。「鳥羽」は都の南の交通・物流の要衝であり、院政期の離宮が建てられた。"
            }
        ]
    },
    {
        id: 10,
        title: "ダンジョン10: 出家と信仰（仏教常識）",
        recommendedPower: "21,782〜23,777",
        icon: "fa-hands-praying",
        stages: [
            {
                id: "d10_s01",
                name: "ステージ1: 出家と落飾",
                recommendedPower: "21,782",
                icon: "fa-scissors",
                description: "【出家（しゅっけ）と落飾（らくしょく）の深掘り解説】髪を剃り（落飾）、世俗の身分・欲望・政治闘争を捨てて仏門に入ること。病気や愛する人の死、政治的敗北、あるいは極楽往生を願って行われた。貴族の人生の最終的救済の手段。"
            },
            {
                id: "d10_s02",
                name: "ステージ2: 勤行と法要",
                recommendedPower: "14,500",
                icon: "fa-book-open",
                description: "【勤行（ごんぎょう）と法要（ほうよう）の深掘り解説】「勤行」は決まった時間に読経・加持祈祷を行う日課。「法要」は追善供養や病気平癒のために僧侶（行者・阿闍梨）を招いて行う仏教儀式。加持祈祷によって物の怪を調伏（ちょうぶく）した。"
            },
            {
                id: "d10_s03",
                name: "ステージ3: 後世菩提の祈り",
                recommendedPower: "14,800",
                icon: "fa-hands-praying",
                description: "【後世菩提（ごせぼだい）の深掘り解説】「後世（来世・死後の世界）」における冥福（菩提）を祈ること。現世の富や繁栄以上に、死後に地獄へ落ちず浄土に生まれることを平安貴族は切実・切望に祈願し、寺院を建立し仏像を造立した。"
            },
            {
                id: "d10_s04",
                name: "ステージ4: 宿世と因果応報",
                recommendedPower: "15,000",
                icon: "fa-rotate",
                description: "【宿世（すくせ）と因果応報の深掘り解説】「宿世（すくせ／すくせの契り）」は前世からの深い縁・宿命。「因果応報」は前世の善悪の行為（業：カルマ）が必ず現世の幸・不幸となって現れるという思想。逃れられない不幸を「宿世」として受け入れた。"
            },
            {
                id: "d10_s05",
                name: "ステージ5: 極楽浄土と阿弥陀仏",
                recommendedPower: "15,300",
                icon: "fa-ankh",
                description: "【極楽浄土（ごくらくじょうど）と阿弥陀仏】西方の彼方にある苦しみのない理想郷。平安中期の恵心僧都源信『往生要集』により浄土信仰が大流行し、「南無阿弥陀仏」と唱えて阿弥陀如来のお迎え（来迎）を待つ文化が定着した。"
            },
            {
                id: "d10_s06",
                name: "ステージ6: 諸行無常の響き",
                recommendedPower: "15,500",
                icon: "fa-bell-concierge",
                description: "【諸行無常（しょぎょうむじょう）の深掘り解説】この世のすべての現象は変化し続け、永遠なるものは一つもないという仏教の根本真理。『平家物語』冒頭「祇園精舎の鐘の音、諸行無常の響きあり」に代表される中世文学の骨格。"
            }
        ]
    },
    {
        id: 11,
        title: "ダンジョン11: 陰陽道と平安の禁忌",
        recommendedPower: "25,058〜27,279",
        icon: "fa-hat-wizard",
        stages: [
            {
                id: "d11_s01",
                name: "ステージ1: 物忌み（忌み籠もり）",
                recommendedPower: "25,058",
                icon: "fa-ban",
                description: "【物忌み（ものいみ）の深掘り解説】凶兆（不吉な夢、怪異、凶日）が現れた際、災い・祟りを避けるために一定期間外出を控え、家に閉じこもって身を清めること。門に「物忌」の札を貼り、客の訪問も断った。"
            },
            {
                id: "d11_s02",
                name: "ステージ2: 方違え（吉方へ移動）",
                recommendedPower: "16,100",
                icon: "fa-route",
                description: "【方違え（かたたがえ）の深掘り解説】行きたい目的地がその日の凶方位（天一神などの神がいる方位）に当たるとき、前夜に別の吉方向（方違え所）に一泊移動し、方角を変えてから目的地に向かう平安貴族の必須呪術行動。"
            },
            {
                id: "d11_s03",
                name: "ステージ3: 庚申待ち",
                recommendedPower: "16,400",
                icon: "fa-bed",
                description: "【庚申待ち（こうしんまち）の深掘り解説】60日ごとの「庚申（こうしん）の日」の夜、人間の体内にいる「三尸（さんし）の虫」が寝ている間に抜け出して天帝に悪事を告げ口するのを防ぐため、一晩中起きて詩歌や宴会をして過ごす徹夜行事。"
            },
            {
                id: "d11_s04",
                name: "ステージ4: 呪詛と式神の使役",
                recommendedPower: "16,700",
                icon: "fa-wand-sparkles",
                description: "【呪詛（じゅそ）と式神（しきがみ）の深掘り解説】陰陽師が目に見えない霊体・神霊「式神」を自由自在に操り、吉凶を占い、あるいは政敵・憎い相手に呪い（呪詛）をかける呪術行為。密かに相手の髪の毛や人形で呪いを行った。"
            },
            {
                id: "d11_s05",
                name: "ステージ5: 鬼門と天道の禁",
                recommendedPower: "17,000",
                icon: "fa-skull-crossbones",
                description: "【鬼門（きもん）の深掘り解説】北東（艮：うしとら）の方角。邪気や鬼が侵入する最も不吉な方位。都づくり（延暦寺の建立）や寝殿造の建築設計において、鬼門を封じるための特別な神社仏閣・魔除けが設置された。"
            },
            {
                id: "d11_s06",
                name: "ステージ6: 陰陽師の秘術",
                recommendedPower: "17,200",
                icon: "fa-star-of-david",
                description: "【陰陽師（おんみょうじ）の深掘り解説】陰陽五行説に基づき、天文・暦法・占術・呪術をつかさどる専門職（安倍晴明が有名）。天皇や貴族の生活設計（吉日選び、建築、改元、災難除け）のすべてをコントロールするアドバイザー。"
            }
        ]
    },
    {
        id: 12,
        title: "ダンジョン12: 年中行事（春・夏）",
        recommendedPower: "28,695〜31,155",
        icon: "fa-champagne-glasses",
        stages: [
            {
                id: "d12_s01",
                name: "ステージ1: 子の日の遊び（正月）",
                recommendedPower: "28,695",
                icon: "fa-gifts",
                description: "【子の日の遊び（ねのひのあそび）の深掘り解説】正月最初の子（ね）の日に野山に出かけ、小さな松（根引きの松）を抜いて長寿を祈り、若菜を摘んで七草粥にして食べる宴。万葉集や古今集にも多く詠まれる新春の風流行事。"
            },
            {
                id: "d12_s02",
                name: "ステージ2: 白馬の節会",
                recommendedPower: "17,800",
                icon: "fa-horse",
                description: "【白馬の節会（あおうまのせちえ）の深掘り解説】正月7日、天皇が豊楽殿に出て、庭で引き回される21匹の白馬（青馬）をご覧になる儀式。年の始めに白馬（陽気の象徴）を見ると、その年の邪気が祓われて不老長寿になると信じられた。"
            },
            {
                id: "d12_s03",
                name: "ステージ3: 踏歌の節会",
                recommendedPower: "18,100",
                icon: "fa-music",
                description: "【踏歌の節会（とうかのせちえ）の深掘り解説】正月14日・15日頃、男たち・女たちが大地を踏み鳴らしながら歌い舞う宮廷儀式。春の到来を祝い、地の神を沈めて豊作と平安を祈るエネルギッシュな舞踊行事。"
            },
            {
                id: "d12_s04",
                name: "ステージ4: 上巳の節句（雛遊び）",
                recommendedPower: "18,400",
                icon: "fa-child-dress",
                description: "【上巳の節句（じょうしのせっく：3月3日）】曲水の宴（庭の小川に杯を浮かべて歌を詠む）を行い、紙で作った人形（ひとがた）に自分の罪や穢れを移して川や海に流すお祓い（流し雛）を行った。これが現代の雛祭りのルーツ。"
            },
            {
                id: "d12_s05",
                name: "ステージ5: 賀茂祭（葵祭）",
                recommendedPower: "18,600",
                icon: "fa-clover",
                description: "【賀茂祭（かもまつり／葵祭：4月中旬）】平安時代に「まつり」と言えば単に賀茂祭を指すほど最大級のイベント。勅使や斎院（さいいん）の絢爛豪華な行列が上賀茂・下鴨神社へ参詣する。参列者は皆、牛車や冠に葵（あおい）の葉を飾った。"
            },
            {
                id: "d12_s06",
                name: "ステージ6: 端午の節句（菖蒲）",
                recommendedPower: "18,800",
                icon: "fa-spa",
                description: "【端午の節句（たんごのせっく：5月5日）】邪気を祓うため、薬草である菖蒲（しょうぶ）や蓬（よもぎ）を屋根の軒に葺き（ふき）、菖蒲を冠に挿し、菖蒲酒を飲んだ。菖蒲が「勝負・尚武」に通じることから後に男子の祭りとなる。"
            },
            {
                id: "d12_s07",
                name: "ステージ7: 夏祓え（御祓）",
                recommendedPower: "19,000",
                icon: "fa-water",
                description: "【夏祓え（なつはらえ：6月30日）】「水無月の夏越の祓する人は千歳の命延ぶというなり」。上半期6ヶ月間の罪や穢れを払うため、茅の輪（ちのわ）をくぐり、川辺で御祓（みそぎ）をして下半期の無病息災を祈った。"
            }
        ]
    },
    {
        id: 13,
        title: "ダンジョン13: 年中行事（秋・冬）",
        recommendedPower: "32,720〜35,602",
        icon: "fa-cloud-moon",
        stages: [
            {
                id: "d13_s01",
                name: "ステージ1: 七夕（乞巧奠）",
                recommendedPower: "32,720",
                icon: "fa-star",
                description: "【七夕（たなばた／乞巧奠：きっこうでん：7月7日）】織女星（裁縫・詩歌の神）にあやかり、女子の手芸・和歌・書道の上達を祈る祭典。梶の葉に和歌を書き、瓜やササゲをお供えし、織女と牽牛の年一度の逢瀬を祝福した。"
            },
            {
                id: "d13_s02",
                name: "ステージ2: 重陽の節句（菊綿）",
                recommendedPower: "19,600",
                icon: "fa-spa",
                description: "【重陽の節句（ちょうようのせっく：9月9日）】陽の極数「9」が重なるめでたい日。前夜から菊の花に綿（菊の被綿：きくのわた）を被せておき、朝露と菊の香りが染み込んだ真綿で肌を拭って若返りと長寿を祈った。"
            },
            {
                id: "d13_s03",
                name: "ステージ3: 月見（十五夜）",
                recommendedPower: "20,000",
                icon: "fa-moon",
                description: "【十五夜（じゅうごや：8月15日）の観月宴】1年で最も月が美しい「中秋の名月」。池に船を浮かべて月影（水面に映る月）を愛で、管弦を奏で、即興で素晴らしい和歌を詠み競い合う王朝美学の絶頂。"
            },
            {
                id: "d13_s04",
                name: "ステージ4: 五節の舞姫",
                recommendedPower: "20,300",
                icon: "fa-person-dancing",
                description: "【五節の舞姫（ごせちのまいひめ：11月）】新嘗祭（にいなめさい）の際、貴族の令嬢（未婚の少女）4〜5名が選ばれて宮中で舞（天女の舞）を披露する夢の舞台。選び抜かれた舞姫の美しさは絶大な話題となった。"
            },
            {
                id: "d13_s05",
                name: "ステージ5: 追儺（節分の鬼払い）",
                recommendedPower: "20,600",
                icon: "fa-mask",
                description: "【追儺（ついな：大晦日12月30日）】大晦日の夜、疫病や災いをもたらす悪鬼を追い払う儀式。「方相氏（ほうそうし）」という金色の四つの目を持つ仮面をかぶった者が、桃の木の弓と葦の矢を持って鬼を駆逐した（現代の節分・豆まきのルーツ）。"
            },
            {
                id: "d13_s06",
                name: "ステージ6: 仏名会（罪障消滅）",
                recommendedPower: "21,000",
                icon: "fa-hands-praying",
                description: "【仏名会（ぶつみょうえ：12月17日〜19日）】年末の3日間、宮中や寺院で三世（過去・現在・未来）の仏の御名を唱え呼び上げ、この1年間（あるいは生涯）に犯した無数の罪や穢れを懺悔・消滅させる荘厳な法要。"
            }
        ]
    },
    {
        id: 14,
        title: "ダンジョン14: 平安の結婚と恋愛観",
        recommendedPower: "37,510〜40,314",
        icon: "fa-heart",
        stages: [
            {
                id: "d14_s01",
                name: "ステージ1: 垣間見（不意の覗き）",
                recommendedPower: "37,510",
                icon: "fa-eye",
                description: "【垣間見（かいまみ）の深掘り解説】平安恋愛のすべての始まり。男が屋敷の隙間や垣根越しに、姿を隠している姫君を覗き見すること。女の姿を見ることは即「求婚」を意味し、運命的な恋のドラマが動き出す。"
            },
            {
                id: "d14_s02",
                name: "ステージ2: 懸想文（和歌の贈答）",
                recommendedPower: "21,800",
                icon: "fa-envelope",
                description: "【懸想文（けそうぶみ）と歌のやり取り】垣間見で恋に落ちた男は情熱的な和歌（懸想文）を恋文として送る。紙の質・色・結び方・添える花（枝）のセンス、文字の筆跡で男の知性が試され、女房の取りなしを経て返歌が届く。"
            },
            {
                id: "d14_s03",
                name: "ステージ3: 三日夜の餅",
                recommendedPower: "22,200",
                icon: "fa-cookie",
                description: "【三日夜の餅（みかよのもちい）の深掘り解説】男が女のもとへ3夜連続で通い詰めた3日目の夜（正式成立）、共寝の後に小さな餅（三日夜の餅）を食べる新郎新婦の儀式。翌朝、披露宴（所顕：ところあらわし）が開かれ結婚が承認された。"
            },
            {
                id: "d14_s04",
                name: "ステージ4: 通い婚（婿取り）",
                recommendedPower: "22,500",
                icon: "fa-house-user",
                description: "【通い婚（かよいこん／婿取り）の深掘り解説】平安時代は「一夫多妻制」かつ男が女の家に夜な夜な通う「通い婚」。子どもは女の実家で育てられ、女の実家の経済力（父親の権力）が子の出世を決定づけた。"
            },
            {
                id: "d14_s05",
                name: "ステージ5: 後朝の絹（早朝の別れ）",
                recommendedPower: "22,800",
                icon: "fa-sun",
                description: "【後朝（きぬぎぬ）の文と切なさ】共に夜を明かした翌朝、男は日の出前に立ち去る。自分の邸に戻った男は、すぐさま愛の余韻と切なさを詠んだ「後朝の文（絹）」を女に贈るのが絶対のルール・マナーであった。"
            },
            {
                id: "d14_s06",
                name: "ステージ6: 愛執と物の怪の恐怖",
                recommendedPower: "23,000",
                icon: "fa-ghost",
                description: "【愛執（あいしゅう）と生霊・物の怪】男の足が遠のいた時（途絶え）、見捨てられた女の強烈な嫉妬や恨みは生霊（いきすだま）となって男の正妻や他の女を崇り殺す（『源氏物語』六条御息所が典型）。"
            }
        ]
    },
    {
        id: 15,
        title: "ダンジョン15: 住宅建築（寝殿造）",
        recommendedPower: "47,057〜50,461",
        icon: "fa-vihara",
        stages: [
            {
                id: "d15_s01",
                name: "ステージ1: 寝殿（主屋）",
                recommendedPower: "47,057",
                icon: "fa-house",
                description: "【寝殿（しんでん）の深掘り解説】敷地中央に南面して建つ正妻・主人の居住する中心建物。中央の「母屋（もや）」とその四方の「庇（ひさし）」からなる。壁が極めて少なく、開け放たれた広大な空間。"
            },
            {
                id: "d15_s02",
                name: "ステージ2: 対の屋（付属屋）",
                recommendedPower: "23,900",
                icon: "fa-city",
                description: "【対の屋（たいのや）の深掘り解説】寝殿の東西および北側に配置された別棟の建物（東の対・西の対・北の対）。家族、側室、子どもたち、来客などの居室として用いられた。"
            },
            {
                id: "d15_s03",
                name: "ステージ3: 渡殿と釣殿",
                recommendedPower: "24,300",
                icon: "fa-bridge",
                description: "【渡殿（わたどの）と釣殿（つりどの）】寝殿と対の屋を結ぶ廊下が「渡殿」。南庭の池に臨んで突き出た廊下の先端にある建物が「釣殿」。涼んだり月見をしたり、釣りをし宴会を楽しむ風流スポット。"
            },
            {
                id: "d15_s04",
                name: "ステージ4: 簾と御簾",
                recommendedPower: "24,600",
                icon: "fa-bars",
                description: "【簾（すだれ）と御簾（みす）の深掘り解説】細い竹を編んだ目隠し。貴族の境界線。特に高貴な女性の居所に垂らす緑色の縁取りがついたものを「御簾（みす）」と呼ぶ。内側からは外が見えるが、外からは内が見えない。"
            },
            {
                id: "d15_s05",
                name: "ステージ5: 几帳と屏風",
                recommendedPower: "24,900",
                icon: "fa-border-all",
                description: "【几帳（きちょう）と屏風（びょうぶ）】室内を仕切る可動式家具。「几帳」はT字型の木枠に絹布を垂らしたパーテーション。「屏風」は絵（大和絵など）が描かれた折り畳み式の衝立。"
            },
            {
                id: "d15_s06",
                name: "ステージ6: 透垣と前庭",
                recommendedPower: "25,100", icon: "fa-tree",
                description: "【透垣（すいがき）と南庭（みなみてい）】「透垣」は間が空いた風通しの良い板垣。「南庭」は寝殿の南側に広がる白砂の広場。儀式・蹴鞠・演劇（舞楽）の舞台となり、南側に大きな池と中島が造られた。"
            },
            {
                id: "d15_s07",
                name: "ステージ7: 蔀戸と塗籠",
                recommendedPower: "25,200",
                icon: "fa-door-closed",
                description: "【蔀戸（しとみど）と塗籠（ぬりごめ）】「蔀戸」は格子に取り付けた板戸で、上半分を吊り上げて開放する。「塗籠」は壁でしっかり囲まれた頑丈な部屋。納戸（宝物庫）や主人の寝室として用いられた。"
            }
        ]
    },
    {
        id: 16,
        title: "ダンジョン16: 乗り物と移動手段",
        recommendedPower: "53,869〜57,867",
        icon: "fa-truck-field",
        stages: [
            {
                id: "d16_s01",
                name: "ステージ1: 網代車（普及型牛車）",
                recommendedPower: "53,869",
                icon: "fa-cow",
                description: "【網代車（あじろぐるま）の深掘り解説】檜や竹を網状に編んだ「網代」で車屋根を覆った牛車。最も一般的・日常的な乗用牛車であり、四位・五位の貴族や公卿の普段乗りとして広く愛用された。"
            },
            {
                id: "d16_s02",
                name: "ステージ2: 檳榔毛車（最高級牛車）",
                recommendedPower: "26,000",
                icon: "fa-car",
                description: "【檳榔毛車（びろうげぐるま）の深掘り解説】檳榔（ビンロウ）の葉の繊維を細かく割いて屋根全体を覆った超豪華・最高級クラスの牛車。摂政・関白・大臣・上皇など極めて限られた雲上の最高権力者のみが乗ることを許された。"
            },
            {
                id: "d16_s03",
                name: "ステージ3: 輿と乗馬",
                recommendedPower: "26,400",
                icon: "fa-horse",
                description: "【輿（こし）と乗馬（じょうば）の深掘り解説】「輿」は人が手や肩で担いで運ぶ乗り物（手輿・腰輿）。天皇や皇族の移動、あるいは神聖な神事で使用。「乗馬」は主に男性貴族や武士の高速移動手段。"
            },
            {
                id: "d16_s04",
                name: "ステージ4: 車争い（賀茂祭の衝突）",
                recommendedPower: "26,800",
                icon: "fa-burst",
                description: "【車争い（くるまあらそい）の深掘り解説】賀茂祭などのイベント時、見物場所の特等席を巡って従者同士が牛車の場所を奪い合う激しい闘争。『源氏物語』で光源氏の正妻・葵の上と側室・六条御息所の牛車が激突した事件が伝説的。"
            },
            {
                id: "d16_s05",
                name: "ステージ5: 旅装束と壺装束",
                recommendedPower: "27,200",
                icon: "fa-person-hiking",
                description: "【壺装束（つぼしょうぞく）と市女笠】女性が社寺参詣（長谷寺や熊野詣）などの旅行をする際の服装。着物の裾を高く折り上げて（壺折り）動きやすくし、頭には「市女笠（いちめがさ）」をかぶり、日よけ・顔隠しの虫の垂れ布（むしのたれぎぬ）を垂らした。"
            },
            {
                id: "d16_s06",
                name: "ステージ6: 遠道の旅路",
                recommendedPower: "27,500",
                icon: "fa-route",
                description: "【関所・東国への旅路】都（京都）から遠く離れた東国（関東）や西国へ赴く旅は死と隣り合わせの苦難。伊勢・熊野参詣や国司としての赴任など、途中の関所（逢坂の関など）で詠まれる哀傷歌が文学の大きなジャンル。"
            }
        ]
    },
    {
        id: 17,
        title: "ダンジョン17: 人間関係と呼称・親族",
        recommendedPower: "61,915〜66,337",
        icon: "fa-people-roof",
        stages: [
            {
                id: "d17_s01",
                name: "ステージ1: 北の方（正妻）",
                recommendedPower: "61,915",
                icon: "fa-user-nurse",
                description: "【北の方（きたのかた）の深掘り解説】貴族の「正妻（第一の妻）」に対する敬称。寝殿造の住宅で、風当たりが少なく最も日当たりの良い北の対（あるいは北の庇）を居所としたことからこの名がついた。"
            },
            {
                id: "d17_s02",
                name: "ステージ2: 命婦と女房",
                recommendedPower: "28,400",
                icon: "fa-users",
                description: "【女房（にょうぼう）と命婦（みょうぶ）】「女房」は宮中や貴族の屋敷で部屋（房）を与えられて仕える知的な侍女（紫式部・清少納言など）。「命婦」は五位以上の位階を持つ高位の宮中女性官吏。"
            },
            {
                id: "d17_s03",
                name: "ステージ3: 随身と乳母",
                recommendedPower: "28,800",
                icon: "fa-person-breastfeeding",
                description: "【乳母（めのと）と随身（ずいしん）】「乳母」は母親に代わって貴族の子を育てる女性。実母以上の強い絆で結ばれ、その子は「乳母子（めのとご）」として強い同盟関係となる。「随身」は貴族の護衛・警護役。"
            },
            {
                id: "d17_s04",
                name: "ステージ4: 伯父（父の兄）と叔父（父の弟）",
                recommendedPower: "29,200",
                icon: "fa-user-tie",
                description: "【伯父（おじ）と叔父（おじ）の識別】漢字の使い分けに注意。「伯父」は父母の「兄（年上）」。「叔父」は父母の「弟（年下）」。「伯母・叔母」も同様。摂関家では母方の伯父・叔父が強大な後見人となった。"
            },
            {
                id: "d17_s05",
                name: "ステージ5: 伯母（母の姉）と叔母（母の妹）",
                recommendedPower: "29,600",
                icon: "fa-user",
                description: "【伯母（おば）と叔母（おば）の識別】「伯母」は父母の「姉」。「叔母」は父母の「妹」。母方の伯母・叔母は、母親が死亡した後に幼い姫君を引き取って育てる「養母」の役割を果たすことが多かった。"
            },
            {
                id: "d17_s06",
                name: "ステージ6: 御息所（皇子の母）",
                recommendedPower: "30,000",
                icon: "fa-heart",
                description: "【御息所（みやすどころ）の深掘り解説】天皇の寵愛を受け、皇子や皇女を産んだ女御・更衣に対する敬称（または東宮の妃）。『源氏物語』の六条御息所のように、気品高く高貴な女性の象徴。"
            }
        ]
    },
    {
        id: 18,
        title: "ダンジョン18: 歌合と宮廷の遊び",
        recommendedPower: "70,872〜75,519",
        icon: "fa-dice",
        stages: [
            {
                id: "d18_s01",
                name: "ステージ1: 歌合と判者の評価",
                recommendedPower: "70,872",
                icon: "fa-scroll",
                description: "【歌合（うたあわせ）と判者（はんじゃ）】歌人を左と右の二組に分け、題（春・恋など）に合わせて出された和歌の優劣を競うイベント。「判者」と呼ばれる審判役の権威が勝敗（勝ち・負け・持＝引き分け）を決定した。"
            },
            {
                id: "d18_s02",
                name: "ステージ2: 偏つき（漢字ゲーム）",
                recommendedPower: "30,900",
                icon: "fa-font",
                description: "【偏つき（へんつき）の深掘り解説】漢字の「偏（へん）」だけが書かれた紙を見て、その偏を持つ漢字を素早く答える宮中の知的インテリゲーム。『枕草子』などで女房たちが漢字の教養を自慢し競い合った。"
            },
            {
                id: "d18_s03",
                name: "ステージ3: 貝覆い（貝合わせ）",
                recommendedPower: "31,300",
                icon: "fa-puzzle-piece",
                description: "【貝覆い（かいおおい）の深掘り解説】ハマグリの貝殻360個を使用するゲーム。金箔や美しい大和絵が描かれた貝殻（出貝）と対になる貝（地貝）をぴったり合わせる。絶対に1対1しか合わないため「夫婦和合・結納」の象徴とされる。"
            },
            {
                id: "d18_s04",
                name: "ステージ4: 蹴鞠の技芸",
                recommendedPower: "31,700",
                icon: "fa-futbol",
                description: "【蹴鞠（けまり）の深掘り解説】鹿の革で作った鞠を「地面に落とさないように」足の甲で蹴り続けるスポーツ。「アリ」「ヤァ」「オウ」と声を掛け合い、勝利ではなく「相手が取りやすいように打ち返す相手への思いやり」が評価される。"
            },
            {
                id: "d18_s05",
                name: "ステージ5: 囲碁と双六",
                recommendedPower: "32,100",
                icon: "fa-chess-board",
                description: "【囲碁（いご）と盤双六（ばんすごろく）】「囲碁」は高雅な頭脳戦として貴族男女に大人気。「盤双六」はサイコロを振って駒を進めるバックギャモンに似たゲームで、あまりのギャンブル性の高さに禁止令が出るほど熱中された。"
            },
            {
                id: "d18_s06",
                name: "ステージ6: 琴・笛の管弦の興",
                recommendedPower: "32,500",
                icon: "fa-music",
                description: "【管弦（かんげん）の宴】琴（和琴・箏・琵琶）や笛（笙・篳篥・龍笛）を奏でる音楽演奏。月夜や花の下で貴族たちが演奏を合わせる「管弦の興」は、人間関係を滑らかにし情緒を高める最高の教養。"
            }
        ]
    },
    {
        id: 19,
        title: "ダンジョン19: 敬意の方向と敬語法則",
        recommendedPower: "80,580〜85,464",
        icon: "fa-comments",
        stages: [
            {
                id: "d19_s01",
                name: "ステージ1: 尊敬語（動作主へ）",
                recommendedPower: "80,580",
                icon: "fa-handshake-angle",
                description: "【尊敬語の基本原則】動作の「主体（〜する人）」を高める。話者（地の文なら筆者、会話文なら話者）から『動作の主体』へ敬意が向く。代表語：給ふ（なさる）、おはす（いらっしゃる）、のたまふ（おっしゃる）。"
            },
            {
                id: "d19_s02",
                name: "ステージ2: 謙譲語（客体・受け手へ）",
                recommendedPower: "33,400",
                icon: "fa-hands-holding",
                description: "【謙譲語の基本原則】動作の「目的語・受け手（〜に、〜をされる人）」を高める。自分の動作をへりくだることで相手を高める。話者から『動作の受け手』へ敬意が向く。代表語：申す（申し上げる）、奉る（差し上げる・〜申しあげる）。"
            },
            {
                id: "d19_s03",
                name: "ステージ3: 丁寧語（聞き手へ）",
                recommendedPower: "33,800",
                icon: "fa-comment",
                description: "【丁寧語の基本原則】話を聞いている「聞き手・読者」に直接敬意を表す。会話文では『聞き手』、地の文では『読者』へ向く。代表語：侍り（ございます・ございます）、さぶらふ（ございます・ございます）。"
            },
            {
                id: "d19_s04",
                name: "ステージ4: 二重敬語（最高敬語）",
                recommendedPower: "34,200",
                icon: "fa-crown",
                description: "【最高敬語（二重敬語）の法則】尊敬語を2つ重ねる表現。「せ給ふ・させ給ふ」「おはしまし給ふ」。皇族（天皇・中宮・皇太子など）クラスの極めて高い身分にのみ使用される。「〜なさる・お〜になる」と訳す。"
            },
            {
                id: "d19_s05",
                name: "ステージ5: 自敬表現（天皇の自称）",
                recommendedPower: "34,600",
                icon: "fa-user-gear",
                description: "【自敬表現の深掘り解説】絶対的権力者（天皇や宣旨を出す者など）が、自分自身の動作に対して尊敬語を使う特殊な表現。自分が至高の存在であることを示す古代的文法現象。"
            },
            {
                id: "d19_s06",
                name: "ステージ6: 会話文と地文の敬意判断",
                recommendedPower: "35,000",
                icon: "fa-scale-balanced",
                description: "【敬意の方向決定アルゴリズム】1. 地の文中の敬語→すべて「筆者（作者）」からの敬意。2. 会話文中の敬語→すべて「話者（喋っている人）」からの敬意。この軸を絶対にブラさないことが古文解読の鉄則。"
            }
        ]
    },
    {
        id: 20,
        title: "ダンジョン20: 入試試練・平安絵巻",
        recommendedPower: "91,092〜97,507",
        icon: "fa-book-open-reader",
        stages: [
            {
                id: "d20_s01",
                name: "ステージ1: 『大鏡』政権の攻防",
                recommendedPower: "91,092",
                icon: "fa-shield-halved",
                description: "【『大鏡（おおかがみ）』の深掘り解説】平安後期の歴史物語。190歳の繁樹と180歳の直世という超長寿のお爺さん2人が花山院の雲林院で昔語りをする形式。藤原道長の栄華とその権力闘争（花山天皇の出家事件など）を批判的・客観的に描く。"
            },
            {
                id: "d20_s02",
                name: "ステージ2: 『源氏物語』愛憎の渦",
                recommendedPower: "36,000",
                icon: "fa-heart-crack",
                description: "【『源氏物語』全54帖の深掘り解説】紫式部作の長編物語。主人公・光源氏の光と影、継母・藤壺との禁断の恋、紫の上との生涯、出家と死（雲隠）、そして息子の薫たちの宇治十帖へと続く「もののあはれ」の最高峰。"
            },
            {
                id: "d20_s03",
                name: "ステージ3: 宮廷サロンの知恵比べ",
                recommendedPower: "36,500",
                icon: "fa-lightbulb",
                description: "【定子サロン vs 彰子サロン】一条天皇の後宮。中宮定子に仕えた清少納言（『枕草子』：をかしの文化）と、中宮彰子に仕えた紫式部（『源氏物語』：もののあはれの文化）。権力と美が火花を散らした宮廷サロン文学。"
            },
            {
                id: "d20_s04",
                name: "ステージ4: 説話・軍記の英雄伝",
                recommendedPower: "37,000",
                icon: "fa-khanda",
                description: "【『今昔物語集』と『宇治拾遺物語』】庶民の滑稽な話や怪談、説話を集めた宝庫。さらに鎌倉時代の『平家物語』へと続く武士の台頭と平氏の滅亡を描く軍記物語。古代から中世への価値観の劇的な転換点。"
            },
            {
                id: "d20_s05",
                name: "ステージ5: 歌人たちの和歌対決",
                recommendedPower: "37,500",
                icon: "fa-feather",
                description: "【八代集と歌聖たちの系譜】『古今和歌集』（紀貫之ら：繊細優美な理知風）から『新古今和歌集』（藤原定家ら：幽玄・体言止めの象徴風）へ。本歌取り（ほんかとりの技法）を駆使した高度な修辞の対決。"
            },
            {
                id: "d20_s06",
                name: "ステージ6: 決戦！太政大臣の試練",
                recommendedPower: "38,000",
                icon: "fa-trophy",
                description: "【古文常識制覇の総決算】平安文化の政治構造（摂関・院政）、宗教観（浄土・陰陽道）、生活様式（寝殿造・装束）のすべてが頭に入っていれば、文章の行間や文脈が立体映像のように浮かび上がる！"
            }
        ]
    },
    {
        id: 21,
        title: "ダンジョン21: 助動詞の識別①（ぬ・ね・に）",
        recommendedPower: "103,814〜109,207",
        icon: "fa-spell-check",
        stages: [
            {
                id: "d21_s01",
                name: "ステージ1: 「ぬ」打消ず vs 完了ぬ",
                recommendedPower: "103,814",
                icon: "fa-xmark",
                description: "【「ぬ」徹底見分け方】接続と活用形で見分ける！1. 上が『未然形』なら「打消ず」の連体形（〜ない）。2. 上が『連用形』なら「完了ぬ」の終止形（〜した・〜してしまう）。例：「書か（未然）ぬ（打消）」vs「書き（連用）ぬ（完了）」。"
            },
            {
                id: "d21_s02",
                name: "ステージ2: 「ね」打消已然 vs 完了命令",
                recommendedPower: "39,000",
                icon: "fa-exclamation",
                description: "【「ね」徹底見分け方】1. 未然形＋「ね」＋ば/ど＝打消「ず」の已然形（〜ないので/ないけれど）。2. 連用形＋「ね」＋「。」＝完了「ぬ」の命令形（〜してしまえ！）。接続する活用形と文末か途中の助詞（ば・ど）で一発判定！"
            },
            {
                id: "d21_s03",
                name: "ステージ3: 「に」断定なり vs 完了ぬ連用",
                recommendedPower: "39,500",
                icon: "fa-check",
                description: "【「に」徹底見分け方】最も出題される超重要識別！1. 体言/連体形＋「に」＋あり/侍り＝断定「なり」の連用形（〜である）。2. 動詞連用形＋「に」＋き/けり/たり＝完了「ぬ」の連用形（〜てしまった）。「〜にき」「〜にけり」の「に」は100%完了！"
            },
            {
                id: "d21_s04",
                name: "ステージ4: 「に」格助詞・接続助詞の識別",
                recommendedPower: "40,000",
                icon: "fa-link",
                description: "【「に」助詞の識別】1. 体言＋「に」（＋移動動詞など）＝格助詞（〜に、〜において）。2. 活用形連体形＋「に」＋（句点なし）＝接続助詞（〜のに、〜すると）。直前の語が「体言（名詞）」か「活用形の連体形」かを必ずチェック！"
            },
            {
                id: "d21_s05",
                name: "ステージ5: 「ぬ・ね・に」完全識別演習",
                recommendedPower: "40,500",
                icon: "fa-graduation-cap",
                description: "【「ぬ・ね・に」最強アルゴリズム】1. 直前の接続形を見る（未然か連用か）。2. 後ろに「き・けり・あり・ば」があるか見る。3. 文脈で「〜ない」か「〜した」かを最終確認する。この3ステップで「ぬ・ね・に」識別は完璧！"
            }
        ]
    },
    {
        id: 22,
        title: "ダンジョン22: 助動詞の識別②（る・れ・られ）",
        recommendedPower: "116,176〜121,843",
        icon: "fa-vial",
        stages: [
            {
                id: "d22_s01",
                name: "ステージ1: 「る」受身・尊敬・自発・可能",
                recommendedPower: "116,176",
                icon: "fa-sliders",
                description: "【「る・られ」意味の見分け方】1. 心情動詞（思ふ・泣く・偲ぶ等）＋る＝【自発】（自然と〜される）。2. 上に「〜に」等の動作主がある＝【受身】（〜される）。3. 主語が高貴な人＝【尊敬】（〜なさる）。4. 打消（〜ず）を伴う＝【可能】（〜できる）。"
            },
            {
                id: "d22_s02",
                name: "ステージ2: 「れ」自発・尊敬 vs 完了り已然",
                recommendedPower: "41,500",
                icon: "fa-code-branch",
                description: "【「れ」の文法識別】1. 未然形（四段/ナ変/ラ変以外）＋「れ」＝助動詞「る」の未然/連用形。2. エ段の音（サ変未然/四段已然：リカちゃんサ変未然四段已然）＋「れ」＝完了「り」の已然形・命令形。接続の音（ア段＋れ か エ段＋れ か）で見分けよ！"
            },
            {
                id: "d22_s03",
                name: "ステージ3: 「られ」下二段活用と助動詞",
                recommendedPower: "42,000",
                icon: "fa-gears",
                description: "【「られ」の接続法則】「る」は四段・ナ変・ラ変の未然形に接続（ア段＋る）。「られ」はそれ以外の動詞（上一・下一・上二・下二・カ変・サ変）の未然形に接続（イ段/エ段/オ段＋られ）。動詞の活用種類で自動的に形が決まる！"
            },
            {
                id: "d22_s04",
                name: "ステージ4: 四段未然形＋る/下二未然形＋られ",
                recommendedPower: "42,500",
                icon: "fa-file-signature",
                description: "【助動詞「る・られ」の活用】共に「下二段活用（れ・れ・る・るる・るれ・れよ）」をする。活用形は文末や係り結び、接続助詞で判断。例：「思は・れ・ず（未然形）」「思は・るる・人（連体形）」。"
            },
            {
                id: "d22_s05",
                name: "ステージ5: 「る・れ・られ」総合識別",
                recommendedPower: "43,000",
                icon: "fa-award",
                description: "【「る・れ・られ」完璧判定フロー】1. 接続音を確認（ア段かエ段か＝る・られ vs 完了り）。2. 文中の主語と「〜に」の有無を確認。3. 心情動詞か打消の有無を確認。これで受身・尊敬・自発・可能・完了の全識別が完了する！"
            }
        ]
    },
    {
        id: 23,
        title: "ダンジョン23: 助動詞の識別③（なむ・てむ・にき）",
        recommendedPower: "129,528〜135,483",
        icon: "fa-bolt",
        stages: [
            {
                id: "d23_s01",
                name: "ステージ1: 「なむ」強意＋推量・願望",
                recommendedPower: "129,528",
                icon: "fa-wand-magic",
                description: "【「なむ」4大識別・前半】1. 未然形＋「なむ」＝他者への【他体願望】終助詞（〜してほしい）。2. 完了「ぬ」未然形「な」＋推量「む」＝【確述推量】（きっと〜だろう）。未然形接続の「なむ」は願望か確述推量！"
            },
            {
                id: "d23_s02",
                name: "ステージ2: 「なむ」係助詞・識別",
                recommendedPower: "44,000",
                icon: "fa-code",
                description: "【「なむ」4大識別・後半】3. 体言/活用形＋「なむ」＝【係助詞】（結びは連体形・強意）。4. ナ変動詞（死ぬ・死ぬ等）語幹/未然形「な」＋推量「む」。切り離せるか（係助詞）切り離せないかで見分ける！"
            },
            {
                id: "d23_s03",
                name: "ステージ3: 「てむ・なむ」確述推量",
                recommendedPower: "44,500",
                icon: "fa-bullseye",
                description: "【確述推量「てむ・なむ」の秘密】完了の助動詞（つ・ぬ）＋推量の助動詞（む）。「てむ」「なむ」「つべし」「ぬべし」「つらん」「ぬらん」。このセットを見たら「きっと〜だろう（推量）」「きっと〜しよう（意志）」と強く訳す！"
            },
            {
                id: "d23_s04",
                name: "ステージ4: 「にき・にし・しか」過去助動詞",
                recommendedPower: "45,000",
                icon: "fa-clock-rotate-left",
                description: "【「にき・にし・しか」の完全解剖】完了「ぬ」の連用形「に」＋過去「き」の活用形（基本形き・連体形し・已然形しか）。「にき（〜てしまった）」「にし（〜てしまった…）」「にしか（〜てしまったので）」。すべて【過去・完了】！"
            },
            {
                id: "d23_s05",
                name: "ステージ5: 「なむ・てむ」文法識別演習",
                recommendedPower: "45,500",
                icon: "fa-clipboard-check",
                description: "【「なむ」見分けの極意まとめ】「未然形＋なむ」→してほしい（願望）。「連用形＋なむ」→きっと〜だろう（確述推量）。「体言＋なむ」→〜ぞ/〜なむ（係助詞）。この3パターンを丸暗記すれば受験で無敵！"
            }
        ]
    },
    {
        id: 24,
        title: "ダンジョン24: 助動詞の識別④（す・さす・し・しか）",
        recommendedPower: "143,936〜150,194",
        icon: "fa-hand-point-right",
        stages: [
            {
                id: "d24_s01",
                name: "ステージ1: 「す・さす・しむ」使役 vs 尊敬",
                recommendedPower: "143,936",
                icon: "fa-user-pen",
                description: "【「す・さす・しむ」使役 vs 尊敬の絶対法則】直後に【尊敬語（給ふ・おはす等）】があるか無いかを見よ！1. 下に尊敬語が無い→100%【使役】（〜させる）。2. 下に尊敬語がある→「〜に（人に）」という使役対象があれば【使役＋尊敬】、無ければ【二重尊敬】（〜なさる）。"
            },
            {
                id: "d24_s02",
                name: "ステージ2: 「し・しか」過去き連体・已然",
                recommendedPower: "46,500",
                icon: "fa-hourglass-end",
                description: "【過去の助動詞「き」の特殊活用】（せ）・○・き・し・しか・○。1. 体言に連なる「し」は「き」の連体形（〜した…）。2. 「已然形＋ば」や「こそ〜しか」の「しか」は「き」の已然形（〜したところ/〜した）。直接体験の過去を表す。"
            },
            {
                id: "d24_s03",
                name: "ステージ3: 「し」強意副助詞の見分け",
                recommendedPower: "47,000",
                icon: "fa-bolt-lightning",
                description: "【「し」の識別】過去「き」の連体形「し」vs 強意の副助詞「し」。1. 動詞の連用形＋「し」＋体言＝過去「き」の連体形。2. 助詞や副詞＋「し」（例：よくし・法師もし）＝単なる強調（強意）の副助詞（訳さなくてもよい）。"
            },
            {
                id: "d24_s04",
                name: "ステージ4: 尊敬の補助動詞を伴う使役",
                recommendedPower: "47,500",
                icon: "fa-hands-clapping",
                description: "【「せ給ふ・させ給ふ」の構造分析】「帝、使ひを（人に）遣はさせ給ふ」。この「に」があるため、「させ」は使役（〜させ）、「給ふ」は尊敬（なさる）。合わせて「〜におさせになる」と完璧に訳し分ける！"
            },
            {
                id: "d24_s05",
                name: "ステージ5: 「す・さす・し」マスター演習",
                recommendedPower: "48,000",
                icon: "fa-medal",
                description: "【使役・尊敬・過去識別まとめ】1. 接続（四段/ナ変/ラ変未然＋す、その他未然＋さす）。2. 下の尊敬語の有無。3. 文中の「〜に」の指示対象。この3点をチェックすれば使役と尊敬の混乱は完全にゼロになる！"
            }
        ]
    },
    {
        id: 25,
        title: "ダンジョン25: 助動詞の識別⑤（なり・めり・音便）",
        recommendedPower: "159,476〜166,052",
        icon: "fa-ear-listen",
        stages: [
            {
                id: "d25_s01",
                name: "ステージ1: 「なり」断定（体言・連体）",
                recommendedPower: "159,476",
                icon: "fa-circle-check",
                description: "【「なり」の超重要2大識別・前半】1. 【体言】または【活用形の連体形】＋「なり」＝【断定・存在】（〜である、〜にある）。活用はラ変型（なら/なり・に/なり/なる/なれ/なれ）。例：「男なり（男である）」「見るなり（見るのである）」。"
            },
            {
                id: "d25_s02",
                name: "ステージ2: 「なり」伝聞・推定（終止形）",
                recommendedPower: "49,000",
                icon: "fa-bullhorn",
                description: "【「なり」の超重要2大識別・後半】2. 【活用形の終止形（ラ変型は連体形）】＋「なり」＝【伝聞・推定】（〜だそうだ、〜の音がする・〜のようだ）。例：「男もすなる（すると聞く）日記」「笛を吹き鳴らすなり（音を聞いて推定）」。"
            },
            {
                id: "d25_s03",
                name: "ステージ3: 撥音便＋なり（あんなり等）",
                recommendedPower: "49,500",
                icon: "fa-wave-square",
                description: "【撥音便＋なり（伝聞推定）】「なる（連体形）」が音便化して「ん」になり、さらに「ん」が表記されないパターン。「男もす（ん）なり」「あ（ん）なり」「た（ん）なり」。撥音便（ん）の直後の「なり」は100%【伝聞・推定】！"
            },
            {
                id: "d25_s04",
                name: "ステージ4: 「めり」視覚推定の識別",
                recommendedPower: "50,000",
                icon: "fa-eye",
                description: "【助動詞「めり」の見分けと意味】終止形（ラ変型は連体形）に接続。【視覚的推定】（〜のようだ・見たところ〜らしい）および【婉曲】（〜のようだ）。語源は「見＋あり＝みあり→めり」。目で見た様子から判断する時に使う！"
            },
            {
                id: "d25_s05",
                name: "ステージ5: 「なり・めり」完全攻略",
                recommendedPower: "50,500",
                icon: "fa-trophy",
                description: "【「なり」識別黄金ルーツ】1. 直前が体言・連体形→断定！2. 直前が終止形（または撥音便ん）→伝聞・推定！3. ナリ活用形容動詞の活用語尾（あはれなり等）ではないか確認！この3ステップで「なり」判別は100%完璧！"
            }
        ]
    },
    {
        id: 26,
        title: "ダンジョン26: 助詞と係り結びの識別",
        recommendedPower: "176,223〜183,134",
        icon: "fa-diagram-project",
        stages: [
            {
                id: "d26_s01",
                name: "ステージ1: 「で」打消接続 vs 格助詞",
                recommendedPower: "176,223",
                icon: "fa-ban",
                description: "【「で」の見分け方】1. 【動詞の未然形】＋「で」＝打消接続助詞（〜ないで）。（ず＋て＝で）。例：「食は（未然）で（〜ないで）行く」。2. 【体言】＋「で」＝格助詞（〜で：手段・場所）。接続する言葉が未然形か名詞かで見分ける！"
            },
            {
                id: "d26_s02",
                name: "ステージ2: 「ば」未然（仮定）vs 已然（確定）",
                recommendedPower: "51,500",
                icon: "fa-question",
                description: "【「ば」の超重要識別】1. 【未然形】＋ば＝【仮定条件】（もし〜ならば）。2. 【已然形】＋ば＝【確定条件】（①〜ので【原因・理由】、②〜すると【偶然】、③〜したところ【きっかけ】）。未然形か已然形かで意味が180度激変する！"
            },
            {
                id: "d26_s03",
                name: "ステージ3: 「ぞ・なむ・や・か」係り結び",
                recommendedPower: "52,000",
                icon: "fa-link",
                description: "【係り結びの法則・基本】文中に「ぞ・なむ・や・か」があると、文末は【連体形】になる（ぞ・なむ＝強意、や・か＝疑問・反語）。文中「こそ」があると文末は【已然形】になる（強意）。文章読解で文末の形を決定づける超原則！"
            },
            {
                id: "d26_s04",
                name: "ステージ4: 「こそ〜已然形、」逆接用法",
                recommendedPower: "52,500",
                icon: "fa-repeat",
                description: "【「こそ〜已然形、」の逆接流れ】「こそ〜已然形」の直後に読点（、）があって文言が下に続く場合、「〜けれども・〜だが」という【逆接（〜けれども）】で訳す。例：「見ればこそあれ、〜（見るけれど、〜）」。入試記述の減点回避ポイント！"
            },
            {
                id: "d26_s05",
                name: "ステージ5: 係助詞・接続助詞総合テスト",
                recommendedPower: "53,000",
                icon: "fa-square-check",
                description: "【助詞識別の総まとめ】1. 未然＋ば（仮定）vs 已然＋ば（確定）。2. 未然＋で（打消ないで）。3. 係り結びの結びの消滅・流れ（流れて文末が変化）。助詞の機能を掴むことで、古文の文構造の骨組みが完全に読めるようになる！"
            }
        ]
    },
    {
        id: 27,
        title: "ダンジョン27: 和歌の掛詞特訓①（自然・植物）",
        recommendedPower: "194,261〜201,523",
        icon: "fa-seedling",
        stages: [
            {
                id: "d27_s01",
                name: "ステージ1: 「松」と「待つ」",
                recommendedPower: "194,261",
                icon: "fa-tree",
                description: "【掛詞特訓「まつ」】植物の「松」と、愛しい人を「待つ」を掛ける。浜辺の「松」の景色を詠みながら、実は「あなたをひたすら待っている」という女の切ない情念を二重に表現する。和歌の超定番パターン。"
            },
            {
                id: "d27_s02",
                name: "ステージ2: 「秋」と「飽き」",
                recommendedPower: "54,000",
                icon: "fa-leaf",
                description: "【掛詞特訓「あき」】季節の「秋」と、心が離れる「飽き」を掛ける。「秋風（あきかぜ）」は「立ち去る秋の風」であると同時に「男の飽き（厭き）の風」を表す。季節の情景がそのまま失恋の表現になる修辞の真骨頂。"
            },
            {
                id: "d27_s03",
                name: "ステージ3: 「枯れ」と「離れ（かれ）」",
                recommendedPower: "54,500",
                icon: "fa-plant-wilt",
                description: "【掛詞特訓「かれ」】草木が「枯れる」と、男の足が「離れる（疎遠になる）」を掛ける。冬の野山で「草木が枯れていく」寂しい視覚描写と、「あの人の足が遠のいてしまった」という悲しみを重ね合わす。"
            },
            {
                id: "d27_s04",
                name: "ステージ4: 「渚」と「無き」/「寄る」",
                recommendedPower: "55,000",
                icon: "fa-water",
                description: "【掛詞特訓「なぎさ」】波が打ち寄せる「渚（なぎさ）」と、関係や言葉が「無き（なき）」を掛ける。あるいは波が「寄る」と、身を「寄せる」「夜（よる）」を掛ける。海辺の描写から人間の恋模様を引き出す。"
            },
            {
                id: "d27_s05",
                name: "ステージ5: 植物・自然系掛詞マスター",
                recommendedPower: "55,500",
                icon: "fa-spa",
                description: "【自然系掛詞の見つけ方】和歌の中に自然の言葉（松・秋・枯れ・渚・蒲公英・ススキなど）が出てきたら、必ず「人間の感情や恋の動作（待つ・飽きる・離れる・泣くなど）が隠されていないか？」と疑うクセをつけよう！"
            }
        ]
    },
    {
        id: 28,
        title: "ダンジョン28: 和歌の掛詞特訓②（生活・情念）",
        recommendedPower: "213,678〜221,309",
        icon: "fa-fire-flame-curved",
        stages: [
            {
                id: "d28_s01",
                name: "ステージ1: 「張る」と「春」",
                recommendedPower: "213,678",
                icon: "fa-sun",
                description: "【掛詞特訓「はる」】季節の「春」と、弓や氷を「張る」、衣服を「貼る（裁つ）」を掛ける。春がやってくる喜びと、弓を引き絞る緊張感、あるいは着物を張りかえる生活感を同時に表現する。"
            },
            {
                id: "d28_s02",
                name: "ステージ2: 「思ひ」の中の「火」",
                recommendedPower: "56,500",
                icon: "fa-fire",
                description: "【掛詞特訓「おもひ」】「思ひ（思い・恋心）」という言葉の中に隠された「火（情熱の火・大文字の火など）」をみつける。「思ひ」の「ひ」は「火」であり、心の中で胸を焦がす激しい恋の炎を二重に象徴する。"
            },
            {
                id: "d28_s03",
                name: "ステージ3: 「難波」と「何（なに）」",
                recommendedPower: "57,000",
                icon: "fa-question",
                description: "【掛詞特訓「なにわ」】大阪の地名「難波（なにわ）」と、疑問詞「何（なに）」を掛ける。「難波潟（なにわがた）」の葦の風景を歌いながら、「何か〜だろうか（いや、そうではない）」という疑問・反語の感情を導入する。"
            },
            {
                id: "d28_s04",
                name: "ステージ4: 「近江」と「会ふ身」",
                recommendedPower: "57,500",
                icon: "fa-handshake",
                description: "【掛詞特訓「あふみ」】地名「近江（おうみ）」と、男女が逢う「会ふ身（逢ふ身）」を掛ける。近江の海の美しい水面を詠みながら、大好きなあの人とめぐり逢いたいという恋の願いを歌に込める。"
            },
            {
                id: "d28_s05",
                name: "ステージ5: 生活・恋心掛詞特訓",
                recommendedPower: "58,000",
                icon: "fa-heart",
                description: "【生活系掛詞の読み解き極意】「思ひ（火）」「立ち（裁ち・発ち）」「文（踏み）」「憂し（有し）」。ひらがなで書かれた和歌の1語に2つの漢字を当てはめてみるトレーニングこそが、掛詞発見の唯一の道！"
            }
        ]
    },
    {
        id: 29,
        title: "ダンジョン29: 古文文法総合識別演習",
        recommendedPower: "234,567〜244,591",
        icon: "fa-brain",
        stages: [
            {
                id: "d29_s01",
                name: "ステージ1: 「給ふ」本動詞 vs 補助動詞",
                recommendedPower: "234,567",
                icon: "fa-hands",
                description: "【「給ふ」本動詞 vs 補助動詞の識別】1. 独立して使われ「〜をお与えになる・くださる」と訳せる＝【本動詞（四段）】。2. 用言（動詞・形容詞等）の連用形の下について「〜なさる・お〜になる」と訳す＝【尊敬補助動詞（四段）】。"
            },
            {
                id: "d29_s02",
                name: "ステージ2: 「給ふ」四段 vs 下二段（会話文）",
                recommendedPower: "59,000",
                icon: "fa-comments",
                description: "【「給ふ」ハ行下二段活用の秘密】会話文（手紙文）の中で「思ひ給ふ」「知り給ふ」のように【自分側の動作】について使われている「給ふ」は【謙譲の補助動詞】で下二段活用（たまへ・たまへ・たまふ・たまふる・たまふれ・たまへ）！「〜ております」と訳す。"
            },
            {
                id: "d29_s03",
                name: "ステージ3: 動詞の活用型判別（ラ変・ナ変）",
                recommendedPower: "59,500",
                icon: "fa-list-check",
                description: "【特殊活用の完全暗記】1. ラ変（あり・をり・はべり・いまそかり）→ら/り/り/る/れ/れ。2. ナ変（死ぬ・いぬ）→な/に/ぬ/ぬる/ぬれ/ね。3. カ変（く）→こ/き/く/くる/くれ/こ（こよ）。4. サ変（す・おはす）→せ/し/す/する/すれ/せよ。"
            },
            {
                id: "d29_s04",
                name: "ステージ4: 形容詞・形容動詞の識別",
                recommendedPower: "60,000",
                icon: "fa-pen-to-square",
                description: "【形容詞・形容動詞の見分け】形容詞は「ク活用（く・し・き・ければ）」と「シク活用（しく・し・しき・しければ）」。形容動詞は「ナリ活用（なり・に・なり・なる・なれ）」と「タリ活用（たり・と・たり・たる・たれ）」。文末の音と言い切りで判定！"
            },
            {
                id: "d29_s05",
                name: "ステージ5: 古文文法総合識別特訓",
                recommendedPower: "61,000",
                icon: "fa-graduation-cap",
                description: "【文法解読の総合アルゴリズム】単語を1語ずつ解体する。品詞（動詞・助詞・助動詞）に分ける。それぞれの接続と活用形を確認する。文脈に合わせて現代語訳を組み立てる。このステップで読めない古文文章は存在しない！"
            }
        ]
    },
    {
        id: 30,
        title: "ダンジョン30: 【最難関】掛詞・識別完全マスター",
        recommendedPower: "261,242〜273,882",
        icon: "fa-dungeon",
        stages: [
            {
                id: "d30_s01",
                name: "ステージ1: 超難関識別：複合助動詞の罠",
                recommendedPower: "261,242",
                icon: "fa-skull",
                description: "【「させ給ひてけり」「せ給ひつらん」等の解体】助動詞が3つも4つも連なる超難関文。「させ（尊敬/使役）＋給ひ（尊敬）＋て（完了）＋けり（過去）」。1語ずつ品詞分解し、接続のチェーンを解きほぐす能力が問われる！"
            },
            {
                id: "d30_s02",
                name: "ステージ2: 複雑な和歌のダブル掛詞・修辞",
                recommendedPower: "62,800",
                icon: "fa-scroll",
                description: "【1首に3つ以上の修辞が詰まった超難関和歌】枕詞＋見立て＋ダブル掛詞＋本歌取りが同時に押し寄せる。『古今集』『新古今集』の最高峰和歌を、すべての技法を解剖して完璧に現代語訳・鑑賞する試練！"
            },
            {
                id: "d30_s03",
                name: "ステージ3: 助詞・助動詞の多義語判別",
                recommendedPower: "63,500",
                icon: "fa-shuffle",
                description: "【「な」「に」「し」「の」「とも」の全多義識別】「な（禁止・願望・強意・ナ変）」「の（主格・連体格・同格・準体格・比喩）」。文脈の中でどの機能として働いているかをミリ単位で判別する最終精密判定技術。"
            },
            {
                id: "d30_s04",
                name: "ステージ4: 敬語の方向＋識別の融合問題",
                recommendedPower: "64,200",
                icon: "fa-shield-cat",
                description: "【難関大入試の最頻出融合問題】文章中に登場する3〜4人の人物（帝・大臣・姫君・女房）。誰が誰に対して敬意を払っているのか、謙譲語・尊敬語・二重敬語が混ざり合った文から主語と目的語を完璧に特定する！"
            },
            {
                id: "d30_s05",
                name: "ステージ5: 最終試練！入試古文文法制覇",
                recommendedPower: "65,000",
                icon: "fa-crown",
                description: "おつかれさまでした！本編30ダンジョン・200ステージの修行を見事完遂しましたね！ここから先は平日ダンジョン50連戦が待っています。古文常識・語彙・敬語・文学史をさらに研ぎ澄まし、真の完全制覇を目指しましょう！"
            }
        ]
    },
    {
        id: 31,
        title: "月曜ダンジョン1: 「あはれなり」の多義性",
        recommendedPower: "4,000〜5,320",
        icon: "fa-moon",
        gimmick: "levelHalf",
        stages: [
            { id: "d31_s01", name: "ステージ1: 「あはれなり」の多義性", recommendedPower: "4,000", icon: "fa-moon", description: "【「あはれなり」の深掘り解説】\n本来は「あは（感嘆詞）」から生じた言葉で、心に深くしみじみと感じ入る感情全般を表す。平安時代の文学（特に『源氏物語』）における「もののあはれ」の中心的概念。\n①「しみじみとした情趣がある・しみじみと深い味わいがある」（自然や情景に対する感動）\n②「いとしい・愛おしい・可愛らしい」（対象に対する深い愛情）\n③「かわいそうだ・気の毒だ・悲しい」（不遇な人や悲惨な状況への同情）\n文章の文脈によってプラスの感情（感動・愛着）かマイナスの感情（悲哀・憐憫）かを見極めることが入試読解の鍵となる。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d31_s02", name: "ステージ2: 「をかし」の多義性", recommendedPower: "4,330", icon: "fa-moon", description: "【「をかし」の深掘り解説】\n「招き寄せたいほど魅力的だ」という語源を持ち、知性・客観性を伴った明るい美的評価を表す。『枕草子』の中心的理念（「をかし」の文学）。\n①「趣がある・風情がある」（知的・客観的な美）\n②「美しい・可愛らしい」（見た目の華やかさ・愛らしさ）\n③「滑稽だ・おかしい」（笑いを誘う面白さ）\n「あはれなり」が湿り気のある情緒的感情（悲しさ・哀愁を含む）であるのに対し、「をかし」は乾いた知的な明るさ・面白さを表す対比構造を絶対に押さえておくこと。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d31_s03", name: "ステージ3: 「かなし」の二面性", recommendedPower: "4,660", icon: "fa-moon", description: "【「かなし」の深掘り解説】\n漢字では「愛し」と「悲し/哀し」の両方が当てられる。自分の心の奥底から湧き上がる切実な感情を表す。\n①「愛おしい・いとしい」（切ないほどにかわいい・大事にしたい）\n②「悲しい・切ない」（痛切に悲しい・嘆かわしい）\n入試では「愛し（愛おしい）」の意味で出題されることが非常に多い。「子どもの可愛らしさ」「恋人への愛着」などの文脈では「悲しい」と訳すと正反対の意味になるため要注意。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d31_s04", name: "ステージ4: 「うし」と「つらし」の心境の違い", recommendedPower: "4,990", icon: "fa-moon", description: "【「うし」と「つらし」の深掘り解説】\nどちらも辛い感情を表すが、原因のベクトルが異なる。\n・「うし（憂し）」：自分が置かれている状況や世の中全体に対して「つらい・いやだ・憂鬱だ」と感じる（ベクトルが自分自身・環境に向く）。\n・「つらし（辛し）」：相手の冷たい態度や不誠実さに対して「薄情だ・恨めしい・冷たい」と感じる（ベクトルが他人・相手に向く）。\n「つらし」は相手への難詰・恨みのニュアンスを含むため、和歌における贈答文脈で頻出する。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d31_s05", name: "ステージ5: 「いとほし」と「かなし」の情念", recommendedPower: "5,320", icon: "fa-moon", description: "【「いとほし」と「かなし」の情念の深掘り解説】\n・「いとほし」：「いと・愛し」から派生し、相手の不遇や弱さを見て「気の毒だ・かわいそうだ」と同情する気持ち。また「愛おしい」の意味も併せ持つ。\n・「かなし」：上記ステージ3の通り、自分の感情として「切ないほど愛おしい」「耐えがたく悲しい」という強い情念。\n「いとほし」は相手に視点を置いた同情の比重が高く、「かなし」は自己の内部から溢れる愛着・哀傷の比重が高い。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" }
        ]
    },
    {
        id: 32,
        title: "月曜ダンジョン2: 「めでたし」の絶賛",
        recommendedPower: "4,780〜6,100",
        icon: "fa-moon",
        gimmick: "levelHalf",
        stages: [
            { id: "d32_s01", name: "ステージ1: 「めでたし」の絶賛", recommendedPower: "4,780", icon: "fa-moon", description: "【「めでたし」の深掘り解説】\n動詞「愛づ（感嘆する・褒める）」＋形容詞化接尾語「たし」。手を叩いて称賛したくなるような最高級の褒め言葉。\n①「すばらしい・見事だ・立派だ」\n②「目出度い（祝うべきだ）」\n人物の容姿・才能・振る舞い、あるいは建造物や和歌の出来栄えなど、あらゆる対象に対する手放しの「絶賛」を表す。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d32_s02", name: "ステージ2: 「ありがたし」の滅多になさ", recommendedPower: "5,110", icon: "fa-moon", description: "【「ありがたし」の深掘り解説】\n「有り＋難し（存在することが難しい）」が原義。\n①「滅多にない・めずらしい」（確率的に存在しがたい）\n②「（滅多にないほど）すばらしい・立派だ」（類まれな優秀さ）\n③「生きるのが難しい・世を渡るのが難儀だ」（生存の困難）\n現代語の「ありがとう（感謝）」の語源であるが、古文では「めったにないほど素晴らしい」という超ハイレベルな称賛、あるいは「難行苦行」を意味することが多い。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d32_s03", name: "ステージ3: 「あやし」の3つの顔", recommendedPower: "5,440", icon: "fa-moon", description: "【「あやし」の深掘り解説】\n漢字表記によって「怪し」「賤し」「奇し」となり、意味が明確に分かれる重要識別語。\n①怪し：「不思議だ・奇妙だ・変だ」（理解を超えたあやしさ）\n②賤し：「身分が低い・卑しい」（社会階層の低さ）\n③賤し：「見苦しい・むさくるしい・粗末だ」（身なりや住居の質の低さ）\n文脈判断が必須。「あやしき下衆」「あやしき家」は「賤し（粗末・身分低）」であり、「あやしき光」などは「怪し（不思議）」となる。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d32_s04", name: "ステージ4: 「やごとなし」の気品", recommendedPower: "5,770", icon: "fa-moon", description: "【「やごとなし」の深掘り解説】\n「やむにやまれぬ（放っておけない）」が原義。放置できないほど高貴で格別である様子。\n①「身分が高い・高貴だ」（家柄や立場が特別である）\n②「格別だ・尊い・放置できない」（大切に扱うべきである）\n対義語である「あやし（身分が低い）」と組み合わせて社会階層を描写する文章で多用される。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d32_s05", name: "ステージ5: 「いうなり」と「えんなり」の優雅さ", recommendedPower: "6,100", icon: "fa-moon", description: "【「いうなり」と「えんなり」の深掘り解説】\n中世・王朝美意識を代表する形容動詞。\n・「いうなり（優なり）」：上品で優雅だ、優れている。優美で洗練された気品を表す。\n・「えんなり（艶なり）」：しっとりと艶やかで美しい、なまめかしい。情趣に富み、恋愛的な魅力を感じさせる華やかさ・色気を表す。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" }
        ]
    },
    {
        id: 33,
        title: "月曜ダンジョン3: 「むつかし」の不快感",
        recommendedPower: "5,560〜6,880",
        icon: "fa-moon",
        gimmick: "levelHalf",
        stages: [
            { id: "d33_s01", name: "ステージ1: 「むつかし」の不快感", recommendedPower: "5,560", icon: "fa-moon", description: "【「むつかし」の深掘り解説】\n自分の思い通りにならず、不快で心が乱れている状態を表す。\n①「うっとうしい・不快だ」（気分がすっきりしない）\n②「見苦しい・むさくるしい」（状況や見た目が不快）\n③「恐ろしい・気味が悪い」（怪異や暗闇などに恐怖を感じる）\n現代語の「むずかしい（困難だ）」とはニュアンスが大きく異なるため注意。「むつかしき気色」は「不機嫌な様子」「不快そうな顔つき」。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d33_s02", name: "ステージ2: 「い忌まし」と「かたはらいたし」", recommendedPower: "5,890", icon: "fa-moon", description: "【「い忌まし」と「かたはらいたし」の深掘り解説】\n・「い忌まし（不吉だ・忌々しい）」：神事・信仰上の不吉さや不快感。\n・「かたはらいたし（傍ら痛し）」：傍ら（隣）で見たり聞いたりしていて、苦々しい・見苦しい。また、自分が他人の目を意識して「きまり悪い・恥ずかしい・気まずい」。\n「かたはらいたし」は「他人のイタい行動を見ていてハラハラ・苦々しく思う」心理と、「他人の目が気になって恥ずかしい」という自意識の両面を押さえる。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d33_s03", name: "ステージ3: 「うしろめたし」の不安", recommendedPower: "6,220", icon: "fa-moon", description: "【「うしろめたし」の深掘り解説】\n「後ろ＋目痛し（後ろ振り返りが気になる）」が語源。\n①「心配だ・気がかりだ・不安だ」\n現代語の「後ろめたい（罪悪感がある）」とはまったく意味が異なる。古文では「自分の後方が心配で落ち着かない」「留守中が心配だ」という純粋な「不安・心配」を表す。入試での現代語訳・ひっかけ問題の超定番。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d33_s04", name: "ステージ4: 「うしろやすし」の安心感", recommendedPower: "6,550", icon: "fa-moon", description: "【「うしろやすし」の深掘り解説】\n「うしろめたし」の対義語。「後ろ＋安し」。\n①「安心だ・頼もしい・気がかりがない」\n背後を任せられる、後顧の憂いがないという信頼感・安心感を表す。後見人（後見）がしっかりしている時などに使われる。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d33_s05", name: "ステージ5: 「わりなし」の理不尽さ", recommendedPower: "6,880", icon: "fa-moon", description: "【「わりなし」の深掘り解説】\n「割り（理・道理）＋無し」。筋道が通らない極端な状態。\n①「道理に合わない・理不尽だ」\n②「無理やりだ・強引だ」\n③「どうしようもない・耐えがたい」\n④「格別だ・ひどく（副詞的）」\n道理を無視した振る舞いや、コントロール不可能な感情・状況に対して使われる万能な感情形容詞。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" }
        ]
    },
    {
        id: 34,
        title: "月曜ダンジョン4: 「ののしる」の大騒ぎ",
        recommendedPower: "6,340〜7,660",
        icon: "fa-moon",
        gimmick: "levelHalf",
        stages: [
            { id: "d34_s01", name: "ステージ1: 「ののしる」の大騒ぎ", recommendedPower: "6,340", icon: "fa-moon", description: "【「ののしる」の深掘り解説】\n現代語の「罵倒する（大声で悪口を言う）」ではなく、単に大声を出して騒ぎ立てる様子。\n①「大声で騒ぐ・大騒ぎする」\n②「評判になる・世間で話題になる」（噂が大声で飛び交う）\n③「権力を振るう・威勢を誇る」\n好ましいことでも好ましくないことでも、周囲に響き渡るほどの音量・評判が存在する状態を表す。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d34_s02", name: "ステージ2: 「しのぶ」の隠忍と懐古", recommendedPower: "6,670", icon: "fa-moon", description: "【「しのぶ」の深掘り解説】\n漢字表記によって「忍ぶ」と「偲ぶ」に分かれる重要語。\n①忍ぶ：「耐え忍ぶ・我慢する」\n②忍ぶ：「人目を忍ぶ・隠れる・秘密にする」（「忍び歩き」など）\n③偲ぶ：「懐かしむ・過去を思い出す」（和歌や物語で故人を慕う場面）\n文脈に応じて「じっと耐えている」のか「人目を隠している」のか「昔を懐かしんでいる」のかを読み分ける。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d34_s03", name: "ステージ3: 「いらへる」と「こたふ」", recommendedPower: "7,000", icon: "fa-moon", description: "【「いらへる」と「こたふ」の深掘り解説】\nどちらも返答を表すが、ニュアンスと構文が異なる。\n・「いらふ（答ふ・応ふ）」：呼びかけに対して声を返す、「返事をする・応答する」。\n・「こたふ（応ふ・答ふ）」：質問や求めに応じる、「答える・返答する」。また「耐える・身体にこたえる」の意味もある。\n会話文の文脈で「応答する」場面での動作主特定に直結する。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d34_s04", name: "ステージ4: 「ぐす」と「いざなふ」", recommendedPower: "7,330", icon: "fa-moon", description: "【「ぐす」と「いざなふ」の深掘り解説】\n・「ぐす（具す）」：連れて行く・付き添う、また（自分が）連れ立つ・引き連れる。さらに「具備する（揃う）」の意味もある。サ変サ行変格活用。\n・「いざなふ（誘ふ）」：人を誘って連れて行く・促す。\n「具す」は「〜を具して（〜を連れて）」という形で旅立ちや移動の場面に多用される。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d34_s05", name: "ステージ5: 「あく」と「あかず」", recommendedPower: "7,660", icon: "fa-moon", description: "【「あく」と「あかず」の深掘り解説】\nカ行四段動詞「あく（飽く・満足する）」。\n・「あく」：満足する・飽きる。\n・「あかず」：満足しない・物足りない、または「飽きない・どれほど〜しても足りない（愛情や名残惜しさ）」。\n「あかず（飽かず）」は「名残惜しい」「いつまでも見ていたい」という肯定的な愛着・美称として和歌で超頻出。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" }
        ]
    },
    {
        id: 35,
        title: "月曜ダンジョン5: 「あたらし」の惜しさ",
        recommendedPower: "7,120〜8,440",
        icon: "fa-moon",
        gimmick: "levelHalf",
        stages: [
            { id: "d35_s01", name: "ステージ1: 「あたらし」の惜しさ", recommendedPower: "7,120", icon: "fa-moon", description: "【「あたらし」の深掘り解説】\n「惜し（あたらし）」。「新しい」ではないことに最大の注意が必要。\n①「惜しい・勿体ない」\n価値あるものが失われるのを惜しむ気持ち。「あたら〜（あたら惜しき人などを逃した）」の形で「惜しくも・勿体なくも」と訳す副詞的用法も極めて重要。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d35_s02", name: "ステージ2: 「こころづくし」の気苦労", recommendedPower: "7,450", icon: "fa-moon", description: "【「こころづくし」の深掘り解説】\n「心＋尽くし（心をすり減らすこと）」。\n①「あれこれと気をもむこと・心苦労をすること・物思いにふけること」\n恋愛や将来の不安などで、精神エネルギーを極限まで使い果たすような憂愁の心境を表す。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d35_s03", name: "ステージ3: 「おぼつかなし」の不鮮明", recommendedPower: "7,780", icon: "fa-moon", description: "【「おぼつかなし」の深掘り解説】\n「おぼろげ」と同根で、対象がぼんやりしてはっきりしない状態。\n①「はっきりしない・ぼんやりしている」（視界や記憶の不鮮明）\n②「気がかりだ・不安だ」（情勢が明確でないための焦り）\n③「待ち遠しい・じれったい」（連絡や訪れがはっきりしない）\n時間的・空間的・精神的な「不透明さ」から生じる心理の流れを押さえる。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d35_s04", name: "ステージ4: 「こころもとなし」の焦燥", recommendedPower: "8,110", icon: "fa-moon", description: "【「こころもとなし」の深掘り解説】\n「心が浮ついて落ち着かない」状態。\n①「じれったい・待ち遠しい」（早く結果が知りたくて落ち着かない）\n②「気がかりだ・不安だ」\n③「はっきりしない」\n「おぼつかなし」とほぼ同義だが、「こころもとなし」は特に「じれったさ・焦燥感（早く〜したい）」のニュアンスが強く出る。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d35_s05", name: "ステージ5: 「まめなり」の誠実さ", recommendedPower: "8,440", icon: "fa-moon", description: "【「まめなり」の深掘り解説】\n「魔滅（まめ＝実質的・真面目）」から。\n①「誠実だ・真面目だ・真心がある」\n②「実用的だ・実質的だ」（華美・風流ではなく役に立つ）\n③「身体が達者だ・健康だ」\n風流・好色（あだなり）の対義語として、堅実で信頼できる人物像や、飾り気のない実用的な道具・道具立てを表す。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" }
        ]
    },
    {
        id: 36,
        title: "月曜ダンジョン6: 「え〜（ず）」打消の不可能",
        recommendedPower: "7,900〜9,220",
        icon: "fa-moon",
        gimmick: "levelHalf",
        stages: [
            { id: "d36_s01", name: "ステージ1: 「え〜（ず）」打消の不可能", recommendedPower: "7,900", icon: "fa-moon", description: "【「え〜（ず）」の深掘り解説】\n副詞「え」が下に打消語（ず・じ・まじ等）を伴う不可能な呼応構文。\n①「え〜ず：〜することができない」\n単なる「〜しない」ではなく、「能力・状況・強要によって、どうしても〜することが不可能だ」という「不可能」を表す。文脈読解で動作の成否を見分ける重要ポイント。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d36_s02", name: "ステージ2: 「つゆ〜（ず）」全打消", recommendedPower: "8,230", icon: "fa-moon", description: "【「つゆ〜（ず）」の深掘り解説】\n副詞「つゆ（露のひとしずく）」＋打消語。\n①「つゆ〜ず：全く〜ない・少しも〜ない」\n完全否定（全打消）。「露ほども〜ない」という直訳から連想する。「全打消」の呼応には他に「つやつや〜ず」「さらに〜ず」「おほよその〜ず」「たえて〜ず」などがある。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d36_s03", name: "ステージ3: 「よも〜（じ）」強い打消推量", recommendedPower: "8,560", icon: "fa-moon", description: "【「よも〜（じ）」の深掘り解説】\n副詞「よも」＋打消推量の助動詞（じ・まじ等）。\n①「よも〜じ：まさか〜ないだろう・よもや〜ないだろう」\n話し手・書き手の強い確信を持った打消推量。相手に対する安心の保証や、絶対にあり得ないという推測を表す。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d36_s04", name: "ステージ4: 「いかが・いかに」疑問と反語", recommendedPower: "8,890", icon: "fa-moon", description: "【「いかが・いかに」の深掘り解説】\n文脈と文末の活用形によって「疑問」か「反語」かが決定する重要疑問副詞。\n①疑問：「どのように〜か・どうして〜か」\n②反語：「どうして〜か（いや、〜ない）」\n③いかがはせむ：「どうしようか、いや、どうしようもない（仕方がない）」\n文脈上、否定の結論に導いている場合は必ず「反語」で訳出する。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d36_s05", name: "ステージ5: 「などを・などか」反語・疑問", recommendedPower: "9,220", icon: "fa-moon", description: "【「などを・などか」の深掘り解説】\n「など（疑問副詞）」＋「を・か（係助詞）」。\n①「どうして〜か（いや、〜ない）」（反語）\n②「どうして〜か」（疑問）\n結びが連体形となり、強い反語（「どうして〜あろうか、いや、ない」）を表すことが多い。詰問や強い嘆きのニュアンスを伴う。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" }
        ]
    },
    {
        id: 37,
        title: "月曜ダンジョン7: 「あやし（怪し / 賤し）」の文脈判定",
        recommendedPower: "8,680〜10,000",
        icon: "fa-moon",
        gimmick: "levelHalf",
        stages: [
            { id: "d37_s01", name: "ステージ1: 「あやし（怪し / 賤し）」の文脈判定", recommendedPower: "8,680", icon: "fa-moon", description: "【「あやし」の文脈判定解説】\n前後の文脈や修飾される名詞によって判定する。\n・「怪し」：自然現象の異常、物の怪、正体のわからない現象（「あやしき光」「あやしき心地」）。\n・「賤し」：人物の身分、服装の粗末さ、家の貧しさ（「あやしき下衆」「あやしき身」「あやしき屋」）。\n文脈から「社会的ステータス・質の低さ（賤）」か「常識外れ・不可解（怪）」かを素早く識別する。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d37_s02", name: "ステージ2: 「ふみ（文 / 踏み）」の識別", recommendedPower: "9,010", icon: "fa-moon", description: "【「ふみ」の識別解説】\n・「文（ふみ）」：手紙、書物、漢詩文・学問（「文をやる」「文を読む」）。\n・「踏み（ふみ）」：動詞「踏む」の連用形（「踏み分ける」「踏み迷う」）。\n特に「文（手紙・漢詩）」の文脈は王朝文学で最頻出。手紙を「送る（やる）」「見る」「破る」などの動詞との結びつきに注目。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d37_s03", name: "ステージ3: 「よ（世 / 代 / 夜）」の多義性", recommendedPower: "9,340", icon: "fa-moon", description: "【「よ」の多義性解説】\n・「世」：男女の仲・夫婦関係、世の中・世間、一生・人生。\n・「代」：治世・時代、年齢。\n・「夜」：よる・夜間。\n古文の恋愛・和歌文脈における「よ（世）」は、ほぼ例外なく「男女の深い仲・愛の営み」を指すことを丸暗記しておくこと。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d37_s04", name: "ステージ4: 「から（柄 / 幹 / 殻）」の文脈解釈", recommendedPower: "9,670", icon: "fa-moon", description: "【「から」の文脈解釈解説】\n・「柄（から）」：生まれつきの性質、品格、血統（「人柄」「血柄」）。\n・「〜から」：〜によって（原因・理由の格助詞・接続助詞）。\n・「幹（から）/ 殻（から）」：木の幹、空っぽの抜け殻。\n「〜のからに」の形は「〜のゆえに・〜のために」という理由表現として頻出する。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d37_s05", name: "ステージ5: 「けしき（気色）」の解釈", recommendedPower: "10,000", icon: "fa-moon", description: "【「けしき（気色）」の解釈解説】\n目に見える外的な兆候や、内面の目に見えるあらわれ。\n①「自然の様子・景観」（空模様や季節の移り変わり）\n②「人の様子・表情・態度」（顔色・雰囲気）\n③「ご機嫌」（尊貴な人の機嫌）\n④「意向・考え」（内面の意志・心づもり）\n「けしきばむ」「けしきだつ」は「兆候があらわれる・心の中が顔に出る・気取る」という意味の派生動詞。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" }
        ]
    },
    {
        id: 38,
        title: "月曜ダンジョン8: 最高敬語「せ給ふ・させ給ふ」の主体判定",
        recommendedPower: "9,460〜10,780",
        icon: "fa-moon",
        gimmick: "levelHalf",
        stages: [
            { id: "d38_s01", name: "ステージ1: 最高敬語「せ給ふ・させ給ふ」の主体判定", recommendedPower: "9,460", icon: "fa-moon", description: "【最高敬語の主体判定解説】\n「使役の助動詞『す・さす』＋尊敬の補助動詞『給ふ』」の形。\n・「せ給ふ・させ給ふ」に直前に目的語（「〜に」等）がなく、使役の相手が指定されていない場合 ＝ 最高敬語（「〜なさる・お〜になる」）。\n・主体の対象：天皇・中宮・法皇・上皇・皇太子などの超・雲上人（トップクラスの身分）。\nもし直前に「人に」など使役される人物がいれば「〜にお命じになって〜させなさる」という通常の使役＋尊敬になる。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d38_s02", name: "ステージ2: 「給へ」「侍り」の会話文における自称・他称", recommendedPower: "9,790", icon: "fa-moon", description: "【会話文における敬語の自称・他称解説】\n・「給ふ」の下二段活用（給へ・給ふ・給ふる…）＝ 謙譲語（「〜させていただきます・〜申し上げます」）。会話文・手紙の中で話し手（自分）の動作を低める。\n・「侍り（はべり）」「さぶらふ」＝ 丁寧語（「〜です・〜ます」）または謙譲語（「お仕えする」）。\n会話文で「給へ」が出てきた場合、主語は100%「話し手（私）」となるため、主語特定において決定的な根拠となる。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d38_s03", name: "ステージ3: 敬意の不一致から探る「誰から誰への敬意」", recommendedPower: "10,120", icon: "fa-moon", description: "【敬意の方向探知解説】\n敬語の方向（誰から誰へ）：\n①地の文：作者（地の文の書き手）から → 動作の主体（尊敬）/ 動作の客体（謙譲）/ 聞き手・読者（丁寧）\n②会話文：話し手（スピーカー）から → 動作の主体（尊敬）/ 動作の客体（謙譲）/ 聞き手（丁寧）\n敬意の度合い（最高敬語＞一般的な尊敬語）や敬語の組み合わせから、登場人物の社会的身分関係を逆算して主語を絞り込む。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d38_s04", name: "ステージ4: 「聞こゆ」「聞こえさす」の謙譲・献上文脈", recommendedPower: "10,450", icon: "fa-moon", description: "【「聞こゆ」「聞こえさす」の解説】\n・「聞こゆ」：①（謙譲）申し上げる・差し上げる（「言ふ」「与ふ」の謙譲）。②（自発・可能・受動）聞こえる・評判になる。\n・「聞こえさす」：より強い謙譲（「申し上げ散らす・お申し入れする」）。\n動作の受け手（客体）に対して強い敬意を示すため、手紙を差し出す相手や、言葉を伝える貴人が「客体（〜に）」に存在することを証明する。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d38_s05", name: "ステージ5: 「奏す」「啓す」の絶対敬意対象", recommendedPower: "10,780", icon: "fa-moon", description: "【「奏す」「啓す」の絶対敬意対象解説】\n言動を伝える対象が限定されている絶対謙譲語。\n・「奏す（そうす）」：天皇・法皇・上皇に申し上げる。\n・「啓す（けいす）」：皇后・中宮・皇太子に申し上げる。\n本文中に「奏す」があれば、行き先（客体）は必ず天皇クラスであり、「啓す」であれば中宮・東宮クラスであると一瞬で特定できる。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" }
        ]
    },
    {
        id: 39,
        title: "月曜ダンジョン9: 接続助詞「て」「して」の前後の主語同一法則",
        recommendedPower: "10,240〜11,560",
        icon: "fa-moon",
        gimmick: "levelHalf",
        stages: [
            { id: "d39_s01", name: "ステージ1: 接続助詞「て」「して」の前後の主語同一法則", recommendedPower: "10,240", icon: "fa-moon", description: "【主語同一法則の解説】\n接続助詞「て」「して」で前後が結ばれている場合、原則として前後で動作の主語は交代せず、「同一の主語」が継続する。\n例：「（帝）御覧じて（※主語同一）、～と仰せらる。」\nこの法則を徹底することで、長文のストーリー展開を見失わずに読み進めることができる。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d39_s02", name: "ステージ2: 接続助詞「を」「に」「ば」「ども」の前後の主語交代法則", recommendedPower: "10,570", icon: "fa-moon", description: "【主語交代法則の解説】\n接続助詞「を」「に」「ば」「ども」「が」「の」で文が繋がる場合、その前後で「主語が交代する（別の人物に切り替わる）」確率が非常に高い。\n例：「（男）訪ね行きたるに（※主語交代）、（女）え出で会はず。」\n主語の変化するスイッチとしてこれらの助詞をチェックする。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d39_s03", name: "ステージ3: 「〜と（思う・言う）」の引用表現における主語復元", recommendedPower: "10,900", icon: "fa-moon", description: "【引用表現における主語復元の解説】\n「〜と（て）［思考・発言動詞の省略］」の構造。\n「〜と（て）」の直後にある「思ふ」「言ふ」「聞く」などの動詞は高確率で省略される。\n引用節の内側にある敬語（謙譲語・丁寧語）や呼応から「誰のセリフ・心の声か」を割り出し、直後に「と言ひて」「と思ひて」を復元して読解する。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d39_s04", name: "ステージ4: 敬語の有無による登場人物の主語振り分け", recommendedPower: "11,230", icon: "fa-moon", description: "【敬語による主語振り分け解説】\n登場人物の「身分格差」を利用した読解法。\n身分の高い人物（例：帝、姫君）と低い人物（例：従者、乳母）が登場する場面で、動詞に尊敬語がついていれば身分の高い人物が主語、ついていなければ低い人物が主語となる。\n主語が一切書かれていなくても、敬語のオン・オフだけで主語の交互変化を完璧に追跡できる。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d39_s05", name: "ステージ5: 対話文における「〜とぞ」「〜とて」の会話主特定", recommendedPower: "11,560", icon: "fa-moon", description: "【対話文の会話主特定解説】\n「〜とぞ（言ひける）」「〜とて（立ちぬ）」など、「と」の直前までの会話文のニュアンス、人称代名詞（「まろ」「我」「いも」など）、および敬意の方向を総合して、発話者を特定する。\n対話のラリー（A→B→A→B）の周期性を意識しながら読む。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" }
        ]
    },
    {
        id: 40,
        title: "月曜ダンジョン10: 「し」の識別",
        recommendedPower: "11,020〜12,340",
        icon: "fa-moon",
        gimmick: "levelHalf",
        stages: [
            { id: "d40_s01", name: "ステージ1: 「し」の識別", recommendedPower: "11,020", icon: "fa-moon", description: "【「し」の識別解説】\n本文中の「し」を見たら、以下の2つを識別する。\n①過去の助動詞「き」の連体形：直前が「サ変の未然形（せ）」または「カ変の未然形（こ）」または「動詞の連用形」。下に名詞（体言）や助詞が続く。（例：見し人、来し方）\n②強意の副助詞：直前に様々な語が来ても意味を強めるだけ（訳さなくても通じる）。（例：花し咲かば、今日し無事に）\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d40_s02", name: "ステージ2: 「と」の識別", recommendedPower: "11,350", icon: "fa-moon", description: "【「と」の識別解説】\n①格助詞（結果・相手・比較・引用）：「〜となる」「〜と一緒に」「〜と（言う/思う）」。\n②接続助詞（〜と・〜すると）：用言の終止形（活用語）について、時間的連続や条件を表す。（例：見ると等しく）\n③副詞の一部：「と（〜のように）」。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d40_s03", name: "ステージ3: 「とも」の仮定逆接", recommendedPower: "11,680", icon: "fa-moon", description: "【「とも」の仮定逆接解説】\n終止形（※形容詞は連用形・ク活用形）＋接続助詞「とも」。\n①「たとえ〜としても・〜だとしても」（仮定逆接）\nまだ起きていない事態や、事実に反する仮定を設定して「たとえ〜という事態になろうとも」と訳す。確定逆接の「ども（〜けれども）」との混同に注意。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d40_s04", name: "ステージ4: 「ものを」「ものをば」の詠嘆・逆接", recommendedPower: "12,010", icon: "fa-moon", description: "【「ものを」「ものをば」の解説】\n活用語の連体形＋「ものを」「ものをば」「ものゆゑ」。\n①「〜のに・〜のだが」（逆接の接続助詞）\n②「〜ことよ・〜なのになあ」（文末での詠嘆）\n余情や恨み、嘆きの気持ちを込めて文を締めくくる表現として和歌や会話文で非常によく使われる。\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" },
            { id: "d40_s05", name: "ステージ5: 「だに・スラ・さへ」の類推・添加", recommendedPower: "12,340", icon: "fa-moon", description: "【「だに・さへ」の解説】\n・「だに」：①類推（〜でさえ・〜すら）。極端な例を出して他を推し量らせる。②最小限の希望（せめて〜だけでも）。命令・意思・願望表現と呼応する。\n・「さへ」：添加（〜までも）。「〜に加えて〜までも」の意味。（※現代語の「〜さえ」と異なり、古文の「さへ」は「添加（その上さらに）」を意味する）\n\n【月曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体のレベルが5秒間だけ半分になります。レベル半減は個別に復帰し、同時発生の上限はありません。" }
        ]
    },
    {
        id: 41,
        title: "火曜ダンジョン1: 「き」と「けり」の過去の質感",
        recommendedPower: "4,500〜5,820",
        icon: "fa-fire",
        gimmick: "defect",
        stages: [
            { id: "d41_s01", name: "ステージ1: 「き」と「けり」の過去の質感", recommendedPower: "4,500", icon: "fa-fire", description: "【「き」と「けり」の過去の比較解説】\n・「き」：直接体験の過去（自分自身が直接経験・目撃した事実を回想する）。「〜た」。\n・「けり」：伝聞過去（人から聞いた昔話・伝承）または気づき・新事実の発見（「〜だったのだなあ」）。\n歴史物語や物語の語り出し（「昔、男ありけり」）では「けり（伝聞）」が使われ、自分の体験談（日記など）では「き」が中心となる。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d41_s02", name: "ステージ2: 「けり」の詠嘆用法", recommendedPower: "4,830", icon: "fa-fire", description: "【「けり」の詠嘆用法の解説】\n和歌・会話文・心内語における「けり」は、過去の意味ではなく「気づき・感嘆（詠嘆）」となる。\n①「〜であったのだなあ・〜なのだなあ」\n今初めてその事実に気づいて深く感動している心理を表す。和歌の中の「けり」を見たら100%「詠嘆」と解釈してよい。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d41_s03", name: "ステージ3: 「む」「むず」の6大意味", recommendedPower: "5,160", icon: "fa-fire", description: "【「む」「むず」の6大意味解説】\n主語の人称によって意味が決定する鉄則（スイカカエ）：\n①一人称（私）：意思（〜しよう）\n②二人称（あなた）：勧誘・適当（〜するのがよい・〜してください）\n③三人称（彼・それ）：推量（〜だろう）\n④文途中（連体形＋体言）：婉曲（〜のような）/ 仮定（もし〜ならば）\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d41_s04", name: "ステージ4: 「らむ」「けむ」の現在・過去の原因推量", recommendedPower: "5,490", icon: "fa-fire", description: "【「らむ」「けむ」の解説】\n・「らむ」：①現在の推量（今頃〜しているだろう）②現在の原因推量（なぜ〜しているのだろう）\n・「けむ」：①過去の推量（〜しただろう）②過去の原因推量（なぜ〜したのだろう）\n文中に「など（なぜ）」「なに（何）」「いかに（どうして）」などの疑問・反語語がある場合や、理由を問う文脈では「原因推量（どうして〜なのだろう）」と訳す。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d41_s05", name: "ステージ5: 「じ」「まじ」の打消推量・打消意思・不適当", recommendedPower: "5,820", icon: "fa-fire", description: "【「じ」「まじ」の解説】\n・「じ」：「む」の打ち消し。①打消意思（〜するつもりはない・〜しないぞ）②打消推量（〜ないだろう）。\n・「まじ」：「べし」の打ち消し。①打消推量（〜ないだろう）②打消意思（〜しないつもりだ）③不可能（〜できない）④禁止・不適当（〜してはならない・〜しないほうがよい）。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" }
        ]
    },
    {
        id: 42,
        title: "火曜ダンジョン2: 形容詞ク活用とシク活用の見分け方",
        recommendedPower: "5,280〜6,600",
        icon: "fa-fire",
        gimmick: "defect",
        stages: [
            { id: "d42_s01", name: "ステージ1: 形容詞ク活用とシク活用の見分け方", recommendedPower: "5,280", icon: "fa-fire", description: "【ク活用・シク活用の識別解説】\n形容詞の終止形語尾「し」の上に「か」を補って「かなり」と言えるかどうかで判定する。\n・「かなり」と言える ＝ シク活用（例：美し → うつくしかなり ○ → シク活用）\n・「かなり」と言えない ＝ ク活用（例：高し → たかかなり × → たかくかなり ＝ ク活用）\n基本形に「〜し」をつけた時、感情や主観的状態を表すものの多くがシク活用（悲し、頼もし、口惜し）になる。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d42_s02", name: "ステージ2: ナリ活用とタリ活用の違いと用途", recommendedPower: "5,610", icon: "fa-fire", description: "【形容動詞ナリ活用・タリ活用の解説】\n・ナリ活用：和風・和文的表現。しなやかで感情・状態を表す（静かなり、あてなり、あはれなり）。\n・タリ活用：漢語・漢文訓読的表現。堅固で状況・様相を堂々と描く（堂々タリ、揚々タリ、茫々タリ）。\n文章のジャンル（物語か軍記物語・漢詩文か）によって使い分けられる。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d42_s03", name: "ステージ3: 語幹用法", recommendedPower: "5,940", icon: "fa-fire", description: "【語幹用法の解説】\n形容詞の語幹がそのまま独立して使われる特殊な感嘆表現。\n①「あな、〜（語幹）」（例：あな、あはれ！ ＝ ああ、しみじみ愛おしい/悲しい！）\n②「〜（語幹）の、〜や」（例：あな、かまびすし ＝ ああ、やかましい！）\n文末や感動詞の直後に語幹だけが置かれ、強い感情の凝縮を表す。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d42_s04", name: "ステージ4: 連用形＋「あり」の音便・補助化", recommendedPower: "6,270", icon: "fa-fire", description: "【形容詞連用形＋ありの解説】\n形容詞の連用形（〜く）に「あり」が接続して「〜かり」活用（カリ活用）が生まれる。\nまた、連用形「〜に」＋「あり」が音便化・合体して「〜なり（存在・断定）」や「〜無くなり」などへ発展する言語変化の仕組みを押さえる。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d42_s05", name: "ステージ5: 形容詞の連体形＋「に」の副詞的用法", recommendedPower: "6,600", icon: "fa-fire", description: "【連体形＋「に」の解説】\n形容詞・形容動詞の連体形や連用形に「に」が接続し、下の動詞を修飾する副詞的機能を果たす。\n例：「切に（深く・ひたすら）願ふ」「あてに（優雅に）暮らす」。\n単なる格助詞ではなく、全体で状態を表す副詞的表現として滑らかに訳出する。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" }
        ]
    },
    {
        id: 43,
        title: "火曜ダンジョン3: 強飯（こわいい）と姫飯（ひめいい）の食生活",
        recommendedPower: "6,060〜7,380",
        icon: "fa-fire",
        gimmick: "defect",
        stages: [
            { id: "d43_s01", name: "ステージ1: 強飯（こわいい）と姫飯（ひめいい）の食生活", recommendedPower: "6,060", icon: "fa-fire", description: "【平安の主食文化の深掘り解説】\n平安貴族の主食は米。\n・強飯（こわいい）：蒸し器（甑・こしき）で蒸した固いご飯。日常食や儀式の際に用いられた。\n・姫飯（ひめいい）：現代のご飯と同じように多めの水で炊いた柔らかいご飯。\n病気・養生の際や、幼少期には柔らかい「姫飯」や「粥（かゆ）」が食された。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d43_s02", name: "ステージ2: 大饗（たいきょう）と宮中の宴の献立", recommendedPower: "6,390", icon: "fa-fire", description: "【宮中宴席の食文化の深掘り解説】\n大臣就任時や正月に催される最高級の宴「大饗（たいきょう）」。\n料理は加熱調理された温かいスープ類ではなく、干物・塩辛・果物・唐菓子（からくだもの）などが冷えた状態で小皿に美しく盛り付けられた。各自が塩・酢・酒・ひしお（醤油の原型）の4種の調味料（四種器）で自分好みに味付けして食べた。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d43_s03", name: "ステージ3: 氷室の氷と削り氷（かき氷）の贅沢", recommendedPower: "6,720", icon: "fa-fire", description: "【平安の冷味文化の深掘り解説】\n冬場に天然の氷を山中の「氷室（ひむろ）」に保存し、夏に宮中へ運ばせた。\n『枕草子』の「あてなるもの（上品なもの）」として有名：「削り氷（けずりひ）にあまづら入れて、新しき金鋺（かなまり）に入れたる」。あまづらはツタの汁を煮詰めた高級甘味料。真夏の氷は権力と富の象徴であった。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d43_s04", name: "ステージ4: 蘇（そ）と醍醐（だいご）などの乳製品", recommendedPower: "7,050", icon: "fa-fire", description: "【平安の乳製品文化の深掘り解説】\n牛乳を長時間煮詰めて作られた超高級保存食品が「蘇（そ）」。さらにそれを精製・熟成させた最高峰の味わいが「醍醐（だいご）」（「醍醐味」の語源）。\n薬用・補養品として天皇や最高幹部貴族のみに献上された。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d43_s05", name: "ステージ5: 屠蘇（とそ）と薬酒の風習", recommendedPower: "7,380", icon: "fa-fire", description: "【正月・年中行事の薬酒解説】\n正月元旦に、一年の邪気を払い長寿を祈って飲まれる薬用酒「屠蘇（とそ）」。\n山椒・防風・桔梗などを組み合わせて酒やみりんに浸したもの。年少のものから順に飲む風習（若いエキスを年長者が受け取るため）があり、宮中行事として定着していた。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" }
        ]
    },
    {
        id: 44,
        title: "火曜ダンジョン4: 鉄漿（かね・おはぐろ）と眉墨（まゆずみ）の美意識",
        recommendedPower: "6,840〜8,160",
        icon: "fa-fire",
        gimmick: "defect",
        stages: [
            { id: "d44_s01", name: "ステージ1: 鉄漿（かね・おはぐろ）と眉墨（まゆずみ）の美意識", recommendedPower: "6,840", icon: "fa-fire", description: "【平安化粧の深掘り解説】\n成人（加冠・裳着）を果たした貴族女性・男性の身だしなみ。\n・鉄漿（おはぐろ）：鉄のくずを茶や酒で酸化させた液体で歯を黒く染める。既婚や成人の証。\n・眉墨（まゆずみ/額眉）：地眉を抜き、眉の上方の額にふんわりと墨で太い眉を描く（殿上眉）。\n人間の生々しさを消し、抽象的で優雅な面立ちを作ることが平安の「美」であった。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d44_s02", name: "ステージ2: 薫物（たきもの）と香の薫物合わせ", recommendedPower: "7,170", icon: "fa-fire", description: "【平安の香文化の深掘り解説】\n貴族は部屋や着物に独自の香を焚き染めた（薫物）。沈香・白檀・丁子などの香料を梅肉や蜜で練り合わせたもの。\n誰が一番優雅な香調を作れるかを競う「薫物合（たきものあわせ）」は、貴族の知性・センスを示す重大な文化イベントであった。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d44_s03", name: "ステージ3: 病の正体（物の怪の調伏と加持祈祷）", recommendedPower: "7,500", icon: "fa-fire", description: "【平安の病気観の深掘り解説】\n平安時代、病気はウイルスや内科的疾患ではなく、「生霊・死霊（物の怪・もののけ）」や「怨霊」が人間に取り憑くことによって引き起こされると考えられていた。\nそのため、医療の第一選択は医師の薬投与ではなく、高僧（密教の僧修験者）による「加持祈祷（かじきとう）」や「物の怪の調伏（ちょうぶく）」であった。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d44_s04", name: "ステージ4: 疫病と流行病（赤斑瘡など）への恐れ", recommendedPower: "7,830", icon: "fa-fire", description: "【古代の疫病観の深掘り解説】\n天然痘（赤斑瘡・あかもそう）やインフルエンザ（咳病）などの流行病は「疱瘡神」や怨霊の祟りと恐れられた。\n都の四方に疫神を追い払う「御霊会（ごりょうえ）」や神社の祈願が行われ、感染者は隔離された。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d44_s05", name: "ステージ5: 服薬と「お灸・鍼」の治療", recommendedPower: "8,160", icon: "fa-fire", description: "【古代の東洋医学解説】\n加持祈祷と並行して、典薬寮（てんやくりょう）の典薬師たちによる漢方薬（生薬）の服薬や、灸（きゅう）・鍼（はり）治療も行われた。\nしかし、肌に傷をつける鍼や熱い灸は貴族に嫌がられることも多く、最終的には神仏への祈願に依存する割合が高かった。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" }
        ]
    },
    {
        id: 45,
        title: "火曜ダンジョン5: 誕生の儀式と産養（うぶやかい）",
        recommendedPower: "7,620〜8,940",
        icon: "fa-fire",
        gimmick: "defect",
        stages: [
            { id: "d45_s01", name: "ステージ1: 誕生の儀式と産養（うぶやかい）", recommendedPower: "7,620", icon: "fa-fire", description: "【出産・育児儀式の深掘り解説】\n赤ちゃんが誕生すると、初誕生から3日、5日、7日、9日目の夜に親族や高官が集まり、祝宴と贈り物（衣類・調度品）を贈る「産養（うぶやかい）」が行われた。赤ちゃんの生存率が極めて低かったため、無事な成長を数日刻みで祝った。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d45_s02", name: "ステージ2: 髪削ぎ（かみそぎ）と袴着（はかまぎ）の儀", recommendedPower: "7,950", icon: "fa-fire", description: "【幼児成長儀式の深掘り解説】\n・髪削ぎ（着髪）：数歳になった子供の髪を整え、伸ばし始める儀式。\n・袴着（はかまぎ）：3〜5歳頃、初めて基盤（碁盤）の上に立ち、吉方に向かって袴を穿く儀式。碁盤から飛び降りる動作で「立ち世（立身出世）」を祈願した。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d45_s03", name: "ステージ3: 男性の元服（加冠）と初冠（ういかんむり）", recommendedPower: "8,280", icon: "fa-fire", description: "【男性の成人式の深掘り解説】\n12〜15歳頃、男児が成人となる儀式「元服（げんぷく）」。\nみずら等の子供の髪型を改め、角髪を結って初めて冠をかぶせる（加冠）。冠をかぶせる役を「加冠の父（仮親）」と呼び、後見人としての強い絆を結んだ。『伊勢物語』冒頭の「初冠（ういかんむり）」はまさにこの場面。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d45_s04", name: "ステージ4: 女性の髪上げ（かみあげ）と裳着（もぎ）", recommendedPower: "8,610", icon: "fa-fire", description: "【女性の成人式の深掘り解説】\n12〜14歳頃、女児が成人となる儀式「裳着（もぎ）」。\n童女の垂れ髪を上げ、成人女性の装束である「裳（も）」を腰に結びつける（腰結の役）。これによって結婚可能な大人として社会的に認められた。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d45_s05", name: "ステージ5: 童（わらわ）の髪型", recommendedPower: "8,940", icon: "fa-fire", description: "【子供の髪型の深掘り解説】\n成年前の子供たちの独特な髪型。\n・みずら（角髪）：髪を左右に分け、耳の横で束ねて環をつくる（主に男児）。\n・髪そそけ・禿（かむろ）：肩のあたりで切り揃えたボサボサ・ふんわりした髪型（女児や童女）。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" }
        ]
    },
    {
        id: 46,
        title: "火曜ダンジョン6: 陣の定め（じんのさだめ）における貴族会議",
        recommendedPower: "8,400〜9,720",
        icon: "fa-fire",
        gimmick: "defect",
        stages: [
            { id: "d46_s01", name: "ステージ1: 陣の定め（じんのさだめ）における貴族会議", recommendedPower: "8,400", icon: "fa-fire", description: "【最高政務会議の深掘り解説】\n内裏の「陣の座（近衛陣営の詰所）」で公卿（大臣・大納言・中納言）たちが集まって行う最高政務会議。\n外交、改元、人事、儀式、大事件の審議など、国家の重要施策はすべてこの「陣の定め」での議論を経て、公事・決定とされた。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d46_s02", name: "ステージ2: 外戚（がいせき）政治の仕組み", recommendedPower: "8,730", icon: "fa-fire", description: "【摂関政治の権力構造解説】\n藤原氏が用いた「摂関政治」の根幹。\n自分の娘を天皇の妃（中宮・女御）に入内させ、生まれた男の子（皇子）を次の天皇に即位させる。自分はその新天皇の「母方の祖父（外祖父）」として、幼少時は「摂政」、成人後は「関白」となり権力を完全掌握した。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d46_s03", name: "ステージ3: 宣旨（せんじ）と詔書（しょうしょ）の公式文書", recommendedPower: "9,060", icon: "fa-fire", description: "【朝廷公式文書の深掘り解説】\n・詔書（しょうしょ）：天皇の意思を公式に示す最上級の文書。\n・宣旨（せんじ）：天皇の命を受けた蔵人頭（くろうんどのとう）などが、口頭命令を文書化して下達した実用的な公式命令書。物語で官職任命などの場面によく登場する。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d46_s04", name: "ステージ4: 昇殿（しょうでん）の許しと殿上人の資格", recommendedPower: "9,390", icon: "fa-fire", description: "【貴族の身分階層解説】\n天皇の日常生活の場である清涼殿の「殿上の間（てんじょうのま）」に上ることを許されること（昇殿の許し）。\n・殿上人（てんじょうびと）：五位以上の貴族および四位の一部（昇殿を許された者）。\n・地下（じげ）：六位以下の一般官人、または五位以上でも昇殿が許されない者。この格差は貴族にとって人生最大の関心事であった。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d46_s05", name: "ステージ5: 遷都と内裏の火災・再建", recommendedPower: "9,720", icon: "fa-fire", description: "【宮廷生活の危機と裏側解説】\n平安宮の内裏は木造建築のため、頻繁に火災（亡失）に見舞われた。\n内裏が焼失すると、天皇は一時的に摂関家などの大邸宅に身を寄せた。これを「里内裏（さとだいり）」と呼ぶ。物語文学の舞台が内裏ではなく貴族邸である場合、里内裏が背景になっていることが多い。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" }
        ]
    },
    {
        id: 47,
        title: "火曜ダンジョン7: 保元・平治の乱と武士の都進出",
        recommendedPower: "9,180〜10,500",
        icon: "fa-fire",
        gimmick: "defect",
        stages: [
            { id: "d47_s01", name: "ステージ1: 保元・平治の乱と武士の都進出", recommendedPower: "9,180", icon: "fa-fire", description: "【武家社会への変容解説】\n1156年「保元の乱」、1159年「平治の乱」。\n皇室・摂関家の内紛を解決するために武士（平清盛・源義朝）の軍事力が不可欠となった事件。これをきっかけに貴族社会の警備員に過ぎなかった武士が国家の表舞台・政治の中心へとのし上がっていった。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d47_s02", name: "ステージ2: 院政期における武士のガードマン（北面の武士）", recommendedPower: "9,510", icon: "fa-fire", description: "【院政と軍事力の深掘り解説】\n白河上皇が退位後に設立した「院政」。\n上皇の御所（院）の北側に配置され、院の警護や寺社の大衆（だいしゅ＝強訴する僧兵）を防ぐために取り立てられた武士組織が「北面の武士（ほくめんのぶし）」。「武士の都進出」の大きな足がかりとなった。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d47_s03", name: "ステージ3: 主従関係と「一所懸命」の土地執着", recommendedPower: "9,840", icon: "fa-fire", description: "【武士の倫理観・価値観解説】\n武士の主従関係は「御恩（土地の保障・与え）」と「奉公（命をかけた軍事サービス）」という契約関係。\n祖先から受け継いだ自分の領地（一所）を命がけで守り抜く態度から「一所懸命」の語が生まれた。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d47_s04", name: "ステージ4: 弓馬の道と武芸（流鏑馬・犬追物）", recommendedPower: "10,170", icon: "fa-fire", description: "【武士の嗜みと実践訓練解説】\n武士の本分は「弓馬の道（きゅうばのみち）」。\n走る馬の上から的に向かって鏑矢を射る「流鏑馬（やぶさめ）」や、走る犬を的に見立てて弓を射る「犬追物（いぬおいもの）」は、実戦の軍事訓練であると同時に武士の威厳を示す儀礼であった。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d47_s05", name: "ステージ5: 遁世（とんせい）思想と世捨て人の庵（いおり）生活", recommendedPower: "10,500", icon: "fa-fire", description: "【中世の無常観と出家解説】\n戦乱や社会の激変（無常）に直面した人々が、人間関係や俗世の利益を捨てて仏門に入る「遁世（とんせい）」。\n山里に小さな草庵（いおり）を結び、清貧の中で自己の内面や仏道に向き合う生き方が『方丈記』（鴨長明）や『徒然草』（兼好法師）の文学的基盤となった。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" }
        ]
    },
    {
        id: 48,
        title: "火曜ダンジョン8: 本歌取りのルール",
        recommendedPower: "9,960〜11,280",
        icon: "fa-fire",
        gimmick: "defect",
        stages: [
            { id: "d48_s01", name: "ステージ1: 本歌取りのルール", recommendedPower: "9,960", icon: "fa-fire", description: "【和歌の高度な技法解説】\n古今和歌集などの誰でも知っている有名な古歌（本歌）のフレーズ（1・2句など）や状況設定を意図的に自身の歌に取り入れる創作技法。\n読者が「あ、あの有名歌が下敷きになっているな」と気づくことで、本歌の持つ情景やストーリーが重層的に重なり、歌の深み・奥行きが倍増する。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d48_s02", name: "ステージ2: 季節や感情の反転・ズレを楽しむ技法", recommendedPower: "10,290", icon: "fa-fire", description: "【本歌取りの表現技法解説】\n本歌の言葉をそのまま借りつつ、季節・時間帯・立場・感情をあえて「反転」させる高度な表現。\n（例：本歌が「春の桜の華やかさ」なら、それを取った新歌は「秋の紅葉のしんみりした情景」にするなど）。この比較の落差・ひねりが鑑賞の醍醐味。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d48_s03", name: "ステージ3: 藤原定家の『詠歌概略』に見る本歌取りの極意", recommendedPower: "10,620", icon: "fa-fire", description: "【定家の歌論解説】\n鎌倉初期の大歌人・藤原定家が示した本歌取りの厳格なルール：\n①本歌は有名な古歌から取ること。\n②取り入れる語句は句の半分程度（2句程度）に留めること。\n③本歌とは全く異なる季節やテーマ・心情に昇華させること。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d48_s04", name: "ステージ4: 新古今和歌集における幽玄・有心の表現", recommendedPower: "10,950", icon: "fa-fire", description: "【新古今調の美意識解説】\n『新古今和歌集』時代の最高峰の美意識。\n言葉の表面だけでなく、余情・妖艶さ・絵画的な象徴美が漂う「幽玄（ゆうげん）」「有心（うしん）」。本歌取りの技法は、この幻想的で深い余韻を作り出すための必須テクニックであった。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d48_s05", name: "ステージ5: 入試に出る「本歌」と「引き歌」の読解演習", recommendedPower: "11,280", icon: "fa-fire", description: "【入試実戦・本歌取り問題の解法】\n設問で「本歌」が提示された場合：\n①本歌の「季節・情景・登場人物の心情」を正確に直訳する。\n②本文中の和歌（引き歌）が、本歌のどの部分を継承し、どの部分を変化・対比させているかを比較する。\n選択肢の「本歌との共通点・相違点」のすり替えを見抜くのが合格点への最短ルート。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" }
        ]
    },
    {
        id: 49,
        title: "火曜ダンジョン9: 序詞の長さと枕詞の違い",
        recommendedPower: "10,740〜12,060",
        icon: "fa-fire",
        gimmick: "defect",
        stages: [
            { id: "d49_s01", name: "ステージ1: 序詞の長さと枕詞の違い", recommendedPower: "10,740", icon: "fa-fire", description: "【修辞技法の識別解説】\n・枕詞（まくらことば）：原則「5音（一句分）」で固定の特定語句を導く慣用表現（例：ひさかたの→光・月）。訳さなくてよい。\n・序詞（じのことば）：長さは決まっておらず「7音〜20音以上（二句〜三句以上に及ぶ）」の長い前置き。ある特定の言葉（中心となる語）を音の共通性やイメージで導き出す。訳す必要がある。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d49_s02", name: "ステージ2: 音の共通性で導く序詞（掛詞・同音異義）", recommendedPower: "11,070", icon: "fa-fire", description: "【音で導く序詞の構造解説】\n序詞の末尾の音が、導きたい中心語の音と同じ（同音異義・掛詞）パターン。\n（例：「みしのせる吉野の川のよしの川」→「よしの」の音を導く）。\n音の響きの連鎖によって、自然の景色から一気に人間の情念へと場面を接続する。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d49_s03", name: "ステージ3: 比喩・イメージの連想で導く序詞", recommendedPower: "11,400", icon: "fa-fire", description: "【イメージで導く序詞の構造解説】\n「〜のように」という比喩（たとえ）のイメージで本題の感情を引き出すパターン。\n（例：「秋のののみなに咲きたるなでしこ」→「撫でし子（愛しい我が子）」を連想で導く）。\n自然界の様子をたとえとして提示し、自分の切実な人間的感情を表現する。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d49_s04", name: "ステージ4: 訳し方の鉄則", recommendedPower: "11,730", icon: "fa-fire", description: "【序詞の現代語訳ルール】\n序詞部分は現代語訳で無視してはならず、必ず言葉の繋がりを明示する。\n訳し方の基本パターン：「〜のように」「〜ではないが、その〜のように」。\n序詞部分が比喩であることを明確にして本文の歌の意味に繋げる。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d49_s05", name: "ステージ5: 入試長文における序詞の発見アルゴリズム", recommendedPower: "12,060", icon: "fa-fire", description: "【序詞の解法ステップ】\n①歌の中で「どこからが筆者の言いたい本当の気持ち（本題）か」を見極める。\n②それより上の長い句（二〜三句分）が、本題の単語に音や比喩で強引に繋がっていないかチェック。\n③「〜のように」と補ってスムーズに読めれば序詞と確定。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" }
        ]
    },
    {
        id: 50,
        title: "火曜ダンジョン10: 水・川・海系の縁語",
        recommendedPower: "11,520〜12,840",
        icon: "fa-fire",
        gimmick: "defect",
        stages: [
            { id: "d50_s01", name: "ステージ1: 水・川・海系の縁語", recommendedPower: "11,520", icon: "fa-fire", description: "【縁語連想ネットワーク①】\n和歌の中で連想によって結びつく言葉のグループ（縁語）。\n・水・川・海系：「流る」「浮く」「袖」「濡る」「渚」「波」「瀬」「淵」「海人」「寄る」「干る」。\n涙で袖が濡れる連想から「水・川」の単語群が一斉に連動する。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d50_s02", name: "ステージ2: 衣・裁縫系の縁語", recommendedPower: "11,850", icon: "fa-fire", description: "【縁語連想ネットワーク②】\n・衣・裁縫系：「着る」「張る（春）」「裁つ（立つ）」「裾」「返る」「小夜衣」「解く」「脱ぐ」「縫う」。\n（例：「春」の季節に「（弓・衣を）張る」を掛け、さらに「着る・裁つ」の連鎖を作る）。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d50_s03", name: "ステージ3: 弓・矢系の縁語", recommendedPower: "12,180", icon: "fa-fire", description: "【縁語連想ネットワーク③】\n・弓・矢系：「引く」「張る」「射る（居る）」「音」「春」「執る」「外づる」。\n感情が強まる（引き締まる・心が張る）心理を弓矢の道具群で表現する。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d50_s04", name: "ステージ4: 火・煙系の縁語", recommendedPower: "12,510", icon: "fa-fire", description: "【縁語連想ネットワーク④】\n・火・煙系：「燃ゆ」「消ゆ」「思ひ（火）」「立ち上る」「富士の山」「焦がる」「くゆり」。\n激しい情熱・恋心を「火・煙」に関連するワードで固めて補強する。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" },
            { id: "d50_s05", name: "ステージ5: 縁語を見つけることで解き明かす和歌の主旨", recommendedPower: "12,840", icon: "fa-fire", description: "【縁語を活用した読解法】\n一見すると「ただの自然描写（風景）」に見える和歌でも、散りばめられた縁語グループを発見できれば、「実は激しい恋の歌だった」「深い悲しみの歌だった」という隠された主旨（テーマ）を正確に見破ることができる。\n\n【火曜ギミック】敵が攻撃するたび、ランダムな確率でランダムな味方1体が一時的に敵陣営へ寝返ります。寝返りは最大3体までで、戦闘終了または時間経過で復帰します。" }
        ]
    },
    {
        id: 51,
        title: "水曜ダンジョン1: 折句（おりく）の構造",
        recommendedPower: "5,000〜6,320",
        icon: "fa-wand-magic-sparkles",
        gimmick: "morph",
        stages: [
            { id: "d51_s01", name: "ステージ1: 折句（おりく）の構造", recommendedPower: "5,000", icon: "fa-wand-magic-sparkles", description: "【言語遊戯・折句の深掘り解説】\n五・七・五・七・七の各句の頭文字（1文字目）を繋げると、ある言葉（地名や人名、花の名など）が隠されているテクニック。\n『伊勢物語』東下りの「かきつばた」の歌（「から衣 きつつなれにし つましあれば はるばるきぬる 旅をしぞおもふ」→頭文字「か・き・つ・ば・た」）が超絶有名。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d51_s02", name: "ステージ2: 物名（ものな）の構造", recommendedPower: "5,330", icon: "fa-wand-magic-sparkles", description: "【言語遊戯・物名の深掘り解説】\n歌の意味・文脈とは全く関係のない「物の名前（動植物・道具など）」を、歌の言葉の中に音として隠し込む技法。\n（例：歌の途中に「〜ほのほの〜」と書いて「炎」を隠すなど）。古今和歌集の物名歌群などに多く見られる。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d51_s03", name: "ステージ3: 体言止め（たいげんどめ）の余韻と緊迫感", recommendedPower: "5,660", icon: "fa-wand-magic-sparkles", description: "【体言止めの効果解説】\n和歌の結び（末尾）を動詞の言い切りではなく「名詞（体言）」で終える修辞技法。\n①名詞を強調する。\n②余情・余韻を文末に残す。\n③情景をパッと静止画のように提示して、緊張感を出す。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d51_s04", name: "ステージ4: 三句切れ・初句切れなどの句切れの判定", recommendedPower: "5,990", icon: "fa-wand-magic-sparkles", description: "【句切れ判定の完全ルール】\n和歌の文法的・意味的な「言い切り（中断）」がどこにあるかを判定する。\n判定基準：終止形、命令形、係結びの結び（連体形・己然形）、詠嘆の助詞（かな・や）で文が途切れている場所。\n・初句で切れれば「初句切れ」、三句目で切れれば「三句切れ」、切れ目がなければ「句切れなし」。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d51_s05", name: "ステージ5: 和歌における疑問・反語の結びの省略", recommendedPower: "6,320", icon: "fa-wand-magic-sparkles", description: "【和歌の省略ルール解説】\n和歌の第5句（末尾）が「〜か」「〜や」などの係助詞で終わっている場合、本来下に続くはずの動詞（「〜であらうか［いや、〜ない］」「〜と思ふ」等）が省略されている。\n文末に省略されたニュアンス（反語か疑問か）を補って歌の意味を完成させる。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" }
        ]
    },
    {
        id: 52,
        title: "水曜ダンジョン2: 『竹取物語』求婚難題と伝奇性",
        recommendedPower: "5,780〜7,100",
        icon: "fa-wand-magic-sparkles",
        gimmick: "morph",
        stages: [
            { id: "d52_s01", name: "ステージ1: 『竹取物語』求婚難題と伝奇性", recommendedPower: "5,780", icon: "fa-wand-magic-sparkles", description: "【竹取物語の読解常識】\n「物語の出で来はじめの親（かな物語の始祖）」とされる最古の物語。\n前半はかぐや姫が5人の貴公子に無理難題（仏の御石の鉢、蓬莱の玉の枝、火鼠の皮衣、龍の首の珠、燕の安子貝）を突きつけ、人間の強欲や愚かさを暴く滑稽・求婚説話。後半は帝との文文のやり取りと、月へ昇天する伝奇的フィナーレを描く。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d52_s02", name: "ステージ2: 『伊勢物語』歌物語の形式と「昔、男ありけり」", recommendedPower: "6,110", icon: "fa-wand-magic-sparkles", description: "【伊勢物語の読解常識】\n「昔、男ありけり」の定型句で始まる最古の「歌物語」。\n主人公のモデルは在原業平。短いエピソード（章段）と和歌がセットになっており、男の元服から恋、東下り、落ちぶれ、臨終までの一生を描く。抒情性と「雅（みやび）」の美意識が中心。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d52_s03", name: "ステージ3: 『平中物語』『大和物語』の滑稽さと恋愛模様", recommendedPower: "6,440", icon: "fa-wand-magic-sparkles", description: "【平安初期・中期の歌物語解説】\n・『平中物語』：モテ男だがどこか間が抜けていて失敗ばかりする平中（平貞文）の滑稽な恋愛遍歴を描く。\n・『大和物語』：皇族・貴族たちの実際の和歌にまつわるエピソード（姨捨山伝説や生田川伝説など）を集めた歌物語。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d52_s04", name: "ステージ4: 『源氏物語』の成立背景と「もののあはれ」", recommendedPower: "6,770", icon: "fa-wand-magic-sparkles", description: "【源氏物語の読解常識】\n紫式部著。全54帖におよぶ平安最高峰の長編物語。\n主人公・光源氏の栄華と苦悩の人生を描く前編・中編と、その死後の子孫たちの救いなき恋愛を描く「宇治十帖（後編）」。本質的なテーマは「もののあはれ（深く情に触れる人間ドラマ・哀愁）」。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d52_s05", name: "ステージ5: 『狭衣物語』『夜の寝覚』など王朝後期の物語", recommendedPower: "7,100", icon: "fa-wand-magic-sparkles", description: "【王朝後期物語の発展解説】\n『源氏物語』の影響を強烈に受けて作られた後期物語群。\n・『狭衣物語（さごろも）』：源氏物語に匹敵する人気を博した、悲恋と苦悩の物語。\n・『夜の寝覚（よのねざめ）』：宿命的な悲恋と心理描写の深化を描いた文学。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" }
        ]
    },
    {
        id: 53,
        title: "水曜ダンジョン3: 『枕草子』の類聚的章段と「をかし」の美的眼識",
        recommendedPower: "6,560〜7,880",
        icon: "fa-wand-magic-sparkles",
        gimmick: "morph",
        stages: [
            { id: "d53_s01", name: "ステージ1: 『枕草子』の類聚的章段と「をかし」の美的眼識", recommendedPower: "6,560", icon: "fa-wand-magic-sparkles", description: "【枕草子の読解常識】\n清少納言著。一条天皇の中宮定子に仕えた宮廷随筆。\n構成：①「〜は」で始まる類聚（ものづくし）章段（例：すさまじきもの、あてなるもの）、②日常の観察・自然描写章段（例：春はあけぼの）、③宮廷回想章段。明るく知的で直感的な美（「をかし」）を追求した。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d53_s02", name: "ステージ2: 『方丈記』鴨長明の安達太良・無常観と災害記録", recommendedPower: "6,890", icon: "fa-wand-magic-sparkles", description: "【方丈記の読解常識】\n鴨長明著。鎌倉初期の隠棲随筆。「ゆく河の流れは絶えずして、しかももとの水にあらず」。\n前半は安元の大火、治承の竜巻、福原遷都、養和の飢饉、元暦の大地震などの天災・人災の記録。後半は日野山に構えた一丈四方（方丈）の庵での無常観と、執着を捨てきれない自己の葛藤を描く。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d53_s03", name: "ステージ3: 『徒然草』兼好法師の世俗批判と人間観察", recommendedPower: "7,220", icon: "fa-wand-magic-sparkles", description: "【徒然草の読解常識】\n兼好法師（卜部兼好）著。南北朝時代の随筆。「つれづれなるままに、日ひぐらし形しろけ物にむかひて…」。\n自然観、人生訓、世俗の人間観察、有職故実（儀式や伝統）など多岐にわたる。諸行無常を受け入れつつ、今この瞬間を味わう現実的・客観的な知恵が語られる。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d53_s04", name: "ステージ4: 随筆における筆者の主張・感想の読み取り方", recommendedPower: "7,550", icon: "fa-wand-magic-sparkles", description: "【随筆読解のアルゴリズム】\n具体的なエピソード（事実・体験談）が語られた後、章段の最後に筆者の「批評・まとめのコメント（主張）」が置かれる構造が多い。\nエピソード部分と、筆者の「〜こそ〜あれ」「〜まほし」「〜べきなり」という主張部分を明確に切り分けて読む。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d53_s05", name: "ステージ5: 日記と随筆の境界線", recommendedPower: "7,880", icon: "fa-wand-magic-sparkles", description: "【日記と随筆の差異】\n・日記：時系列（日付順）に沿って自分のプライベートな体験や感情を記録する。\n・随筆：テーマ別（思考・観察別）に配列され、個人的体験を超えた普遍的な人間観察や美意識の批評を提示する。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" }
        ]
    },
    {
        id: 54,
        title: "水曜ダンジョン4: 『土佐日記』男もすなる日記",
        recommendedPower: "7,340〜8,660",
        icon: "fa-wand-magic-sparkles",
        gimmick: "morph",
        stages: [
            { id: "d54_s01", name: "ステージ1: 『土佐日記』男もすなる日記", recommendedPower: "7,340", icon: "fa-wand-magic-sparkles", description: "【土佐日記の読解常識】\n紀貫之著。仮名文字による最古の日記。「男もすなる日記といふものを、女もしてみむとてするなり」。\n土佐国司の任期を終えた貫之が、女性に仮託して京へ帰る55日間の旅路を描く。途中で亡くした幼い娘への哀傷と、和歌を中心としたユーモア溢れる表現が特徴。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d54_s02", name: "ステージ2: 『蜻蛉日記』藤原道綱母の結婚生活の現実と苦悩", recommendedPower: "7,670", icon: "fa-wand-magic-sparkles", description: "【蜻蛉日記の読解常識】\n藤原道綱母著。平安女流日記文学の先駆。「上等な物語の嘘に比べて、自分の身の上の現実を書こう」という動機。\n夫・藤原兼家との冷めゆく結婚生活の苦悩、一妻多夫制下の葛藤、愛子・道綱への愛情を身を切るようなリアルな心理描写で描いた自伝的一記。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d54_s03", name: "ステージ3: 『和泉式部日記』情熱的な歌のやり取りと愛執", recommendedPower: "8,000", icon: "fa-wand-magic-sparkles", description: "【和泉式部日記の読解常識】\n恋多き歌人・和泉式部著。\n亡き恋人（弾正宮）の弟である帥宮（そちのみや）とのドラマチックな恋愛模様を描く。二人の間で交わされた膨大な贈答歌を中心に、熱烈な愛執と不安に揺れる女心が描かれる。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d54_s04", name: "ステージ4: 『紫式部日記』宮中批判と同僚宮廷女房の人物評", recommendedPower: "8,330", icon: "fa-wand-magic-sparkles", description: "【紫式部日記の読解常識】\n紫式部著。一条天皇の中宮彰子に出仕した際の記録。\n彰子の親王出産を祝う宮廷儀式の華やかな記録と同時に、同僚の女房（清少納言や和泉式部など）に対する鋭い人物批判、および自身の内省的な孤独感が綴られている。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d54_s05", name: "ステージ5: 『更級日記』菅原孝標女の物語への憧れと人生の回想", recommendedPower: "8,660", icon: "fa-wand-magic-sparkles", description: "【更級日記の読解常識】\n菅原孝標女（すがわらのたかすえのむすめ）著。50代になって自分の人生を振り返った回想日記。\n上総国（東国）で育ち『源氏物語』を読むことを夢見た少女時代、大人になって現実の厳しい結婚生活に直面し、晩年に信心へと向かっていく悲哀とロマンを描く。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" }
        ]
    },
    {
        id: 55,
        title: "水曜ダンジョン5: 「四鏡（しきょう）」の成立順と歴史の時代区分",
        recommendedPower: "8,120〜9,440",
        icon: "fa-wand-magic-sparkles",
        gimmick: "morph",
        stages: [
            { id: "d55_s01", name: "ステージ1: 「四鏡（しきょう）」の成立順と歴史の時代区分", recommendedPower: "8,120", icon: "fa-wand-magic-sparkles", description: "【四鏡の基本データ】\n成立順（「鏡」の成立）：『大鏡』→『今鏡』→『水鏡』→『増鏡』（覚え方：か・い・み・ます）。\n描かれた時代順：\n①『水鏡』（神武天皇〜文徳天皇/最古）\n②『大鏡』（文徳天皇〜後一条天皇/藤原道長の栄華）\n③『今鏡』（後一条天皇〜高倉天皇/院政期）\n④『増鏡』（後鳥羽院〜後醍醐天皇/鎌倉時代・南北朝）\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d55_s02", name: "ステージ2: 批判的歴史観（大鏡の繁樹と直世の対話構造）", recommendedPower: "8,450", icon: "fa-wand-magic-sparkles", description: "【大鏡の構造と表現解説】\n『大鏡』の画期的な手法。\n190歳の大宅繁樹（おおやけのしげき）と180歳の夏山繁樹（なつやまのしげき）という超長寿の老人が雲林院の仏名会で昔語り（対話）をし、それを若者が聞き取るという座談会形式。\n公的な歴史書（六国史）と異なり、道長の栄華を称賛しつつも、権力闘争の陰謀や人間の愚かさを批判的に活写した。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d55_s03", name: "ステージ3: 編年体と紀伝体の物語構成の違い", recommendedPower: "8,780", icon: "fa-wand-magic-sparkles", description: "【歴史書の記述形式解説】\n・編年体（へんねんたい）：年月・日付の順番（時間経過）に沿って出来事を記述する形式（例：『日本書紀』『水鏡』）。\n・紀伝体（きでんたい）：帝王の記録（本紀）や個人ごとの伝記（列伝）という「人物別」に章を分けて記述する形式（例：『大鏡』『史記』）。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d55_s04", name: "ステージ4: 藤原氏の権力掌握プロセスと政変の記録", recommendedPower: "9,110", icon: "fa-wand-magic-sparkles", description: "【大鏡に出る重要歴史エピソード】\n藤原氏（特に道長）がいかにライバルを蹴落として頂点に立ったかのドキュメンタリー。\n安和の変、花山天皇を欺いて出家させた「寛和の変（道兼の陰謀）」など、生々しい政変の裏側が入試の古文長文として頻出する。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d55_s05", name: "ステージ5: 歴史物語における事実とフィクションの融合", recommendedPower: "9,440", icon: "fa-wand-magic-sparkles", description: "【歴史物語の解法ポイント】\n歴史的語り（史実）の中に、登場人物のセリフや心情、怪異現象などの文学的・フィクション的演出が巧みに織り込まれている。文脈における人物の思惑を見抜くことが不可欠。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" }
        ]
    },
    {
        id: 56,
        title: "水曜ダンジョン6: 世俗説話と仏教説話の違い",
        recommendedPower: "8,900〜10,220",
        icon: "fa-wand-magic-sparkles",
        gimmick: "morph",
        stages: [
            { id: "d56_s01", name: "ステージ1: 世俗説話と仏教説話の違い", recommendedPower: "8,900", icon: "fa-wand-magic-sparkles", description: "【説話文学の二大ジャンル解説】\n・仏教説話：因果応報、出家得道、観音の霊験など、仏法のありがたさや教訓を伝える説話。\n・世俗説話：貴族や庶民の滑稽な話、失敗談、武勇伝、怪異譚、芸術・歌の秘話など、人間の生き様そのものを面白がる説話。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d56_s02", name: "ステージ2: 『今昔物語集』の「今ハ昔」と和漢混淆文", recommendedPower: "9,230", icon: "fa-wand-magic-sparkles", description: "【今昔物語集の読解常識】\n日本最大の説話集。全31巻。\n冒頭はすべて「今ハ昔（今は昔）」で始まる。\n構成：「天竺（インド）」「震旦（中国）」「本朝（日本）」の3部構成。文章は漢字ひらがな交じりの力強い「和漢混淆文」。ダイナミックな庶民の生き生きとした姿が描かれる。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d56_s03", name: "ステージ3: 『宇治拾遺物語』の滑稽・怪異・教訓", recommendedPower: "9,560", icon: "fa-wand-magic-sparkles", description: "【宇治拾遺物語の読解常識】\n鎌倉初期の代表的世俗説話集。\n「わらしべ長者」「こぶとりじいさん」「舌切り雀」などの昔話の原形から、オチのある滑稽話（「利生のお頭」）、怪異譚（「百鬼夜行」）まで多種多様。人間味溢れるコミカルな視点が特徴。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d56_s04", name: "ステージ4: 『十訓抄』幼少期の道徳教育・教訓書としての側面", recommendedPower: "9,890", icon: "fa-wand-magic-sparkles", description: "【十訓抄の読解常識】\n鎌倉時代の教訓説話集。\n年少者の道徳教育のために、人間として守るべき10の教訓（例：「人に恵みを施すべき事」「情を解すべき事」「可意の友を選ぶべき事」など）を掲げ、それに沿ったエピソードを分類して提示する。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d56_s05", name: "ステージ5: 『古今著聞集』風流・芸能・執着の説話", recommendedPower: "10,220", icon: "fa-wand-magic-sparkles", description: "【古今著聞集の読解常識】\n橘成季（たちばなのなりすえ）著。鎌倉中期の説話集。\n王朝時代の風流・芸術（和歌・管弦・蹴鞠・絵画など）を称賛・懐古するストーリーが多く収められている。執着心や芸能に命をかける人間の姿が美しく描かれる。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" }
        ]
    },
    {
        id: 57,
        title: "水曜ダンジョン7: 物語本文と「評論・解説文」の照らし合わせ",
        recommendedPower: "9,680〜11,000",
        icon: "fa-wand-magic-sparkles",
        gimmick: "morph",
        stages: [
            { id: "d57_s01", name: "ステージ1: 物語本文と「評論・解説文」の照らし合わせ", recommendedPower: "9,680", icon: "fa-wand-magic-sparkles", description: "【共通テスト形式攻略①】\n古文本文（資料A）と、それに対する現代の評論家・研究者の解説文（資料B）がセットで出題されるパターン。\n解法：解説文の中に書かれている「物語の主題」「人物の心理分析」のキーワードをチェックし、それが本文（資料A）のどのセリフや行動に対応しているかをパズル的に照合する。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d57_s02", name: "ステージ2: 和歌と「和歌の注釈書（歌学書）」の対比", recommendedPower: "10,010", icon: "fa-wand-magic-sparkles", description: "【共通テスト形式攻略②】\n和歌そのものと、その歌の出来栄えや背景を評価した歌論・注釈書を比べるパターン。\n解法：歌注釈書の中で選者が「この歌のここが見事だ」「この掛詞が効いている」と絶賛しているポイントを探し、和歌の該当部分の修辞（掛詞・縁語）と合致しているか確認する。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d57_s03", name: "ステージ3: 同一場面を描いた「物語」と「日記」の視点比較", recommendedPower: "10,340", icon: "fa-wand-magic-sparkles", description: "【共通テスト形式攻略③】\n同じ歴史的事件・場面を、客観的・伝奇的に描いた「物語文学」と、当事者がリアルタイムで書いた「日記文学」を比較する問題。\n解法：登場人物の名前の違い、感情表現の温度差、主観的解釈のズレを比較し設問の選択肢を吟味する。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d57_s04", name: "ステージ4: 本文と「図解・挿絵・絵巻物」の合致問題", recommendedPower: "10,670", icon: "fa-wand-magic-sparkles", description: "【共通テスト形式攻略④】\n文章表現と、絵巻物の描かれ方（位置関係・人物の配置・服装・部屋の構造）の一致を問う問題。\n解法：本文中の「位置関係の語（上座・下座・簾の内・御簾の外・南の庇）」や「持ち物」を注意深く読み取り、視覚情報と完全一致するものを選ぶ。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d57_s05", name: "ステージ5: 登場人物の意見対立・対話文の整理", recommendedPower: "11,000", icon: "fa-wand-magic-sparkles", description: "【共通テスト形式攻略⑤】\n複数の登場人物（または現代の生徒たち）が対話しながら本文を解釈する思考力問題。\n解法：各発言者の論点（A君は「悲しみの表現」と主張、Bさんは「怒りの表現」と主張）を整理し、本文の根拠（助詞・助動詞・敬語）に照らしてどちらの主張が妥当かを判定する。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" }
        ]
    },
    {
        id: 58,
        title: "水曜ダンジョン8: 選択肢の中の「掛詞の過剰解釈」を見抜く",
        recommendedPower: "10,460〜11,780",
        icon: "fa-wand-magic-sparkles",
        gimmick: "morph",
        stages: [
            { id: "d58_s01", name: "ステージ1: 選択肢の中の「掛詞の過剰解釈」を見抜く", recommendedPower: "10,460", icon: "fa-wand-magic-sparkles", description: "【和歌選択肢の罠①】\n選択肢の中に「存在しない掛詞」を深読みして組み込んだ間違い選択肢。\n吟味法：単語の音が本当に２つの意味に分割できるか（例：「松」と「待つ」は成立するが、不自然な分割は×）。掛詞として成立していない解釈を排除する。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d58_s02", name: "ステージ2: 和歌の「直訳」と「心情の意訳」のバランス", recommendedPower: "10,790", icon: "fa-wand-magic-sparkles", description: "【和歌選択肢の罠②】\n選択肢が「言葉の直訳だけで心情に触れていない」または「心情ばかり膨らんで言葉の直訳を無視している」パターン。\n正解の選択肢は必ず【修辞に基づいた正確な直訳】＋【文脈に合致した登場人物の心理】の両方が過不足なく含まれている。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d58_s03", name: "ステージ3: 返歌（へんか）における「贈歌の言葉の踏襲」", recommendedPower: "11,120", icon: "fa-wand-magic-sparkles", description: "【返歌の法則と読解】\n贈歌（相手から送られてきた歌）に対して詠む返歌（お返しの歌）。\n返歌の鉄則：相手の歌に使われていた「キーワード（単語）」や「修辞」をあえてそのまま自分の歌に取り込み、それを打ち消したり上書きしたりして返答する。\nこの「言葉のキャッチボール」の関係性を選択肢から探す。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d58_s04", name: "ステージ4: 歌の背景にある「状況（文脈）」の確認", recommendedPower: "11,450", icon: "fa-wand-magic-sparkles", description: "【和歌の文脈確認】\n和歌は単体で存在することはなく、必ず「詞書（ことばがき）」や「直前の文章」という背景が存在する。\n歌だけを見て判断せず、「誰が、誰に対して、どういう状況（逢瀬の翌朝、別れ、身分の差）で詠んだか」を本文から補完して解釈する。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d58_s05", name: "ステージ5: 共通テスト特有の「生徒の話し合い問題」攻略法", recommendedPower: "11,780", icon: "fa-wand-magic-sparkles", description: "【生徒対話問題の攻略アルゴリズム】\n共通テスト古文の問4などで出題される生徒の会話。\n生徒の発言文中の空欄を埋める際、直前直後の「でも〜」「確かに〜」などの接続語に着目し、議論のロジック（肯定・反論・補足）に整合する文法・解釈の根拠を選択肢から導き出す。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" }
        ]
    },
    {
        id: 59,
        title: "水曜ダンジョン9: 時間の経過を示す語",
        recommendedPower: "11,240〜12,560",
        icon: "fa-wand-magic-sparkles",
        gimmick: "morph",
        stages: [
            { id: "d59_s01", name: "ステージ1: 時間の経過を示す語", recommendedPower: "11,240", icon: "fa-wand-magic-sparkles", description: "【文脈推測のキーワード①】\n時間の経過・展開を示す副詞・接続語を見逃さない。\n・「やがて」：すぐに・そのまま。\n・「ほどなく」：間もなく・しばらくして。\n・「あけて」：夜が明けて。\n・「年ごろ」：長年・数年来。\n時間の跳躍を把握することで、場面が「回想」から「現在」へ戻ったことなどを察知する。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d59_s02", name: "ステージ2: 場面・場所の移動", recommendedPower: "11,570", icon: "fa-wand-magic-sparkles", description: "【文脈推測のキーワード②】\n登場人物の移動を示す敬語動詞・移動動詞。\n・「まかる」「退出する」：宮中や貴人宅から下がる（場所移動）。\n・「まいる」「詣づ」：神社仏閣・高貴な屋敷へ行く。\n・「いでたつ」：旅立つ・出発する。\nどこからどこへ空間が移動したかを明確に補いながら読む。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d59_s03", name: "ステージ3: 登場人物の出入り", recommendedPower: "11,900", icon: "fa-wand-magic-sparkles", description: "【文脈推測のキーワード③】\n・「訪ねてくる（訪ふ・おとづる）」\n・「さし入る・入る」\n・「去ぬ・退く」\n新たな人物の登場によって会話の相手や画面上の人間関係が激変する瞬間をキャッチする。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d59_s04", name: "ステージ4: 心情の変化を表す接句・接続語", recommendedPower: "12,230", icon: "fa-wand-magic-sparkles", description: "【感情のブレイクポイント】\n・「されど」「文脈の『〜ど』『〜ば』」\n・「思い返すに」「〜心地して」\n登場人物が葛藤の末に決断を変更した（出家を決意した、諦めた）プロセスの転換点を見つける。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d59_s05", name: "ステージ5: 結末の教訓・落としどころの捉え方", recommendedPower: "12,560", icon: "fa-wand-magic-sparkles", description: "【文章全体のオチの把握】\n説話や物語の最後は、「だから〜なのだ」「これによって人は〜と褒め称えた」という教訓・結論（オチ）で締めくくられる。\n物語全体のテーマ（成功談なのか、失敗の教訓なのか、悲恋の哀悼なのか）をラストシーンから逆算して確定させる。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" }
        ]
    },
    {
        id: 60,
        title: "水曜ダンジョン10: 会話文の始めと終わりの省略（鍵かっこ補完）",
        recommendedPower: "12,020〜13,340",
        icon: "fa-wand-magic-sparkles",
        gimmick: "morph",
        stages: [
            { id: "d60_s01", name: "ステージ1: 会話文の始めと終わりの省略（鍵かっこ補完）", recommendedPower: "12,020", icon: "fa-wand-magic-sparkles", description: "【省略攻略法①】\n古文の原文には鍵かっこ「 」が存在しない。\n会話文の開始位置（「〜と言ひて」「〜と思ふに」の直前）と終了位置（「〜と（て）」「〜文を」の直前）に自分で鍵かっこを正確に書き補うトレーニングを徹底する。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d60_s02", name: "ステージ2: 目的語（〜を、〜に）の省略の復元", recommendedPower: "12,350", icon: "fa-wand-magic-sparkles", description: "【省略攻略法②】\n主語だけでなく「誰を（目的語）」「誰に（対象）」の省略も頻発する。\n特に「（帝が）［姫君に］（使者を）遣はす」「（男が）［女に］（手紙を）奉る」といった授受・敬語動詞の周囲で省略された目的語を文脈から復元する。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d60_s03", name: "ステージ3: 和歌の詠み手の省略の特定", recommendedPower: "12,680", icon: "fa-wand-magic-sparkles", description: "【省略攻略法③】\n物語で突然和歌が詠まれる際、「誰が詠んだか」が省略されることが多い。\n和歌の直前にある動詞の敬語レベル（尊敬語があれば高貴な人物、なければ一般的な人物）と、歌の内容（男視点か女視点か）から詠み手を一瞬で特定する。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d60_s04", name: "ステージ4: 引用の「と」「て」の直後の動詞省略（言う・思う）", recommendedPower: "13,010", icon: "fa-wand-magic-sparkles", description: "【省略攻略法④】\n古文の絶対ルール：「〜と（て）［省略］」。\n引用の格助詞「と」「て」の直後にある「言ふ」「思ふ」「聞く」「見る」などの基本動詞は超高確率で省略される。頭の中で「と言って」「と思って」を自動的に足して読む。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" },
            { id: "d60_s05", name: "ステージ5: 手紙・文（ふみ）の内容の省略読み取り", recommendedPower: "13,340", icon: "fa-wand-magic-sparkles", description: "【省略攻略法⑤】\n「文の中には『〜〜』となむ書きたりける」の構造。\n手紙の引用文の切れ目を見極め、手紙を「書いた人（差出人）」と「受け取った人（受取人）」の関係性を常に整理して本文を読む。\n\n【水曜ギミック】敵が攻撃するたび、ランダムな確率でメイン編成の1体が別キャラへ変身します。対象数に上限はなく、貴族も対象になり得ます。" }
        ]
    },
    {
        id: 61,
        title: "木曜ダンジョン1: 語彙・文法・常識のトリプルチェック法",
        recommendedPower: "5,500〜6,820",
        icon: "fa-scroll",
        gimmick: "kogo",
        stages: [
            { id: "d61_s01", name: "ステージ1: 語彙・文法・常識のトリプルチェック法", recommendedPower: "5,500", icon: "fa-scroll", description: "【満点テクニック①】\n難解な古文長文に遭遇した際、解釈のブレを抑える3重の検証枠組み：\n①単語の意味（多義語の正しい選択）。\n②文法構造（助動詞の意味・敬語の方向による主語特定）。\n③古文常識（当時の身分制・文化・恋愛ルールの矛盾がないか）。\nこの3つが合致した解釈のみを正解とする。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d61_s02", name: "ステージ2: 制限時間内で解くスキャニング・スキミング技術", recommendedPower: "5,830", icon: "fa-scroll", description: "【満点テクニック②】\n共通テストの厳しい制限時間（古文に割り当てられる約15〜20分）を突破する速読術。\n・注釈（リード文・脚注）を本文の前に100%完璧に読み込む（登場人物と状況の半分は注釈で解明できる）。\n・設問の選択肢をチラ見して、ストーリーの大まかな流れをあらかじめ把握してから本文を読む。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d61_s03", name: "ステージ3: 選択肢のひっかけパターン", recommendedPower: "6,160", icon: "fa-scroll", description: "【満点テクニック③】\n悪魔的なひっかけ選択肢の3大パターンを見抜く：\n①「すり替え」：AのセリフなのにBのセリフにすり替わっている。\n②「言い過ぎ（過剰解釈）」：本文に書いていない現代的な心理まで深読みし過ぎている。\n③「不足（要素抜け）」：和歌の重要な修辞（掛詞）の訳がごっそり抜けている。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d61_s04", name: "ステージ4: 和歌を含んだ複合問題の最終攻略", recommendedPower: "6,490", icon: "fa-scroll", description: "【満点テクニック④】\n本文のストーリー展開と、劇中で詠まれる和歌、さらに解説文（資料）の3要素が完全にリンクするポイントを見抜く。\n和歌は文章全体の「感情の最高潮（クライマックス）」であることを理解して解く。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d61_s05", name: "ステージ5: 古文攻略の総仕上げ・満点達成試練", recommendedPower: "6,820", icon: "fa-scroll", description: "【古文マスターへの最終提言】\n古文は外国語ではなく「昔の日本語」。\n単体の知識（文法・単語）を丸暗記する段階を終えたら、それらをつなぎ合わせて「当時の貴族たちの心・生のドラマ」を追体験する読解へと昇華させること。\n以上の全60ダンジョン・155ステージの知識を武器に、共通テストおよび二次試験の古文長文で満点を勝ち取れ！ダンジョン61: 現代語と意味が異なる「罠」単語\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" }
        ]
    },
    {
        id: 62,
        title: "木曜ダンジョン2: 「おどろく」",
        recommendedPower: "6,280〜7,600",
        icon: "fa-scroll",
        gimmick: "kogo",
        stages: [
            { id: "d62_s01", name: "ステージ1: 「おどろく」", recommendedPower: "6,280", icon: "fa-scroll", description: "【おどろくの深掘り解説】現代語の「恐怖や意外さでびっくりする」ではなく、古文では「目を覚ます」「（ハッと）気づく」を意味する。夢から覚める場面や、それまで忘れていたことに突然思い至る文脈で多用される。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d62_s02", name: "ステージ2: 「ののしる」", recommendedPower: "6,610", icon: "fa-scroll", description: "【ののしるの深掘り解説】現代語の「悪口を言う」ではなく、「大声で騒ぐ」「評判になる」を意味する。プラス・マイナス両方の意味で用いられ、館内がガヤガヤと賑わう様子や、名声が世間に広まっている状態を表す。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d62_s03", name: "ステージ3: 「あさまし」", recommendedPower: "6,940", icon: "fa-scroll", description: "【あさましの深掘り解説】現代語の「情けない・浅ましい」ではなく、「呆れるほどだ」「思いがけないことに驚く」を意味する。予期せぬ事態に直面して茫然自失となったり、開いた口が塞がらない状態を指す。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d62_s04", name: "ステージ4: 「こころぐるし」", recommendedPower: "7,270", icon: "fa-scroll", description: "【こころぐるしの深掘り解説】自分が心苦しいだけでなく、他人の不幸や困窮を見て「気の毒だ」「心配だ」と痛々しく思う客観的・同情的なニュアンスが強い。相手を気遣う優しさが滲む重要語。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d62_s05", name: "ステージ5: 「ありがたし」", recommendedPower: "7,600", icon: "fa-scroll", description: "【ありがたしの深掘り解説】現代語の「感謝している」ではなく、「滅多にない（有難し）」「めったにないほど素晴らしい」「（生きるのが）難しい」を意味する。滅多に存在しない貴重さや奇跡的な状態を表す。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" }
        ]
    },
    {
        id: 63,
        title: "木曜ダンジョン3: 「なさけ（情け）」",
        recommendedPower: "7,060〜8,380",
        icon: "fa-scroll",
        gimmick: "kogo",
        stages: [
            { id: "d63_s01", name: "ステージ1: 「なさけ（情け）」", recommendedPower: "7,060", icon: "fa-scroll", description: "【なさけ（情け）の深掘り解説】単なる同情心だけでなく、人間味あふれる「思いやり」、風流や恋愛を理解する「風流心・風趣」、そして「情愛」の3要素を併せ持つ。平安貴族の教養と情愛の象徴。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d63_s02", name: "ステージ2: 「ほ意（本意）」", recommendedPower: "7,390", icon: "fa-scroll", description: "【ほ意（本意）の深掘り解説】「本来の志や望み」のこと。特に王朝文学や出家物語においては「出家して仏道に専念したいという長年の願い（本意を果たす）」を指す文脈が極めて多い。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d63_s03", name: "ステージ3: 「ちぎり（契り）」", recommendedPower: "7,720", icon: "fa-scroll", description: "【ちぎり（契り）の深掘り解説】男女の「約束・交わり」を指すほか、仏教的な「前世からの宿縁・因縁」を意味する。逃れられない運命や巡り合わせを表現する際に使われる。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d63_s04", name: "ステージ4: 「けしき（気色）」", recommendedPower: "8,050", icon: "fa-scroll", description: "【けしき（気色）の深掘り解説】目に見える「様子・風景」から、人の「機嫌・表情」、さらには内に秘めた「意向・意中」まで表す。相手の意向を察する文脈（けしきばむ等）で重要となる。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d63_s05", name: "ステージ5: 「よのなか（世の中）」", recommendedPower: "8,380", icon: "fa-scroll", description: "【よのなか（世の中）の深掘り解説】単なる社会（世間）や政治（治世）だけでなく、特に王朝文学では「男女の仲・夫婦関係」を直接的に指す。世の無常さや人間関係の無常感を込めて詠まれる。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" }
        ]
    },
    {
        id: 64,
        title: "木曜ダンジョン4: 「あまた・ここら・そこら」",
        recommendedPower: "7,840〜9,160",
        icon: "fa-scroll",
        gimmick: "kogo",
        stages: [
            { id: "d64_s01", name: "ステージ1: 「あまた・ここら・そこら」", recommendedPower: "7,840", icon: "fa-scroll", description: "【あまた・ここら・そこらの深掘り解説】いずれも「たくさん・数多く」を意味する副詞。「ここら・そこら」は単なる場所の指示ではなく、「これほど多く・そこかしこにたくさん」という数量の多さを強調する。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d64_s02", name: "ステージ2: 「いささか・ちと・わずかに」", recommendedPower: "8,170", icon: "fa-scroll", description: "【いささか・ちと・わずかにの深掘り解説】程度や数量が「ほんの少し・わずか」であることを表す。「いささか」は現代語より否定を伴わない単純な「少し」の意で使われることが多く、慎ましい表現に好まれる。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d64_s03", name: "ステージ3: 「ひねもす・よもすがら」", recommendedPower: "8,500", icon: "fa-scroll", description: "【ひねもす・よもすがらの深掘り解説】「ひねもす」は朝から夕方までの「一日中」、「よもすがら」は夜が明けるまでの「一晩中」を指す。時の経過の長さを強調し、物思いに沈む場面などで対比される。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d64_s04", name: "ステージ4: 「おのずから・たまたま」", recommendedPower: "8,830", icon: "fa-scroll", description: "【おのずから・たまたまの深掘り解説】「おのずから」は自然の成り行きで「自然と・ひとりでに」。「たまたま」は滅多にないことが起こる「偶然・偶然にも」を意味する。文脈での因果関係の判定に必須。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d64_s05", name: "ステージ5: 「すでに・ついに」", recommendedPower: "9,160", icon: "fa-scroll", description: "【すでに・ついにの深掘り解説】「すでに」は「すっかり・完全に（または今にも）」、「ついに」は「とうとう・最後まで（下に打消を伴って『二度と〜ない』）」という意味になる。結末や状態の完了を示す。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" }
        ]
    },
    {
        id: 65,
        title: "木曜ダンジョン5: 「心苦し・心を尽くす」",
        recommendedPower: "8,620〜9,940",
        icon: "fa-scroll",
        gimmick: "kogo",
        stages: [
            { id: "d65_s01", name: "ステージ1: 「心苦し・心を尽くす」", recommendedPower: "8,620", icon: "fa-scroll", description: "【心苦し・心を尽くすの深掘り解説】「心を尽くす」は気をもみ、あらゆる心配をして「心を痛める・精神をすり減らす」こと。相手を想うあまり悲嘆や苦悶に陥る心理状態を繊細に描写する。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d65_s02", name: "ステージ2: 「目もあやなり・目移りす」", recommendedPower: "8,950", icon: "fa-scroll", description: "【目もあやなり・目移りすの深掘り解説】「目もあやなり」はあまりに素晴らしくて「眩しいほどだ・正視できない」さま。「目移りす」は心が定まらず「気が散る・他方に心が惹かれる」状態を表す。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d65_s03", name: "ステージ3: 「袖をぬらす・涙を落とす」", recommendedPower: "9,280", icon: "fa-scroll", description: "【袖をぬらす・涙を落とすの深掘り解説】悲しみや落胆により「深く悲しんで涙を流す」様子を表現する定番の慣用表現。袖が涙で濡れて重くなる描写は王朝文学の叙情性の核心。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d65_s04", name: "ステージ4: 「心をやる・心を澄ます」", recommendedPower: "9,610", icon: "fa-scroll", description: "【心をやる・心を澄ますの深掘り解説】「心をやる」は塞ぎ込んだ気分を晴らす「気晴らしをする・心を慰める」。「心を澄ます」は雑念を払い「心を落ち着かせる・澄み切った状態にする」こと。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d65_s05", name: "ステージ5: 「名を立つ・名を流す」", recommendedPower: "9,940", icon: "fa-scroll", description: "【名を立つ・名を流すの深掘り解説】世間に評判や噂が広まること。「名を立つ」は功名や浮名が世間に立つこと、「名を流す」は噂や浮名（噂話）が流布して浮き名が立ってしまうことを意味する。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" }
        ]
    },
    {
        id: 66,
        title: "木曜ダンジョン6: 断定の「なり」",
        recommendedPower: "9,400〜10,720",
        icon: "fa-scroll",
        gimmick: "kogo",
        stages: [
            { id: "d66_s01", name: "ステージ1: 断定の「なり」", recommendedPower: "9,400", icon: "fa-scroll", description: "【断定の「なり」の深掘り解説】体言や活用語の連体形に接続する「なり」は断定（〜である・〜だ）。存在（〜にある・居る）の意味も持つ。「名詞＋なり」「連体形＋なり」の形を見極めるのが識別の第一歩。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d66_s02", name: "ステージ2: 伝聞・推定の「なり」", recommendedPower: "9,730", icon: "fa-scroll", description: "【伝聞・推定の「なり」の深掘り解説】終止形（ラ変型は連体形）に接続する「なり」は伝聞（〜という）または推定（〜のようだ・〜音がする）。特に音や声など聴覚的根拠に基づく推定で多く用いられる。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d66_s03", name: "ステージ3: 存在の「なり」", recommendedPower: "10,060", icon: "fa-scroll", description: "【存在の「なり」の深掘り解説】場所を表す体言や格助詞「に」などに接続し、「〜にある・〜に居る」と存在する場所を示す。「〜に＋なり」の形で出題されることが多く、実質断定の連用形＋存在。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d66_s04", name: "ステージ4: 形容動詞の活用語尾としての「なり」", recommendedPower: "10,390", icon: "fa-scroll", description: "【形容動詞の活用語尾の「なり」の深掘り解説】「あてなり（貴なり）」「あやかなり」など、状態を表す単語の一部となっているもの。語幹を取り出してみて状態を表す形容動詞を作るかどうかが判断基準。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d66_s05", name: "ステージ5: 共通テスト即効！「なり」の選択肢判定法", recommendedPower: "10,720", icon: "fa-scroll", description: "【「なり」の選択肢判定法の深掘り解説】①直前の接続（体言・連体形か、終止形か）を確認。②音表現（声、音、文脈）があれば伝聞推定。③単独で意味が成立する状態語なら形容動詞活用語尾、と3ステップで瞬殺する。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" }
        ]
    },
    {
        id: 67,
        title: "木曜ダンジョン7: 「〜せ給ふ」の使役 vs 尊敬の判定ルール",
        recommendedPower: "10,180〜11,500",
        icon: "fa-scroll",
        gimmick: "kogo",
        stages: [
            { id: "d67_s01", name: "ステージ1: 「〜せ給ふ」の使役 vs 尊敬の判定ルール", recommendedPower: "10,180", icon: "fa-scroll", description: "【「〜せ給ふ」の判定ルールの深掘り解説】「す・さす＋給ふ」の形（最高敬語）を見たら、直前に「使役の対象（人に・〜をして）」があるか確認。対象があれば「使役＋尊敬」、なければ単なる「最高敬語（〜なさる）」。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d67_s02", name: "ステージ2: 直後に「人に」「〜に」がある使役パターン", recommendedPower: "10,510", icon: "fa-scroll", description: "【直後に「人に」「〜に」がある使役パターンの深掘り解説】「AにBせしむ」「人に〜させ給ふ」のように、命令や指示を受ける人物（「〜に」）が明記されている場合、「す・さす・しめ」は100%使役（〜させる）となる。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d67_s03", name: "ステージ3: 最高敬語の「させ給ふ・せ給ふ」", recommendedPower: "10,840", icon: "fa-scroll", description: "【最高敬語の「させ給ふ・せ給ふ」の深掘り解説】帝・中宮・法皇など超高貴な人物が動作主の場合、「せ給ふ・させ給ふ」は使役の意味が消滅し、二重尊敬（最高敬語：「〜なさる・お〜になる」）として機能する。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d67_s04", name: "ステージ4: 地の文と会話文での使い分け", recommendedPower: "11,170", icon: "fa-scroll", description: "【地の文と会話文での使い分けの深掘り解説】地の文での「せ給ふ」は最高敬語になりやすいのに対し、会話文では「（誰かに）〜させなさる」という使役＋尊敬のニュアンスが残りやすい。発話者の視点を把握する。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d67_s05", name: "ステージ5: 錯覚しやすい単体の「す・さす」の識別", recommendedPower: "11,500", icon: "fa-scroll", description: "【単体の「す・さす」の識別の深掘り解説】下に敬語を伴わない単体の「す・さす」は、絶対に尊敬の意味にはならず「使役（〜させる）」確定となる。サ変・四段動詞の未然形接続に注意。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" }
        ]
    },
    {
        id: 68,
        title: "木曜ダンジョン8: 格助詞の「に」",
        recommendedPower: "10,960〜12,280",
        icon: "fa-scroll",
        gimmick: "kogo",
        stages: [
            { id: "d68_s01", name: "ステージ1: 格助詞の「に」", recommendedPower: "10,960", icon: "fa-scroll", description: "【格助詞の「に」の深掘り解説】体言につき、時（〜に）・場所（〜で）・対象（〜に向かって）・原因理由（〜によって）などを表す。下に動詞を伴い、意味の骨組みを作る基本的な助詞。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d68_s02", name: "ステージ2: 接続助詞の「に」", recommendedPower: "11,290", icon: "fa-scroll", description: "【接続助詞の「に」の深掘り解説】活用語の連体形につき、「〜すると・〜したところ（順接）」や「〜なのに（逆接）」を表す。文と文を繋ぎ、文脈の展開（特に述語の主語交代）を指し示す目印。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d68_s03", name: "ステージ3: 助動詞「なり」の連用形", recommendedPower: "11,620", icon: "fa-scroll", description: "【助動詞「なり」の連用形の深掘り解説】断定の助動詞「なり」の連用形「に」。「〜であって（〜に＋あり/侍り/す）」の形で使われる。下に「あり」や敬語動詞が続く「にて」「にあり」の形が目印。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d68_s04", name: "ステージ4: 助動詞「断定のなり」＋「に」", recommendedPower: "11,950", icon: "fa-scroll", description: "【助動詞「断定のなり」＋「に」の深掘り解説】「〜であって〜だ」と断定しつつ文節を繋ぐ。「静かなるに（形容動詞連体形＋格助詞/接続助詞）」と「静かなり（断定連用形）」の差異を接続で見分ける。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d68_s05", name: "ステージ5: 形容動詞・副詞の語尾の「に」", recommendedPower: "12,280", icon: "fa-scroll", description: "【形容動詞・副詞の語尾の「に」の深掘り解説】「静かに」「あはれに」などナリ活用形容動詞の連用形語尾、あるいは「げに」「さらに」など単体で副詞を形成する「に」。単語の一部なので取り外せない。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" }
        ]
    },
    {
        id: 69,
        title: "木曜ダンジョン9: イ音便・ウ音便・撥音便・促音便の見分け",
        recommendedPower: "11,740〜13,060",
        icon: "fa-scroll",
        gimmick: "kogo",
        stages: [
            { id: "d69_s01", name: "ステージ1: イ音便・ウ音便・撥音便・促音便の見分け", recommendedPower: "11,740", icon: "fa-scroll", description: "【音便の見分けの深掘り解説】発音のしやすさから変化した形。イ音便（書いて→書きて）、ウ音便（あやうく→あやぶく）、撥音便（「ん」：飛んで）、促音便（「っ」：立ちて）。元の終止形を復元する力が必須。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d69_s02", name: "ステージ2: 撥音便＋無表記（「〜ん」の「ん」が抜ける現象）", recommendedPower: "12,070", icon: "fa-scroll", description: "【撥音便＋無表記の深掘り解説】「なるめり」が「なんめり」となり、さらに表記上「なめり」と「ん」が脱落する現象。見た目は「なめり」「あんめり」となるため、元の形（なる・ある）を見破る必要がある。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d69_s03", name: "ステージ3: サ変・ラ変・カ変の複合動詞", recommendedPower: "12,400", icon: "fa-scroll", description: "【サ変・ラ変・カ変の複合動詞の深掘り解説】「ご覧ず（サ変）」「そこなふ（四段）」「来至る（カ変＋四段）」など。文末の活用語尾がどの特殊動詞（す・あり・く）に由来するかで活用型を正しく識別する。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d69_s04", name: "ステージ4: 飽く・借る・足る（四段 vs 上二段・下二段の罠）", recommendedPower: "12,730", icon: "fa-scroll", description: "【四段 vs 上二段・下二段の罠の深掘り解説】「飽く（四段：飽きず）」と「飽く（下二段：飽けず）」のように、現代語の感覚で上一段・下二段と勘違いしやすい古典動詞の活用型（飽く・借る・足る・足る・忍ぶなど）の厳密な丸暗記。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d69_s05", name: "ステージ5: 補助動詞化による意味の変容", recommendedPower: "13,060", icon: "fa-scroll", description: "【補助動詞化による意味の変容の深掘り解説】「見る」「聞く」「給ふ」「侍り」などが本動詞（具体的な動作）から離れ、他の動詞の下について「〜してみる」「〜し申し上げる」など文法・敬語的意味を添える現象。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" }
        ]
    },
    {
        id: 70,
        title: "木曜ダンジョン10: 陰陽道と物忌み・方違えの基本",
        recommendedPower: "12,520〜13,840",
        icon: "fa-scroll",
        gimmick: "kogo",
        stages: [
            { id: "d70_s01", name: "ステージ1: 陰陽道と物忌み・方違えの基本", recommendedPower: "12,520", icon: "fa-scroll", description: "【陰陽道と物忌み・方違えの基本の深掘り解説】陰陽師の占いに基づき、凶方（悪い方角）へ向かうのを避けるため前夜に別の方向へ泊まる「方違え（かたたがえ）」や、悪日・穢れに家に引き籠もる「物忌み」は平安貴族の日常行動。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d70_s02", name: "ステージ2: 庚申待ち（こうしんまち）と夜明かし", recommendedPower: "12,850", icon: "fa-scroll", description: "【庚申待ち（こうしんまち）の深掘り解説】60日ごとの庚申（こうしん）の夜、体内から三尸（さんし）の虫が抜け出して天帝に罪を告げないよう、徹夜して酒宴や語らいを楽しんで夜を明かす風習。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d70_s03", name: "ステージ3: 物の怪（もののけ）の憑依と退散祈禱", recommendedPower: "13,180", icon: "fa-scroll", description: "【物の怪の憑依と退散祈禱の深掘り解説】病気や異変は怨霊や生霊（物の怪）の仕業と考えられた。加持祈祷を行う高僧（修験者）を呼び、憑依した物の怪を「寄らしめ（憑座・よりまし）」に移して調伏・退散させた。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d70_s04", name: "ステージ4: 夢占い（夢違え）と夢のメッセージ", recommendedPower: "13,510", icon: "fa-scroll", description: "【夢占い（夢違え）の深掘り解説】夢は神仏や死者からの予言・メッセージとされた。吉夢を見たら人に話し、悪夢を見たら夢違え（ゆめたがえ）の呪ないを行って災いを回避しようとした。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" },
            { id: "d70_s05", name: "ステージ5: 御霊信仰と天変地異の恐怖", recommendedPower: "13,840", icon: "fa-scroll", description: "【御霊信仰と天変地異の恐怖の深掘り解説】無念の死を遂げた者の怨霊（菅原道真や早良親王など）が疫病や天変地異を引き起こすと信じられた。これを宥めるために御霊会（ごりょうえ）を催し、神として祀る風習。\n\n【木曜ギミック】問題文は現代語・日本語の意味で提示され、選択肢から対応する古語を選ぶ逆引き形式になります。語感だけでなく文脈知識も試されます。" }
        ]
    },
    {
        id: 71,
        title: "金曜ダンジョン1: 寝殿造りの構造（母屋・対の屋・渡殿）",
        recommendedPower: "6,000〜7,320",
        icon: "fa-users",
        gimmick: "mirrorParty",
        stages: [
            { id: "d71_s01", name: "ステージ1: 寝殿造りの構造（母屋・対の屋・渡殿）", recommendedPower: "6,000", icon: "fa-users", description: "【寝殿造りの構造の深掘り解説】貴族の邸宅様式。中心となる「母屋（もや）」を身内の居住スペースとし、東西北に「対の屋（たいのや）」を配し、それらを屋根付きの廊下「渡殿（わたどの）」で接続した。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d71_s02", name: "ステージ2: 簾（すだれ）・御簾・几帳（きちょう）・屏風による遮蔽", recommendedPower: "6,330", icon: "fa-users", description: "【遮蔽具の深掘り解説】空間を仕切る調度品。御簾（みす）や几帳（きちょう）は姿を直に見せないための衝立。女性はこれらの陰に身を隠し、男性と会話を交わした。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d71_s03", name: "ステージ3: 蔀（しとみ）・透垣（すいがい）・透かし彫り", recommendedPower: "6,660", icon: "fa-users", description: "【建具と仕切りの深掘り解説】「蔀（しとみ）」は格子を取り付けた板戸で、上半分を跳ね上げて日光を入れた。「透垣（すいがい）」は隙間のある竹や木の垣根で、垣間見（かいまみ）の舞台となる。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d71_s04", name: "ステージ4: 庭園・遣水（やりみず）・泉水の美学", recommendedPower: "6,990", icon: "fa-users", description: "【庭園と遣水の美学の深掘り解説】南庭には池（泉水）があり、そこに水を引く人工の小川「遣水（やりみず）」が流れていた。ここで「曲水の宴」を催すなど、自然と一体化した風流を楽しんだ。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d71_s05", name: "ステージ5: 南殿・清涼殿など内裏の配置と主要な建物", recommendedPower: "7,320", icon: "fa-users", description: "【内裏の配置と建物の深掘り解説】天皇の住まいである「内裏」。公式な儀式を行う「紫宸殿（南殿）」と、日常の御所である「清涼殿」、妃たちが暮らす「弘徽殿」「藤壺」などの位置関係は人間関係の象徴。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" }
        ]
    },
    {
        id: 72,
        title: "金曜ダンジョン2: 牛車（あじろ車・びんろう毛の車）の種類と格",
        recommendedPower: "6,780〜8,100",
        icon: "fa-users",
        gimmick: "mirrorParty",
        stages: [
            { id: "d72_s01", name: "ステージ1: 牛車（あじろ車・びんろう毛の車）の種類と格", recommendedPower: "6,780", icon: "fa-users", description: "【牛車の種類と格の深掘り解説】貴族の主な乗物。乗る者の身分によって「檳榔毛（びんろうげ）の車」「網代（あじろ）の車」「半輿」など厳格な格式・装飾が決まっていた。車争いの原因にもなる。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d72_s02", name: "ステージ2: 輿（こし）・膝行（しっこう）・徒歩の移動", recommendedPower: "7,110", icon: "fa-users", description: "【輿と徒歩の移動の深掘り解説】身分の高い人物の外出や社寺参詣には「輿（こし）」を用いた。貴族は原則として歩かず、室内では膝で進む「膝行（しっこう）」を行うのが作法とされた。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d72_s03", name: "ステージ3: 随身（ずいじん）・前駆（さき）の役割", recommendedPower: "7,440", icon: "fa-users", description: "【随身と前駆の役割の深掘り解説】貴族の外出時に護衛として同行する「随身（ずいじん）」や、先頭で「先払い（さき）」をして通行人を退かす従者。従者の多さが主人の権威を象徴した。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d72_s04", name: "ステージ4: 旅の装束（壺装束・市女笠）と関所の通過", recommendedPower: "7,770", icon: "fa-users", description: "【旅の装束の深掘り解説】女性が旅に出る際は、裾を繰り上げて着る「壺装束（つぼしょうぞく）」に、虫の垂れ布をつけた「市女笠（いちめがさ）」を被り、顔を隠して歩いた。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d72_s05", name: "ステージ5: 東国下りと東海道の難所（富士山・宇津の山）", recommendedPower: "8,100", icon: "fa-users", description: "【東国下りと東海道の難所の深掘り解説】都から東国へ下る旅（『伊勢物語』など）では、逢坂の関を越え、宇津の山（蔦の細道）や足柄山、富士山など名所・難所を歌に詠み込みながら進んだ。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" }
        ]
    },
    {
        id: 73,
        title: "金曜ダンジョン3: 禅宗の伝来と「無」の美学",
        recommendedPower: "7,560〜8,880",
        icon: "fa-users",
        gimmick: "mirrorParty",
        stages: [
            { id: "d73_s01", name: "ステージ1: 禅宗の伝来と「無」の美学", recommendedPower: "7,560", icon: "fa-users", description: "【禅宗の伝来と「無」の美学の深掘り解説】栄西や道元によって伝えられた禅宗は、無駄を削ぎ落とし精神統一を図る「無」の精神をもたらした。これが後の武士の死生観や水墨画・庭園文化の基礎となった。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d73_s02", name: "ステージ2: 侘び・寂び・幽玄の成立", recommendedPower: "7,890", icon: "fa-users", description: "【侘び・寂び・幽玄の深掘り解説】簡素なものの中に奥深い美を見出す「侘び（わび）」、時を経て衰えたものの美「寂び（さび）」、言葉に表せない奥深い情趣「幽玄（ゆうげん）」という中世美学の確立。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d73_s03", name: "ステージ3: 武家社会の礼法と主従の絆", recommendedPower: "8,220", icon: "fa-users", description: "【武家社会の礼法と主従の絆の深掘り解説】御恩と奉公に基づく主従関係。「一所懸命」の土地執着や、恥を重んじる武士道精神が文学（『平家物語』や軍記物語）に強く反映された。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d73_s04", name: "ステージ4: 応仁の乱以降の世相（下剋上と世常の移り変わり）", recommendedPower: "8,550", icon: "fa-users", description: "【下剋上と世常の移り変わりの深掘り解説】応仁の乱により京都は荒廃。実力主義の「下剋上（げこくじょう）」が横行し、従来の身分秩序が崩壊した無常感・戦乱の世相が文献に深く刻まれた。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d73_s05", name: "ステージ5: 隠者文学（世捨て人）の暮らしと草庵の魅力", recommendedPower: "8,880", icon: "fa-users", description: "【隠者文学と草庵の暮らしの深掘り解説】鴨長明（『方丈記』）や兼好法師（『徒然草』）のように、世俗を捨てて「草庵」に身を置き、静かに社会を客観視・批評する隠者文学が隆盛した。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" }
        ]
    },
    {
        id: 74,
        title: "金曜ダンジョン4: 「ひさかたの（光・天・月）」など超重要パターン",
        recommendedPower: "8,340〜9,660",
        icon: "fa-users",
        gimmick: "mirrorParty",
        stages: [
            { id: "d74_s01", name: "ステージ1: 「ひさかたの（光・天・月）」など超重要パターン", recommendedPower: "8,340", icon: "fa-users", description: "【ひさかたのの深掘り解説】「ひさかたの」は「光・天・月・日・雲・空」などを導く5音の修飾語。原則として訳す必要はなく、直後の語を強調して歌の調子を整える役割を果たす。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d74_s02", name: "ステージ2: 「あしひきの（山・峰）」と山岳イメージ", recommendedPower: "8,670", icon: "fa-users", description: "【あしひきのの深掘り解説】「あしひきの」は「山・峰・（山にある）もみじ・しずく」などを導く。「足引きの」に由来し、山深く重々しいイメージを和歌に与える。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d74_s03", name: "ステージ3: 「たらちねの（母・親）」など親族系枕詞", recommendedPower: "9,000", icon: "fa-users", description: "【たらちねのの深掘り解説】「たらちねの」は「母・親」を導く枕詞（垂乳根に由来）。他に「しろたへの（衣・袖）」「あづさゆみ（引く・張る・射る）」などセットで暗記すべき重要型。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d74_s04", name: "ステージ4: 「ぬばたまの（夜・黒・髪）」など色彩系枕詞", recommendedPower: "9,330", icon: "fa-users", description: "【ぬばたまのの深掘り解説】「ぬばたまの（野干玉の）」は、黒い檜扇の実から「夜・黒・髪・夢・月」など漆黒や夜に関連する語を導く。和歌の視覚的イメージを決定づける。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d74_s05", name: "ステージ5: 未知の枕詞が出たときの直後からの予測法", recommendedPower: "9,660", icon: "fa-users", description: "【未知の枕詞の予測法の深掘り解説】見たことのない5音の言葉が上句にあり、直後に決まった名詞や掛詞が続く場合、枕詞と推測する。訳さずにスルーし、掛かる先の言葉の意味に集中するのがコツ。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" }
        ]
    },
    {
        id: 75,
        title: "金曜ダンジョン5: 「小倉山」「龍田川」紅葉の名所",
        recommendedPower: "9,120〜10,440",
        icon: "fa-users",
        gimmick: "mirrorParty",
        stages: [
            { id: "d75_s01", name: "ステージ1: 「小倉山」「龍田川」紅葉の名所", recommendedPower: "9,120", icon: "fa-users", description: "【小倉山・龍田川の深掘り解説】「小倉山（京都）」や「龍田川（奈良）」は、和歌において「紅葉（もみじ）」の名所として描かれる。地名を聞いただけで紅葉の美しい景色や秋の寂しさを想起させる連想ルール。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d75_s02", name: "ステージ2: 「吉野」「初瀬」雪と祈りの地", recommendedPower: "9,450", icon: "fa-users", description: "【吉野・初瀬の深掘り解説】「吉野」は桜や深雪の美しさ、「初瀬（長谷）」は長谷寺参詣や祈念を象徴する。歌枕は単なる地理情報ではなく、特定の感情や季節感を惹起するコードとして機能する。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d75_s03", name: "ステージ3: 「須磨」「明石」侘びと渡来の地", recommendedPower: "9,780", icon: "fa-users", description: "【須磨・明石の深掘り解説】『源氏物語』でも有名な「須磨・明石」は、都落ちした者が佇む「侘び・悲愁・寂哀」の地。波の音や関守の描写とともに都への憧憬を歌に込める。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d75_s04", name: "ステージ4: 「八橋」「三河」折句と旅の思い出", recommendedPower: "10,110", icon: "fa-users", description: "【八橋・三河の深掘り解説】『伊勢物語』東下りで有名な「八橋（愛知）」。杜若（かきつばた）の花が咲き誇る地で、各句の頭に文字を仕込む「折句」を詠むなど旅愁と望郷を象徴する。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d75_s05", name: "ステージ5: 歌枕が与える「情景と心情」の補強効果", recommendedPower: "10,440", icon: "fa-users", description: "【歌枕の補強効果の深掘り解説】歌文において歌枕が提示されると、作者は言葉数を省きつつも、読者に「過去の有名な歌の情景や感情（本歌取り的な効果）」を一瞬で共有させることができる。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" }
        ]
    },
    {
        id: 76,
        title: "金曜ダンジョン6: 歌合のルール（左と右、方人、判者）",
        recommendedPower: "9,900〜11,220",
        icon: "fa-users",
        gimmick: "mirrorParty",
        stages: [
            { id: "d76_s01", name: "ステージ1: 歌合のルール（左と右、方人、判者）", recommendedPower: "9,900", icon: "fa-users", description: "【歌合のルールの深掘り解説】歌人を「左」と「右」の2組に分け、出された題（題詠）に合わせて詠まれた歌を一番ずつ対戦させるゲーム。味方を「方人（かたうど）」、審判を「判者（はんじゃ）」と呼ぶ。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d76_s02", name: "ステージ2: 判詞（はんし）に書かれた評価基準", recommendedPower: "10,230", icon: "fa-users", description: "【判詞の深掘り解説】判者（審判）が勝敗の理由を記した批評文が「判詞」。古今集以来の伝統（古典性）、詠みぶりの新しさ、意匠の巧みさなどが評価基準となった。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d76_s03", name: "ステージ3: 歌道家系（二条派 vs 京極派）の対立", recommendedPower: "10,560", icon: "fa-users", description: "【二条派 vs 京極派の深掘り解説】中世和歌における二大派閥。「二条派」は伝統的・保守的で平易な歌風を重んじ、「京極派（冷泉派）」は個性的・情熱的で斬新な表現を追求して対立した。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d76_s04", name: "ステージ4: 詠歌のテーマ（「題詠」と「当座」）", recommendedPower: "10,890", icon: "fa-users", description: "【題詠と当座の深掘り解説】あらかじめ与えられたテーマ（「春」「恋」など）に沿って創作する「題詠（だいえい）」と、その場で出されたお題に即興で詠む「当座（とうざ）」。平安貴族の教養試験。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d76_s05", name: "ステージ5: 『近代秀歌』『毎月抄』などの歌論書の主張", recommendedPower: "11,220", icon: "fa-users", description: "【歌論書の主張の深掘り解説】藤原定家らによる歌論書。「心をばあまねく使い、言葉は新しく、姿は古きを慕う（心新奇・言葉伝統）」といった、和歌創作の指導理念や鑑賞基準が語られる。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" }
        ]
    },
    {
        id: 77,
        title: "金曜ダンジョン7: 長句（575）と短句（77）の交互付合",
        recommendedPower: "10,680〜12,000",
        icon: "fa-users",
        gimmick: "mirrorParty",
        stages: [
            { id: "d77_s01", name: "ステージ1: 長句（575）と短句（77）の交互付合", recommendedPower: "10,680", icon: "fa-users", description: "【長句と短句の交互付合の深掘り解説】複数の参加者が、5・7・5の「長句（上の句）」と7・7の「短句（下の句）」を交互に詠み繋いでいく文芸形式。前の句の意味を汲みつつ新展開を作る。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d77_s02", name: "ステージ2: 発句・脇句・第三の役割", recommendedPower: "11,010", icon: "fa-users", description: "【発句・脇句・第三の役割の深掘り解説】一番最初の575を「発句（ほっく）」と呼び（後の俳句）、それに付ける77を「脇句」、続く575を「第三」と呼ぶ。発句には季語と切れ字を入れるなど厳格なルールが存在。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d77_s03", name: "ステージ3: 連歌のルール（式目・つけあい）", recommendedPower: "11,340", icon: "fa-users", description: "【式目とつけあいの深掘り解説】連歌の文法・表現ルールを集大成したものを「式目（しきもく）」という。同じ語やテーマを連続させてはならない「去り（さり）」などの複雑な制約のなかで変化を楽しむ。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d77_s04", name: "ステージ4: 『新撰菟玖波集』と心敬・宗祇の美学", recommendedPower: "11,670", icon: "fa-users", description: "【心敬・宗祇の美学の深掘り解説】室町時代、宗祇らが選集した『新撰菟玖波集』により連歌は芸術的頂点に達した。心敬の「冷え・痩せる」美学など、寂しさを極めた中世精神の結晶。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d77_s05", name: "ステージ5: 庶民化する俳諧と和歌の架け橋", recommendedPower: "12,000", icon: "fa-users", description: "【庶民化する俳諧の深掘り解説】連歌の持つ厳格で高雅なルールを崩し、日常語や可笑しみ・ユーモアを取り入れたのが「俳諧（はいかい）の連歌」。近世の芭蕉らの俳諧へと発展していく。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" }
        ]
    },
    {
        id: 78,
        title: "金曜ダンジョン8: 主人公を取り巻く三角関係の読み取り",
        recommendedPower: "11,460〜12,780",
        icon: "fa-users",
        gimmick: "mirrorParty",
        stages: [
            { id: "d78_s01", name: "ステージ1: 主人公を取り巻く三角関係の読み取り", recommendedPower: "11,460", icon: "fa-users", description: "【三角関係の読み取りの深掘り解説】古文長文では「男・本妻・愛人」や「男A・女・男B」の三角関係が頻出。敬語の向きや互いの呼び名（〜の上、〜の君）から、誰が誰に惹かれているかを即座に整理する。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d78_s02", name: "ステージ2: 身分差（帝・宮・上人・下人）の上下関係", recommendedPower: "11,790", icon: "fa-users", description: "【身分差の上下関係の深掘り解説】「帝（絶対権力）」「宮（皇族）」「上人（殿上人）」「下人（従者）」という身分の階層構造を把握する。敬意の高さ（絶対敬語・二重尊敬）で発話者と客体を特定できる。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d78_s03", name: "ステージ3: 親子・きょうだい・後見人の血縁関係", recommendedPower: "12,120", icon: "fa-users", description: "【血縁関係の深掘り解説】婚姻や後宮での出世において「後見人（後ろ盾となる叔父や父）」の存在が不可欠。単なる家族関係だけでなく、政治的権力闘争の背景として親子・兄弟を捉える。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d78_s04", name: "ステージ4: 呼び名の変化（官職名が変わる人物の追跡）", recommendedPower: "12,450", icon: "fa-users", description: "【呼び名の変化の深掘り解説】物語中で人物は「少将」→「中将」→「宰相」のように昇進に伴って名前（官職名）が変わる。同一人物であることを文脈や敬語表現から見失わない追跡力が必要。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d78_s05", name: "ステージ5: 人物相関図の最終確定", recommendedPower: "12,780", icon: "fa-users", description: "【人物相関図の最終確定・補充解説】長文読解の最終局面では、恋愛関係・血縁・主従・政治的後見の4本線を一枚の相関図に統合するのが有効。呼称の変化や敬語の向きが食い違わないかを最後に点検し、誰が誰を支え、誰と対立しているかを確定する。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" }
        ]
    },
    {
        id: 79,
        title: "金曜ダンジョン9: 「面映ゆし」「心苦し」など会話中の心情語",
        recommendedPower: "12,240〜13,560",
        icon: "fa-users",
        gimmick: "mirrorParty",
        stages: [
            { id: "d79_s01", name: "ステージ1: 「面映ゆし」「心苦し」など会話中の心情語", recommendedPower: "12,240", icon: "fa-users", description: "【会話中の心情語の深掘り解説】会話文の中に埋め込まれた「面映ゆし（照れくさい）」「心苦し（申し訳ない・気の毒だ）」などの心情語を取り出し、発話者の内面や相手へのスタンスを読み取る。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d79_s02", name: "ステージ2: 本音と建前（地の文の心情 vs 会話文の発言）", recommendedPower: "12,570", icon: "fa-users", description: "【本音と建前の深掘り解説】地の文に記された主人公の内心（本音）と、実際に相手に語った言葉（建前）のギャップ（乖離）に着目する。平安貴族特有の風流や奥ゆかしさによる拒絶の意図を読む。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d79_s03", name: "ステージ3: 婉曲表現（「〜にや」「〜に調法」）に隠れた拒絶", recommendedPower: "12,900", icon: "fa-users", description: "【婉曲表現に隠れた拒絶の深掘り解説】直接的な「ノー」を避け、「〜にや（〜でしょうか）」「あやし（変ですね）」など婉曲に和歌や言葉を濁すことで、遠回しに辞退・拒絶・批判する心理を読み解く。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d79_s04", name: "ステージ4: 対話による解決・対立の結末", recommendedPower: "13,230", icon: "fa-users", description: "【対話による解決・対立の結末の深掘り解説】和歌の贈答や対話を経て、登場人物同士の関係が修復したのか、あるいは決裂（出身・絶交）に至ったのか、最後の着地点（結末）を精度高く把握する。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d79_s05", name: "ステージ5: 和歌応酬から読み解く本心の確定", recommendedPower: "13,560", icon: "fa-users", description: "【和歌応酬から読み解く本心の確定・補充解説】会話と和歌が並ぶ場面では、直前の発言よりも和歌の比喩・掛詞・縁語に本心が強く現れる。婉曲な返答でも、季節語や色彩語の選び方から受容・拒絶・未練を判定できる。地の文と贈答歌を突き合わせて感情の着地点を読む。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" }
        ]
    },
    {
        id: 80,
        title: "金曜ダンジョン10: 『平家物語』『和漢朗詠集』の和漢混淆表現",
        recommendedPower: "13,020〜14,340",
        icon: "fa-users",
        gimmick: "mirrorParty",
        stages: [
            { id: "d80_s01", name: "ステージ1: 『平家物語』『和漢朗詠集』の和漢混淆表現", recommendedPower: "13,020", icon: "fa-users", description: "【和漢混淆表現の深掘り解説】漢文の訓読口調（〜なり、〜す）と、和文（古文）の繊細な描写が合体した「和漢混淆文」。力強い七五調のリズムと軍記物語特有の無常感が特徴。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d80_s02", name: "ステージ2: 漢語・典拠（中国の故事）の引き込み", recommendedPower: "13,350", icon: "fa-users", description: "【漢語・典拠の引き込みの深掘り解説】文章中に中国の歴史（史記・漢書）や故事成句（始皇帝、楊貴妃など）が引かれ、日本の出来事と対比・重ね合わせて人物の悲劇性や栄華を強調する技法。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d80_s03", name: "ステージ3: 白氏文集などの唐詩が与えた王朝文学への影響", recommendedPower: "13,680", icon: "fa-users", description: "【唐詩の影響の深掘り解説】白居易の『白氏文集』は平安貴族の必読書。『源氏物語』『枕草子』などで唐詩のフレーズが和歌や会話に引かれ、深い教養的ニュアンスを文体に加える。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d80_s04", name: "ステージ4: 和漢混淆文のリズムと語法の見抜き方", recommendedPower: "14,010", icon: "fa-users", description: "【和漢混淆文のリズムと語法の見抜き方・補充解説】和漢混淆文では、漢語が続く硬質なリズムと、やまとことばの繊細な叙情が交互に現れる。漢語句が威勢や歴史的格調を担い、和語句が情景や情念を支える構造を押さえると、軍記物語や説話の文体差が読みやすくなる。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" },
            { id: "d80_s05", name: "ステージ5: 典拠比較で仕上げる総合読解", recommendedPower: "14,340", icon: "fa-users", description: "【典拠比較で仕上げる総合読解・補充解説】中国故事・唐詩・和歌・物語本文が一つの文章に交差する場合、何が引用で何が本文の主張かを切り分けることが重要。典拠は権威づけや悲劇性の強調に使われることが多く、引用先のイメージを踏まえると設問の要旨一致問題に強くなる。\n\n【金曜ギミック】敵は自軍候補や未所持キャラを含むランダム編成で出現し、全員が自分の編成最高レベルに同期します。後半ほど敵人数が増える総力戦です。" }
        ]
    }
];

        function stageNumFromId(id){ const m=String(id||'').match(/_s(\d+)/); return m ? parseInt(m[1],10) : 1; }
        const WEEKDAY_EXTRA_DUNGEONS = [
        ];
        WEEKDAY_EXTRA_DUNGEONS.forEach(d=>DUNGEONS_DATA.push(d));
        // Multi-Meaning Vocabulary Quiz Bank
        const KOBUN_WORDS = [
    // --- 古文単語315 索引（txt 全 738 語・マーク除去済み）---
    { word: "あ", primary: "このわたし・あの人", synonymous: ["このわたし", "あの人"], group: "other" },
    { word: "あいなし", primary: "つまらない・なんとなく", synonymous: ["つまらない", "なんとなく"], group: "other" },
    { word: "あかし〔明かし〕", primary: "明るい", synonymous: ["明るい"], group: "other" },
    { word: "あかず〔飽かず〕", primary: "満足しない・飽きることがない", synonymous: ["満足しない", "飽きることがない"], group: "other" },
    { word: "あかなくに〔飽かなくに〕", primary: "満足していないのに・名残惜しいのに", synonymous: ["満足していないのに", "名残惜しいのに"], group: "other" },
    { word: "あからさまなり", primary: "ほんのちょっと", synonymous: ["ほんのちょっと"], group: "other" },
    { word: "あからめもせず", primary: "よそ見もしない", synonymous: ["よそ見もしない"], group: "other" },
    { word: "あきらむ〔明らむ〕", primary: "明らかにする", synonymous: ["明らかにする"], group: "other" },
    { word: "あきる〔呆る〕", primary: "途方に暮れる", synonymous: ["途方に暮れる"], group: "other" },
    { word: "あく〔飽く〕", primary: "満足する・飽きる", synonymous: ["満足する", "飽きる"], group: "other" },
    { word: "あくがる", primary: "（魂が体から）さまよい出る・浮かれ歩く", synonymous: ["（魂が体から）さまよい出る", "浮かれ歩く"], group: "other" },
    { word: "あさまし", primary: "驚くほどだ・あきれるほどだ・情けない", synonymous: ["驚くほどだ", "あきれるほどだ", "情けない"], group: "other" },
    { word: "あさましくなる", primary: "死ぬ", synonymous: ["死ぬ"], group: "other" },
    { word: "あさむ", primary: "驚く・あきれる", synonymous: ["驚く", "あきれる"], group: "other" },
    { word: "あし", primary: "悪い", synonymous: ["悪い"], group: "other" },
    { word: "あしこ", primary: "あそこ", synonymous: ["あそこ"], group: "other" },
    { word: "あした〔朝〕", primary: "朝・翌朝", synonymous: ["朝", "翌朝"], group: "other" },
    { word: "あそばす〔遊ばす〕", primary: "（何かを）なさる", synonymous: ["（何かを）なさる"], group: "other" },
    { word: "あそび〔遊び〕", primary: "管弦の遊び", synonymous: ["管弦の遊び"], group: "other" },
    { word: "あそぶ", primary: "管弦を楽しむ", synonymous: ["管弦を楽しむ"], group: "other" },
    { word: "あだあだし", primary: "不誠実だ・浮気だ", synonymous: ["不誠実だ", "浮気だ"], group: "other" },
    { word: "あだなり〔徒なり〕", primary: "はかない・浮気だ", synonymous: ["はかない", "浮気だ"], group: "other" },
    { word: "あたら", primary: "惜しむべき・惜しいことに", synonymous: ["惜しむべき", "惜しいことに"], group: "other" },
    { word: "あたらし〔惜し〕", primary: "惜しい", synonymous: ["惜しい"], group: "other" },
    { word: "あぢきなし", primary: "おもしろくない・つまらない", synonymous: ["おもしろくない", "つまらない"], group: "other" },
    { word: "あつかふ〔扱ふ〕", primary: "面倒を見る・もてあます", synonymous: ["面倒を見る", "もてあます"], group: "other" },
    { word: "あてなり〔貴なり〕", primary: "高貴である・上品である", synonymous: ["高貴である", "上品である"], group: "other" },
    { word: "あてやかなり", primary: "高貴だ・上品だ", synonymous: ["高貴だ", "上品だ"], group: "other" },
    { word: "案内", primary: "内容・事情・取り次ぎ", synonymous: ["内容", "事情", "取り次ぎ"], group: "other" },
    { word: "あなかしこ（～禁止）", primary: "決して（～するな）", synonymous: ["決して（～するな）"], group: "other" },
    { word: "あながちなり〔強ちなり〕", primary: "強引だ・むやみに", synonymous: ["強引だ", "むやみに"], group: "other" },
    { word: "あなかま", primary: "ああ、うるさい・静かに", synonymous: ["ああ、うるさい", "静かに"], group: "other" },
    { word: "あなた", primary: "向こう", synonymous: ["向こう"], group: "other" },
    { word: "あはす", primary: "結婚させる", synonymous: ["結婚させる"], group: "other" },
    { word: "あはれ", primary: "ああ", synonymous: ["ああ"], group: "other" },
    { word: "あはれがる", primary: "心に深く感じる", synonymous: ["心に深く感じる"], group: "other" },
    { word: "あはれなり", primary: "しみじみと心に深く感じられる", synonymous: ["しみじみと心に深く感じられる"], group: "other" },
    { word: "あはれむ", primary: "心に深く感じる", synonymous: ["心に深く感じる"], group: "other" },
    { word: "あふ〔合（会・逢）ふ〕", primary: "結婚する", synonymous: ["結婚する"], group: "other" },
    { word: "あふ〔敢ふ〕", primary: "〈打消を伴い〉耐えられない・〈動詞につき、打消を伴い〉～きれない", synonymous: ["〈打消を伴い〉耐えられない", "〈動詞につき、打消を伴い〉～きれない"], group: "other" },
    { word: "あへて〔敢へて〕（～打消）", primary: "まったく（～ない）", synonymous: ["まったく（～ない）"], group: "other" },
    { word: "あへなし〔敢へ無し〕", primary: "落胆している・はかない", synonymous: ["落胆している", "はかない"], group: "other" },
    { word: "あまた〔数多〕", primary: "たくさん", synonymous: ["たくさん"], group: "other" },
    { word: "あやし〔怪し〕", primary: "不思議だ", synonymous: ["不思議だ"], group: "other" },
    { word: "あやし〔賤し〕", primary: "身分が低い・粗末だ", synonymous: ["身分が低い", "粗末だ"], group: "other" },
    { word: "あやなし〔文無し〕", primary: "わけがわからない", synonymous: ["わけがわからない"], group: "other" },
    { word: "あやにくなり", primary: "意地が悪い・あいにくだ", synonymous: ["意地が悪い", "あいにくだ"], group: "other" },
    { word: "あやめ〔文目〕", primary: "（物事の）道理", synonymous: ["（物事の）道理"], group: "other" },
    { word: "あらぬ", primary: "別の", synonymous: ["別の"], group: "other" },
    { word: "あらはなり〔顕なり〕", primary: "まる見えである", synonymous: ["まる見えである"], group: "other" },
    { word: "あらまし", primary: "予想・期待", synonymous: ["予想", "期待"], group: "other" },
    { word: "あらまほし", primary: "望ましい", synonymous: ["望ましい"], group: "other" },
    { word: "あり", primary: "ある・いる・（ものごとを）する", synonymous: ["ある", "いる", "（ものごとを）する"], group: "other" },
    { word: "ありありて", primary: "生き続けて・結局", synonymous: ["生き続けて", "結局"], group: "other" },
    { word: "ありがたし", primary: "めったにない・すばらしい", synonymous: ["めったにない", "すばらしい"], group: "other" },
    { word: "ありく〔歩く〕", primary: "出歩く・～しまわる・～続ける", synonymous: ["出歩く", "～しまわる", "～続ける"], group: "other" },
    { word: "ありし", primary: "以前の・あの", synonymous: ["以前の", "あの"], group: "other" },
    { word: "ありつる", primary: "先程の", synonymous: ["先程の"], group: "other" },
    { word: "あるじ〔主〕", primary: "主人", synonymous: ["主人"], group: "other" },
    { word: "あるじ〔饗〕", primary: "もてなし", synonymous: ["もてなし"], group: "other" },
    { word: "あれ", primary: "このわたし・あの人", synonymous: ["このわたし", "あの人"], group: "other" },
    { word: "あれかにもあらず", primary: "呆然としている", synonymous: ["呆然としている"], group: "other" },
    { word: "あれかひとか", primary: "呆然としている", synonymous: ["呆然としている"], group: "other" },
    { word: "いうなり〔優なり〕", primary: "優れている・優雅である", synonymous: ["優れている", "優雅である"], group: "other" },
    { word: "いかが", primary: "どのように・どうして（～だろうか）・どうして（～だろうか、いや、～ない）・どんなにか（～だろう）", synonymous: ["どのように", "どうして（～だろうか）", "どうして（～だろうか、いや、～ない）", "どんなにか（～だろう）"], group: "other" },
    { word: "いかがはせむ", primary: "どうしようもない", synonymous: ["どうしようもない"], group: "other" },
    { word: "いかで", primary: "どうして（～だろうか）・どうして（～だろうか、いや、～ない）・なんとかして（～よう・～たい）", synonymous: ["どうして（～だろうか）", "どうして（～だろうか、いや、～ない）", "なんとかして（～よう", "～たい）"], group: "other" },
    { word: "いかでか", primary: "どうして（～だろうか）・どうして（～だろうか、いや、～ない）・なんとかして（～よう・～たい）", synonymous: ["どうして（～だろうか）", "どうして（～だろうか、いや、～ない）", "なんとかして（～よう", "～たい）"], group: "other" },
    { word: "いかに", primary: "どのように・どうして（～だろうか）・どうして（～だろうか、いや、～ない）・どんなにか（～だろう）", synonymous: ["どのように", "どうして（～だろうか）", "どうして（～だろうか、いや、～ない）", "どんなにか（～だろう）"], group: "other" },
    { word: "いかにもなる", primary: "死ぬ", synonymous: ["死ぬ"], group: "other" },
    { word: "いぎたなし", primary: "寝坊だ", synonymous: ["寝坊だ"], group: "other" },
    { word: "いざさせ給へ", primary: "さあいらっしゃい", synonymous: ["さあいらっしゃい"], group: "other" },
    { word: "いざ～知らず", primary: "さあ、～分からない", synonymous: ["さあ、～分からない"], group: "other" },
    { word: "いざ給へ", primary: "さあ、いらっしゃい", synonymous: ["さあ、いらっしゃい"], group: "other" },
    { word: "いそぎ〔急ぎ〕", primary: "準備", synonymous: ["準備"], group: "other" },
    { word: "いそぐ〔急ぐ〕", primary: "準備する", synonymous: ["準備する"], group: "other" },
    { word: "いたし〔甚し・痛し〕", primary: "すばらしい・ひどい・はなはだしく・〈いたく（う）の形で打消を伴って〉それほど", synonymous: ["すばらしい", "ひどい", "はなはだしく", "〈いたく（う）の形で打消を伴って〉それほど"], group: "other" },
    { word: "いたづらなり〔徒らなり〕", primary: "役に立たない・むなしい", synonymous: ["役に立たない", "むなしい"], group: "other" },
    { word: "いたづらになる", primary: "死ぬ", synonymous: ["死ぬ"], group: "other" },
    { word: "いたはる", primary: "病気で苦しむ・苦労する", synonymous: ["病気で苦しむ", "苦労する"], group: "other" },
    { word: "いちのひと〔一の人〕", primary: "摂政・関白", synonymous: ["摂政", "関白"], group: "other" },
    { word: "いつ", primary: "いつ（疑問）", synonymous: ["いつ（疑問）"], group: "other" },
    { word: "いづかた", primary: "どちら", synonymous: ["どちら"], group: "other" },
    { word: "いづく", primary: "どこ", synonymous: ["どこ"], group: "other" },
    { word: "いづこ", primary: "どこ", synonymous: ["どこ"], group: "other" },
    { word: "いつしか", primary: "いつの間にか・（できるだけ）早く（～してほしい）", synonymous: ["いつの間にか", "（できるだけ）早く（～してほしい）"], group: "other" },
    { word: "いづち", primary: "どちら", synonymous: ["どちら"], group: "other" },
    { word: "いづれ", primary: "どれ", synonymous: ["どれ"], group: "other" },
    { word: "いときなし", primary: "幼い", synonymous: ["幼い"], group: "other" },
    { word: "いとけなし", primary: "幼い", synonymous: ["幼い"], group: "other" },
    { word: "いともあらず", primary: "たいしたこともない", synonymous: ["たいしたこともない"], group: "other" },
    { word: "いともなし", primary: "たいしたこともない", synonymous: ["たいしたこともない"], group: "other" },
    { word: "いとど", primary: "ますます", synonymous: ["ますます"], group: "other" },
    { word: "いとどし", primary: "いっそうはなはだしい・いよいよ著しい", synonymous: ["いっそうはなはだしい", "いよいよ著しい"], group: "other" },
    { word: "いとおし", primary: "気の毒だ", synonymous: ["気の毒だ"], group: "other" },
    { word: "いとま〔暇〕", primary: "暇・（仕事を）休むこと", synonymous: ["暇", "（仕事を）休むこと"], group: "other" },
    { word: "いはけなし", primary: "子どもっぽい", synonymous: ["子どもっぽい"], group: "other" },
    { word: "いはむかたなし", primary: "言いようもない", synonymous: ["言いようもない"], group: "other" },
    { word: "いはむかたなくなる", primary: "言いようもない・言いようもなくすばらしい", synonymous: ["言いようもない", "言いようもなくすばらしい"], group: "other" },
    { word: "いふかひなし", primary: "言ってもかいがない・つまらない・取るに足りない", synonymous: ["言ってもかいがない", "つまらない", "取るに足りない"], group: "other" },
    { word: "いぶせし", primary: "うっとうしい・気がかりだ", synonymous: ["うっとうしい", "気がかりだ"], group: "other" },
    { word: "言ふばかりなし", primary: "言いようもない・何とも言いようがない", synonymous: ["言いようもない", "何とも言いようがない"], group: "other" },
    { word: "～（と）いふもおろかなり", primary: "（～という言葉では）言い尽くせない", synonymous: ["（～という言葉では）言い尽くせない"], group: "other" },
    { word: "いふもさらなり〔言ふも更なり〕", primary: "言うまでもない", synonymous: ["言うまでもない"], group: "other" },
    { word: "～（と）いふもなかなかなり", primary: "言うとかえってよくない・言わないほうがましだ", synonymous: ["言うとかえってよくない", "言わないほうがましだ"], group: "other" },
    { word: "～（と）いふもなべてなり", primary: "（～という言葉では）言い尽くせない", synonymous: ["（～という言葉では）言い尽くせない"], group: "other" },
    { word: "～（と）いふも世の常なり", primary: "（～という言葉では）言い尽くせない", synonymous: ["（～という言葉では）言い尽くせない"], group: "other" },
    { word: "～（と）いへばおろかなり", primary: "（～という言葉では）言い尽くせない", synonymous: ["（～という言葉では）言い尽くせない"], group: "other" },
    { word: "いへばさらなり", primary: "言うまでもない", synonymous: ["言うまでもない"], group: "other" },
    { word: "～（と）いへば世の常なり", primary: "（～という言葉では）言い尽くせない", synonymous: ["（～という言葉では）言い尽くせない"], group: "other" },
    { word: "いま〔今〕", primary: "すぐに・もう", synonymous: ["すぐに", "もう"], group: "other" },
    { word: "いまいまいし〔忌ま忌まし〕", primary: "不吉だ", synonymous: ["不吉だ"], group: "other" },
    { word: "います", primary: "いらっしゃる・～（て）いらっしゃる", synonymous: ["いらっしゃる", "～（て）いらっしゃる"], group: "other" },
    { word: "いますかり・いますがり", primary: "いらっしゃる・～（て）いらっしゃる", synonymous: ["いらっしゃる", "～（て）いらっしゃる"], group: "other" },
    { word: "いまそかり・いまそがり", primary: "いらっしゃる・～（て）いらっしゃる", synonymous: ["いらっしゃる", "～（て）いらっしゃる"], group: "other" },
    { word: "いまはかう", primary: "もはやこれまで", synonymous: ["もはやこれまで"], group: "other" },
    { word: "いまは限り", primary: "もはやこれまで", synonymous: ["もはやこれまで"], group: "other" },
    { word: "いまはかく", primary: "もはやこれまで", synonymous: ["もはやこれまで"], group: "other" },
    { word: "いまめかし", primary: "当世風だ", synonymous: ["当世風だ"], group: "other" },
    { word: "いみぢ", primary: "すばらしい・ひどい・とても", synonymous: ["すばらしい", "ひどい", "とても"], group: "other" },
    { word: "いも〔妹〕", primary: "親しいあなた", synonymous: ["親しいあなた"], group: "other" },
    { word: "いやし", primary: "身分が低い・みすぼらしい", synonymous: ["身分が低い", "みすぼらしい"], group: "other" },
    { word: "いらふ〔答ふ〕", primary: "答える", synonymous: ["答える"], group: "other" },
    { word: "いらへ", primary: "返事・返答", synonymous: ["返事", "返答"], group: "other" },
    { word: "色に出づ", primary: "（こらえきれず）表情に出る", synonymous: ["（こらえきれず）表情に出る"], group: "other" },
    { word: "寝を寝", primary: "寝る", synonymous: ["寝る"], group: "other" },
    { word: "承る", primary: "お受けする・お聞きする", synonymous: ["お受けする", "お聞きする"], group: "other" },
    { word: "うし〔憂し〕", primary: "つらい・いやだ", synonymous: ["つらい", "いやだ"], group: "other" },
    { word: "失ふ", primary: "殺す", synonymous: ["殺す"], group: "other" },
    { word: "うしろめたし", primary: "気がかりだ", synonymous: ["気がかりだ"], group: "other" },
    { word: "うしろめたなし", primary: "気がかりだ", synonymous: ["気がかりだ"], group: "other" },
    { word: "うしろやすし", primary: "安心だ", synonymous: ["安心だ"], group: "other" },
    { word: "失す", primary: "死ぬ", synonymous: ["死ぬ"], group: "other" },
    { word: "うたて", primary: "いやな感じに・異様に怪しく", synonymous: ["いやな感じに", "異様に怪しく"], group: "other" },
    { word: "うたてし", primary: "いやだ", synonymous: ["いやだ"], group: "other" },
    { word: "うち〔内裏・内〕", primary: "宮中・帝", synonymous: ["宮中", "帝"], group: "other" },
    { word: "うちつけなり", primary: "にわかだ・軽率だ", synonymous: ["にわかだ", "軽率だ"], group: "other" },
    { word: "うちとく", primary: "くつろぐ・油断する", synonymous: ["くつろぐ", "油断する"], group: "other" },
    { word: "うつくし〔美し〕", primary: "かわいい", synonymous: ["かわいい"], group: "other" },
    { word: "うつろふ〔移ろふ〕", primary: "色あせる", synonymous: ["色あせる"], group: "other" },
    { word: "うつつ〔現〕", primary: "現実・正気", synonymous: ["現実", "正気"], group: "other" },
    { word: "うべ〔宜〕", primary: "なるほど", synonymous: ["なるほど"], group: "other" },
    { word: "うべなり〔宜なり〕", primary: "もっともだ", synonymous: ["もっともだ"], group: "other" },
    { word: "うらなし〔心なし〕", primary: "（心の内を）包み隠すことがない", synonymous: ["（心の内を）包み隠すことがない"], group: "other" },
    { word: "うるさし", primary: "煩わしい・立派だ", synonymous: ["煩わしい", "立派だ"], group: "other" },
    { word: "うるせし", primary: "賢い・巧みだ", synonymous: ["賢い", "巧みだ"], group: "other" },
    { word: "うるはし", primary: "きちんとしている・美しい", synonymous: ["きちんとしている", "美しい"], group: "other" },
    { word: "うれふ〔愁ふ・憂ふ〕", primary: "（嘆き）訴える", synonymous: ["（嘆き）訴える"], group: "other" },
    { word: "うれへ〔愁へ・憂へ〕", primary: "訴え", synonymous: ["訴え"], group: "other" },
    { word: "え～（打消）", primary: "〈下に打消を伴い〉（～する）ことができない", synonymous: ["〈下に打消を伴い〉（～する）ことができない"], group: "other" },
    { word: "えならず", primary: "言いようもない", synonymous: ["言いようもない"], group: "other" },
    { word: "えもいはず", primary: "言いようもない・言いようもなくすばらしい", synonymous: ["言いようもない", "言いようもなくすばらしい"], group: "other" },
    { word: "おいらかなリなり", primary: "おっとりしている", synonymous: ["おっとりしている"], group: "other" },
    { word: "おきつ〔掟つ〕", primary: "決めておく・指図する", synonymous: ["決めておく", "指図する"], group: "other" },
    { word: "おくる〔後る・遅る〕", primary: "先立たれる", synonymous: ["先立たれる"], group: "other" },
    { word: "おこす", primary: "およこす", synonymous: ["およこす"], group: "other" },
    { word: "おこたり", primary: "（過失の）おわび・謝罪", synonymous: ["（過失の）おわび", "謝罪"], group: "other" },
    { word: "おこたる〔怠る〕", primary: "病気が治る", synonymous: ["病気が治る"], group: "other" },
    { word: "おこない〔行ひ〕", primary: "仏道修行", synonymous: ["仏道修行"], group: "other" },
    { word: "おこなふ〔行ふ〕", primary: "仏道修行をする", synonymous: ["仏道修行をする"], group: "other" },
    { word: "おとうと・をとと〔弟〕", primary: "妹", synonymous: ["妹"], group: "other" },
    { word: "おとづる", primary: "訪ねる", synonymous: ["訪ねる"], group: "other" },
    { word: "おとなし〔大人し〕", primary: "思慮分別がある・主だっている", synonymous: ["思慮分別がある", "主だっている"], group: "other" },
    { word: "おとなふ", primary: "訪ねる", synonymous: ["訪ねる"], group: "other" },
    { word: "音に聞く", primary: "噂に聞く", synonymous: ["噂に聞く"], group: "other" },
    { word: "おどろおどろし", primary: "大げさだ・気味が悪い", synonymous: ["大げさだ", "気味が悪い"], group: "other" },
    { word: "おどろかす", primary: "起こす・（はっと）気づかせる", synonymous: ["起こす", "（はっと）気づかせる"], group: "other" },
    { word: "おどろく〔驚く〕", primary: "目を覚ます・（はっと）気づく", synonymous: ["目を覚ます", "（はっと）気づく"], group: "other" },
    { word: "おの", primary: "このわたし", synonymous: ["このわたし"], group: "other" },
    { word: "おのれ", primary: "このわたし", synonymous: ["このわたし"], group: "other" },
    { word: "おはします", primary: "いらっしゃる・～（て）いらっしゃる", synonymous: ["いらっしゃる", "～（て）いらっしゃる"], group: "other" },
    { word: "おはす", primary: "いらっしゃる・～（て）いらっしゃる", synonymous: ["いらっしゃる", "～（て）いらっしゃる"], group: "other" },
    { word: "大内山", primary: "宮中", synonymous: ["宮中"], group: "other" },
    { word: "おぼえ〔覚へ〕", primary: "（世間の）評判・寵愛されること", synonymous: ["（世間の）評判", "寵愛されること"], group: "other" },
    { word: "おほかた（大方）（～打消）", primary: "まったく（～ない）", synonymous: ["まったく（～ない）"], group: "other" },
    { word: "おぼけなし", primary: "身のほど知らずだ", synonymous: ["身のほど知らずだ"], group: "other" },
    { word: "おぼし召す", primary: "お思いになる", synonymous: ["お思いになる"], group: "other" },
    { word: "仰す", primary: "おっしゃる", synonymous: ["おっしゃる"], group: "other" },
    { word: "思す", primary: "お思いになる", synonymous: ["お思いになる"], group: "other" },
    { word: "仰せ", primary: "お言葉・ご命令", synonymous: ["お言葉", "ご命令"], group: "other" },
    { word: "おぼつかなし〔覚束無し〕", primary: "はっきりしない・気がかりだ・待ち遠しい", synonymous: ["はっきりしない", "気がかりだ", "待ち遠しい"], group: "other" },
    { word: "おほどかなりなり", primary: "おっとりしている", synonymous: ["おっとりしている"], group: "other" },
    { word: "おほとのごもる〔大殿籠る〕", primary: "おやすみになる", synonymous: ["おやすみになる"], group: "other" },
    { word: "おほけや〔公〕", primary: "朝廷・帝", synonymous: ["朝廷", "帝"], group: "other" },
    { word: "おぼゆ〔覚ゆ〕", primary: "思われる・思い出される・似る", synonymous: ["思われる", "思い出される", "似る"], group: "other" },
    { word: "おぼろけならず", primary: "並ひととおりではない", synonymous: ["並ひととおりではない"], group: "other" },
    { word: "おぼろげなり", primary: "並ひととおりだ・並ひととおりではない", synonymous: ["並ひととおりだ", "並ひととおりではない"], group: "other" },
    { word: "御前", primary: "（神仏や貴人の）お側", synonymous: ["（神仏や貴人の）お側"], group: "other" },
    { word: "おもしろし", primary: "すばらしい", synonymous: ["すばらしい"], group: "other" },
    { word: "おもほえずなり", primary: "思いがけない・不満だ", synonymous: ["思いがけない", "不満だ"], group: "other" },
    { word: "思ほす", primary: "お思いになる", synonymous: ["お思いになる"], group: "other" },
    { word: "およすく・およすぐ", primary: "成長する・大人びる", synonymous: ["成長する", "大人びる"], group: "other" },
    { word: "おろかなり〔疎かなり〕", primary: "いい加減だ・並ひととおりだ", synonymous: ["いい加減だ", "並ひととおりだ"], group: "other" },
    { word: "おんとのごもる〔御殿籠る〕", primary: "おやすみになる", synonymous: ["おやすみになる"], group: "other" },
    { word: "か", primary: "あの人・あれ", synonymous: ["あの人", "あれ"], group: "other" },
    { word: "かいまみる〔垣間見る〕", primary: "のぞき見る", synonymous: ["のぞき見る"], group: "other" },
    { word: "かいまみ〔垣間見〕", primary: "のぞき見", synonymous: ["のぞき見"], group: "other" },
    { word: "かかり", primary: "こうである", synonymous: ["こうである"], group: "other" },
    { word: "かかるほどに", primary: "こうしているうちに", synonymous: ["こうしているうちに"], group: "other" },
    { word: "かかれど", primary: "こうではあるが", synonymous: ["こうではあるが"], group: "other" },
    { word: "かかれば", primary: "こうであるので", synonymous: ["こうであるので"], group: "other" },
    { word: "かきくらす〔掻き暗す〕", primary: "空を暗くする・悲しみにくれる", synonymous: ["空を暗くする", "悲しみにくれる"], group: "other" },
    { word: "かぎり〔限り〕", primary: "限界・限度・臨終・すべて", synonymous: ["限界", "限度", "臨終", "すべて"], group: "other" },
    { word: "限りなし", primary: "この上ない", synonymous: ["この上ない"], group: "other" },
    { word: "かく", primary: "このように", synonymous: ["このように"], group: "other" },
    { word: "隠る", primary: "死ぬ", synonymous: ["死ぬ"], group: "other" },
    { word: "かげ〔影〕", primary: "光・姿", synonymous: ["光", "姿"], group: "other" },
    { word: "かげ〔陰〕", primary: "日陰・光の当たらない所", synonymous: ["日陰", "光の当たらない所"], group: "other" },
    { word: "かけて（～打消）", primary: "まったく・決して（～ない）", synonymous: ["まったく", "決して（～ない）"], group: "other" },
    { word: "かけても（～打消）", primary: "まったく・決して（～ない）", synonymous: ["まったく", "決して（～ない）"], group: "other" },
    { word: "かこつ〔託つ〕", primary: "嘆く", synonymous: ["嘆く"], group: "other" },
    { word: "かごと〔託言〕", primary: "言い訳・恨み言", synonymous: ["言い訳", "恨み言"], group: "other" },
    { word: "かごとがまし", primary: "恨みがましい", synonymous: ["恨みがましい"], group: "other" },
    { word: "かごとのことばかり", primary: "ほんの少し・形ばかり", synonymous: ["ほんの少し", "形ばかり"], group: "other" },
    { word: "かしこ", primary: "あそこ", synonymous: ["あそこ"], group: "other" },
    { word: "かしこし〔畏し・賢し〕", primary: "おそれ多い・優れている・うまい具合に", synonymous: ["おそれ多い", "優れている", "うまい具合に"], group: "other" },
    { word: "かしこまる〔畏まる〕", primary: "恐縮する・恐縮して正座する", synonymous: ["恐縮する", "恐縮して正座する"], group: "other" },
    { word: "かしづく", primary: "大切に育てる・大切にお世話をする", synonymous: ["大切に育てる", "大切にお世話をする"], group: "other" },
    { word: "頭下ろす", primary: "出家する", synonymous: ["出家する"], group: "other" },
    { word: "かたじけなし〔忝し〕", primary: "おそれ多い・面目ない", synonymous: ["おそれ多い", "面目ない"], group: "other" },
    { word: "かたちを変ふ", primary: "出家する", synonymous: ["出家する"], group: "other" },
    { word: "かたはらいたし", primary: "きまり悪い・苦々しい・気の毒だ", synonymous: ["きまり悪い", "苦々しい", "気の毒だ"], group: "other" },
    { word: "かたへ〔片方〕", primary: "半分・傍ら・仲間", synonymous: ["半分", "傍ら", "仲間"], group: "other" },
    { word: "かたほなり", primary: "不完全だ・未熟だ", synonymous: ["不完全だ", "未熟だ"], group: "other" },
    { word: "かたみに〔互に〕", primary: "互いに", synonymous: ["互いに"], group: "other" },
    { word: "かたらふ〔語らふ〕", primary: "語り合う・親しく交際する・（男女が）契る・説得する", synonymous: ["語り合う", "親しく交際する", "（男女が）契る", "説得する"], group: "other" },
    { word: "かつ", primary: "一方では・すぐに", synonymous: ["一方では", "すぐに"], group: "other" },
    { word: "かづく〔被く〕", primary: "かぶる・（貴人からほうびとして）いただく", synonymous: ["かぶる", "（貴人からほうびとして）いただく"], group: "other" },
    { word: "かづく〔被く〕", primary: "（貴人がほうびとして）与える", synonymous: ["（貴人がほうびとして）与える"], group: "other" },
    { word: "潜く", primary: "潜る", synonymous: ["潜る"], group: "other" },
    { word: "かづけもの", primary: "ほうびの品物", synonymous: ["ほうびの品物"], group: "other" },
    { word: "かなし", primary: "いとしい", synonymous: ["いとしい"], group: "other" },
    { word: "かなしうす", primary: "かわいがる", synonymous: ["かわいがる"], group: "other" },
    { word: "かなた", primary: "あちら", synonymous: ["あちら"], group: "other" },
    { word: "かまへて（～打消・禁止）", primary: "決して（～ない・～するな）・なんとかして", synonymous: ["決して（～ない", "～するな）", "なんとかして"], group: "other" },
    { word: "かりそめなり", primary: "ほんの一時的である", synonymous: ["ほんの一時的である"], group: "other" },
    { word: "かる〔離る〕", primary: "離れる", synonymous: ["離れる"], group: "other" },
    { word: "かれ", primary: "あの人", synonymous: ["あの人"], group: "other" },
    { word: "消え入る", primary: "死ぬ・気絶する", synonymous: ["死ぬ", "気絶する"], group: "other" },
    { word: "聞こえ", primary: "噂・評判", synonymous: ["噂", "評判"], group: "other" },
    { word: "聞こえさす", primary: "申し上げる・（お）～申し上げる", synonymous: ["申し上げる", "（お）～申し上げる"], group: "other" },
    { word: "聞こし召す", primary: "お聞きになる・召し上がる", synonymous: ["お聞きになる", "召し上がる"], group: "other" },
    { word: "聞こゆ", primary: "聞こえる・評判になる・分かる", synonymous: ["聞こえる", "評判になる", "分かる"], group: "other" },
    { word: "聞こゆ", primary: "申し上げる・（お）～申し上げる", synonymous: ["申し上げる", "（お）～申し上げる"], group: "other" },
    { word: "きは〔際〕", primary: "身分", synonymous: ["身分"], group: "other" },
    { word: "行幸", primary: "帝のお出まし", synonymous: ["帝のお出まし"], group: "other" },
    { word: "消ゆ", primary: "死ぬ", synonymous: ["死ぬ"], group: "other" },
    { word: "清げなり", primary: "さっぱりとして美しい", synonymous: ["さっぱりとして美しい"], group: "other" },
    { word: "清らなり", primary: "清らかで美しい", synonymous: ["清らかで美しい"], group: "other" },
    { word: "朽葉", primary: "カバー袖（襲の色目）", synonymous: ["カバー袖（襲の色目）"], group: "other" },
    { word: "くちをし〔口惜し〕", primary: "残念だ", synonymous: ["残念だ"], group: "other" },
    { word: "くどく〔口説く〕", primary: "繰り返し同じことを言う・意中を訴える", synonymous: ["繰り返し同じことを言う", "意中を訴える"], group: "other" },
    { word: "隈", primary: "陰・くま", synonymous: ["陰", "くま"], group: "other" },
    { word: "隈なし〔隈無し〕", primary: "陰がない・なんでも知っている", synonymous: ["陰がない", "なんでも知っている"], group: "other" },
    { word: "雲の上", primary: "宮中", synonymous: ["宮中"], group: "other" },
    { word: "雲居", primary: "宮中・天空・はるか遠く", synonymous: ["宮中", "天空", "はるか遠く"], group: "other" },
    { word: "くるしからず", primary: "不都合ではない・差し支えない", synonymous: ["不都合ではない", "差し支えない"], group: "other" },
    { word: "紅", primary: "カバー袖（襲の色目）", synonymous: ["カバー袖（襲の色目）"], group: "other" },
    { word: "けうらなり", primary: "清らかで美しい", synonymous: ["清らかで美しい"], group: "other" },
    { word: "け〔故〕", primary: "ため・せい・わけ", synonymous: ["ため", "せい", "わけ"], group: "other" },
    { word: "啓す", primary: "（中宮・東宮に）申し上げる", synonymous: ["（中宮", "東宮に）申し上げる"], group: "other" },
    { word: "けうとし", primary: "不気味だ・寂しい・疎遠だ", synonymous: ["不気味だ", "寂しい", "疎遠だ"], group: "other" },
    { word: "けし〔怪し・異し〕", primary: "異様だ", synonymous: ["異様だ"], group: "other" },
    { word: "けしうあらず", primary: "悪くはない", synonymous: ["悪くはない"], group: "other" },
    { word: "けしうはあらず", primary: "悪くはない", synonymous: ["悪くはない"], group: "other" },
    { word: "けしからず", primary: "よくない", synonymous: ["よくない"], group: "other" },
    { word: "けしき〔気色〕", primary: "様子・機嫌・意向", synonymous: ["様子", "機嫌", "意向"], group: "other" },
    { word: "気色立つ", primary: "様子が外に現れる", synonymous: ["様子が外に現れる"], group: "other" },
    { word: "けしきばかり", primary: "ほんの少し・形ばかり", synonymous: ["ほんの少し", "形ばかり"], group: "other" },
    { word: "気色ばむ", primary: "様子が外に現れる", synonymous: ["様子が外に現れる"], group: "other" },
    { word: "けぢめ", primary: "遠慮・けじめ・区別", synonymous: ["遠慮", "けじめ", "区別"], group: "other" },
    { word: "けに", primary: "いよいよ・ますます", synonymous: ["いよいよ", "ますます"], group: "other" },
    { word: "げに〔実に〕", primary: "（実際）本当に", synonymous: ["（実際）本当に"], group: "other" },
    { word: "けやけし", primary: "際立っている・すばらしい・異様だ", synonymous: ["際立っている", "すばらしい", "異様だ"], group: "other" },
    { word: "見参に入る", primary: "（貴人に）お目にかかる・（貴人に）お目にかける", synonymous: ["（貴人に）お目にかかる", "（貴人に）お目にかける"], group: "other" },
    { word: "こ", primary: "この人・これ", synonymous: ["この人", "これ"], group: "other" },
    { word: "こうず〔困ず〕", primary: "疲れる", synonymous: ["疲れる"], group: "other" },
    { word: "紅梅", primary: "カバー袖（襲の色目）", synonymous: ["カバー袖（襲の色目）"], group: "other" },
    { word: "御幸", primary: "上皇のお出まし", synonymous: ["上皇のお出まし"], group: "other" },
    { word: "ここ", primary: "このわたし・こちら", synonymous: ["このわたし", "こちら"], group: "other" },
    { word: "心地", primary: "病気・気分（の悪さ）", synonymous: ["病気", "気分（の悪さ）"], group: "other" },
    { word: "九重", primary: "宮中", synonymous: ["宮中"], group: "other" },
    { word: "こごら", primary: "たくさん", synonymous: ["たくさん"], group: "other" },
    { word: "こころ", primary: "たくさん・たいそう", synonymous: ["たくさん", "たいそう"], group: "other" },
    { word: "こころあり", primary: "情趣を解する・道理を解する・思いやりがある", synonymous: ["情趣を解する", "道理を解する", "思いやりがある"], group: "other" },
    { word: "こころぐるし〔心苦し〕", primary: "気の毒だ・気がかりだ", synonymous: ["気の毒だ", "気がかりだ"], group: "other" },
    { word: "こころざし〔心ざし・志〕", primary: "愛情・お礼の贈り物", synonymous: ["愛情", "お礼の贈り物"], group: "other" },
    { word: "こころづきなし", primary: "気にくわない", synonymous: ["気にくわない"], group: "other" },
    { word: "こころづくし〔心尽くし〕", primary: "もの思いをすること", synonymous: ["もの思いをすること"], group: "other" },
    { word: "こころなし", primary: "情趣を解さない・道理を解さない・思いやりがない", synonymous: ["情趣を解さない", "道理を解さない", "思いやりがない"], group: "other" },
    { word: "こころにくし", primary: "奥ゆかしい", synonymous: ["奥ゆかしい"], group: "other" },
    { word: "心の闇", primary: "心の迷い・分別を失った親心", synonymous: ["心の迷い", "分別を失った親心"], group: "other" },
    { word: "こころばへ", primary: "気だて・心づかい・趣", synonymous: ["気だて", "心づかい", "趣"], group: "other" },
    { word: "心まうけ", primary: "心積もり", synonymous: ["心積もり"], group: "other" },
    { word: "こころもとなし〔心許なし〕", primary: "かすかだ・不安だ・じれったい", synonymous: ["かすかだ", "不安だ", "じれったい"], group: "other" },
    { word: "こころやる", primary: "気晴らしをする・得意になる", synonymous: ["気晴らしをする", "得意になる"], group: "other" },
    { word: "こころゆく", primary: "満足する・気が晴れる", synonymous: ["満足する", "気が晴れる"], group: "other" },
    { word: "こころをやる", primary: "気晴らしをする・得意になる", synonymous: ["気晴らしをする", "得意になる"], group: "other" },
    { word: "こしらふ", primary: "なだめすかす・説得する", synonymous: ["なだめすかす", "説得する"], group: "other" },
    { word: "古代紫", primary: "カバー袖（襲の色目）", synonymous: ["カバー袖（襲の色目）"], group: "other" },
    { word: "こち", primary: "こちら", synonymous: ["こちら"], group: "other" },
    { word: "こちたし", primary: "（噂や評判が）うるさい・大げさだ・はなはだしい", synonymous: ["（噂や評判が）うるさい", "大げさだ", "はなはだしい"], group: "other" },
    { word: "こちなし", primary: "不作法だ・無骨だ", synonymous: ["不作法だ", "無骨だ"], group: "other" },
    { word: "こと〔言〕", primary: "言葉・和歌", synonymous: ["言葉", "和歌"], group: "other" },
    { word: "ことごととし", primary: "大げさだ", synonymous: ["大げさだ"], group: "other" },
    { word: "ことなり〔異なり〕", primary: "異なっている・格別だ", synonymous: ["異なっている", "格別だ"], group: "other" },
    { word: "ことに〔殊に〕", primary: "特に・とりわけ", synonymous: ["特に", "とりわけ"], group: "other" },
    { word: "ことわり〔理〕", primary: "道理", synonymous: ["道理"], group: "other" },
    { word: "ことわりなり", primary: "もっともである・当然である", synonymous: ["もっともである", "当然である"], group: "other" },
    { word: "ことわる", primary: "（道理に従って）判断・説明する", synonymous: ["（道理に従って）判断", "説明する"], group: "other" },
    { word: "こなた", primary: "このわたし", synonymous: ["このわたし"], group: "other" },
    { word: "このかみ〔兄〕", primary: "兄・姉・年長者", synonymous: ["兄", "姉", "年長者"], group: "other" },
    { word: "御覧ず", primary: "御覧になる", synonymous: ["御覧になる"], group: "other" },
    { word: "御覧ぜず", primary: "御覧に入れる・お目に掛ける", synonymous: ["御覧に入れる", "お目に掛ける"], group: "other" },
    { word: "これ", primary: "このわたし", synonymous: ["このわたし"], group: "other" },
    { word: "さ", primary: "そのように", synonymous: ["そのように"], group: "other" },
    { word: "さうざうし", primary: "もの足りない", synonymous: ["もの足りない"], group: "other" },
    { word: "さうなし〔双無し〕", primary: "比べるものがない", synonymous: ["比べるものがない"], group: "other" },
    { word: "左右なし", primary: "あれこれ考えない・決着がつかない", synonymous: ["あれこれ考えない", "決着がつかない"], group: "other" },
    { word: "さうらふ〔候ふ〕", primary: "～（でございます）・お仕え申し上げる", synonymous: ["～（でございます）", "お仕え申し上げる"], group: "other" },
    { word: "才", primary: "（漢学・漢詩文の）教養・（和歌・音楽などの）才能", synonymous: ["（漢学", "漢詩文の）教養", "（和歌", "音楽などの）才能"], group: "other" },
    { word: "さかし〔賢し〕", primary: "優れている・しっかりしている・こざかしい", synonymous: ["優れている", "しっかりしている", "こざかしい"], group: "other" },
    { word: "さかしら", primary: "利口ぶること・こざかしさ", synonymous: ["利口ぶること", "こざかしさ"], group: "other" },
    { word: "さがなし", primary: "意地が悪い・いたずらだ", synonymous: ["意地が悪い", "いたずらだ"], group: "other" },
    { word: "さいらへ", primary: "返事・返答", synonymous: ["返事", "返答"], group: "other" },
    { word: "（動詞＋）さす", primary: "添う・添わせる", synonymous: ["添う", "添わせる"], group: "other" },
    { word: "さすがに", primary: "そうはいってもやはり・なんといってもやはり", synonymous: ["そうはいってもやはり", "なんといってもやはり"], group: "other" },
    { word: "させる", primary: "たいした", synonymous: ["たいした"], group: "other" },
    { word: "沙汰", primary: "評議・裁き・命令・噂", synonymous: ["評議", "裁き", "命令", "噂"], group: "other" },
    { word: "さだめて〔定めて〕（～推量）", primary: "きっと（～だろう）", synonymous: ["きっと（～だろう）"], group: "other" },
    { word: "さて〔然て〕", primary: "そのまま・そのほか", synonymous: ["そのまま", "そのほか"], group: "other" },
    { word: "さてしもあらず", primary: "そのままにしてはおけない", synonymous: ["そのままにしてはおけない"], group: "other" },
    { word: "さてしもあるべきことならず", primary: "そのままにしてはおけない", synonymous: ["そのままにしてはおけない"], group: "other" },
    { word: "さながら〔然ながら〕", primary: "そのまま・すべて", synonymous: ["そのまま", "すべて"], group: "other" },
    { word: "さはり〔障り〕", primary: "支障", synonymous: ["支障"], group: "other" },
    { word: "さはる〔障る〕", primary: "差し支える・妨げられる", synonymous: ["差し支える", "妨げられる"], group: "other" },
    { word: "さはれ", primary: "どうとでもなれ・それはそうだが", synonymous: ["どうとでもなれ", "それはそうだが"], group: "other" },
    { word: "さばれ", primary: "どうとでもなれ・それはそうだが", synonymous: ["どうとでもなれ", "それはそうだが"], group: "other" },
    { word: "さぶらふ〔候ふ〕", primary: "～（でございます）・お仕え申し上げる", synonymous: ["～（でございます）", "お仕え申し上げる"], group: "other" },
    { word: "さま〔様〕", primary: "様子・方法・方角", synonymous: ["様子", "方法", "方角"], group: "other" },
    { word: "さまばかり", primary: "ほんの少し・形ばかり", synonymous: ["ほんの少し", "形ばかり"], group: "other" },
    { word: "様を変ふ", primary: "出家する", synonymous: ["出家する"], group: "other" },
    { word: "さらじ", primary: "そうでないならば", synonymous: ["そうでないならば"], group: "other" },
    { word: "さらで", primary: "そうでなくて・それ以外で", synonymous: ["そうでなくて", "それ以外で"], group: "other" },
    { word: "さらでだに", primary: "そうでなくてさえ・ただでさえ", synonymous: ["そうでなくてさえ", "ただでさえ"], group: "other" },
    { word: "さらでは", primary: "そうでなくては・そうでなかったら", synonymous: ["そうでなくては", "そうでなかったら"], group: "other" },
    { word: "さらでも", primary: "そうでなくても", synonymous: ["そうでなくても"], group: "other" },
    { word: "さらなり〔更なり〕", primary: "言うまでもない", synonymous: ["言うまでもない"], group: "other" },
    { word: "さらに〔更に〕（～打消）", primary: "まったく（～ない）", synonymous: ["まったく（～ない）"], group: "other" },
    { word: "さらにもあらず", primary: "言うまでもない", synonymous: ["言うまでもない"], group: "other" },
    { word: "さらにもいはず", primary: "言うまでもない", synonymous: ["言うまでもない"], group: "other" },
    { word: "さらぬ〔然らぬ〕", primary: "そうではない", synonymous: ["そうではない"], group: "other" },
    { word: "さらぬ〔避らぬ〕", primary: "避けられない", synonymous: ["避けられない"], group: "other" },
    { word: "さり", primary: "そうである", synonymous: ["そうである"], group: "other" },
    { word: "さりとて", primary: "そうであるといって・だからといって", synonymous: ["そうであるといって", "だからといって"], group: "other" },
    { word: "さりとて", primary: "そうではあっても・いくらなんでも", synonymous: ["そうではあっても", "いくらなんでも"], group: "other" },
    { word: "さりながら", primary: "そうではあるが", synonymous: ["そうではあるが"], group: "other" },
    { word: "さりぬべき", primary: "そうなるはずの・ふさわしい・立派な", synonymous: ["そうなるはずの", "ふさわしい", "立派な"], group: "other" },
    { word: "さる〔避る〕", primary: "避ける", synonymous: ["避ける"], group: "other" },
    { word: "さる〔去る〕", primary: "（その時に）なる", synonymous: ["（その時に）なる"], group: "other" },
    { word: "さる〔然る〕", primary: "しかるべき・立派な", synonymous: ["しかるべき", "立派な"], group: "other" },
    { word: "さることにて", primary: "言うまでもないことで・ともかくとして", synonymous: ["言うまでもないことで", "ともかくとして"], group: "other" },
    { word: "さるべき", primary: "そうなるはずの・ふさわしい・立派な", synonymous: ["そうなるはずの", "ふさわしい", "立派な"], group: "other" },
    { word: "さるべきにや（ありけむ）", primary: "そうなるはずの前世からの因縁であったのだろうか", synonymous: ["そうなるはずの前世からの因縁であったのだろうか"], group: "other" },
    { word: "さるほどに", primary: "そうしているうちに", synonymous: ["そうしているうちに"], group: "other" },
    { word: "さるものにて", primary: "言うまでもないことで・ともかくとして", synonymous: ["言うまでもないことで", "ともかくとして"], group: "other" },
    { word: "されば", primary: "そうであるから", synonymous: ["そうであるから"], group: "other" },
    { word: "さればこそ", primary: "思ったとおりだ・案の定だ", synonymous: ["思ったとおりだ", "案の定だ"], group: "other" },
    { word: "さればよ", primary: "思ったとおりだ・案の定だ", synonymous: ["思ったとおりだ", "案の定だ"], group: "other" },
    { word: "しか", primary: "そのように", synonymous: ["そのように"], group: "other" },
    { word: "しかしながら", primary: "そっくりそのまま・すべて", synonymous: ["そっくりそのまま", "すべて"], group: "other" },
    { word: "しからば", primary: "そうであるならば", synonymous: ["そうであるならば"], group: "other" },
    { word: "しかり", primary: "そうである", synonymous: ["そうである"], group: "other" },
    { word: "しかるに", primary: "そうであるのに・ところが", synonymous: ["そうであるのに", "ところが"], group: "other" },
    { word: "しかるべき", primary: "そうなるはずの・ふさわしい・立派な", synonymous: ["そうなるはずの", "ふさわしい", "立派な"], group: "other" },
    { word: "しかるを", primary: "そうであるのに・ところが", synonymous: ["そうであるのに", "ところが"], group: "other" },
    { word: "しかれども", primary: "そうであるけれども", synonymous: ["そうであるけれども"], group: "other" },
    { word: "しげし〔繁し・茂し〕", primary: "（何かが）多い", synonymous: ["（何かが）多い"], group: "other" },
    { word: "知る", primary: "親しく付き合う・男女の交際をする・治める", synonymous: ["親しく付き合う", "男女の交際をする", "治める"], group: "other" },
    { word: "しるし〔著し〕", primary: "はっきりと分かる・～（の）とおりに", synonymous: ["はっきりと分かる", "～（の）とおりに"], group: "other" },
    { word: "しるし〔験・徴〕", primary: "効き目・ご利益・きざし", synonymous: ["効き目", "ご利益", "きざし"], group: "other" },
    { word: "しろしめす", primary: "知っていらっしゃる・お治めになる", synonymous: ["知っていらっしゃる", "お治めになる"], group: "other" },
    { word: "姿を変ふ", primary: "出家する", synonymous: ["出家する"], group: "other" },
    { word: "好き", primary: "風流の道に熱中すること・色好み", synonymous: ["風流の道に熱中すること", "色好み"], group: "other" },
    { word: "好き好きし", primary: "風流だ・好色だ", synonymous: ["風流だ", "好色だ"], group: "other" },
    { word: "しだい〔次第〕", primary: "順序", synonymous: ["順序"], group: "other" },
    { word: "しどけなし", primary: "怠慢だ・気楽だ", synonymous: ["怠慢だ", "気楽だ"], group: "other" },
    { word: "しな〔品〕", primary: "身分・気品", synonymous: ["身分", "気品"], group: "other" },
    { word: "しのぶA〔忍ぶ〕", primary: "がまんする・人目につかないようにする", synonymous: ["がまんする", "人目につかないようにする"], group: "other" },
    { word: "しのぶB〔偲ぶ〕", primary: "思い出す", synonymous: ["思い出す"], group: "other" },
    { word: "しほたる〔潮垂る〕", primary: "涙を流す", synonymous: ["涙を流す"], group: "other" },
    { word: "好く", primary: "風流を好む", synonymous: ["風流を好む"], group: "other" },
    { word: "すごし〔凄し〕", primary: "気味が悪い・さびしい・（ぞっとするほど）すばらしい", synonymous: ["気味が悪い", "さびしい", "（ぞっとするほど）すばらしい"], group: "other" },
    { word: "すさびごと", primary: "慰みごと", synonymous: ["慰みごと"], group: "other" },
    { word: "すさぶ〔荒ぶ・進ぶ・遊ぶ〕", primary: "（何かに）興じる・気の向くままに（何かを）する", synonymous: ["（何かに）興じる", "気の向くままに（何かを）する"], group: "other" },
    { word: "すさまじ", primary: "興ざめだ・殺風景だ", synonymous: ["興ざめだ", "殺風景だ"], group: "other" },
    { word: "すずろなり〔漫ろなり〕", primary: "なんとなく（こと）（わけ）もない・思いがけない・むやみやたらだ", synonymous: ["なんとなく（こと）（わけ）もない", "思いがけない", "むやみやたらだ"], group: "other" },
    { word: "ずちなし〔術無し〕", primary: "どうしようもない", synonymous: ["どうしようもない"], group: "other" },
    { word: "すなはち〔即ち・則ち・乃ち〕", primary: "すぐに", synonymous: ["すぐに"], group: "other" },
    { word: "蘇芳", primary: "カバー袖（襲の色目）", synonymous: ["カバー袖（襲の色目）"], group: "other" },
    { word: "すまふ〔争ふ・辞ふ〕", primary: "抵抗する・断る", synonymous: ["抵抗する", "断る"], group: "other" },
    { word: "住む", primary: "（女のもとに）通う", synonymous: ["（女のもとに）通う"], group: "other" },
    { word: "せうと〔兄人〕", primary: "兄", synonymous: ["兄"], group: "other" },
    { word: "せきあへず〔塞き敢へず〕", primary: "（涙などを）せき止めきれない", synonymous: ["（涙などを）せき止めきれない"], group: "other" },
    { word: "せちなり〔切なり〕", primary: "切実である・大切である", synonymous: ["切実である", "大切である"], group: "other" },
    { word: "せむかたなし", primary: "どうしようもない", synonymous: ["どうしようもない"], group: "other" },
    { word: "せめて", primary: "強いて・ひどく", synonymous: ["強いて", "ひどく"], group: "other" },
    { word: "そ", primary: "その人・それ", synonymous: ["その人", "それ"], group: "other" },
    { word: "奏す", primary: "（帝・上皇・法皇に）申し上げる", synonymous: ["（帝", "上皇", "法皇に）申し上げる"], group: "other" },
    { word: "そこ", primary: "あなた", synonymous: ["あなた"], group: "other" },
    { word: "そこはかとなし", primary: "何ということもない", synonymous: ["何ということもない"], group: "other" },
    { word: "そこばく", primary: "たくさん", synonymous: ["たくさん"], group: "other" },
    { word: "そこら", primary: "たくさん・たいそう", synonymous: ["たくさん", "たいそう"], group: "other" },
    { word: "そぞろなり〔漫ろなり〕", primary: "なんとなく（こと）（わけ）もない・思いがけない・むやみやたらだ", synonymous: ["なんとなく（こと）（わけ）もない", "思いがけない", "むやみやたらだ"], group: "other" },
    { word: "そち", primary: "そちら", synonymous: ["そちら"], group: "other" },
    { word: "そなた", primary: "あなた", synonymous: ["あなた"], group: "other" },
    { word: "そのかみ", primary: "その当時", synonymous: ["その当時"], group: "other" },
    { word: "そのこととなく", primary: "これということもなく", synonymous: ["これということもなく"], group: "other" },
    { word: "そばめにかく", primary: "横目で見る・軽く見る", synonymous: ["横目で見る", "軽く見る"], group: "other" },
    { word: "そらごと〔空言・虚言〕", primary: "嘘", synonymous: ["嘘"], group: "other" },
    { word: "それ", primary: "あなた", synonymous: ["あなた"], group: "other" },
    { word: "それがし", primary: "だ・だれ", synonymous: ["だ", "だれ"], group: "other" },
    { word: "た", primary: "だれ", synonymous: ["だれ"], group: "other" },
    { word: "たいだいし", primary: "もってのほかだ・不都合だ", synonymous: ["もってのほかだ", "不都合だ"], group: "other" },
    { word: "当時", primary: "現在・その時", synonymous: ["現在", "その時"], group: "other" },
    { word: "たうぶ〔給ふ〕", primary: "お与えになる・～なさる", synonymous: ["お与えになる", "～なさる"], group: "other" },
    { word: "たえ入る", primary: "死ぬ・気絶する", synonymous: ["死ぬ", "気絶する"], group: "other" },
    { word: "たえて〔絶えて〕（～打消）", primary: "まったく（～ない）", synonymous: ["まったく（～ない）"], group: "other" },
    { word: "たぐふ", primary: "（四段）添う・（下二段）添わせる", synonymous: ["（四段）添う", "（下二段）添わせる"], group: "other" },
    { word: "ただならずなる", primary: "懐妊する", synonymous: ["懐妊する"], group: "other" },
    { word: "たづき〔方便〕", primary: "手段・手がかり", synonymous: ["手段", "手がかり"], group: "other" },
    { word: "尋ぬ", primary: "探し求める", synonymous: ["探し求める"], group: "other" },
    { word: "奉る", primary: "差し上げる・（お）～申し上げる・お召しになる・召し上がる・お乗りになる", synonymous: ["差し上げる", "（お）～申し上げる", "お召しになる", "召し上がる", "お乗りになる"], group: "other" },
    { word: "たのし", primary: "裕福だ", synonymous: ["裕福だ"], group: "other" },
    { word: "たのみ", primary: "あてにすること・期待", synonymous: ["あてにすること", "期待"], group: "other" },
    { word: "たのむ〔頼む〕", primary: "あてにする", synonymous: ["あてにする"], group: "other" },
    { word: "たのむ〔頼む〕", primary: "あてにさせる", synonymous: ["あてにさせる"], group: "other" },
    { word: "たのめ", primary: "あてにさせること", synonymous: ["あてにさせること"], group: "other" },
    { word: "頼もし", primary: "頼みになる・裕福だ", synonymous: ["頼みになる", "裕福だ"], group: "other" },
    { word: "たばかる〔謀る〕", primary: "工夫する・だます", synonymous: ["工夫する", "だます"], group: "other" },
    { word: "たぶ〔給ふ〕", primary: "お与えになる・～なさる", synonymous: ["お与えになる", "～なさる"], group: "other" },
    { word: "たまはす〔給はす・賜はす〕", primary: "お与えになる", synonymous: ["お与えになる"], group: "other" },
    { word: "たまはる〔賜はる・給はる〕", primary: "いただく", synonymous: ["いただく"], group: "other" },
    { word: "給ふ", primary: "お与えになる・下さる・～なさる・お～になる", synonymous: ["お与えになる", "下さる", "～なさる", "お～になる"], group: "other" },
    { word: "給ふ", primary: "～（ており）ます", synonymous: ["～（ており）ます"], group: "other" },
    { word: "ためし〔例〕", primary: "先例", synonymous: ["先例"], group: "other" },
    { word: "ためらふ", primary: "気持ちを静める", synonymous: ["気持ちを静める"], group: "other" },
    { word: "たゆ", primary: "死ぬ・気絶する", synonymous: ["死ぬ", "気絶する"], group: "other" },
    { word: "たより〔頼り・便り〕", primary: "よりどころ・つて・よい機会", synonymous: ["よりどころ", "つて", "よい機会"], group: "other" },
    { word: "たれ", primary: "だれ", synonymous: ["だれ"], group: "other" },
    { word: "力なし", primary: "どうしようもない・しかたない・どうにもならない", synonymous: ["どうしようもない", "しかたない", "どうにもならない"], group: "other" },
    { word: "ちぎり〔契り〕", primary: "約束・宿縁", synonymous: ["約束", "宿縁"], group: "other" },
    { word: "ついで〔序〕", primary: "序列・機会", synonymous: ["序列", "機会"], group: "other" },
    { word: "つかまつる〔仕まつる〕", primary: "お仕え申し上げる・（何かを）し申し上げる・（お）～申し上げる", synonymous: ["お仕え申し上げる", "（何かを）し申し上げる", "（お）～申し上げる"], group: "other" },
    { word: "つかはす〔遣はす〕", primary: "（人や物を）おやりになる", synonymous: ["（人や物を）おやりになる"], group: "other" },
    { word: "つきごろ〔月頃〕", primary: "数か月（の間）", synonymous: ["数か月（の間）"], group: "other" },
    { word: "つきづきし〔付き付きし〕", primary: "似つかわしい", synonymous: ["似つかわしい"], group: "other" },
    { word: "つきなし", primary: "ふさわしくない", synonymous: ["ふさわしくない"], group: "other" },
    { word: "つつまし", primary: "遠慮される・気がひける", synonymous: ["遠慮される", "気がひける"], group: "other" },
    { word: "つつむ〔慎む〕", primary: "遠慮する", synonymous: ["遠慮する"], group: "other" },
    { word: "つとめて", primary: "早朝・翌朝", synonymous: ["早朝", "翌朝"], group: "other" },
    { word: "つま〔夫・妻〕", primary: "夫", synonymous: ["夫"], group: "other" },
    { word: "つま〔端〕", primary: "はし・端緒", synonymous: ["はし", "端緒"], group: "other" },
    { word: "つやつや（～打消）", primary: "まったく（～ない）", synonymous: ["まったく（～ない）"], group: "other" },
    { word: "つゆ（～打消）", primary: "少しも（～ない）", synonymous: ["少しも（～ない）"], group: "other" },
    { word: "つゆけし〔露けし〕", primary: "涙がちだ", synonymous: ["涙がちだ"], group: "other" },
    { word: "つらし〔辛し〕", primary: "薄情だ", synonymous: ["薄情だ"], group: "other" },
    { word: "つれづれなり〔徒然なり〕", primary: "退屈である・ものさびしい", synonymous: ["退屈である", "ものさびしい"], group: "other" },
    { word: "つれなし", primary: "平然としている・冷淡だ", synonymous: ["平然としている", "冷淡だ"], group: "other" },
    { word: "手名", primary: "字・演奏法", synonymous: ["字", "演奏法"], group: "other" },
    { word: "手習ひ", primary: "習字・心に浮かぶ歌などを書き流すこと", synonymous: ["習字", "心に浮かぶ歌などを書き流すこと"], group: "other" },
    { word: "と", primary: "あのように", synonymous: ["あのように"], group: "other" },
    { word: "とが〔咎・科〕", primary: "欠点・罪", synonymous: ["欠点", "罪"], group: "other" },
    { word: "とかく", primary: "あれこれと", synonymous: ["あれこれと"], group: "other" },
    { word: "ときしもあれ", primary: "ほかに時もあろうに・よりによってこんな時に", synonymous: ["ほかに時もあろうに", "よりによってこんな時に"], group: "other" },
    { word: "ときにあふ", primary: "ちょうどよい時期に出会う・時流に乗って栄える", synonymous: ["ちょうどよい時期に出会う", "時流に乗って栄える"], group: "other" },
    { word: "ときめかす", primary: "寵愛する", synonymous: ["寵愛する"], group: "other" },
    { word: "ときめく〔時めく〕", primary: "寵愛を受ける・栄える", synonymous: ["寵愛を受ける", "栄える"], group: "other" },
    { word: "ところう〔所得〕", primary: "よい地位を得る・得意になる", synonymous: ["よい地位を得る", "得意になる"], group: "other" },
    { word: "ところせし〔所狭し〕", primary: "窮屈だ", synonymous: ["窮屈だ"], group: "other" },
    { word: "とし〔疾し〕", primary: "早い", synonymous: ["早い"], group: "other" },
    { word: "としごろ〔年頃・年比・年来〕", primary: "長年", synonymous: ["長年"], group: "other" },
    { word: "～とはおろかなり", primary: "（～という言葉では）言い尽くせない", synonymous: ["（～という言葉では）言い尽くせない"], group: "other" },
    { word: "とばかり", primary: "ちょっとの間・しばらく", synonymous: ["ちょっとの間", "しばらく"], group: "other" },
    { word: "～とは世の常なり", primary: "（～という言葉では）言い尽くせない", synonymous: ["（～という言葉では）言い尽くせない"], group: "other" },
    { word: "問ふ", primary: "訪ねる", synonymous: ["訪ねる"], group: "other" },
    { word: "とぶらふA〔訪ふ〕", primary: "訪ねる・見舞う", synonymous: ["訪ねる", "見舞う"], group: "other" },
    { word: "とぶらふB〔弔ふ〕", primary: "弔う", synonymous: ["弔う"], group: "other" },
    { word: "とみなり〔頓なり〕", primary: "急だ", synonymous: ["急だ"], group: "other" },
    { word: "とみに", primary: "急に・すぐに", synonymous: ["急に", "すぐに"], group: "other" },
    { word: "ともかくもなる", primary: "死ぬ", synonymous: ["死ぬ"], group: "other" },
    { word: "とりあえず", primary: "すぐに", synonymous: ["すぐに"], group: "other" },
    { word: "な", primary: "あなた", synonymous: ["あなた"], group: "other" },
    { word: "名", primary: "評判", synonymous: ["評判"], group: "other" },
    { word: "な〜そ", primary: "（～する）な・（～し）てはならない", synonymous: ["（～する）な", "（～し）てはならない"], group: "other" },
    { word: "なかなか", primary: "かえって", synonymous: ["かえって"], group: "other" },
    { word: "なかなかかなり〔中々かなり〕", primary: "中途半端だ・かえってしないほうがよい・かえってないほうがましだ", synonymous: ["中途半端だ", "かえってしないほうがよい", "かえってないほうがましだ"], group: "other" },
    { word: "なかなかにお", primary: "かえって", synonymous: ["かえって"], group: "other" },
    { word: "ながむ〔眺む〕", primary: "もの思いに沈む", synonymous: ["もの思いに沈む"], group: "other" },
    { word: "ながむ〔詠む〕", primary: "（漢詩や和歌を）口ずさむ", synonymous: ["（漢詩や和歌を）口ずさむ"], group: "other" },
    { word: "なさけあり", primary: "情趣を解する・道理を解する・思いやりがある", synonymous: ["情趣を解する", "道理を解する", "思いやりがある"], group: "other" },
    { word: "なさけなし", primary: "情趣を解さない・道理を解さない・思いやりがない", synonymous: ["情趣を解さない", "道理を解さない", "思いやりがない"], group: "other" },
    { word: "なじかは", primary: "どうして（～か）", synonymous: ["どうして（～か）"], group: "other" },
    { word: "なぞ〔何ぞ〕", primary: "どうして", synonymous: ["どうして"], group: "other" },
    { word: "なつかし", primary: "親しみ深い", synonymous: ["親しみ深い"], group: "other" },
    { word: "なでふA", primary: "なんという・どのような", synonymous: ["なんという", "どのような"], group: "other" },
    { word: "なでふB", primary: "どうして（反語）", synonymous: ["どうして（反語）"], group: "other" },
    { word: "など", primary: "どうして（～か）", synonymous: ["どうして（～か）"], group: "other" },
    { word: "などか", primary: "どうして（～か）", synonymous: ["どうして（～か）"], group: "other" },
    { word: "などて", primary: "どうして（～か）", synonymous: ["どうして（～か）"], group: "other" },
    { word: "～などもおろかなり", primary: "（～という言葉では）言い尽くせない", synonymous: ["（～という言葉では）言い尽くせない"], group: "other" },
    { word: "～なども世の常なり", primary: "（～という言葉では）言い尽くせない", synonymous: ["（～という言葉では）言い尽くせない"], group: "other" },
    { word: "なに〔何〕", primary: "どうして", synonymous: ["どうして"], group: "other" },
    { word: "名に負ふ", primary: "名前を持つ・有名である", synonymous: ["名前を持つ", "有名である"], group: "other" },
    { word: "なにか〔何か〕", primary: "どうして", synonymous: ["どうして"], group: "other" },
    { word: "なにがし", primary: "だれ", synonymous: ["だれ"], group: "other" },
    { word: "何かせむ", primary: "いったい何になろうか・何にもならない", synonymous: ["いったい何になろうか", "何にもならない"], group: "other" },
    { word: "名にし負ふ", primary: "名前を持つ・有名である", synonymous: ["名前を持つ", "有名である"], group: "other" },
    { word: "なにしに〔何しに〕", primary: "どうして", synonymous: ["どうして"], group: "other" },
    { word: "何にかはせむ", primary: "いったい何になろうか・何にもならない", synonymous: ["いったい何になろうか", "何にもならない"], group: "other" },
    { word: "なのめならず", primary: "並ひととおりではない", synonymous: ["並ひととおりではない"], group: "other" },
    { word: "なのめなり〔斜めなり〕", primary: "並ひととおりだ・いい加減だ・並ひととおりではない", synonymous: ["並ひととおりだ", "いい加減だ", "並ひととおりではない"], group: "other" },
    { word: "なべて", primary: "一般に・並ひととおり", synonymous: ["一般に", "並ひととおり"], group: "other" },
    { word: "なべてならず", primary: "並ひととおりではない", synonymous: ["並ひととおりではない"], group: "other" },
    { word: "なほ〔猶〕", primary: "なんといってもやはり・それでもやはり", synonymous: ["なんといってもやはり", "それでもやはり"], group: "other" },
    { word: "なほざりなり", primary: "本気でない・いい加減だ", synonymous: ["本気でない", "いい加減だ"], group: "other" },
    { word: "なまめかし", primary: "上品だ・若々しい", synonymous: ["上品だ", "若々しい"], group: "other" },
    { word: "なまめく", primary: "落ち着いて上品だ・若くみずみずしい", synonymous: ["落ち着いて上品だ", "若くみずみずしい"], group: "other" },
    { word: "なめし", primary: "無礼だ", synonymous: ["無礼だ"], group: "other" },
    { word: "なやむ〔悩む〕", primary: "病気になる", synonymous: ["病気になる"], group: "other" },
    { word: "ならひ〔慣らひ〕", primary: "習慣", synonymous: ["習慣"], group: "other" },
    { word: "ならふ〔慣らふ・馴らふ〕", primary: "慣れる・なじむ", synonymous: ["慣れる", "なじむ"], group: "other" },
    { word: "なれ", primary: "あなた", synonymous: ["あなた"], group: "other" },
    { word: "なんぢ", primary: "あなた", synonymous: ["あなた"], group: "other" },
    { word: "なんでう・何条A", primary: "なんという・どのような", synonymous: ["なんという", "どのような"], group: "other" },
    { word: "なんでう・何条B", primary: "どうして（反語）", synonymous: ["どうして（反語）"], group: "other" },
    { word: "なんでふA", primary: "なんという・どのような", synonymous: ["なんという", "どのような"], group: "other" },
    { word: "なんでふB", primary: "どうして（反語）", synonymous: ["どうして（反語）"], group: "other" },
    { word: "にくし", primary: "気にくわない・いやだ", synonymous: ["気にくわない", "いやだ"], group: "other" },
    { word: "二なし", primary: "この上もない", synonymous: ["この上もない"], group: "other" },
    { word: "鈍色", primary: "美しく落ち着いた色つや・香り", synonymous: ["美しく落ち着いた色つや", "香り"], group: "other" },
    { word: "にほひ", primary: "美しい色つや・香り", synonymous: ["美しい色つや", "香り"], group: "other" },
    { word: "にほふ〔匂ふ〕", primary: "美しく映える", synonymous: ["美しく映える"], group: "other" },
    { word: "ねたし〔妬し〕", primary: "くやしい", synonymous: ["くやしい"], group: "other" },
    { word: "音に泣く", primary: "声を上げて泣く", synonymous: ["声を上げて泣く"], group: "other" },
    { word: "ねぶ", primary: "年をとる・大人びる", synonymous: ["年をとる", "大人びる"], group: "other" },
    { word: "ねむごろなり〔懇ろなり〕", primary: "心を込めている・親密だ", synonymous: ["心を込めている", "親密だ"], group: "other" },
    { word: "音を泣く", primary: "声を上げて泣く", synonymous: ["声を上げて泣く"], group: "other" },
    { word: "ねんごろなり〔懇ろなり〕", primary: "心を込めている・親密だ", synonymous: ["心を込めている", "親密だ"], group: "other" },
    { word: "ねんず〔念ず〕", primary: "我慢する", synonymous: ["我慢する"], group: "other" },
    { word: "～のがり", primary: "～のもとへ", synonymous: ["～のもとへ"], group: "other" },
    { word: "のたまはす〔宣はす〕", primary: "おっしゃる", synonymous: ["おっしゃる"], group: "other" },
    { word: "のたまふ〔宣ふ〕", primary: "おっしゃる", synonymous: ["おっしゃる"], group: "other" },
    { word: "ののしる", primary: "大声で騒ぐ・評判になる・羽振りをきかす", synonymous: ["大声で騒ぐ", "評判になる", "羽振りをきかす"], group: "other" },
    { word: "はかなくなる", primary: "死ぬ", synonymous: ["死ぬ"], group: "other" },
    { word: "はかなし", primary: "頼りない・ちょっとしたことだ", synonymous: ["頼りない", "ちょっとしたことだ"], group: "other" },
    { word: "はかばかし", primary: "しっかりしている・はっきりしている", synonymous: ["しっかりしている", "はっきりしている"], group: "other" },
    { word: "はかる", primary: "企てる・だます", synonymous: ["企てる", "だます"], group: "other" },
    { word: "～ばこそあらめ", primary: "～ならともかく（実際はそうではない）", synonymous: ["～ならともかく（実際はそうではない）"], group: "other" },
    { word: "はしたなし", primary: "（いたたまれないほど）そっけない・激しい・きまり悪い", synonymous: ["（いたたまれないほど）そっけない", "激しい", "きまり悪い"], group: "other" },
    { word: "はしたなむ", primary: "恥ずかしい思いをさせる", synonymous: ["恥ずかしい思いをさせる"], group: "other" },
    { word: "はた", primary: "また・やはり", synonymous: ["また", "やはり"], group: "other" },
    { word: "はづかし〔恥づかし〕", primary: "立派だ", synonymous: ["立派だ"], group: "other" },
    { word: "はべり〔侍り〕", primary: "（貴人の側に）お仕え申し上げる・あります・～（でござい）ます", synonymous: ["（貴人の側に）お仕え申し上げる", "あります", "～（でござい）ます"], group: "other" },
    { word: "はらから〔同胞〕", primary: "兄弟", synonymous: ["兄弟"], group: "other" },
    { word: "ひがこと・ひがごと〔僻事〕", primary: "間違い", synonymous: ["間違い"], group: "other" },
    { word: "ひがひがし", primary: "ひねくれている・風流心がない", synonymous: ["ひねくれている", "風流心がない"], group: "other" },
    { word: "日暮らし", primary: "一日中", synonymous: ["一日中"], group: "other" },
    { word: "ひごろ〔日頃〕", primary: "数日（の間）", synonymous: ["数日（の間）"], group: "other" },
    { word: "人となる", primary: "一人前になる・正気にする・正気に戻る", synonymous: ["一人前になる", "正気にする", "正気に戻る"], group: "other" },
    { word: "一日", primary: "一日中", synonymous: ["一日中"], group: "other" },
    { word: "ひとやりならず", primary: "他人のせいで（ある）・自分のせいで（ある）", synonymous: ["他人のせいで（ある）", "自分のせいで（ある）"], group: "other" },
    { word: "ひとわろし〔人悪し〕", primary: "みっともない", synonymous: ["みっともない"], group: "other" },
    { word: "ひねもす〔終日〕", primary: "一日中", synonymous: ["一日中"], group: "other" },
    { word: "日一日", primary: "一日中", synonymous: ["一日中"], group: "other" },
    { word: "ひま〔隙・暇〕", primary: "すき間・合間", synonymous: ["すき間", "合間"], group: "other" },
    { word: "びんなし〔便無し〕", primary: "不都合だ・気の毒だ", synonymous: ["不都合だ", "気の毒だ"], group: "other" },
    { word: "経", primary: "（時間が）たつ・（場所を）通る", synonymous: ["（時間が）たつ", "（場所を）通る"], group: "other" },
    { word: "ふびんなり〔不便なり〕", primary: "不都合だ・気の毒だ", synonymous: ["不都合だ", "気の毒だ"], group: "other" },
    { word: "文・書", primary: "手紙・漢詩", synonymous: ["手紙", "漢詩"], group: "other" },
    { word: "ふるさと〔古里・故郷〕", primary: "なじみの土地・（家を離れた人にとって）わが家", synonymous: ["なじみの土地", "（家を離れた人にとって）わが家"], group: "other" },
    { word: "ほい〔本意〕", primary: "かねてからの願い", synonymous: ["かねてからの願い"], group: "other" },
    { word: "本意なし", primary: "残念だ", synonymous: ["残念だ"], group: "other" },
    { word: "ほだし〔絆〕", primary: "障害となるもの", synonymous: ["障害となるもの"], group: "other" },
    { word: "ほど〔程〕", primary: "ころ・広さ・身分・様子", synonymous: ["ころ", "広さ", "身分", "様子"], group: "other" },
    { word: "まうく〔設く〕", primary: "用意する", synonymous: ["用意する"], group: "other" },
    { word: "まうけ", primary: "用意・もてなし", synonymous: ["用意", "もてなし"], group: "other" },
    { word: "まうけの君", primary: "皇太子", synonymous: ["皇太子"], group: "other" },
    { word: "申す", primary: "申し上げる・（お）～申し上げる", synonymous: ["申し上げる", "（お）～申し上げる"], group: "other" },
    { word: "まうづ〔詣づ〕", primary: "参上する", synonymous: ["参上する"], group: "other" },
    { word: "まかう〔罷う〕", primary: "（貴所から）退出する", synonymous: ["（貴所から）退出する"], group: "other" },
    { word: "まかる〔罷る〕", primary: "（貴所から）退出する", synonymous: ["（貴所から）退出する"], group: "other" },
    { word: "まこと〔真〕", primary: "真実", synonymous: ["真実"], group: "other" },
    { word: "まさなし", primary: "よくない", synonymous: ["よくない"], group: "other" },
    { word: "まします", primary: "いらっしゃる・～（て）いらっしゃる", synonymous: ["いらっしゃる", "～（て）いらっしゃる"], group: "other" },
    { word: "ます", primary: "いらっしゃる・～（て）いらっしゃる", synonymous: ["いらっしゃる", "～（て）いらっしゃる"], group: "other" },
    { word: "まだき", primary: "早くも", synonymous: ["早くも"], group: "other" },
    { word: "またし", primary: "完全だ", synonymous: ["完全だ"], group: "other" },
    { word: "まだし〔未し〕", primary: "まだ早い", synonymous: ["まだ早い"], group: "other" },
    { word: "又なし", primary: "この上もない", synonymous: ["この上もない"], group: "other" },
    { word: "またの", primary: "次の", synonymous: ["次の"], group: "other" },
    { word: "まどふ〔惑ふ〕", primary: "迷う・ひどく（～する）", synonymous: ["迷う", "ひどく（～する）"], group: "other" },
    { word: "まねぶ〔学ぶ〕", primary: "まねる・（見聞きした物事をそのまま）伝える", synonymous: ["まねる", "（見聞きした物事をそのまま）伝える"], group: "other" },
    { word: "まばゆし", primary: "まぶしい・（まばゆいほど）美しい・恥ずかしい・見ていられない", synonymous: ["まぶしい", "（まばゆいほど）美しい", "恥ずかしい", "見ていられない"], group: "other" },
    { word: "まほなり", primary: "完全である", synonymous: ["完全である"], group: "other" },
    { word: "まぼる〔守る〕", primary: "見つめる・監視する", synonymous: ["見つめる", "監視する"], group: "other" },
    { word: "〜ままに", primary: "～（する）とすぐに・～ので・～につれて", synonymous: ["～（する）とすぐに", "～ので", "～につれて"], group: "other" },
    { word: "まめなり〔実なり・忠実なり〕", primary: "まじめである・実用的である", synonymous: ["まじめである", "実用的である"], group: "other" },
    { word: "まめまめし", primary: "まじめだ・実用的だ", synonymous: ["まじめだ", "実用的だ"], group: "other" },
    { word: "まめやかなり〔実やかなり・忠実やかなり〕", primary: "まじめである・実用的である", synonymous: ["まじめである", "実用的である"], group: "other" },
    { word: "まもる〔守る〕", primary: "見つめる・監視する", synonymous: ["見つめる", "監視する"], group: "other" },
    { word: "まろ", primary: "このわたし", synonymous: ["このわたし"], group: "other" },
    { word: "参らす", primary: "差し上げる・（お）～申し上げる", synonymous: ["差し上げる", "（お）～申し上げる"], group: "other" },
    { word: "まゐる〔参る〕", primary: "参上する・（貴人に何かをして）差し上げる・召し上がる", synonymous: ["参上する", "（貴人に何かをして）差し上げる", "召し上がる"], group: "other" },
    { word: "御髪下ろす", primary: "出家する", synonymous: ["出家する"], group: "other" },
    { word: "見す", primary: "結婚させる", synonymous: ["結婚させる"], group: "other" },
    { word: "みそかなり〔密かなり〕", primary: "ひそかに", synonymous: ["ひそかに"], group: "other" },
    { word: "みづから〔自ら〕", primary: "わたし・その人自身", synonymous: ["わたし", "その人自身"], group: "other" },
    { word: "身罷る", primary: "死ぬ", synonymous: ["死ぬ"], group: "other" },
    { word: "みめ〔見目〕", primary: "見た目・容貌", synonymous: ["見た目", "容貌"], group: "other" },
    { word: "見ゆ", primary: "見える・思われる・見せる・（女性が）結婚する", synonymous: ["見える", "思われる", "見せる", "（女性が）結婚する"], group: "other" },
    { word: "見る", primary: "思う・（男女の）関係を結ぶ・面倒を見る", synonymous: ["思う", "（男女の）関係を結ぶ", "面倒を見る"], group: "other" },
    { word: "昔の人", primary: "亡くなった人・昔の知人", synonymous: ["亡くなった人", "昔の知人"], group: "other" },
    { word: "むくつけし", primary: "気味が悪い・恐ろしい・無骨だ・ひどい・ひどく", synonymous: ["気味が悪い", "恐ろしい", "無骨だ", "ひどい", "ひどく"], group: "other" },
    { word: "むげなり〔無下なり〕", primary: "ひどい・ひどく", synonymous: ["ひどい", "ひどく"], group: "other" },
    { word: "むすぶA〔結ぶ〕", primary: "できる", synonymous: ["できる"], group: "other" },
    { word: "むすぶB〔掬ぶ〕", primary: "（両手で水などを）すくう", synonymous: ["（両手で水などを）すくう"], group: "other" },
    { word: "むつかる", primary: "不快に思う", synonymous: ["不快に思う"], group: "other" },
    { word: "むなしくなる", primary: "死ぬ", synonymous: ["死ぬ"], group: "other" },
    { word: "むべ〔宜〕", primary: "なるほど", synonymous: ["なるほど"], group: "other" },
    { word: "むべなり〔宜なり〕", primary: "もっともだ", synonymous: ["もっともだ"], group: "other" },
    { word: "めざまし〔目覚まし〕", primary: "気にくわない・すばらしい", synonymous: ["気にくわない", "すばらしい"], group: "other" },
    { word: "召す", primary: "（人を側に）お呼びになる・（物を取り寄せに）お取り寄せになる・お召しになる・お乗りになる", synonymous: ["（人を側に）お呼びになる", "（物を取り寄せに）お取り寄せになる", "お召しになる", "お乗りになる"], group: "other" },
    { word: "めづ〔愛づ〕", primary: "愛する・感嘆する", synonymous: ["愛する", "感嘆する"], group: "other" },
    { word: "めづらし", primary: "すばらしい", synonymous: ["すばらしい"], group: "other" },
    { word: "めでたし", primary: "すばらしい", synonymous: ["すばらしい"], group: "other" },
    { word: "目もあやなり", primary: "まぶしいほど立派だ", synonymous: ["まぶしいほど立派だ"], group: "other" },
    { word: "めやすし〔目安し〕", primary: "（見た目の）感じがよい", synonymous: ["（見た目の）感じがよい"], group: "other" },
    { word: "萌黄", primary: "カバー袖（襲の色目）", synonymous: ["カバー袖（襲の色目）"], group: "other" },
    { word: "もてなす", primary: "振る舞う・取り扱う", synonymous: ["振る舞う", "取り扱う"], group: "other" },
    { word: "もとどり切る", primary: "出家する", synonymous: ["出家する"], group: "other" },
    { word: "求む", primary: "探す", synonymous: ["探す"], group: "other" },
    { word: "物語", primary: "世間話", synonymous: ["世間話"], group: "other" },
    { word: "ものぐるほし", primary: "正気を失ったようだ", synonymous: ["正気を失ったようだ"], group: "other" },
    { word: "ものし", primary: "不快だ・見苦しい", synonymous: ["不快だ", "見苦しい"], group: "other" },
    { word: "ものす〔物す〕", primary: "（ものごとを）する・いらっしゃる", synonymous: ["（ものごとを）する", "いらっしゃる"], group: "other" },
    { word: "ものもおぼえず", primary: "呆然としている", synonymous: ["呆然としている"], group: "other" },
    { word: "百敷", primary: "宮中", synonymous: ["宮中"], group: "other" },
    { word: "やう〔様〕", primary: "様子・理由・方法・～ことには", synonymous: ["様子", "理由", "方法", "～ことには"], group: "other" },
    { word: "やうやう〔漸う〕", primary: "しだいに", synonymous: ["しだいに"], group: "other" },
    { word: "やうやく〔漸く〕", primary: "しだいに", synonymous: ["しだいに"], group: "other" },
    { word: "〜やおそきと", primary: "～（する）とすぐに", synonymous: ["～（する）とすぐに"], group: "other" },
    { word: "やがて", primary: "（ある状態が）そのまま・（時間的に）すぐに", synonymous: ["（ある状態が）そのまま", "（時間的に）すぐに"], group: "other" },
    { word: "やすくなし〔益なし〕", primary: "かいがない・むだだ", synonymous: ["かいがない", "むだだ"], group: "other" },
    { word: "やごとなし", primary: "高貴だ・並々でない", synonymous: ["高貴だ", "並々でない"], group: "other" },
    { word: "やさし〔恥し・優し〕", primary: "優美だ・上品だ・殊勝だ", synonymous: ["優美だ", "上品だ", "殊勝だ"], group: "other" },
    { word: "やすらふ〔休らふ〕", primary: "ためらう・立ち止まる", synonymous: ["ためらう", "立ち止まる"], group: "other" },
    { word: "やす", primary: "質素にする・出家する", synonymous: ["質素にする", "出家する"], group: "other" },
    { word: "やする", primary: "目立たない服装（様子）になる", synonymous: ["目立たない服装（様子）になる"], group: "other" },
    { word: "やはら〔柔ら・和ら〕", primary: "そっと", synonymous: ["そっと"], group: "other" },
    { word: "やむ〔止む〕", primary: "（そのまま）終わる", synonymous: ["（そのまま）終わる"], group: "other" },
    { word: "やむごとなし", primary: "高貴だ・並々でない", synonymous: ["高貴だ", "並々でない"], group: "other" },
    { word: "やや", primary: "しだいに", synonymous: ["しだいに"], group: "other" },
    { word: "やらむかたなし", primary: "（心を）晴らしようがない・どうしようもない", synonymous: ["（心を）晴らしようがない", "どうしようもない"], group: "other" },
    { word: "やらん", primary: "～であろうか", synonymous: ["～であろうか"], group: "other" },
    { word: "やる〔遣る〕", primary: "（物を）送る・～きれない", synonymous: ["（物を）送る", "～きれない"], group: "other" },
    { word: "やる〔破る〕", primary: "破る", synonymous: ["破る"], group: "other" },
    { word: "やるかたなし", primary: "（心を）晴らしようがない・どうしようもない", synonymous: ["（心を）晴らしようがない", "どうしようもない"], group: "other" },
    { word: "やをら〔柔ら・和ら〕", primary: "そっと", synonymous: ["そっと"], group: "other" },
    { word: "やんごとななし", primary: "高貴だ・並々でない", synonymous: ["高貴だ", "並々でない"], group: "other" },
    { word: "ゆかし", primary: "見たい・聞きたい・知りたい・心ひかれる", synonymous: ["見たい", "聞きたい", "知りたい", "心ひかれる"], group: "other" },
    { word: "ゆくりなし", primary: "突然だ", synonymous: ["突然だ"], group: "other" },
    { word: "ゆめ（～打消・禁止）", primary: "決して（～ない）・決して（～するな）", synonymous: ["決して（～ない）", "決して（～するな）"], group: "other" },
    { word: "ゆめゆめ（～打消・禁止）", primary: "決して（～ない）・決して（～するな）", synonymous: ["決して（～ない）", "決して（～するな）"], group: "other" },
    { word: "ゆゆし", primary: "不吉だ・すばらしい・はなはだしく", synonymous: ["不吉だ", "すばらしい", "はなはだしく"], group: "other" },
    { word: "ゆゑ〔故〕", primary: "理由・風情・由緒", synonymous: ["理由", "風情", "由緒"], group: "other" },
    { word: "世", primary: "男女の仲・夫婦の仲", synonymous: ["男女の仲", "夫婦の仲"], group: "other" },
    { word: "用意", primary: "気配り", synonymous: ["気配り"], group: "other" },
    { word: "よし", primary: "身分が高い・教養がある・よい", synonymous: ["身分が高い", "教養がある", "よい"], group: "other" },
    { word: "よし〔由〕", primary: "風情・由緒・手立て・こと", synonymous: ["風情", "由緒", "手立て", "こと"], group: "other" },
    { word: "よしあり", primary: "由緒・教養がある・風情がある", synonymous: ["由緒", "教養がある", "風情がある"], group: "other" },
    { word: "よしづく", primary: "由緒ありげな振る舞いや様子をする", synonymous: ["由緒ありげな振る舞いや様子をする"], group: "other" },
    { word: "よしなし〔由無し〕", primary: "つまらない・関係がない", synonymous: ["つまらない", "関係がない"], group: "other" },
    { word: "よしなしごと", primary: "つまらないこと", synonymous: ["つまらないこと"], group: "other" },
    { word: "よしばむ", primary: "由緒ありげな振る舞いや様子をする", synonymous: ["由緒ありげな振る舞いや様子をする"], group: "other" },
    { word: "世に（～打消）", primary: "まったく（～ない）・（打消を伴わないで）実に", synonymous: ["まったく（～ない）", "（打消を伴わないで）実に"], group: "other" },
    { word: "世にあり", primary: "この世に生きている・世間に認められている", synonymous: ["この世に生きている", "世間に認められている"], group: "other" },
    { word: "世の中", primary: "男女の仲・夫婦の仲", synonymous: ["男女の仲", "夫婦の仲"], group: "other" },
    { word: "よばふ〔呼ばふ〕", primary: "呼び続ける・求婚する", synonymous: ["呼び続ける", "求婚する"], group: "other" },
    { word: "夜一夜", primary: "一晩中", synonymous: ["一晩中"], group: "other" },
    { word: "よも（～打消推量）", primary: "まさか（～ないだろう）", synonymous: ["まさか（～ないだろう）"], group: "other" },
    { word: "夜もすがら", primary: "一晩中", synonymous: ["一晩中"], group: "other" },
    { word: "よろこび〔喜び〕", primary: "（昇進・任官の）お礼・お礼を申し上げること", synonymous: ["（昇進", "任官の）お礼", "お礼を申し上げること"], group: "other" },
    { word: "よろこび申し", primary: "お礼を申し上げること", synonymous: ["お礼を申し上げること"], group: "other" },
    { word: "よろし", primary: "悪くはない・普通だ", synonymous: ["悪くはない", "普通だ"], group: "other" },
    { word: "よろづ〔万〕", primary: "さまざま・何ごとにつけても", synonymous: ["さまざま", "何ごとにつけても"], group: "other" },
    { word: "世を出づ", primary: "出家する", synonymous: ["出家する"], group: "other" },
    { word: "世を厭ふ", primary: "出家する", synonymous: ["出家する"], group: "other" },
    { word: "世を捨つ", primary: "出家する", synonymous: ["出家する"], group: "other" },
    { word: "世を背く", primary: "出家する", synonymous: ["出家する"], group: "other" },
    { word: "世を遁る", primary: "出家する", synonymous: ["出家する"], group: "other" },
    { word: "世を離る", primary: "出家する", synonymous: ["出家する"], group: "other" },
    { word: "らうがはし", primary: "騒がしい・乱雑だ", synonymous: ["騒がしい", "乱雑だ"], group: "other" },
    { word: "らうたげなり", primary: "かわいらしい", synonymous: ["かわいらしい"], group: "other" },
    { word: "らうたし", primary: "かわいい", synonymous: ["かわいい"], group: "other" },
    { word: "らうらうじ〔労労じ〕", primary: "巧みだ・上品だ", synonymous: ["巧みだ", "上品だ"], group: "other" },
    { word: "例ならず", primary: "いつもではない・体調がいつもどおりでない", synonymous: ["いつもではない", "体調がいつもどおりでない"], group: "other" },
    { word: "例の", primary: "いつものように・いつもの", synonymous: ["いつものように", "いつもの"], group: "other" },
    { word: "料", primary: "ため", synonymous: ["ため"], group: "other" },
    { word: "ろく〔禄〕", primary: "ほうび", synonymous: ["ほうび"], group: "other" },
    { word: "わ", primary: "このわたし", synonymous: ["このわたし"], group: "other" },
    { word: "わきがたし", primary: "理解しがたい", synonymous: ["理解しがたい"], group: "other" },
    { word: "わく〔分く〕", primary: "理解する", synonymous: ["理解する"], group: "other" },
    { word: "わざ〔業〕", primary: "こと・葬儀", synonymous: ["こと", "葬儀"], group: "other" },
    { word: "わざと", primary: "わざと・特に・（下に「の」を伴い）正式な", synonymous: ["わざと", "特に", "（下に「の」を伴い）正式な"], group: "other" },
    { word: "わざとならず", primary: "ことさらではない", synonymous: ["ことさらではない"], group: "other" },
    { word: "私", primary: "個人的なこと", synonymous: ["個人的なこと"], group: "other" },
    { word: "わたす", primary: "移す", synonymous: ["移す"], group: "other" },
    { word: "わたる〔渡る〕", primary: "通る・いらっしゃる・～続ける・一面に（～する）", synonymous: ["通る", "いらっしゃる", "～続ける", "一面に（～する）"], group: "other" },
    { word: "わづらふ", primary: "苦しむ・～しかねる", synonymous: ["苦しむ", "～しかねる"], group: "other" },
    { word: "わびし〔侘びし〕", primary: "苦しい", synonymous: ["苦しい"], group: "other" },
    { word: "わぶ〔侘ぶ〕", primary: "困る・嘆く・～かねる", synonymous: ["困る", "嘆く", "～かねる"], group: "other" },
    { word: "わりなし", primary: "ひどい・どうしようもない・苦しい", synonymous: ["ひどい", "どうしようもない", "苦しい"], group: "other" },
    { word: "われ", primary: "このわたし", synonymous: ["このわたし"], group: "other" },
    { word: "われにもあらず", primary: "呆然としている", synonymous: ["呆然としている"], group: "other" },
    { word: "われかひとか", primary: "呆然としている", synonymous: ["呆然としている"], group: "other" },
    { word: "わるし", primary: "よくない", synonymous: ["よくない"], group: "other" },
    { word: "ゐる〔居る〕", primary: "座る・～ている", synonymous: ["座る", "～ている"], group: "other" },
    { word: "ゐる〔率る〕", primary: "連れる", synonymous: ["連れる"], group: "other" },
    { word: "をかし", primary: "すばらしい・滑稽だ", synonymous: ["すばらしい", "滑稽だ"], group: "other" },
    { word: "をこ", primary: "愚かなこと", synonymous: ["愚かなこと"], group: "other" },
    { word: "をこがまし", primary: "ばかばかしい", synonymous: ["ばかばかしい"], group: "other" },
    { word: "をこなり〔痴なり・烏滸なり・尾籠なり〕", primary: "愚かだ・ばかばかしい", synonymous: ["愚かだ", "ばかばかしい"], group: "other" },
    { word: "をさをさ（～打消）", primary: "ほとんど（～ない）", synonymous: ["ほとんど（～ない）"], group: "other" },
    { word: "をさをさし〔長長し〕", primary: "しっかりしている", synonymous: ["しっかりしている"], group: "other" },
    { word: "畏手", primary: "漢字", synonymous: ["漢字"], group: "other" },
    { word: "男になる", primary: "男子が元服して一人前になる", synonymous: ["男子が元服して一人前になる"], group: "other" },
    { word: "女手", primary: "平仮名", synonymous: ["平仮名"], group: "other" },
        ];

        const OUTFIT_PARTS = {
            "束帯": [
                { id: "sokutai_kanmuri", name: "冠 (かんむり)", baseAtk: 5, baseHp: 300, cost: 200 },
                { id: "sokutai_tachi", name: "飾り太刀", baseAtk: 12, baseHp: 150, cost: 350 },
                { id: "sokutai_shaku", name: "笏 (しゃく)", baseAtk: 4, baseHp: 350, cost: 250 }
            ],
            "直衣": [
                { id: "noushi_robe", name: "直衣 (のうし)", baseAtk: 6, baseHp: 500, cost: 300 },
                { id: "noushi_eboshi", name: "烏帽子 (えぼし)", baseAtk: 4, baseHp: 250, cost: 180 },
                { id: "noushi_fan", name: "檜扇 (ひおうぎ)", baseAtk: 5, baseHp: 400, cost: 220 }
            ],
            "十二単": [
                { id: "juni_karaginu", name: "唐衣 (からぎぬ)", baseAtk: 8, baseHp: 550, cost: 320 },
                { id: "juni_mo", name: "裳 (も)", baseAtk: 5, baseHp: 600, cost: 280 },
                { id: "juni_hakama", name: "緋の袴 (ひのはかま)", baseAtk: 6, baseHp: 700, cost: 350 }
            ]
        };

        let state = {
            coins: 1000,
            gems: 100,
            deck: ["ch_000"],
            // ① メイン枠（貴族含む最大10）。10を超えた分の出家回数ぶん、サブ枠が追加される
            subDeck: [],
            ownedUnits: ["ch_000"],
            unitOwnershipCounts: { "ch_000": 1 },
            noble: {
                level: 1,
                gender: "男性",
                outfits: {
                    sokutai_kanmuri: 1, sokutai_tachi: 1, sokutai_shaku: 1,
                    noushi_robe: 1, noushi_eboshi: 1, noushi_fan: 1,
                    juni_karaginu: 1, juni_mo: 1, juni_hakama: 1
                }
            },
            unitLevels: {},
            formations: [],
            unitSpecialLevels: {},
            clearedStages: {},
            wrongWords: [],
            shukkeCount: 0,
            permanentOwned: [],
            shukkePrompted: false,
            worldLevel: 1,
            bossRushBest: 0,
            bossRushClearedLevels: [],
            bossRushRewardClaimed: {},
            bossRushProgress: null,
            dataTransferUsage: { date: '', count: 0 },
            gachaUnlocks: {},
            gachaCounts: {},
            achievements: {},
            achievementWorldClears: {},
            weekdayPoints: { mon:0, tue:0, wed:0, thu:0, fri:0 },
            reviewPoints: 0,
            reviewGachaPityCount: 0,
            gemLotteryDraws: 0,
            settings: { hideBattleSkills: false, hideBattleSynergies: false, learnMode: false, smartphoneMode: false },
            kaguyaCount: 0,
            butsuOwned: false,
            butsuEverOwned: false,
            kenreimoninUsed: {},
            pvpPoints: 0,
            pvpTitles: 0
        };

        let bossRushState = null;

        let activeOutfitCategory = "束帯";
        let battleState = { active: false };
        let shukkePromptedThisSession = false;
        let quizQueue = [];
        let kogoQueue = [];
        let currentQuizQuestion = null;
        const QUIZ_BALANCE_STATE = {
            normal: { recentWords: [], recentGroups: [] },
            kogo: { recentWords: [], recentGroups: [] },
            pvpNormal: { recentWords: [], recentGroups: [] },
            pvpKogo: { recentWords: [], recentGroups: [] }
        };

        function quizBalanceBucket(isKogo, isPvp) {
            if (isPvp) return isKogo ? QUIZ_BALANCE_STATE.pvpKogo : QUIZ_BALANCE_STATE.pvpNormal;
            return isKogo ? QUIZ_BALANCE_STATE.kogo : QUIZ_BALANCE_STATE.normal;
        }
        function quizPushRecent(arr, value, maxLen) {
            if (!value) return;
            arr.push(value);
            while (arr.length > maxLen) arr.shift();
        }
        function quizQuestionKey(q) {
            if (!q) return '';
            return [q.word || '', q.primary || '', q.kogoMode ? 'k' : 'n'].join('||');
        }
        function quizPctFromText(text, fallback) {
            const s = String(text || '');
            const m = s.match(/(\d+)\s*%/);
            if (m) return parseInt(m[1], 10) || fallback || 0;
            if (/倍増|2倍/.test(s)) return 100;
            if (/特大/.test(s)) return 45;
            if (/大幅|大きく/.test(s)) return 30;
            if (/やや/.test(s)) return 12;
            return fallback || 0;
        }
        function pickBalancedQuizQuestion(pool, bucket) {
            if (!pool || !pool.length) return null;
            const recentWords = new Set((bucket && bucket.recentWords) || []);
            const groupWeights = {};
            ((bucket && bucket.recentGroups) || []).forEach(g => {
                groupWeights[g] = (groupWeights[g] || 0) + 1;
            });
            const ranked = pool
                .filter(Boolean)
                .map(q => {
                    const group = q.group || 'other';
                    const key = quizQuestionKey(q);
                    let score = (groupWeights[group] || 0) * 6;
                    if (recentWords.has(key)) score += 1000;
                    if (!q.primary) score += 500;
                    score += Math.random() * 3;
                    return { q, score };
                })
                .sort((a, b) => a.score - b.score);
            const top = ranked.slice(0, Math.min(12, ranked.length));
            const picked = (top[Math.floor(Math.random() * top.length)] || ranked[0] || {}).q || null;
            if (picked && bucket) {
                quizPushRecent(bucket.recentWords, quizQuestionKey(picked), 18);
                quizPushRecent(bucket.recentGroups, picked.group || 'other', 8);
            }
            return picked;
        }
        function buildQuizChoicesFromPool(currentQuestion, pool) {
            const targetAnswer = currentQuestion.primary;
            const invalidDistractors = new Set([targetAnswer, ...(currentQuestion.synonymous || [])]);
            const group = currentQuestion.group || 'other';
            const scored = [];
            (pool || []).forEach(wordObj => {
                if (!wordObj || !wordObj.primary) return;
                if (wordObj.word === currentQuestion.word && !currentQuestion.kogoMode) return;
                if (invalidDistractors.has(wordObj.primary)) return;
                let score = 0;
                if ((wordObj.group || 'other') === group) score += 4;
                score += Math.random() * 3;
                scored.push({ value: wordObj.primary, score });
            });
            scored.sort((a, b) => a.score - b.score);
            const uniqueDistractors = [];
            const used = new Set([targetAnswer]);
            scored.forEach(item => {
                if (uniqueDistractors.length >= 5) return;
                if (used.has(item.value)) return;
                used.add(item.value);
                uniqueDistractors.push(item.value);
            });
            const allChoices = [targetAnswer, ...uniqueDistractors].sort(() => Math.random() - 0.5);
            return { targetAnswer, allChoices };
        }

