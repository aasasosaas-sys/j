        // ============================================================
        // ① 構成の保存・読み込み・削除（最大5個・名前付き）
        // ============================================================
        function renderFormationSlots() {
            const container = document.getElementById("formationSlotsContainer");
            if (!container) return;
            __PERF.setHTML(container, "");
            const list = state.formations || [];
            if (list.length === 0) {
                __PERF.setHTML(container, `<span class="text-gray-500 col-span-full">保存された構成はありません。「現在の編成を保存」で最大5構成まで名前付きで保存できます。</span>`);
                return;
            }
            list.forEach((f, idx) => {
                const names = (f.units || []).map(uid => { const u = getUnit(uid); return u ? (u.gender === '女性' ? '♀' : u.gender === '男性' ? '♂' : '') + u.name : "?"; }).join("・");
                const card = document.createElement("div");
                card.className = "bg-heian-purple/30 border border-heian-gold/40 rounded-lg p-2 flex flex-col gap-1";
                __PERF.setHTML(card, `
                    <div class="font-bold text-amber-300 text-[11px] truncate" title="${(f.name || "").replace(/"/g, '&quot;')}"><i class="fa-solid fa-bookmark mr-1"></i>${f.name}</div>
                    <div class="text-[9px] text-gray-300 leading-snug min-h-[1.2rem]">${names || "空"}</div>
                    <div class="flex gap-1 mt-1">
                        <button onclick="loadFormation(${idx})" class="flex-1 bg-amber-600 hover:bg-amber-500 text-black font-bold py-1 rounded text-[10px]">読込</button>
                        <button onclick="deleteFormation(${idx})" class="flex-1 bg-red-900/70 hover:bg-red-800 text-red-200 font-bold py-1 rounded text-[10px]">削除</button>
                    </div>
                `);
                container.appendChild(card);
            });
        }

        function promptSaveFormation() {
            const current = state.deck.slice();
            const currentSub = (Array.isArray(state.subDeck) ? state.subDeck.slice() : []);
            if (current.length === 0) {
                showCustomAlert("編成が空です", "保存するには先にキャラクターを編成してください。");
                return;
            }
            if ((state.formations || []).length >= 5) {
                showCustomAlert("保存枠が上限です", "既に5個の構成が保存されています。不要な構成を削除してから保存してください。");
                return;
            }
            const used = new Set((state.formations || []).map(f => f.name));
            let name = "構成1";
            for (let i = 1; i <= 20; i++) { if (!used.has(`構成${i}`)) { name = `構成${i}`; break; } }
            showCustomNamePrompt("構成の名前を入力（最大12文字）", name, (finalName) => {
                const nm = (finalName || "").trim();
                if (!nm) { showCustomAlert("名前が空です", "構成の名前を入力してください。"); return; }
                state.formations = state.formations || [];
                state.formations.push({ name: nm.slice(0, 12), units: current, subUnits: currentSub });
                saveState();
                renderFormationSlots();
                showCustomAlert("構成を保存しました", `「${nm.slice(0, 12)}」を保存しました。`);
            });
        }

        function loadFormation(idx) {
            const f = (state.formations || [])[idx];
            if (!f) return;
            const validUnits = (Array.isArray(f.units) ? f.units : []).filter(uid => state.ownedUnits.includes(uid));
            if (validUnits.length === 0) {
                showCustomAlert("読み込めません", "この構成のキャラクターを所持していません。");
                return;
            }
            state.deck = validUnits.slice();
            ensureNobleFixedDeck();
            const validSubUnits = (Array.isArray(f.subUnits) ? f.subUnits : [])
                .filter(uid => uid !== "ch_000" && state.ownedUnits.includes(uid) && !state.deck.includes(uid));
            state.subDeck = validSubUnits.slice(0, getMaxSubDeckSize());
            saveState();
            renderDeckView();
            showCustomAlert("構成を読み込みました", `「${f.name}」の編成を適用しました。`);
        }

        function deleteFormation(idx) {
            showCustomConfirm("構成を削除", "この構成を削除しますか？この操作は取り消せません。", () => {
                (state.formations || []).splice(idx, 1);
                saveState();
                renderFormationSlots();
            });
        }

        function showCustomNamePrompt(title, defaultValue, onOk) {
            const overlay = document.createElement("div");
            overlay.className = "fixed inset-0 bg-black/85 z-[60] flex items-center justify-center p-3";
            __PERF.setHTML(overlay, `
                <div class="bg-heian-card max-w-sm w-full rounded-xl heian-border-gold p-5 text-center shadow-2xl">
                    <div class="font-mincho text-lg font-bold gold-gradient-text mb-3">${title}</div>
                    <input id="formationNameInput" type="text" maxlength="12" value="${defaultValue.replace(/"/g, '&quot;')}" class="w-full bg-black/70 border border-heian-gold/50 rounded-lg px-3 py-2 text-sm text-yellow-100 focus:outline-none focus:border-heian-gold" />
                    <div class="mt-4 flex justify-center gap-3">
                        <button id="formationNameOkBtn" class="gold-button px-5 py-1.5 rounded text-xs">保存</button>
                        <button id="formationNameCancelBtn" class="bg-gray-700 hover:bg-gray-600 px-4 py-1.5 rounded text-xs text-gray-200">キャンセル</button>
                    </div>
                </div>
            `);
            document.body.appendChild(overlay);
            const input = document.getElementById("formationNameInput");
            input.focus();
            input.select();
            const cleanup = () => { if (overlay.parentNode) overlay.parentNode.removeChild(overlay); };
            document.getElementById("formationNameOkBtn").onclick = () => { const v = input.value; cleanup(); onOk(v); };
            document.getElementById("formationNameCancelBtn").onclick = cleanup;
            input.addEventListener("keydown", (e) => { if (e.key === "Enter") { const v = input.value; cleanup(); onOk(v); } });
        }

        function renderDeckView() {
            ensureNobleFixedDeck();
            const combinedDeckIds = getCombinedBattleDeckIds();
            // ★自チーム戦闘力の実数値化: シナジー・パッシブスキル・必殺技を反映した
            // 実戦同期の有効値を単一ソース（computePartyBattlePower）から取得
            const battlePowerData = computePartyBattlePower(state.deck, Array.isArray(state.subDeck) ? state.subDeck : []);
            const totalHp = battlePowerData.effHp;
            const totalAtk = battlePowerData.effAtk;
            const powerScore = battlePowerData.power;

            document.getElementById("deckTotalHp").textContent = totalHp.toLocaleString();
            document.getElementById("deckTotalAtk").textContent = totalAtk.toLocaleString();
            document.getElementById("deckPowerScore").textContent = powerScore.toLocaleString();

            const activeSynergies = getActiveSynergiesForDeck(combinedDeckIds);
            document.getElementById("deckActiveSynergyCount").textContent = activeSynergies.length;
            document.getElementById("deckUnitCount").textContent = combinedDeckIds.length;

            // Render Deck Slots（貴族の固定枠＋出家回数に応じた自由編成枠）
            const slotsContainer = document.getElementById("deckSlotsContainer");
            __PERF.setHTML(slotsContainer, "");
            const currentMaxDeck = getMaxDeckSize();
            const subMax = getMaxSubDeckSize();

            for (let i = 0; i < currentMaxDeck; i++) {
                const uid = state.deck[i];
                const slot = document.createElement("div");

                if (uid) {
                    const unit = getUnit(uid);
                    const st = getUnitStats(uid);
                    const specLvl = (uid !== 'ch_000' && state.unitSpecialLevels[uid]) ? state.unitSpecialLevels[uid] : 1;

                    slot.className = "bg-heian-card p-2 rounded-xl border border-heian-gold/60 flex flex-col items-center text-center cursor-pointer hover:border-red-500 transition shadow relative group";
                    slot.onclick = () => toggleDeckUnit(uid);

                    __PERF.setHTML(slot, `
                        <span class="text-[9px] ${unit.rarity === '神' ? 'rarity-god' : 'bg-amber-500 text-black'} font-extrabold px-1 rounded mb-1">${unit.rarity}</span>
                        <div class="w-10 h-10 rounded-full bg-heian-purple border border-heian-gold flex items-center justify-center text-heian-gold text-lg mb-1">
                            <i class="fa-solid ${unit.icon}"></i>
                        </div>
                        <div class="font-mincho text-xs font-bold text-yellow-100 truncate w-full">${unit.name} ${genderMark(unit)}</div>
                        <div class="text-[9px] text-gray-300 font-mono mt-0.5">HP ${st.hp} / ATK ${st.atk}</div>
                        <div class="text-[8px] text-cyan-300 font-bold mt-1 bg-black/60 p-1 rounded w-full text-left border border-cyan-500/20">
                            <div class="truncate text-cyan-300 font-bold"><i class="fa-solid fa-sparkles mr-0.5"></i>${unit.skill ? unit.skill.name : 'スキルなし'}</div>
                            <div class="text-[7px] text-gray-300 line-clamp-2 leading-tight mt-0.5 font-normal">${unit.skill ? unit.skill.effect : '効果なし'}</div>
                        </div>
                        <div class="text-[8px] text-amber-300 font-bold mt-1 bg-black/60 p-1 rounded w-full text-left border border-amber-500/20">
                            <div class="truncate text-amber-300 font-bold"><i class="fa-solid fa-wand-magic-sparkles mr-0.5"></i>${unit.special_move ? unit.special_move.name : '秘技'} (Lv.${specLvl})</div>
                            <div class="text-[7px] text-gray-300 line-clamp-2 leading-tight mt-0.5 font-normal">${unit.special_move ? unit.special_move.effect : '効果なし'}</div>
                        </div>
                        <div class="absolute inset-0 bg-red-900/80 rounded-xl opacity-0 group-hover:opacity-100 flex items-center justify-center text-white text-xs font-bold transition">
                            解除
                        </div>
                    `);
                } else {
                    slot.className = "bg-black/30 p-2 rounded-xl border-2 border-dashed border-gray-600 flex flex-col items-center justify-center text-gray-500 min-h-[110px]";
                    __PERF.setHTML(slot, `<i class="fa-solid fa-plus text-lg mb-1"></i><span class="text-[10px]">空き枠</span>`);
                }
                slotsContainer.appendChild(slot);
            }

            // ① サブ枠レンダリング: 既存のレイアウトには追加せず、サブ枠数だけ控えめに表示
            if (subMax > 0) {
                const subArr = Array.isArray(state.subDeck) ? state.subDeck : [];
                const subRow = document.createElement("div");
                subRow.className = "col-span-full mt-2 mb-1 flex flex-wrap items-center gap-2 text-[10px] text-amber-300/80";
                __PERF.setHTML(subRow, `<i class="fa-solid fa-layer-group text-amber-400"></i> <span class="font-bold text-amber-200">サブ枠（戦闘画面には非表示／裏で作動）</span> <span class="font-mono">${subArr.length} / ${subMax}</span> <span class="text-gray-400">- 出撃部隊右下に表示／タップで外せます</span>`);
                slotsContainer.appendChild(subRow);
                const arr = state.subDeck || [];
                for (let i = 0; i < subMax; i++) {
                    const uid = arr[i];
                    const sslot = document.createElement("div");
                    if (uid) {
                        const unit = getUnit(uid);
                        const st = getUnitStats(uid);
                        sslot.className = "bg-heian-card/60 p-2 rounded-xl border border-heian-purple/60 flex flex-col items-center text-center cursor-pointer hover:border-amber-500 transition shadow relative group";
                        sslot.onclick = () => toggleSubUnit(uid);
                        __PERF.setHTML(sslot, `
                            <span class="text-[9px] ${unit.rarity === '神' ? 'rarity-god' : 'bg-purple-700 text-purple-100'} font-extrabold px-1 rounded mb-1">${unit.rarity}<i class="fa-solid fa-eye-slash ml-1"></i></span>
                            <div class="w-9 h-9 rounded-full bg-heian-purple border border-heian-purple flex items-center justify-center text-heian-gold text-base mb-1">
                                <i class="fa-solid ${unit.icon}"></i>
                            </div>
                            <div class="font-mincho text-[11px] font-bold text-yellow-100 truncate w-full">${unit.name}</div>
                            <div class="text-[9px] text-gray-300 font-mono mt-0.5">HP ${st.hp} / ATK ${st.atk}</div>
                            <div class="absolute inset-0 bg-red-900/80 rounded-xl opacity-0 group-hover:opacity-100 flex items-center justify-center text-white text-xs font-bold transition">解除</div>
                        `);
                    } else {
                        sslot.className = "bg-black/30 p-2 rounded-xl border-2 border-dashed border-purple-700/50 flex flex-col items-center justify-center text-purple-300/70 min-h-[110px]";
                        __PERF.setHTML(sslot, `<i class="fa-solid fa-eye-slash text-base mb-1"></i><span class="text-[10px]">サブ空き</span>`);
                    }
                    slotsContainer.appendChild(sslot);
                }
            }

            // Render Active Deck Synergies Display
            const activeSynContainer = document.getElementById("activeDeckSynergies");
            if (activeSynContainer) {
                __PERF.setHTML(activeSynContainer, "");

                if (activeSynergies.length === 0) {
                    __PERF.setHTML(activeSynContainer, `<span class="text-gray-400 col-span-2">現在発動しているシナジー効果はありません</span>`);
                } else {
                    activeSynergies.forEach(syn => {
                        const targetsStr = syn.targetUnits.map(u => u.name).join('＆');
                        const effectText = synergyDisplayEffect(syn.sourceUnit, syn.targetUnits, syn);
                        const card = document.createElement("div");
                        card.className = "bg-black/50 p-2 rounded border border-amber-500/40 text-amber-200 flex flex-col gap-0.5";
                        __PERF.setHTML(card, `
                            <div class="font-bold text-xs text-amber-300"><i class="fa-solid fa-bolt mr-1"></i>【${syn.sourceUnit.name} × ${targetsStr}】${syn.title}</div>
                            <div class="text-[10px] text-gray-300">${effectText}</div>
                        `);
                        activeSynContainer.appendChild(card);
                    });
                }
            }

            // Render Owned Character Pool
            const poolContainer = document.getElementById("ownedCharacterPool");
            __PERF.setHTML(poolContainer, "");

            // ① 所持キャラ一覧をレア度順（URが上）で表示
            [...state.ownedUnits].sort((a, b) => {
                const ua = getUnit(a), ub = getUnit(b);
                const ra = ua ? rarityRank(ua.rarity) : 0;
                const rb = ub ? rarityRank(ub.rarity) : 0;
                if (rb !== ra) return rb - ra;
                return state.ownedUnits.indexOf(a) - state.ownedUnits.indexOf(b);
            }).forEach(uid => {
                const unit = getUnit(uid);
                const isSelected = state.deck.includes(uid) || (Array.isArray(state.subDeck) && state.subDeck.includes(uid));
                const st = getUnitStats(uid);

                // Check if this character has potential synergy with currently deck/sub-placed units
                let hasDeckSynergy = false;
                if (!isSelected && unit.synergies) {
                    hasDeckSynergy = unit.synergies.some(syn => {
                        return (syn.target_id && combinedDeckIds.includes(syn.target_id)) ||
                               (syn.target_ids && syn.target_ids.some(tid => combinedDeckIds.includes(tid)));
                    });
                }

                const card = document.createElement("div");
                card.className = `p-2 rounded-xl border flex flex-col items-center text-center cursor-pointer transition relative ${
                    isSelected ? 'bg-heian-purple/60 border-heian-gold opacity-50' : 'bg-black/50 border-heian-purple/60 hover:border-heian-gold'
                }`;
                card.onclick = () => tryAssignDeckOrSub(uid);

                __PERF.setHTML(card, `
                    ${hasDeckSynergy ? '<span class="absolute top-1 right-1 text-amber-300 font-extrabold text-xs" title="デッキ内キャラとシナジー発生">⚡</span>' : ''}
                    <span class="text-[9px] ${unit.rarity === '神' ? 'rarity-god' : 'bg-amber-500 text-black'} font-extrabold px-1 rounded mb-1">${unit.rarity}</span>
                    <div class="w-10 h-10 rounded-full bg-heian-purple border border-heian-gold flex items-center justify-center text-heian-gold text-lg mb-1">
                        <i class="fa-solid ${unit.icon}"></i>
                    </div>
                    <div class="font-mincho text-xs font-bold text-yellow-100 truncate w-full">${unit.name} ${genderMark(unit)}</div>
                    <div class="text-[9px] text-gray-300 font-mono mt-0.5">HP ${st.hp} / ATK ${st.atk}</div>
                    <div class="text-[8px] text-cyan-300 mt-1 w-full bg-black/50 p-1 rounded text-left border border-cyan-500/20">
                        <div class="font-bold truncate"><i class="fa-solid fa-sparkles mr-0.5"></i>${unit.skill ? unit.skill.name : 'スキルなし'}</div>
                        <div class="text-[7px] text-gray-300 line-clamp-2 leading-tight mt-0.5">${unit.skill ? unit.skill.effect : '効果なし'}</div>
                    </div>
                    <div class="text-[8px] text-amber-300 mt-1 w-full bg-black/50 p-1 rounded text-left border border-amber-500/20">
                        <div class="font-bold truncate"><i class="fa-solid fa-wand-magic-sparkles mr-0.5"></i>${unit.special_move ? unit.special_move.name : '秘技'}</div>
                        <div class="text-[7px] text-gray-300 line-clamp-2 leading-tight mt-0.5">${unit.special_move ? unit.special_move.effect : '効果なし'}</div>
                    </div>
                `);
                poolContainer.appendChild(card);
            });

            renderFormationSlots();
        }

        function toggleDeckUnit(uid) {
            ensureNobleFixedDeck();
            if (uid === "ch_000") {
                if (isPvpRoomActive()) {
                    // オンライン対戦では貴族を外せる
                    state.deck = state.deck.filter(id => id !== uid);
                    ensureUnitOwnershipCounts();
                    ensureNobleFixedDeck();
                    saveState();
                    renderDeckView();
                    return;
                }
                const freeSlots = getMaxDeckSize() - 1;
                showCustomAlert("貴族は固定枠です", `貴族は常に編成される固定枠です。残り${freeSlots}枠を自由に編成できます。`);
                return;
            }
            if (state.deck.includes(uid)) {
                state.deck = state.deck.filter(id => id !== uid);
            } else {
                if (state.deck.length >= getMaxDeckSize()) {
                    const maxSize = getMaxDeckSize();
                    showCustomAlert("編成枠上限", `貴族の固定枠を含め、出撃部隊は最大${maxSize}体までです。不要なキャラクターを解除してから追加してください。`);
                    return;
                }
                state.deck.push(uid);
            }
            ensureUnitOwnershipCounts();
            ensureNobleFixedDeck();
            saveState();
            renderDeckView();
        }
        // ① サブ枠操作: メイン枠が埋まっている時、こちらに追加される可搬枠。
        function toggleSubUnit(uid) {
            if (uid === "ch_000") return;
            if (!Array.isArray(state.subDeck)) state.subDeck = [];
            if (!state.ownedUnits.includes(uid)) return;
            if (state.deck.includes(uid)) {
                state.deck = state.deck.filter(id => id !== uid);
            } else if (state.subDeck.includes(uid)) {
                state.subDeck = state.subDeck.filter(id => id !== uid);
            } else {
                const subMax = getMaxSubDeckSize();
                if (state.subDeck.length >= subMax) {
                    showCustomAlert("サブ枠上限", `サブ枠は最大${subMax}体までです。不要なキャラを解除してから追加してください。`);
                    return;
                }
                state.subDeck.push(uid);
            }
            saveState();
            renderDeckView();
        }
        // 編成画面でキャラをクリックした時、メイン枠空き→メイン、満杯→サブ枠空き を試行
        function tryAssignDeckOrSub(uid) {
            if (uid === "ch_000") {
                if (isPvpRoomActive()) {
                    // オンライン対戦では貴族を出し入れできる
                    if (state.deck.includes(uid)) {
                        state.deck = state.deck.filter(id => id !== uid);
                    } else if (state.deck.length < getMaxDeckSize()) {
                        state.deck.push(uid);
                    }
                    ensureNobleFixedDeck();
                    saveState(); renderDeckView(); return;
                }
                const freeSlots = getMaxDeckSize() - 1;
                showCustomAlert("貴族は固定枠です", `貴族は常に編成される固定枠です。残り${freeSlots}枠を自由に編成できます。`);
                return;
            }
            // すでに入っている場合は外す（メイン／サブ両対応）
            if (state.deck.includes(uid)) {
                state.deck = state.deck.filter(id => id !== uid);
                saveState(); renderDeckView(); return;
            }
            if (state.subDeck && state.subDeck.includes(uid)) {
                state.subDeck = state.subDeck.filter(id => id !== uid);
                saveState(); renderDeckView(); return;
            }
            // メイン枠に空きがあればメインへ
            if (state.deck.length < getMaxDeckSize()) {
                state.deck.push(uid);
                saveState(); renderDeckView(); return;
            }
            // メイン満杯→サブ枠に空きがあればサブへ
            const subMax = getMaxSubDeckSize();
            if ((state.subDeck || []).length < subMax) {
                if (!Array.isArray(state.subDeck)) state.subDeck = [];
                state.subDeck.push(uid);
                saveState(); renderDeckView(); return;
            }
            showCustomAlert("編成枠上限", `メイン・サブ枠がいっぱいです。移籍するには、先にいずれかを解除してください。`);
        }

        // ④ シナジー図鑑などから複数キャラをまとめてパーティへ追加（上限・重複・未所持をガード）
        function addUnitsToDeck(ids) {
            ensureNobleFixedDeck();
            const maxSize = getMaxDeckSize();
            const added = [];
            ids.forEach(id => {
                if (id === "ch_000" || !state.ownedUnits.includes(id)) return;
                if (state.deck.includes(id)) return;
                if (state.deck.length >= maxSize) return;
                state.deck.push(id);
                added.push(id);
            });
            if (added.length === 0) {
                const ownedIds = ids.filter(id => id !== "ch_000" && state.ownedUnits.includes(id));
                if (ownedIds.length > 0 && ownedIds.every(id => state.deck.includes(id))) {
                    showCustomAlert("編成済み", "このシナジーに関わる所持キャラは全てパーティに編成済みです。");
                } else if (state.deck.length >= maxSize) {
                    showCustomAlert("編成枠上限", `出撃部隊は最大${maxSize}体までです。不要なキャラクターを解除してから追加してください。`);
                } else {
                    showCustomAlert("追加できません", "未所持のキャラクターが含まれているため追加できません。");
                }
                return;
            }
            ensureNobleFixedDeck();
            saveState();
            renderDeckView();
            showCustomAlert("パーティに追加", `${added.map(id => { const u = getUnit(id); return u ? u.name : id; }).join("・")} をパーティに追加しました！`);
        }

        function autoBuildSynergyDeck() {
            ensureNobleFixedDeck();
            const includeNoble = !isPvpRoomActive() || (Array.isArray(state.deck) ? state.deck : []).includes("ch_000");
            const mainSlots = Math.max(0, getMaxDeckSize() - 1);
            const owned = [...new Set((state.ownedUnits || []).filter(id => id !== "ch_000" && !!getUnit(id)))];
            if (mainSlots <= 0 || owned.length === 0) {
                state.deck = includeNoble ? ["ch_000"] : [];
                saveState();
                renderDeckView();
                showCustomAlert("おまかせ編成完了", "編成可能な所持キャラがいないため、貴族のみの編成にしました。");
                return;
            }
            if (owned.length <= mainSlots) {
                state.deck = (includeNoble ? ["ch_000"] : []).concat(owned.slice(0, mainSlots));
                ensureNobleFixedDeck();
                saveState();
                renderDeckView();
                showCustomAlert("おまかせ編成完了", `所持キャラをすべて編成しました（シナジー ${getActiveSynergiesForDeck(state.deck).length} 個）。`);
                return;
            }

            const ownedSet = new Set(owned);
            const potentialScore = (id) => {
                const u = getUnit(id);
                if (!u) return -1;
                const syn = (u.synergies || []).reduce((sum, s) => {
                    if (s.target_id) return sum + (ownedSet.has(s.target_id) ? 1 : 0);
                    if (Array.isArray(s.target_ids) && s.target_ids.every(tid => ownedSet.has(tid))) return sum + s.target_ids.length;
                    return sum;
                }, 0);
                const lv = Math.max(1, Math.floor(Number((state.unitLevels || {})[id]) || 1));
                return syn * 1000 + rarityRank(u.rarity) * 100 + lv;
            };

            const candidateLimit = Math.min(16, Math.max(mainSlots + 6, mainSlots));
            const candidates = owned.slice().sort((a, b) => potentialScore(b) - potentialScore(a)).slice(0, candidateLimit);
            const k = Math.min(mainSlots, candidates.length);
            let bestDeck = candidates.slice(0, k);
            let maxSynergies = getActiveSynergiesForDeck(["ch_000", ...bestDeck]).length;
            const picked = [];
            const n = candidates.length;

            function dfs(start) {
                if (picked.length === k) {
                    const combo = ["ch_000", ...picked];
                    const count = getActiveSynergiesForDeck(combo).length;
                    if (count > maxSynergies) {
                        maxSynergies = count;
                        bestDeck = picked.slice();
                    }
                    return;
                }
                if (picked.length + (n - start) < k) return;
                for (let i = start; i < n; i++) {
                    picked.push(candidates[i]);
                    dfs(i + 1);
                    picked.pop();
                }
            }
            dfs(0);

            state.deck = (includeNoble ? ["ch_000"] : []).concat(bestDeck.filter(id => id !== "ch_000"));
            ensureNobleFixedDeck();
            saveState();
            renderDeckView();
            showCustomAlert("おまかせ編成完了", `所持キャラ内で最も多くのシナジー（${maxSynergies}個）が発動する候補を高速探索し、自動構成しました！`);
        }

        // ⑥ 貴族の性別を自由に変更（UI配置・設定はそのまま、性別データのみ追加）
        function setNobleGender(g) {
            if (g !== '男性' && g !== '女性') return;
            state.noble.gender = g;
            if (g === '女性') { activeOutfitCategory = '十二単'; }
            else if (activeOutfitCategory === '十二単') { activeOutfitCategory = '束帯'; }
            saveState();
            renderHeader();
            renderGrowthView();
            setOutfitCategory(activeOutfitCategory);
        }

        function setOutfitCategory(cat) {
            activeOutfitCategory = cat;
            ["束帯", "直衣", "十二単"].forEach(c => {
                const btn = document.getElementById(`outfit-tab-${c}`);
                if (btn) {
                    if (c === cat) {
                        btn.className = "flex-1 py-1 px-1 bg-amber-600 text-black font-bold rounded";
                    } else {
                        btn.className = "flex-1 py-1 px-1 bg-heian-purple text-gray-300 rounded hover:text-white";
                    }
                }
            });
            renderGrowthView();
        }

        function renderGrowthView() {
            const rankInfo = getNobleRankInfo(state.noble.level);
            document.getElementById("nobleLevelBadge").textContent = `Lv.${state.noble.level}`;
            document.getElementById("nobleRankDisplay").textContent = `位階: ${rankInfo.rankStr}`;
            ['男性','女性'].forEach(g => {
                const b = document.getElementById('noble-gender-' + g);
                if (b) b.className = (state.noble.gender === g) ? 'flex-1 py-1 px-1 bg-amber-600 text-black font-bold rounded' : 'flex-1 py-1 px-1 bg-heian-purple text-gray-300 rounded hover:text-white';
            });

            // Outfit Parts List
            const partsContainer = document.getElementById("outfitPartsContainer");
            __PERF.setHTML(partsContainer, "");

            const parts = OUTFIT_PARTS[activeOutfitCategory] || [];
            parts.forEach(part => {
                const lvl = state.noble.outfits[part.id] || 1;
                const cost = part.cost * lvl;

                const row = document.createElement("div");
                row.className = "p-2 rounded bg-black/60 border border-heian-purple/60 flex justify-between items-center text-xs";
                __PERF.setHTML(row, `
                    <div>
                        <div class="font-bold text-yellow-100">${part.name} <span class="text-amber-400 font-mono">Lv.${lvl}</span></div>
                        <div class="text-[10px] text-gray-300">追加HP +${Math.floor(part.baseHp * 0.50 * Math.max(0, lvl - 1))} / ATK +${Math.floor(part.baseAtk * (1 + 0.45 * Math.max(0, lvl - 1)))}</div>
                    </div>
                    <button onclick="upgradeOutfit('${part.id}', ${cost})" class="gold-button px-2.5 py-1 rounded text-[10px] shrink-0">
                        強化 (${cost}文)
                    </button>
                `);
                partsContainer.appendChild(row);
            });

            // Gacha Units Growth List
            const growthContainer = document.getElementById("characterGrowthList");
            __PERF.setHTML(growthContainer, "");

            // ③ 育成一覧はパーティ編成中のキャラを優先して上に表示（次いでレア度順）
            [...state.ownedUnits].filter(id => id !== "ch_000").sort((a, b) => {
                const inA = state.deck.includes(a), inB = state.deck.includes(b);
                if (inA !== inB) return inA ? -1 : 1;
                const ua = getUnit(a), ub = getUnit(b);
                const ra = ua ? rarityRank(ua.rarity) : 0;
                const rb = ub ? rarityRank(ub.rarity) : 0;
                if (rb !== ra) return rb - ra;
                return state.ownedUnits.indexOf(a) - state.ownedUnits.indexOf(b);
            }).forEach(uid => {
                const unit = getUnit(uid);
                const statLvl = state.unitLevels[uid] || 1;
                const specLvl = Math.min(50, state.unitSpecialLevels[uid] || 1);

                const statCost = 150 * statLvl;
                const specCost = specLvl >= 50 ? 0 : 300 * specLvl;
                const st = getUnitStats(uid);

                const card = document.createElement("div");
                card.className = "p-3 rounded-xl bg-black/50 border border-heian-purple/60 flex flex-col justify-between";
                __PERF.setHTML(card, `
                    <div>
                        <div class="flex justify-between items-start mb-1">
                            <span class="font-mincho font-bold text-yellow-100 text-sm flex items-center gap-1.5">
                                <i class="fa-solid ${unit.icon} text-amber-400"></i> ${unit.name} ${genderMark(unit)}
                            </span>
                            <span class="text-[10px] ${unit.rarity === '神' ? 'rarity-god' : 'bg-amber-500 text-black'} font-black px-1.5 py-0.5 rounded">${unit.rarity}</span>
                        </div>
                        <div class="text-[10px] text-gray-300 font-mono mb-1.5">HP: ${st.hp} / ATK: ${st.atk}</div>
                        <div class="bg-black/60 p-1.5 rounded border border-amber-500/30 mb-2 text-left">
                            <div class="text-[10px] font-bold text-amber-300 flex items-center gap-1">
                                <i class="fa-solid fa-wand-magic-sparkles"></i> 必殺技: ${unit.special_move ? unit.special_move.name : '秘技'} <span class="text-amber-400 font-mono">(Lv.${specLvl})</span>
                            </div>
                            <div class="text-[9px] text-gray-300 mt-0.5 leading-snug">${unit.special_move ? unit.special_move.effect : '効果なし'}</div>
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-2 mt-1 pt-2 border-t border-heian-purple/40">
                        <button onclick="upgradeUnitLevel('${uid}', ${statCost})" class="bg-purple-900/80 hover:bg-purple-800 text-purple-200 border border-purple-400/40 p-1.5 rounded text-[10px] font-bold text-center">
                            ステータス強化 (Lv.${statLvl})<br><span class="text-amber-300 font-mono">${statCost}文</span>
                        </button>
                        <button ${specLvl >= 50 ? 'disabled' : `onclick="upgradeUnitSpecial('${uid}', ${specCost})"`} class="bg-amber-900/80 ${specLvl >= 50 ? 'opacity-60 cursor-not-allowed' : 'hover:bg-amber-800'} text-amber-200 border border-amber-400/40 p-1.5 rounded text-[10px] font-bold text-center">
                            必殺技強化 (Lv.${specLvl})<br><span class="text-amber-300 font-mono">${specLvl >= 50 ? 'MAX' : specCost + '文'}</span>
                        </button>
                    </div>
                `);
                growthContainer.appendChild(card);
            });
        }

        function upgradeOutfit(partId, cost) {
            if (state.coins < cost) {
                showCustomAlert("銭不足", "強化に必要な銭が足りません。合戦に勝利して銭を獲得しましょう！");
                return;
            }
            state.coins -= cost;
            state.noble.outfits[partId] = (state.noble.outfits[partId] || 1) + 1;
            state.noble.level += 1;
            saveState();
            renderHeader();
            renderGrowthView();
        }

        function upgradeUnitLevel(uid, cost) {
            if (state.coins < cost) {
                showCustomAlert("銭不足", "強化に必要な銭が足りません。");
                return;
            }
            state.coins -= cost;
            state.unitLevels[uid] = (state.unitLevels[uid] || 1) + 1;
            saveState();
            renderHeader();
            renderGrowthView();
        }

        function upgradeUnitSpecial(uid, cost) {
            const currentLv = Math.min(50, state.unitSpecialLevels[uid] || 1);
            if (currentLv >= 50) {
                showCustomAlert("必殺技強化上限", "必殺技レベルは Lv.50 が上限です。");
                return;
            }
            const actualCost = 300 * currentLv;
            if (state.coins < actualCost) {
                showCustomAlert("銭不足", "強化に必要な銭が足りません。");
                return;
            }
            state.coins -= actualCost;
            state.unitSpecialLevels[uid] = Math.min(50, currentLv + 1);
            saveState();
            renderHeader();
            renderGrowthView();
        }

        function renderSynergyView() {
            const container = document.getElementById("synergyListContainer");
            __PERF.setHTML(container, "");

            ALL_GACHA_CHARACTERS().forEach(unit => {
                if (!unit.synergies || unit.synergies.length === 0) return;

                unit.synergies.forEach(syn => {
                    let targets = [];
                    if (syn.target_id) {
                        const targetUnit = getUnit(syn.target_id);
                        if (targetUnit) targets.push(targetUnit);
                    } else if (syn.target_ids) {
                        syn.target_ids.forEach(tid => {
                            const targetUnit = getUnit(tid);
                            if (targetUnit) targets.push(targetUnit);
                        });
                    }

                    const isSourceOwned = state.ownedUnits.includes(unit.id);
                    const areTargetsOwned = targets.every(t => state.ownedUnits.includes(t.id));
                    const isFullyOwned = isSourceOwned && areTargetsOwned;

                    const card = document.createElement("div");
                    card.className = `p-3 rounded-xl border ${
                        isFullyOwned ? 'bg-heian-card/90 border-heian-gold/60' : 'bg-black/40 border-heian-purple/40 opacity-60'
                    } flex flex-wrap justify-between items-center gap-3`;
                    // ④ シナジー図鑑のカードをタップでパーティへ自動追加
                    card.style.cursor = "pointer";
                    card.title = "タップでパーティに追加";
                    card.onclick = () => addUnitsToDeck([unit.id, ...targets.map(t => t.id)]);

                    const targetsStr = targets.map(t => `<span class="text-amber-300 font-bold">${synergyDisplayName(t)}</span>`).join(' ＆ ');
                    const effectText = synergyDisplayEffect(unit, targets, syn);

                    __PERF.setHTML(card, `
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-full bg-heian-purple border border-heian-gold flex items-center justify-center text-heian-gold text-lg shrink-0">
                                <i class="fa-solid ${unit.icon}"></i>
                            </div>
                            <div>
                                <div class="font-mincho font-bold text-sm text-yellow-100">
                                    【${synergyDisplayName(unit)} × ${targetsStr}】 <span class="text-amber-400 font-sans text-xs ml-1">${syn.title}</span>
                                </div>
                                <div class="text-xs text-gray-300 mt-0.5">${syn.effect}</div>
                            </div>
                        </div>
                        <div>
                            ${isFullyOwned ? 
                                '<span class="bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-bold px-2 py-1 rounded">解放済</span>' : 
                                '<span class="bg-gray-800 text-gray-400 text-[10px] px-2 py-1 rounded">未所持キャラ有り</span>'
                            }
                        </div>
                    `);
                    container.appendChild(card);
                });
            });
        }


