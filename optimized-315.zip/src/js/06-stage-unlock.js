        // ============================================================
        // ステージ・ダンジョン解放判定
        // ダンジョンNは前ダンジョン全制覇で、ステージkは直前ステージの
        // クリアで解放（セーブデータは既存の clearedStages をそのまま利用）
        // ============================================================
        function isDungeonFullyCleared(id) {
            const dung = DUNGEONS_DATA.find(d => d.id === id);
            return !!dung && dung.stages.length > 0 && dung.stages.every(s => !!state.clearedStages[s.id]);
        }
        function isNewGachaUnlocked(bannerId) {
            const banner = NEW_GACHA_BANNERS[bannerId];
            if (!banner) return false;
            const unlocked = isDungeonFullyCleared(banner.unlockDungeon);
            if (unlocked) state.gachaUnlocks[bannerId] = true;
            return unlocked || state.gachaUnlocks[bannerId] === true;
        }

        function isDungeonUnlocked(id) {
            if (id === 1) return true;
            if (WEEKDAY_DUNGEON_IDS.indexOf(id) >= 0) {
                const weekdayKey = getWeekdayKeyByDungeonNum(id);
                const dayList = getWeekdayDungeonListByKey(weekdayKey);
                const localIdx = dayList.indexOf(id);
                if (localIdx <= 0) return true;
                return isDungeonFullyCleared(dayList[localIdx - 1]);
            }
            const prev = DUNGEONS_DATA.find(d => d.id === id - 1);
            if (!prev) return true;
            return prev.stages.every(s => !!state.clearedStages[s.id]);
        }

        function isStageUnlocked(stageId) {
            const dungNum = parseInt(stageId.substring(1, 3)) || 1;
            if (!isDungeonUnlocked(dungNum)) return false;
            const stageNum = parseInt(stageId.split("_s")[1]) || 1;
            if (stageNum <= 1) return true;
            const prevId = `d${String(dungNum).padStart(2, "0")}_s${String(stageNum - 1).padStart(2, "0")}`;
            return !!state.clearedStages[prevId];
        }

        function renderDungeonsView() {
            const grid = document.getElementById("dungeonGrid");
            __PERF.setHTML(grid, "");

            // ⑤ 本編タブには通常ダンジョン（1〜30）のみ表示
            DUNGEONS_DATA.filter(dung => !isWeekdayDungeon(dung.id)).forEach(dung => {
                let clearedInDungeon = dung.stages.filter(stg => state.clearedStages[stg.id]).length;
                let isFullyCleared = clearedInDungeon === dung.stages.length;
                const progressPct = Math.round((clearedInDungeon / dung.stages.length) * 100);
                const stars = Math.min(5, 1 + Math.floor(dung.id / 6));
                const pal = DUNGEON_PALETTES[dung.id % DUNGEON_PALETTES.length];
                const isUnlocked = isDungeonUnlocked(dung.id);

                const card = document.createElement("div");
                card.className = `dungeon-card p-4 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between relative ${
                    isFullyCleared ? 'dungeon-card-clear' : 'dungeon-card-normal'
                } ${isUnlocked ? '' : 'dungeon-card-locked'}`;
                card.style.background = `linear-gradient(160deg, ${pal[0]}cc, ${pal[1]}e6)`;
                card.onclick = isUnlocked
                    ? () => openStageModal(dung.id)
                    : () => showCustomAlert("ダンジョン未開放", "前のダンジョンを全て制覇すると解放されます！");

                __PERF.setHTML(card, `
                    <div class="flex items-start justify-between mb-2 relative z-10">
                        <span class="dungeon-badge">ダンジョン ${dung.id}</span>
                        <span class="dungeon-stars" title="難易度">${'★'.repeat(stars)}${'☆'.repeat(5 - stars)}</span>
                    </div>
                    <div class="flex items-center gap-3 relative z-10">
                        <div class="dungeon-medal">
                            <i class="fa-solid ${dung.icon || 'fa-scroll'} text-sm"></i>
                        </div>
                        <div class="min-w-0">
                            <h3 class="font-mincho font-bold text-sm text-yellow-100 leading-snug">${dung.title}</h3>
                            <div class="text-[10px] text-amber-300/90 font-mono mt-1"><i class="fa-solid fa-bolt mr-1 text-[9px]"></i>推定戦闘力: ${getStageRecommendedPower(dung.id, 1).toLocaleString()}〜${getStageRecommendedPower(dung.id, dung.stages.length).toLocaleString()}</div>
                        </div>
                    </div>
                    <div class="mt-3 relative z-10">
                        <div class="flex justify-between text-[10px] text-gray-300 mb-1">
                            <span>討伐進行度</span>
                            <span class="font-mono font-bold text-amber-300">${clearedInDungeon} / ${dung.stages.length} <span class="text-green-400">(${progressPct}%)</span></span>
                        </div>
                        <div class="w-full h-2 bg-black/50 rounded-full overflow-hidden border border-heian-gold/30">
                            <div class="h-full rounded-full dungeon-progress-bar transition-all duration-500" style="width:${progressPct}%"></div>
                        </div>
                    </div>
                    <div class="mt-3 pt-2 border-t border-white/10 flex justify-between items-center text-xs text-gray-200 relative z-10">
                        <span>全${dung.stages.length}ステージ</span>
                        ${isUnlocked
                            ? `<span class="font-bold text-heian-gold"><i class="fa-solid fa-circle-play mr-1"></i>出撃する</span>`
                            : `<span class="font-bold text-gray-400"><i class="fa-solid fa-lock mr-1"></i>未開放</span>`}
                    </div>
                    ${isFullyCleared ? '<div class="dungeon-seal">完 全 制 覇</div>' : ''}
                    ${isUnlocked ? '' : '<div class="dungeon-lock-seal"><i class="fa-solid fa-lock"></i></div>'}
                `);
                grid.appendChild(card);
            });
        }

        // ⑤ 曜日ダンジョン専用タブの表示（本編と同じカードUI・宝石100消費の案内付き）
        function renderWeekdayDungeonsView() {
            const grid = document.getElementById("weekdayDungeonGrid");
            if (!grid) return;
            __PERF.setHTML(grid, "");
            const todayLabel = document.getElementById('todayWeekdayLabel');
            if (todayLabel) todayLabel.textContent = getTodayWeekdayLabel();
            const todayIds = TODAY_WEEKDAY_IDS || [];
            if (todayIds.length === 0) {
                const closed = document.createElement('div');
                closed.className = 'col-span-full bg-black/50 border-2 border-heian-gold/40 rounded-2xl p-8 text-center';
                __PERF.setHTML(closed, `<div class="text-4xl mb-3"><i class="fa-solid fa-moon text-pink-300"></i></div><h3 class="font-mincho text-xl font-bold text-pink-200 mb-2">本日は曜日ダンジョンのお休みです</h3><p class="text-xs text-gray-300">曜日ダンジョンは毎週月曜〜金曜の開催です。明日の開門をお楽しみに！</p>`);
                grid.appendChild(closed);
                return;
            }

            DUNGEONS_DATA.filter(dung => isWeekdayDungeon(dung.id) && todayIds.indexOf(dung.id) >= 0).forEach(dung => {
                let clearedInDungeon = dung.stages.filter(stg => state.clearedStages[stg.id]).length;
                let isFullyCleared = clearedInDungeon === dung.stages.length;
                const progressPct = Math.round((clearedInDungeon / dung.stages.length) * 100);
                const stars = Math.min(5, 1 + Math.floor(dung.id / 6));
                const pal = DUNGEON_PALETTES[dung.id % DUNGEON_PALETTES.length];
                const isUnlocked = isDungeonUnlocked(dung.id);

                const card = document.createElement("div");
                card.className = `dungeon-card p-4 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between relative ${
                    isFullyCleared ? 'dungeon-card-clear' : 'dungeon-card-normal'
                } ${isUnlocked ? '' : 'dungeon-card-locked'}`;
                card.style.background = `linear-gradient(160deg, ${pal[0]}cc, ${pal[1]}e6)`;
                card.onclick = isUnlocked
                    ? () => openStageModal(dung.id)
                    : () => showCustomAlert("ダンジョン未開放", "前のダンジョンを全て制覇すると解放されます！");

                __PERF.setHTML(card, `
                    <div class="flex items-start justify-between mb-2 relative z-10">
                        <span class="dungeon-badge">曜日 ${dung.id}</span>
                        <span class="dungeon-stars" title="難易度">${'★'.repeat(stars)}${'☆'.repeat(5 - stars)}</span>
                    </div>
                    <div class="flex items-center gap-3 relative z-10">
                        <div class="dungeon-medal">
                            <i class="fa-solid ${dung.icon || 'fa-calendar-day'} text-sm"></i>
                        </div>
                        <div class="min-w-0">
                            <h3 class="font-mincho font-bold text-sm text-yellow-100 leading-snug">${dung.title}</h3>
                            <div class="text-[10px] text-amber-300/90 font-mono mt-1"><i class="fa-solid fa-bolt mr-1 text-[9px]"></i>推定戦闘力: ${getStageRecommendedPower(dung.id, 1).toLocaleString()}〜${getStageRecommendedPower(dung.id, dung.stages.length).toLocaleString()}</div>
                        </div>
                    </div>
                    <div class="mt-3 relative z-10">
                        <div class="flex justify-between text-[10px] text-gray-300 mb-1">
                            <span>討伐進行度</span>
                            <span class="font-mono font-bold text-amber-300">${clearedInDungeon} / ${dung.stages.length} <span class="text-green-400">(${progressPct}%)</span></span>
                        </div>
                        <div class="w-full h-2 bg-black/50 rounded-full overflow-hidden border border-heian-gold/30">
                            <div class="h-full rounded-full dungeon-progress-bar transition-all duration-500" style="width:${progressPct}%"></div>
                        </div>
                    </div>
                    <div class="mt-3 pt-2 border-t border-white/10 flex justify-between items-center text-xs text-gray-200 relative z-10">
                        <span>全${dung.stages.length}ステージ / 宝玉${100}消費</span>
                        ${isUnlocked
                            ? `<span class="font-bold text-heian-gold"><i class="fa-solid fa-circle-play mr-1"></i>出撃する</span>`
                            : `<span class="font-bold text-gray-400"><i class="fa-solid fa-lock mr-1"></i>未開放</span>`}
                    </div>
                    ${isFullyCleared ? '<div class="dungeon-seal">完 全 制 覇</div>' : ''}
                    ${isUnlocked ? '' : '<div class="dungeon-lock-seal"><i class="fa-solid fa-lock"></i></div>'}
                `);
                grid.appendChild(card);
            });
        }

        function openStageModal(dungeonId) {
            const dung = DUNGEONS_DATA.find(d => d.id === dungeonId);
            if (!dung) return;
            const container = document.getElementById("stageListContainer");

            // ★軽量改修: 同一ダンジョン・同一クリア状況なら前回の描画HTMLを再利用し、
            // ステージノードの再構築（createElement × ステージ数）をスキップする。
            const _stageModalClearedKey = dung.stages.map(s => (state.clearedStages[s.id] ? "1" : "0")).join("");
            const _stageModalKey = "d" + dung.id + "|w" + getWorldLevelMult() + "|" + _stageModalClearedKey;
            if (window.__stageModalCache && window.__stageModalCache[_stageModalKey]) {
                document.getElementById("stageModalDungeonTitle").textContent = dung.title;
                container.innerHTML = window.__stageModalCache[_stageModalKey];
                // ★修正: innerHTML復元では node.onclick（JSプロパティ）が失われるため、
                // キャッシュ再利用時は data-stage-id から必ずクリック処理を再バインドする
                // （これがないと退出・敗北後の再戦でステージを選んでも反応しない）
                container.querySelectorAll('.stage-node').forEach((nd) => {
                    const sid = nd.getAttribute('data-stage-id');
                    if (!sid) return;
                    const idx = dung.stages.findIndex(s => s.id === sid);
                    if (idx < 0) return;
                    const stgObj = dung.stages[idx];
                    const unlocked = isStageUnlocked(sid);
                    nd.onclick = unlocked
                        ? () => openStageExplain(dung, stgObj)
                        : () => showCustomAlert("ステージ未開放", `${idx > 0 ? dung.stages[idx - 1].name : '前のステージ'}をクリアすると解放されます。`);
                });
                document.getElementById("stageSelectModal").classList.remove("hidden");
                return;
            }
            if (!window.__stageModalCache) window.__stageModalCache = {};

            document.getElementById("stageModalDungeonTitle").textContent = dung.title;
            __PERF.setHTML(container, "");

            // 一覧ヘッダー（討伐状況・推奨戦闘力）
            const clearedCount = dung.stages.filter(s => state.clearedStages[s.id]).length;
            const header = document.createElement("div");
            header.className = "mb-3 p-3 rounded-xl bg-black/50 border border-heian-gold/40 flex flex-wrap items-center justify-between gap-2";
            __PERF.setHTML(header, `
                <div class="text-xs text-gray-300">
                    <i class="fa-solid fa-scroll mr-1 text-amber-400"></i>全${dung.stages.length}ステージ ・ 討伐済み <span class="text-green-400 font-bold">${clearedCount}</span>
                </div>
                <div class="text-[10px] text-amber-300 font-mono"><i class="fa-solid fa-bolt mr-1"></i>推定戦闘力 ${getStageRecommendedPower(dung.id, 1).toLocaleString()}〜${getStageRecommendedPower(dung.id, dung.stages.length).toLocaleString()}</div>
            `);
            container.appendChild(header);

            // ステージをノード式グリッドで表示（本物のゲームのステージ選択風）
            const nodeGrid = document.createElement("div");
            nodeGrid.className = "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5";

            dung.stages.forEach((stgObj, idx) => {
                const isCleared = !!state.clearedStages[stgObj.id];
                const isUnlocked = isStageUnlocked(stgObj.id);
                const node = document.createElement("div");
                node.className = `stage-node p-3 pt-5 rounded-xl border-2 flex flex-col items-center text-center cursor-pointer transition relative ${isCleared ? 'stage-node-clear' : ''} ${isUnlocked ? '' : 'stage-node-locked'}`;
                node.setAttribute("data-stage-id", stgObj.id); // ★修正: キャッシュ再利用時にも再バインドできるようIDを保持
                node.onclick = isUnlocked
                    ? () => openStageExplain(dung, stgObj)
                    : () => showCustomAlert("ステージ未開放", `${idx > 0 ? dung.stages[idx - 1].name : '前のステージ'}をクリアすると解放されます。`);
                __PERF.setHTML(node, `
                    <span class="stage-node-num">${idx + 1}</span>
                    <i class="fa-solid ${stgObj.icon || 'fa-scroll'} text-lg my-1 stage-node-icon"></i>
                    <span class="font-mincho text-xs font-bold text-yellow-100 leading-tight">${stgObj.name}</span>
                    <span class="text-[9px] text-amber-300/90 font-mono mt-1"><i class="fa-solid fa-bolt mr-0.5 text-[8px]"></i>推奨 ${getStageRecommendedPower(dung.id, idx + 1).toLocaleString()}</span>
                    <span class="text-[9px] mt-1.5 font-bold px-2 py-0.5 rounded-full ${isCleared ? 'text-green-400 bg-green-900/40 border border-green-500/40' : isUnlocked ? 'text-gray-500 bg-black/40 border border-gray-700' : 'text-gray-400 bg-black/40 border border-gray-700'}">${isCleared ? '✓ 討伐済' : isUnlocked ? '未攻略' : '🔒 未開放'}</span>
                `);
                nodeGrid.appendChild(node);
            });

            container.appendChild(nodeGrid);
            window.__stageModalCache[_stageModalKey] = container.innerHTML;

            document.getElementById("stageSelectModal").classList.remove("hidden");
        }

