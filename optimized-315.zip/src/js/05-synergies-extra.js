        // ============================================================
        // ★ 追加シナジー（曜日ガチャキャラ×既存キャラ／曜日ガチャ内／神ランク連携）
        //    追加分はすべて既存の addPairSynergy / addMultiSynergy に乗せているため、
        //    戦闘・図鑑・編成UIの既存シナジー判定ロジックをそのまま利用できる
        // ============================================================
        // 【月曜】
        addPairSynergy('末摘花', 'かぐや姫', '月の姫の共鳴', '必殺技威力40%アップ', '月光ダメージと女性の攻撃力アップ');
        addPairSynergy('末摘花', '月読命', '月神の加護', '初期必殺ゲージ大幅増加', '敵の速度低下効果強化');
        addPairSynergy('源範頼', '渡辺綱', '頼光四天王・鬼斬りの系譜', '攻撃力35%アップ', '敵への特効ダメージ付与');
        addPairSynergy('源範頼', '安倍晴明', '京の守護者', '状態異常耐性アップ', '被ダメージ20%軽減');
        addPairSynergy('千手前', '建礼門院', '平家の女房の縁', '回復量アップ', '踏みとどまり効果強化');
        addPairSynergy('賀茂保憲', '月読命', '月の神官', '女性の必殺チャージ加速', '防御力アップ');
        addPairSynergy('建礼門院右京大夫', '紫式部', '日記の記録者たち', '正解時ゲージ獲得量アップ', '弱点ダメージ30%アップ');
        addPairSynergy('小宰相', '和泉式部', '恋歌の双星', '女性の与ダメージ25%アップ', '必殺チャージ短縮');
        addPairSynergy('小宰相', '小野小町', '恋の歌合', '会心ダメージアップ', '混乱成功率アップ');
        addPairSynergy('明遍', '西行', '月夜の行者', '回復量と防御力アップ', '長期戦で攻撃力上昇');
        addPairSynergy('横笛', '藤原定家', '撰集の夜会', '正解ダメージアップ', '必殺技威力アップ');
        addPairSynergy('仏御前', '祇王', '月待ちの宵', 'RキャラのHP20%アップ', 'すばやさ15%アップ');
        // 【火曜】
        addPairSynergy('源為朝', '平清盛', '火の覇者', '攻撃力35%アップ', '敵の防御力低下');
        addPairSynergy('源為朝', '須佐之男命', '荒ぶる神火', '会心ダメージアップ', '序盤30秒の攻撃爆発');
        addPairSynergy('平教経', '平敦盛', '平家の若武者', '被ダメージ20%軽減', '回復量アップ');
        addPairSynergy('千手前', '巴御前', '木曾軍の双璧', '女性の会心率・速度アップ', '女性の攻撃力20%アップ');
        addPairSynergy('かぐや姫の侍女', 'かぐや姫', '竹取の衣', '防御力アップ', '状態異常耐性アップ');
        addPairSynergy('源為朝', '源義経', '剛弓と八艘飛び', '単体火力35%アップ', '会心発生率アップ');
        addPairSynergy('千手前', '源義経', '母と子の絆', 'HP上限アップ', '被ダメージ20%軽減');
        addPairSynergy('千手前', '静御前', '乱世の女人', '女性の与ダメージアップ', 'すばやさアップ');
        addPairSynergy('源氏の郎等', '渡辺綱', '羅生門の後日譚', 'Rキャラの攻撃力25%アップ', '攻撃ミス無効化率上昇');
        addPairSynergy('建礼門院右京大夫', '和泉式部', '恋の灯火', '女性の必殺チャージ加速', '継続ダメージ強化');
        addPairSynergy('平家の童', '那須の郎等', '火遊びの童たち', 'Rキャラのすばやさアップ', 'SRキャラの会心率アップ');
        // 【水曜】
        addPairSynergy('石作皇子', '末摘花', '水鏡月影・双璧', '回避率と会心率アップ', '必殺チャージ加速');
        addPairSynergy('龍神', '蜻蛉の女', '龍神と海女', '回復量と防御力アップ', '被ダメージ軽減');
        addPairSynergy('花散里（水影）', '紫式部（若紫）', '紫の系譜', '弱点ダメージ35%アップ', '必殺技威力アップ');
        addPairSynergy('源重之（水琴）', '大伴家持', '万葉の調べ', '正解ダメージ25%アップ', '必殺チャージ加速');
        addPairSynergy('蜻蛉の女', '浮舟', '水辺の姫君たち', '回避率20%アップ', '回復効果アップ');
        addPairSynergy('宇治の大君（水影）', '浮舟', '宇治の姫・再映', '女性の与ダメージアップ', '被ダメージ軽減');
        addPairSynergy('宇治川の随身', '源博雅', '河原の管弦', '攻撃速度アップ', 'デバフ成功率アップ');
        addPairSynergy('横川の僧', '西行', '自然に遊ぶ行者', '回復量アップ', '状態異常耐性アップ');
        addPairSynergy('浮御殿の女房', '清少納言', 'をかしの泡沫', '会心ダメージアップ', '敵防御無視効果強化');
        addPairSynergy('宇治川の童', '藤原公任', '管弦の童', 'Rキャラの防御力20%アップ', 'スキル威力アップ');
        // 【木曜】
        addPairSynergy('本居宣長', '賀茂真淵', '古語文法の双璧', '正解ダメージ30%アップ', '必殺ゲージ獲得量アップ');
        addPairSynergy('契沖', '本居宣長', '国学の継承', '弱点ダメージ30%アップ', '状態異常耐性アップ');
        addPairSynergy('契沖', '菅原道真', '学問の神髄', '正解時ゲージ増加量アップ', '雷撃必殺の威力アップ');
        addPairSynergy('荷田春満', '小野小町', '歌の才媛たち', '必殺チャージ加速', '会心ダメージアップ');
        addPairSynergy('上田秋成', '清少納言', '文法の機微', 'SRキャラの与ダメージ25%アップ', '敵防御低下効果強化');
        addPairSynergy('大江匡房', '藤原定家（新古今）', '掛詞の妙', '会心率アップ', '正解ダメージアップ');
        addPairSynergy('源経信', '建礼門院右京大夫', '礼儀の蔵人たち', '防御力アップ', '状態異常耐性アップ');
        addPairSynergy('藤原清輔', '菅原道真', '学問の道', 'Rキャラの正解ダメージ20%アップ', 'ゲージ獲得量アップ');
        addPairSynergy('顕昭', '阿倍晴明', '呪文と文法', '状態異常無効確率アップ', '必殺チャージ加速');
        addPairSynergy('頓阿', '紀貫之', '古今集の系譜', 'R/SRの会心率25%アップ', '敵防御低下効果強化');
        // 【金曜】
        addPairSynergy('藤原秀郷', '源頼義', '鏡と幻影の宮', '回避率と会心率アップ', '混乱成功率アップ');
        addPairSynergy('源仲頼', '平知盛', '写し身の覚悟', '被ダメージ25%軽減', '攻撃力アップ');
        addPairSynergy('渡辺綱', '阿倍晴明', '鏡の結界', '状態異常耐性アップ', '呪いの持続ダメージ強化');
        addPairSynergy('平重衡', '源義経', '影と主君', '会心率と速度アップ', '攻撃力アップ');
        addPairSynergy('平重衡', '那須与一', '影の一矢', '単体火力アップ', '会心発生率アップ');
        addPairSynergy('平維盛', '静御前', '反照の舞', '女性のすばやさアップ', '攻撃速度アップ');
        addPairSynergy('源仲綱', '藤原保昌', '隙なき鏡影', '回避率アップ', '攻撃ミス無効化率上昇');
        addPairSynergy('安倍泰親', '兼好法師', '無常の双影', '回復量アップ', 'デバフ耐性アップ');
        addPairSynergy('斎藤実盛', '平維盛', '老将と若武者', 'Rキャラの回避率20%アップ', '被ダメージ軽減');
        addPairSynergy('平貞盛', '滝口入道', '平安武者の夜警', 'Rキャラのすばやさ・会心率アップ', 'RキャラのHPアップ');
        // 【曜日UR×神ランク 複数連携】
        addMultiSynergy('末摘花', ['かぐや姫', '月読命'], '月の姫神連盟', '女性の全ステータスと必殺威力アップ');
        addMultiSynergy('源為朝', ['平清盛', '須佐之男命'], '火の神将', '序盤の攻撃爆発と会心ダメージアップ');
        addMultiSynergy('石作皇子', ['浮舟', '宇治の大君'], '水辺の姫君たち', '女性の回復量と回避率アップ');
        addMultiSynergy('本居宣長', ['菅原道真', '契沖'], '学問の極み', '正解時ゲージと弱点ダメージ大幅アップ');
        addMultiSynergy('藤原秀郷', ['源義経', '平重衡'], '鏡像の武者たち', '会心率と攻撃速度アップ');

        function getBossRushRewardUnit(worldLevel) {
            return BOSS_RUSH_GOD_UNITS[parseInt(worldLevel, 10)] || null;
        }
        function isBossRushGodId(id) {
            return /^br_god_\d{2}$/.test(id || '');
        }
        function getBossRushClearedLevels() {
            return Array.isArray(state.bossRushClearedLevels)
                ? [...new Set(state.bossRushClearedLevels.map(v => parseInt(v, 10)).filter(v => !isNaN(v) && v >= 1 && v <= 10))].sort((a, b) => a - b)
                : [];
        }
        function isBossRushLevelCleared(worldLevel) {
            const lv = parseInt(worldLevel, 10);
            return lv !== 10 && getBossRushClearedLevels().includes(lv);
        }
        function getAvailableBossRushLevels() {
            return Array.from({ length: 10 }, (_, i) => i + 1);
        }
        function normalizeBossRushSelection() {
            const current = parseInt(state.worldLevel, 10);
            if (isNaN(current) || current < 1 || current > 10) state.worldLevel = 1;
        }
        function isBossRushFinalStage(br) {
            return !!br && parseInt(br.round, 10) === 3 && parseInt(br.stage, 10) === 200;
        }
        function grantBossRushReward(worldLevel) {
            const unit = getBossRushRewardUnit(worldLevel);
            if (!unit) return null;
            if (!state.bossRushRewardClaimed || typeof state.bossRushRewardClaimed !== 'object') state.bossRushRewardClaimed = {};
            const key = String(parseInt(worldLevel, 10));
            const alreadyClaimed = !!state.bossRushRewardClaimed[key];
            if (!alreadyClaimed) {
                const isNew = !Array.isArray(state.ownedUnits) || !state.ownedUnits.includes(unit.id);
                grantOwnedUnit(unit.id, isNew ? 1 : 0, true);
                if (!state.unitSpecialLevels || typeof state.unitSpecialLevels !== 'object') state.unitSpecialLevels = {};
                if (!state.unitSpecialLevels[unit.id]) state.unitSpecialLevels[unit.id] = 1;
                state.bossRushRewardClaimed[key] = true;
            }
            return { ...unit, _alreadyClaimed: alreadyClaimed };
        }
        function markBossRushLevelCleared(worldLevel) {
            const lv = parseInt(worldLevel, 10);
            if (isNaN(lv) || lv < 1 || lv > 10) return;
            if (lv !== 10) {
                const merged = new Set(getBossRushClearedLevels());
                merged.add(lv);
                state.bossRushClearedLevels = [...merged].sort((a, b) => a - b);
            }
            normalizeBossRushSelection();
        }
        function getBossRushRunWorldLevel() {
            if (bossRushState && bossRushState.worldLevel) return parseInt(bossRushState.worldLevel, 10) || getWorldLevel();
            return getWorldLevel();
        }
        function playBossRushClearCeremony(worldLevel, rewardUnit, onDone) {
            const lv = parseInt(worldLevel, 10) || 1;
            const unitName = rewardUnit ? rewardUnit.name : '神ランクキャラ';
            const overlay = document.createElement('div');
            overlay.style.position = 'fixed';
            overlay.style.inset = '0';
            overlay.style.zIndex = '9999';
            overlay.style.display = 'flex';
            overlay.style.alignItems = 'center';
            overlay.style.justifyContent = 'center';
            overlay.style.background = 'radial-gradient(circle at center, rgba(251,191,36,0.28) 0%, rgba(91,33,182,0.78) 35%, rgba(0,0,0,0.96) 100%)';
            overlay.style.backdropFilter = 'blur(8px)';
            __PERF.setHTML(overlay, `
                <div style="position:relative;width:min(92vw,760px);padding:34px 28px;border-radius:28px;border:2px solid rgba(253,224,71,0.75);background:linear-gradient(160deg, rgba(88,28,135,0.88), rgba(17,24,39,0.96));box-shadow:0 0 80px rgba(251,191,36,0.38), inset 0 0 30px rgba(255,255,255,0.08);text-align:center;color:#fff;overflow:hidden;">
                    <div style="position:absolute;inset:0;background:repeating-linear-gradient(120deg, transparent 0 18px, rgba(255,255,255,0.03) 18px 36px);opacity:.65;pointer-events:none;"></div>
                    <div style="position:relative">
                        <div style="font-size:14px;letter-spacing:.35em;color:#fde68a;font-weight:900;margin-bottom:10px;">BOSS RUSH COMPLETE</div>
                        <div style="font-size:26px;font-weight:900;color:#fff7cc;margin-bottom:12px;">世界Lv.${lv} 完 全 制 覇</div>
                        <div style="font-size:54px;line-height:1;margin-bottom:10px;filter:drop-shadow(0 0 18px rgba(251,191,36,0.75));">👑</div>
                        <div style="font-size:18px;color:#f9a8d4;font-weight:800;margin-bottom:4px;">神ランク解放</div>
                        <div style="font-size:32px;color:#ffffff;font-weight:900;margin-bottom:8px;">${unitName}</div>
                        <div style="font-size:13px;color:#e5e7eb;line-height:1.8">三周目・200ステージの果てに到達。<br>無限の試練は、いま一つの終わりを示した。</div>
                    </div>
                </div>`);
            document.body.appendChild(overlay);
            setTimeout(() => {
                overlay.style.transition = 'opacity .45s ease';
                overlay.style.opacity = '0';
                setTimeout(() => {
                    if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
                    if (onDone) onDone();
                }, 460);
            }, 2200);
        }

        function getUnit(id) {
            if (id === "butsu_001") return BUTSU_UNIT;
            if (id === "amaterasu_001") return AMATERASU_UNIT;
            if (id === "kaguya_001") return KAGUYA_UNIT;
            if (isBossRushGodId(id)) return BOSS_RUSH_GOD_UNITS[parseInt(id.slice(-2), 10)] || null;
            const weekdayUnit = getWeekdayUnitsFlat().find(u => u.id === id);
            if (weekdayUnit) return weekdayUnit;
            if (id === "ch_000") {
                const rankInfo = getNobleRankInfo(state.noble.level);
                return {
                    id: "ch_000",
                    name: "貴族",
                    gender: state.noble ? (state.noble.gender || "男性") : "男性",
                    rarity: isNobleGodEvolved() ? "神" : "N",
                    icon: "fa-user-ninja",
                    description: "初期キャラクター。位階: " + rankInfo.rankStr,
                    skill: { name: "執念の位階", effect: "毎秒必殺ゲージ+1%" },
                    special_move: { name: "平安貴族の一撃", effect: "敵単体に強烈な打撃を与える" },
                    gaugePerCorrect: 12,
                    gaugeNeedsVotes: 9, synergies: []
                };
            }
            return ALL_GACHA_CHARACTERS().find(u => u.id === id);
        }

        function getUnitStats(id) {
            if (id === "ch_000") {
                // 初期HPは 690 を維持しつつ、装束数の多さで伸びすぎないよう成長率を抑制（微調整: Lv成長170→150 / 装束HP×0.55→0.50 / 装束ATK×0.50→0.45）
                // Lv1時点の強さは維持し、装束の追加強化分（Lv2以降）だけを緩やかに加算する
                let totalHp = 540 + state.noble.level * 150;
                let totalAtk = 26 + state.noble.level * 1;
                for (let cat in OUTFIT_PARTS) {
                    OUTFIT_PARTS[cat].forEach(p => {
                        let lvl = state.noble.outfits[p.id] || 1;
                        totalHp += p.baseHp * 0.50 * Math.max(0, lvl - 1);
                        totalAtk += p.baseAtk * (1 + 0.45 * Math.max(0, lvl - 1));
                    });
                }
                if (isNobleGodEvolved()) {
                    totalHp *= 3.25;
                    totalAtk *= 3.25;
                }
                return { hp: Math.floor(totalHp), atk: Math.floor(totalAtk) };
            }

            const unit = getUnit(id);
            if (!unit) return { hp: 200, atk: 20 };
            // ① 神レア度（かぐや姫・仏・ボスラッシュ神）も自身のレベルで独立成長（下の汎用計算を使用）

            const lvl = state.unitLevels[id] || 1;
            
            // シナジー編成でR/SRも十分活躍できるよう、レア度差をやや緩和
            let rarityMult = 0.90;
            if (unit.rarity === '神') rarityMult = 3.25;
            else if (unit.rarity === 'UR') rarityMult = 2.35;
            else if (unit.rarity === 'SSR') rarityMult = 1.38;
            else if (unit.rarity === 'SR') rarityMult = 1.08;
            else if (unit.rarity === 'R') rarityMult = 0.90;

            return {
                hp: Math.floor((300 + lvl * 700) * rarityMult),
                atk: Math.floor((30 + lvl * 4) * rarityMult)
            };
        }

        // ⑤ キャラの性別を一目で分かるマーク（男性=♂ / 女性=♀）
        function genderMark(unit) {
            if (!unit || !unit.gender) return "";
            return unit.gender === "女性"
                ? '<span class="text-pink-400 font-black" title="女性">♀</span>'
                : '<span class="text-sky-400 font-black" title="男性">♂</span>';
        }

        // ③ 未所持の神キャラはシナジー表示で「？？？」に秘匿する
        function synergyDisplayName(unit) {
            if (!unit) return '？？？';
            if (unit.rarity === '神' && !state.ownedUnits.includes(unit.id)) return '？？？';
            return unit.name;
        }
        function synergyDisplayEffect(sourceUnit, targets, syn) {
            const hiddenMoonBuddha = !state.ownedUnits.includes('butsu_001') && (
                (sourceUnit && sourceUnit.id === 'kaguya_001' && targets.some(t => t && t.id === 'butsu_001')) ||
                (sourceUnit && sourceUnit.id === 'butsu_001' && targets.some(t => t && t.id === 'kaguya_001'))
            );
            if (hiddenMoonBuddha) return '？？？とシナジーが発動されます';
            return syn.effect;
        }

        function getActiveSynergiesForDeck(deckIds) {
            const activeSynergies = [];
            deckIds.forEach(id => {
                const unit = getUnit(id);
                if (!unit || !unit.synergies) return;

                unit.synergies.forEach(syn => {
                    if (syn.target_id && deckIds.includes(syn.target_id)) {
                        const targetUnit = getUnit(syn.target_id);
                        activeSynergies.push({
                            sourceUnit: unit,
                            targetUnits: [targetUnit],
                            title: syn.title,
                            effect: syn.effect
                        });
                    } else if (syn.target_ids && syn.target_ids.every(tid => deckIds.includes(tid))) {
                        const targetUnits = syn.target_ids.map(tid => getUnit(tid));
                        activeSynergies.push({
                            sourceUnit: unit,
                            targetUnits: targetUnits,
                            title: syn.title,
                            effect: syn.effect
                        });
                    }
                });
            });
            return activeSynergies;
        }

        function getCombinedBattleDeckIds() {
            const mainIds = (Array.isArray(state.deck) ? state.deck : []).filter(id => id === "ch_000" || state.ownedUnits.includes(id));
            // ★ オンライン対戦中はサブ枠を除外（ホスト設定の枠数だけが有効）
            if (isPvpRoomActive()) {
                return [...new Set(mainIds)];
            }
            const subIds = (Array.isArray(state.subDeck) ? state.subDeck : []).filter(id => id !== "ch_000" && state.ownedUnits.includes(id));
            return [...new Set([...mainIds, ...subIds])];
        }

        function ensureUnitOwnershipCounts() {
            if (!Array.isArray(state.ownedUnits)) state.ownedUnits = ["ch_000"];
            if (!state.unitOwnershipCounts || typeof state.unitOwnershipCounts !== 'object') state.unitOwnershipCounts = {};
            const counts = state.unitOwnershipCounts;
            counts["ch_000"] = Math.max(1, Math.floor(Number(counts["ch_000"]) || 1));
            state.ownedUnits.forEach(id => {
                if (id !== "ch_000" && !getUnit(id)) return;
                const fallback = (id === "kaguya_001" && (state.kaguyaCount || 0) > 0)
                    ? Math.max(1, Math.floor(Number(state.kaguyaCount) || 1))
                    : 1;
                counts[id] = Math.max(1, Math.floor(Number(counts[id]) || fallback));
            });
            Object.keys(counts).forEach(id => {
                if (id !== "ch_000" && !state.ownedUnits.includes(id)) {
                    delete counts[id];
                    return;
                }
                counts[id] = Math.max(0, Math.floor(Number(counts[id]) || 0));
            });
        }
        function getOwnedUnitCount(id) {
            ensureUnitOwnershipCounts();
            return Math.max(0, Math.floor(Number(state.unitOwnershipCounts[id]) || 0));
        }
        function grantOwnedUnit(id, count = 1, makePermanent = false) {
            if (!id) return 0;
            const addCount = Math.max(0, Math.floor(Number(count) || 0));
            if (!Array.isArray(state.ownedUnits)) state.ownedUnits = ["ch_000"];
            ensureUnitOwnershipCounts();
            if (!state.ownedUnits.includes(id)) state.ownedUnits.push(id);
            if (addCount > 0) state.unitOwnershipCounts[id] = getOwnedUnitCount(id) + addCount;
            else if (!state.unitOwnershipCounts[id]) state.unitOwnershipCounts[id] = 1;
            if (makePermanent) {
                if (!Array.isArray(state.permanentOwned)) state.permanentOwned = [];
                if (!state.permanentOwned.includes(id)) state.permanentOwned.push(id);
            }
            return Math.max(0, Math.floor(Number(state.unitOwnershipCounts[id]) || 0));
        }

        function getTotalStageCount() {
            return DUNGEONS_DATA.reduce((acc, d) => acc + d.stages.length, 0);
        }

        function hasReincarnationUnlock() {
            return !!(state && state.clearedStages && state.clearedStages['d30_s05']);
        }

        function switchTab(tabName) {
            document.querySelectorAll("main > section").forEach(sec => sec.classList.add("hidden"));
            document.querySelectorAll(".nav-btn").forEach(btn => {
                btn.classList.remove("active", "border-heian-gold", "text-heian-gold", "bg-heian-purple/40");
                btn.classList.add("border-transparent", "text-gray-400");
            });

            const activeSec = document.getElementById(`view-${tabName}`);
            const activeBtn = document.getElementById(`nav-${tabName}`);
            if (activeSec) activeSec.classList.remove("hidden");
            if (activeBtn) {
                activeBtn.classList.add("active", "border-heian-gold", "text-heian-gold", "bg-heian-purple/40");
                activeBtn.classList.remove("border-transparent", "text-gray-400");
            }

            if (tabName === "dungeons") renderDungeonsView();
            if (tabName === "weekday") renderWeekdayDungeonsView();
            if (tabName === "deck") renderDeckView();
            if (tabName === "growth") renderGrowthView();
            if (tabName === "synergy") renderSynergyView();
            if (tabName === "dex") renderDexView();
            if (tabName === "bossrush") renderBossRushView();
            if (tabName === "achievements") { renderAchievementsView(); checkAchievements(); }
            if (tabName === "gacha") { renderNewGachaPanels(); showGachaSubtab('base'); }
            if (tabName === "pvp") { try { const _p = document.getElementById('pvpMainTitlePanel'); if (_p) _p.innerHTML = pvpTitlePanelHtml(); } catch (e) {} try { if (window.__pvpEnsure) window.__pvpEnsure(); } catch (e) {} }
        }

        function renderHeader() {
            document.getElementById("coinDisplay").textContent = state.coins.toLocaleString();
            document.getElementById("gemDisplay").textContent = state.gems.toLocaleString();
            
            const rankInfo = getNobleRankInfo(state.noble.level);
            document.getElementById("playerRankBadge").textContent = rankInfo.rankStr;
            document.getElementById("playerLevelText").textContent = `貴族 Lv.${state.noble.level}`;

            const clearedCount = Object.keys(state.clearedStages).length;
            const totalCount = getTotalStageCount();
            const clearedStageCountEl = document.getElementById("clearedStageCount");
            if (clearedStageCountEl) clearedStageCountEl.textContent = clearedCount;
            const totalStageCountEl = document.getElementById("totalStageCount");
            if (totalStageCountEl) totalStageCountEl.textContent = totalCount;

            const wrongCountEl = document.getElementById("wrongWordCount");
            if (wrongCountEl) wrongCountEl.textContent = (state.wrongWords ? state.wrongWords.length : 0);

            // ⑦ 出家バナー: ダンジョン30・ステージ5クリアで表示
            const reincarnationBanner = document.getElementById('reincarnationBanner');
            if (reincarnationBanner) {
                const isReady = hasReincarnationUnlock();
                reincarnationBanner.style.display = isReady ? 'flex' : 'none';
            }
        }

        const DUNGEON_PALETTES = [
            ["#4A2E69", "#1A0F2B"], ["#6B1F3D", "#1B0D18"], ["#1F4E5F", "#0D1A20"],
            ["#5C3A1E", "#221206"], ["#275E4A", "#0D2118"], ["#4A3B7B", "#171030"],
            ["#6B2D5C", "#200F1C"], ["#2D4B6B", "#0D1A29"]
        ];

