        // ============================================================
        // ⑦ データ移行（キャラ・ステージ進行度・お金・宝石のみ）
        // ============================================================
        function openSettingsModal(){ const modal=document.getElementById('settingsModal'); if(modal){ document.getElementById('hideBattleSkillsToggle').checked=!!(state.settings&&state.settings.hideBattleSkills); document.getElementById('hideBattleSynergiesToggle').checked=!!(state.settings&&state.settings.hideBattleSynergies); document.getElementById('learnModeToggle').checked=!!(state.settings&&state.settings.learnMode); document.getElementById('smartphoneModeToggle').checked=!!(state.settings&&state.settings.smartphoneMode); try{var _pnm=document.getElementById('pvpNameInput');if(_pnm){_pnm.value=(function(){try{return localStorage.getItem('kobun_pvp_name')||'';}catch(e){return '';}})();}}catch(e){} modal.classList.remove('hidden'); } }
        function saveSettings(){ state.settings=state.settings||{}; state.settings.hideBattleSkills=document.getElementById('hideBattleSkillsToggle').checked; state.settings.hideBattleSynergies=document.getElementById('hideBattleSynergiesToggle').checked; state.settings.learnMode=document.getElementById('learnModeToggle').checked; state.settings.smartphoneMode=document.getElementById('smartphoneModeToggle').checked; applySmartphoneModeClass(); try{var _pnm=document.getElementById('pvpNameInput');if(_pnm){var _nm=String(_pnm.value||'').trim().slice(0,10)||'プレイヤー';try{localStorage.setItem('kobun_pvp_name',_nm);}catch(e){} if(window.PVPROOT&&PVPROOT.setMyName)PVPROOT.setMyName(_nm);}}catch(e){} saveState(); closeModal('settingsModal'); if(battleState&&battleState.active&&!battleState.reviewMode){ updateBattlePartyUI(); recalculateBattleSynergies(); } applyLearnModeToCurrentExplain(); }
        function applyLearnModeToCurrentExplain(){
            const btn=document.getElementById('stageExplainFightBtn');
            const modal=document.getElementById('stageExplainModal');
            if(!btn||!modal) return;
            if(modal.classList.contains('hidden')) return;
            startLearnModeCountdown();
        }
        let _learnModeTimer=null;
        function startLearnModeCountdown(){
            const btn = document.getElementById('stageExplainFightBtn');
            const txt = document.getElementById('stageExplainFightBtnText');
            if(!btn) return;
            if (_learnModeTimer) { clearInterval(_learnModeTimer); _learnModeTimer = null; }
            const learn = !!(state.settings && state.settings.learnMode);
            if (!learn) { btn.disabled = false; if(txt) txt.textContent = '戦う'; return; }
            btn.disabled = true;
            let sec = 5;
            if(txt) txt.textContent = `戦う (${sec}秒)`;
            _learnModeTimer = setInterval(() => {
                sec--;
                if (sec <= 0) {
                    clearInterval(_learnModeTimer); _learnModeTimer = null;
                    btn.disabled = false;
                    if(txt) txt.textContent = '戦う';
                } else {
                    if(txt) txt.textContent = `戦う (${sec}秒)`;
                }
            }, 1000);
        }
        function _attachLearnModeToExplain(){
            const modal = document.getElementById('stageExplainModal');
            if(!modal || modal._learnObserver) return;
            const obs = new MutationObserver(() => {
                if(!modal.classList.contains('hidden')) startLearnModeCountdown();
            });
            obs.observe(modal, { attributes: true, attributeFilter: ['class'] });
            modal._learnObserver = obs;
        }

        function getTodayTransferKey() {
            const now = new Date();
            const y = now.getFullYear();
            const m = String(now.getMonth() + 1).padStart(2, '0');
            const d = String(now.getDate()).padStart(2, '0');
            return `${y}-${m}-${d}`;
        }
        function getDataTransferUsage() {
            if (!state.dataTransferUsage || typeof state.dataTransferUsage !== 'object') state.dataTransferUsage = { date: '', count: 0 };
            const today = getTodayTransferKey();
            if (state.dataTransferUsage.date !== today) state.dataTransferUsage = { date: today, count: 0 };
            state.dataTransferUsage.count = Math.max(0, Math.floor(state.dataTransferUsage.count || 0));
            return state.dataTransferUsage;
        }
        // データ移行は1日に何回でも可能（回数制限なし）。ただし1日の回数が3/8/20/50/100回ちょうどでメッセージを表示。
        function getTodayTransferCount() {
            return getDataTransferUsage().count;
        }
        function getTransferJokeMessage(count) {
            if (count === 100) return '勉強したら？';
            if (count === 50) return '当たらないね笑';
            if (count === 20) return '俺はわかってるぞ';
            if (count === 8) return 'データ移行多ない？';
            if (count === 3) return 'データ移行好きなんですね';
            return '';
        }
        function tryConsumeDataTransfer(actionLabel) {
            const usage = getDataTransferUsage();
            usage.count += 1;
            state.dataTransferUsage = usage;
            saveState();
            return getTransferJokeMessage(usage.count);
        }
        function openDataTransferModal() {
            document.getElementById("dataTransferModal").classList.remove("hidden");
        }

        function exportDataTransfer() {
            const transferJoke = tryConsumeDataTransfer('出力');
            try {
                const data = JSON.parse(JSON.stringify(state || {}));
                data.v = 3;
                delete data.wrongWords;
                const code = btoa(unescape(encodeURIComponent(JSON.stringify(data))));
                document.getElementById("dataTransferText").value = code;
                showCustomAlert("移行コードを出力しました", `単語関連データを除く全データの移行コードを出力しました。
本日の移行回数: ${getTodayTransferCount()}回（上限なし）${transferJoke ? '\n\n' + transferJoke : ''}`);
            } catch (e) {
                const usage = getDataTransferUsage();
                usage.count = Math.max(0, usage.count - 1);
                state.dataTransferUsage = usage;
                saveState();
                showCustomAlert("出力に失敗しました", "エラー: " + e.message);
            }
        }

        function copyDataTransfer() {
            const ta = document.getElementById("dataTransferText");
            if (!ta.value) { showCustomAlert("コードがありません", "先に「出力」ボタンで移行コードを生成してください。"); return; }
            ta.select();
            try {
                document.execCommand("copy");
                showCustomAlert("コードをコピーしました", "別端末の「データ移行」欄に貼り付けて読み込みしてください。");
            } catch (e) {
                showCustomAlert("コピーに失敗しました", "コードを手動でコピーしてください。");
            }
        }

        function importDataTransfer() {
            const ta = document.getElementById("dataTransferText");
            const code = (ta.value || "").trim().replace(/\s+/g, "");
            if (!code) {
                showCustomAlert("コードがありません", "移行コードを貼り付けてから読み込みしてください。");
                return;
            }
            const transferJoke = tryConsumeDataTransfer('読み込み');
            try {
                const json = decodeURIComponent(escape(atob(code)));
                const data = JSON.parse(json);
                if (!data || typeof data !== "object" || !Array.isArray(data.ownedUnits)) throw new Error("形式が正しくありません");

                const preservedWrongWords = Array.isArray(state.wrongWords) ? state.wrongWords.slice() : [];

                if (data.v >= 3) {
                    const merged = { ...state, ...data };
                    merged.wrongWords = preservedWrongWords;
                    if (!Array.isArray(merged.subDeck)) merged.subDeck = [];
                    if (!merged.godPreserved || typeof merged.godPreserved !== 'object') merged.godPreserved = { owned: [], levels: {}, specLevels: {} };
                    state = merged;
                } else {
                    const importedUnits = data.ownedUnits.filter(id => !!getUnit(id));
                    state.ownedUnits = importedUnits;
                    if (Array.isArray(data.permanentOwned)) state.permanentOwned = data.permanentOwned.filter(id => id === 'butsu_001' || !!getUnit(id));
                    if (data.v >= 2 || data.unitLevels) {
                        const mergedLevels = {};
                        const mergedSpecLevels = {};
                        const mergedFormations = [];
                        importedUnits.forEach(id => {
                            const lv = (data.unitLevels && typeof data.unitLevels[id] === 'number') ? data.unitLevels[id] : 1;
                            mergedLevels[id] = Math.max(1, Math.floor(lv));
                            const slv = (data.unitSpecialLevels && typeof data.unitSpecialLevels[id] === 'number') ? data.unitSpecialLevels[id] : 1;
                            mergedSpecLevels[id] = Math.max(1, Math.floor(slv));
                        });
                        (Array.isArray(data.formations) ? data.formations : []).forEach(f => {
                            if (f && Array.isArray(f.units)) {
                                const validUnits = f.units.filter(id => importedUnits.includes(id));
                                if (validUnits.length > 0) mergedFormations.push(Object.assign({}, f, { units: validUnits }));
                            }
                        });
                        state.unitLevels = mergedLevels;
                        state.unitSpecialLevels = mergedSpecLevels;
                        if (mergedFormations.length > 0) state.formations = mergedFormations;
                    }
                    state.clearedStages = (data.clearedStages && typeof data.clearedStages === 'object') ? data.clearedStages : {};
                    if (typeof data.coins === 'number' && data.coins >= 0) state.coins = data.coins;
                    if (typeof data.gems === 'number' && data.gems >= 0) state.gems = data.gems;
                    state.wrongWords = preservedWrongWords;
                }

                state.ownedUnits = Array.isArray(state.ownedUnits) ? state.ownedUnits.filter(id => id === 'ch_000' || !!getUnit(id)) : ['ch_000'];
                if (!state.ownedUnits.includes('ch_000')) state.ownedUnits.unshift('ch_000');
                state.ownedUnits = [...new Set(state.ownedUnits)];
                state.permanentOwned = Array.isArray(state.permanentOwned) ? [...new Set(state.permanentOwned.filter(id => id === 'butsu_001' || !!getUnit(id)))] : [];
                state.unitLevels = (state.unitLevels && typeof state.unitLevels === 'object') ? state.unitLevels : {};
                state.unitSpecialLevels = (state.unitSpecialLevels && typeof state.unitSpecialLevels === 'object') ? state.unitSpecialLevels : {};
                if (!state.unitOwnershipCounts || typeof state.unitOwnershipCounts !== 'object') state.unitOwnershipCounts = {};
                Object.keys(state.unitSpecialLevels).forEach(k => { state.unitSpecialLevels[k] = Math.min(50, Math.max(1, Math.floor(Number(state.unitSpecialLevels[k]) || 1))); });
                state.formations = Array.isArray(state.formations) ? state.formations.map(f => {
                    if (!f || !Array.isArray(f.units)) return null;
                    const validUnits = f.units.filter(id => state.ownedUnits.includes(id));
                    if (validUnits.length === 0) return null;
                    return Object.assign({}, f, { units: validUnits });
                }).filter(Boolean) : [];
                state.clearedStages = (state.clearedStages && typeof state.clearedStages === 'object') ? state.clearedStages : {};
                if (typeof state.coins !== 'number' || state.coins < 0) state.coins = 0;
                if (typeof state.gems !== 'number' || state.gems < 0) state.gems = 0;
                if (typeof state.reviewPoints !== 'number' || state.reviewPoints < 0) state.reviewPoints = 0;
                if (typeof state.reviewGachaPityCount !== 'number' || state.reviewGachaPityCount < 0) state.reviewGachaPityCount = 0;
                if (!state.gachaUnlocks || typeof state.gachaUnlocks !== 'object') state.gachaUnlocks = {};
                if (typeof state.shukkeCount !== 'number' || state.shukkeCount < 0) state.shukkeCount = 0;
                state.shukkePrompted = !!state.shukkePrompted;
                if (typeof state.worldLevel !== 'number' || state.worldLevel < 1) state.worldLevel = 1;
                if (typeof state.bossRushBest !== 'number' || state.bossRushBest < 0) state.bossRushBest = 0;
                if (!Array.isArray(state.bossRushClearedLevels)) state.bossRushClearedLevels = [];
                if (!state.bossRushRewardClaimed || typeof state.bossRushRewardClaimed !== 'object') state.bossRushRewardClaimed = {};
                if (!state.dataTransferUsage || typeof state.dataTransferUsage !== 'object') state.dataTransferUsage = { date: '', count: 0 };
                if (!state.settings || typeof state.settings !== 'object') state.settings = { hideBattleSkills: false, hideBattleSynergies: false };
                state.settings.hideBattleSkills = !!state.settings.hideBattleSkills;
                state.settings.hideBattleSynergies = !!state.settings.hideBattleSynergies;
                state.settings.smartphoneMode = !!state.settings.smartphoneMode;
                if (!state.noble || typeof state.noble !== 'object') state.noble = { level: 1, outfits: {} };
                if (typeof state.noble.level !== 'number' || state.noble.level < 1) state.noble.level = 1;
                if (!state.noble.outfits || typeof state.noble.outfits !== 'object') state.noble.outfits = {};
                if (!Array.isArray(state.deck)) state.deck = ['ch_000'];
                state.deck = state.deck.filter(id => state.ownedUnits.includes(id));
                state.bossRushClearedLevels = [...new Set(state.bossRushClearedLevels.map(v => parseInt(v, 10)).filter(v => !isNaN(v) && v >= 1 && v <= 10))].sort((a, b) => a - b);
                ensureUnitOwnershipCounts();
                normalizeBossRushSelection();
                bossRushState = (state.bossRushProgress && typeof state.bossRushProgress === 'object') ? state.bossRushProgress : null;
                ensureNobleFixedDeck();
                saveState();
                renderHeader();
                renderDeckView();
                renderDungeonsView();
                renderBossRushView();
                closeModal("dataTransferModal");
                showCustomAlert("読み込みが完了しました", `単語関連データを除く全データを読み込みました！\n本日の移行回数: ${getTodayTransferCount()}回（上限なし）${transferJoke ? '\n\n' + transferJoke : ''}`);
            } catch (e) {
                const usage = getDataTransferUsage();
                usage.count = Math.max(0, usage.count - 1);
                state.dataTransferUsage = usage;
                saveState();
                showCustomAlert("読み込みに失敗しました", "コードが正しくありません: " + e.message);
            }
        }

        // リセット押下回数（1日あたり・日付キー付きで別ストレージに保存。リセットしても消えない）
        function getResetPressData() {
            const today = getTodayTransferKey();
            try {
                const raw = JSON.parse(localStorage.getItem("kobun_reset_press") || "{}");
                if (!raw || typeof raw !== 'object' || raw.date !== today) return { date: today, count: 0 };
                return { date: today, count: Math.max(0, Math.floor(raw.count || 0)) };
            } catch (e) { return { date: today, count: 0 }; }
        }
        function getResetLifetimeCount() {
            try {
                const raw = Math.floor(Number(localStorage.getItem("kobun_reset_press_lifetime") || 0));
                return Math.max(0, raw || 0);
            } catch (e) { return 0; }
        }
        function addResetPressCount() {
            const data = getResetPressData();
            data.count += 1;
            try { localStorage.setItem("kobun_reset_press", JSON.stringify(data)); } catch (e) {}
            try { localStorage.setItem("kobun_reset_press_lifetime", String(getResetLifetimeCount() + 1)); } catch (e) {}
            return data.count;
        }
        function getResetJokeMessage(count) {
            if (count === 100) return '祝100回';
            if (count === 80) return 'がんばれ';
            if (count === 30) return '当たらないね';
            return '';
        }
        function doHardReset() {
            localStorage.removeItem("kobun_battle_state");
            location.reload();
        }
        function promptResetData() {
            const presses = addResetPressCount();
            const joke = getResetJokeMessage(presses);
            // 5回目以降: 3段階の警告文は表示されず、即リセット（30/80/100回はメッセージを挟む）
            if (presses >= 5) {
                if (joke) {
                    showCustomAlert("リセット", joke, () => doHardReset());
                } else {
                    doHardReset();
                }
                return;
            }
            // 3段階確認: 「データを消しますか？」→「本当に消しますか？」→「さようなら」
            showCustomConfirm("データ初期化", "データを消しますか？", () => {
                showCustomConfirm("データ初期化", "本当に消しますか？", () => {
                    showCustomConfirm("データ初期化", "さようなら", () => doHardReset());
                });
            });
        }

        function promptRetreat() {
            showCustomConfirm("撤退確認", "合戦から撤退しますか？", () => {
                if (battleState && battleState.bossRush) {
                    const br = ensureBossRush();
                    br.playerHp = battleState.playerHp;
                    br.active = true;
                    saveState();
                }
                battleState.active = false;
                if (battleState.loopInterval) clearInterval(battleState.loopInterval);
                exitBattleView();
            });
        }

        function createFloatingText(text, container, extraClasses) {
            if (!container) return;
            const el = document.createElement("div");
            el.className = `damage-float ${extraClasses || 'text-yellow-300'}`;
            el.textContent = text;
            el.style.left = `${Math.random() * 50 + 25}%`;
            el.style.top = `${Math.random() * 30 + 30}%`;
            container.appendChild(el);
            setTimeout(() => {
                if (el.parentNode) el.parentNode.removeChild(el);
            }, 850);
        }

        function closeModal(modalId) {
            document.getElementById(modalId).classList.add("hidden");
        }

        function openGachaRatesModal(bannerId = 'base') {
            const container = document.getElementById("gachaRatesContent");
            const isWeekday = bannerId !== 'base' && !!WEEKDAY_GACHA_BANNERS[bannerId];
            const banner = bannerId === 'base' ? { title: '平安文人 招集', units: GACHA_CHARACTERS } : (NEW_GACHA_BANNERS[bannerId] || WEEKDAY_GACHA_BANNERS[bannerId]);
            if (!banner) return;
            __PERF.setHTML(container, "");

            const rarities = isWeekday ? [
                { key: 'UR', name: 'UR（超激レア）', rate: 2.0, color: 'text-red-400', border: 'border-red-500/80', bg: 'bg-red-950/40' },
                { key: 'SSR', name: 'SSR（激レア）', rate: 15.0, color: 'text-amber-400', border: 'border-amber-500/80', bg: 'bg-amber-950/40' },
                { key: 'SR', name: 'SR（ハイレア）', rate: 30.0, color: 'text-purple-300', border: 'border-purple-500/80', bg: 'bg-purple-950/40' },
                { key: 'R', name: 'R（レア）', rate: 53.0, color: 'text-gray-300', border: 'border-gray-600', bg: 'bg-black/40' }
            ] : [
                { key: 'UR', name: 'UR（超激レア）', rate: 0.2, color: 'text-red-400', border: 'border-red-500/80', bg: 'bg-red-950/40' },
                { key: 'SSR', name: 'SSR（激レア）', rate: 10.0, color: 'text-amber-400', border: 'border-amber-500/80', bg: 'bg-amber-950/40' },
                { key: 'SR', name: 'SR（ハイレア）', rate: 20.0, color: 'text-purple-300', border: 'border-purple-500/80', bg: 'bg-purple-950/40' },
                { key: 'R', name: 'R（レア）', rate: 69.8, color: 'text-gray-300', border: 'border-gray-600', bg: 'bg-black/40' }
            ];

            rarities.forEach(r => {
                const pool = banner.units.filter(c => c.rarity === r.key);
                const indivRate = pool.length > 0 ? (r.rate / pool.length).toFixed(2) : 0;

                const sec = document.createElement("div");
                sec.className = `p-3 rounded-xl border ${r.border} ${r.bg}`;

                let charCardsHtml = "";
                pool.forEach(c => {
                    charCardsHtml += `
                        <div class="bg-black/60 p-2 rounded border border-heian-purple/40 flex items-center gap-2">
                            <div class="w-7 h-7 rounded-full bg-heian-purple border border-heian-gold flex items-center justify-center text-heian-gold text-xs shrink-0">
                                <i class="fa-solid ${c.icon}"></i>
                            </div>
                            <div class="flex-1 min-w-0 text-left">
                                <div class="font-mincho font-bold text-xs text-yellow-100 truncate">${c.name}</div>
                                <div class="text-[9px] text-gray-400">個別確率: <span class="text-amber-300 font-mono font-bold">${indivRate}%</span></div>
                            </div>
                        </div>
                    `;
                });

                __PERF.setHTML(sec, `
                    <div class="flex justify-between items-center mb-2 pb-1 border-b border-heian-purple/40">
                        <span class="font-bold text-xs ${r.color}">${r.name}</span>
                        <span class="text-xs font-mono font-bold text-amber-300">合計 ${r.rate.toFixed(1)}%</span>
                    </div>
                    <div class="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        ${charCardsHtml}
                    </div>
                `);
                container.appendChild(sec);
            });

            document.getElementById("gachaRatesModal").classList.remove("hidden");
        }

