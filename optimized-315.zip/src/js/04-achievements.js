        // ============================================================
        // 実績システム：定義は実データから動的生成。旧セーブは未取得扱い。
        // ============================================================
        let achievementToastQueue = [];
        let achievementToastBusy = false;
        let ACHIEVEMENT_DEFINITIONS = null;
        let ACHIEVEMENT_RENDER_VERSION = 0;
        let LAST_ACHIEVEMENT_RENDERED_VERSION = -1;
        let __saveStateTimer = null;
        const FINAL_WEEKDAY_ACHIEVEMENT_DUNGEONS = new Set([40, 50, 60, 70, 80]);
        let DUNGEON_BY_ID_CACHE = null;
        let BOSS_RUSH_STAGE_IDS_CACHE = null;
        // 頻繁更新される戦闘DOMの参照を再利用（表示・挙動は不変）
        let _battleUiEls = null;
        function getBattleUiEls() {
            if (_battleUiEls) return _battleUiEls;
            _battleUiEls = {
                playerHpBar: document.getElementById('playerHpBar'), playerHpText: document.getElementById('playerHpText'),
                enemyHpBar: document.getElementById('enemyHpBar'), enemyHpText: document.getElementById('enemyHpText'),
                comboBanner: document.getElementById('comboBanner'), comboCountText: document.getElementById('comboCountText'),
                enemyAttackTimerBar: document.getElementById('enemyAttackTimerBar')
            };
            return _battleUiEls;
        }
        function getDungeonById(id) {
            if (!DUNGEON_BY_ID_CACHE) {
                DUNGEON_BY_ID_CACHE = new Map();
                (DUNGEONS_DATA || []).forEach(d => DUNGEON_BY_ID_CACHE.set(String(d.id), d));
            }
            return DUNGEON_BY_ID_CACHE.get(String(id)) || null;
        }
        function shouldKeepWeekdayAchievement(dungeonId) {
            return FINAL_WEEKDAY_ACHIEVEMENT_DUNGEONS.has(parseInt(dungeonId, 10));
        }
        function getBossRushStageIds() {
            if (!BOSS_RUSH_STAGE_IDS_CACHE) BOSS_RUSH_STAGE_IDS_CACHE = DUNGEONS_DATA.flatMap(d => (d.stages || []).map(s => s.id)).slice(0, 200);
            return BOSS_RUSH_STAGE_IDS_CACHE;
        }
        function isAchievementsViewVisible() {
            const el = document.getElementById('view-achievements');
            return !!el && !el.classList.contains('hidden');
        }
        function flushStateToStorage() {
            try {
                if (__saveStateTimer) {
                    clearTimeout(__saveStateTimer);
                    __saveStateTimer = null;
                }
                state.bossRushProgress = bossRushState ? {
                    active: !!bossRushState.active,
                    round: parseInt(bossRushState.round, 10) || 1,
                    stage: parseInt(bossRushState.stage, 10) || 1,
                    scoreKills: parseInt(bossRushState.scoreKills, 10) || 0,
                    worldLevel: parseInt(bossRushState.worldLevel, 10) || getWorldLevel(),
                    playerHp: typeof bossRushState.playerHp === 'number' ? bossRushState.playerHp : null
                } : null;
                localStorage.setItem("kobun_battle_state", JSON.stringify(state));
            } catch (e) { console.error("Failed to save state", e); }
        }
        window.addEventListener('beforeunload', flushStateToStorage);
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'hidden') flushStateToStorage();
        });
        function getAchievementGachaKeys() {
            const keys = ['base'];
            if (typeof NEW_GACHA_BANNERS === 'object') keys.push(...Object.keys(NEW_GACHA_BANNERS));
            if (typeof WEEKDAY_GACHA_BANNERS === 'object') keys.push(...Object.keys(WEEKDAY_GACHA_BANNERS));
            keys.push('review');
            return [...new Set(keys)];
        }
        function getVisibleAchievementDefinitions() {
            return getAchievementDefinitions().filter(d => !d.hidden);
        }
        function getAchievementCompletionInfo() {
            const visibleDefs = getVisibleAchievementDefinitions();
            const unlockedVisible = visibleDefs.filter(d => !!state.achievements?.[d.id]).length;
            return {
                unlockedVisible,
                totalVisible: visibleDefs.length,
                allVisibleUnlocked: visibleDefs.length > 0 && unlockedVisible >= visibleDefs.length
            };
        }
        function isNobleGodEvolved() {
            return getAchievementCompletionInfo().allVisibleUnlocked;
        }
        function getWeekdayFinalClearCount() {
            const cleared = state.clearedStages || {};
            return (WEEKDAY_DUNGEON_IDS || []).reduce((acc, id) => {
                const dung = getDungeonById(id);
                if (!dung || !dung.stages || !dung.stages.length) return acc;
                const finalId = dung.stages[dung.stages.length - 1].id;
                return acc + (cleared[finalId] ? 1 : 0);
            }, 0);
        }
        function getMaxOwnedDuplicateCount() {
            ensureUnitOwnershipCounts();
            return Object.entries(state.unitOwnershipCounts || {}).reduce((mx, [id, count]) => {
                if (id === 'ch_000') return mx;
                return Math.max(mx, Math.floor(Number(count) || 0));
            }, 0);
        }
        function getTotalGachaPulls() {
            return Object.values(state.gachaCounts || {}).reduce((sum, v) => sum + Math.max(0, Math.floor(Number(v) || 0)), 0);
        }
        function getAchievementDefinitions() {
            if (ACHIEVEMENT_DEFINITIONS) return ACHIEVEMENT_DEFINITIONS;
            const defs = [];
            const add = (id, name, desc, kind, target, icon = 'fa-trophy', hidden = false) => defs.push({ id, name, desc, kind, target, icon, hidden });
            add('stage_d1_s1','はじまりの一歩','ダンジョン1・ステージ1をクリアする','stage','dungeon:1:0','fa-shoe-prints');
            if (Array.isArray(DUNGEONS_DATA)) {
                DUNGEONS_DATA.filter(d => !isWeekdayDungeon(d.id)).forEach(d => add(`dungeon_final_${d.id}`,`ダンジョン${d.id} 制覇`,`ダンジョン${d.id}の最後のステージをクリアする`,'stage',`dungeon:${d.id}:final`,'fa-flag-checkered'));
            }
            if (Array.isArray(WEEKDAY_DUNGEON_IDS)) {
                WEEKDAY_DUNGEON_IDS.forEach(id => {
                    if (!shouldKeepWeekdayAchievement(id)) return;
                    const dung = getDungeonById(id);
                    if (dung && dung.stages && dung.stages.length) add(`weekday_dungeon_final_${id}`,`${dung.title} 制覇`,`${dung.title}の最後のステージをクリアする`,'stage',`dungeon:${id}:final`,'fa-calendar-check');
                });
            }
            const worldLevels = Array.from({ length: 10 }, (_, i) => i + 1);
            worldLevels.forEach(w => {
                add(`world_${w}_dungeon30`,`世界Lv.${w} 深奥`,`世界Lv.${w}でダンジョン30の最後のステージをクリアする`,'worldDungeon30',String(w),'fa-mountain');
                add(`world_${w}_bossrush`,`世界Lv.${w} の覇者`,`世界Lv.${w}のボスラッシュをクリアする`,'bossrush',String(w),'fa-dragon');
            });
            getAchievementGachaKeys().forEach(k => {
                const label = k === 'base' ? '平安文人' : k === 'review' ? '復習の恵み' : (typeof NEW_GACHA_BANNERS === 'object' && NEW_GACHA_BANNERS[k]?.title) || (typeof WEEKDAY_GACHA_BANNERS === 'object' && WEEKDAY_GACHA_BANNERS[k]?.title) || k;
                // ★ 復習の恵みの実績は「千連・1000回」に変更（他のガチャは従来どおり一万連）
                const reviewGachaIsThousand = (k === 'review');
                add(`gacha_${k}_100`,`${label} 百連`,`${label}を100回引く`,'gacha',`${k}:100`,'fa-dice');
                add(`gacha_${k}_${reviewGachaIsThousand ? 1000 : 10000}`,`${label} ${reviewGachaIsThousand ? '千連' : '一万連'}`,`${reviewGachaIsThousand ? '復習の恵を1000回引く' : `${label}を1万回引く`}`,'gacha',`${k}:${reviewGachaIsThousand ? 1000 : 10000}`,'fa-dice-d20');
            });
            add('characters_10','十人十色','キャラクターを10体獲得する','characters',10,'fa-user-group');
            add('characters_100','百花繚乱','キャラクターを100体獲得する','characters',100,'fa-users');
            add('characters_all','文人の極み','全キャラクターを獲得する','characters','all','fa-crown');

            add('meta_coin_10000','小銭持ち','所持金を10,000文以上にする','meta','coins:10000','fa-coins');
            add('meta_coin_100000','銭のにおい','所持金を100,000文以上にする','meta','coins:100000','fa-coins');
            add('meta_gems_1000','宝玉ちゃりん','宝玉を1,000個以上ためる','meta','gems:1000','fa-gem');
            add('meta_gems_10000','宝玉の壺','宝玉を10,000個以上ためる','meta','gems:10000','fa-gem');
            add('meta_pulls_10','つい回しちゃう','ガチャを累計10回引く','meta','pulls:10','fa-ticket');
            add('meta_pulls_100','そこそこ回した','ガチャを累計100回引く','meta','pulls:100','fa-ticket');
            add('meta_pulls_500','止まらぬ召喚','ガチャを累計500回引く','meta','pulls:500','fa-ticket');
            add('meta_kaguya_1','月を見上げた日','かぐや姫を1回引く','meta','kaguya:1','fa-moon');
            add('meta_kaguya_5','月見ガチ勢','かぐや姫を5回引く','meta','kaguya:5','fa-moon');
            add('meta_duplicate_5','かぶり上手','同じ仲間を5体以上所持する','meta','duplicate:5','fa-copy');
            add('meta_duplicate_10','だぶつき王朝','同じ仲間を10体以上所持する','meta','duplicate:10','fa-layer-group');
            add('meta_shukke_1','一度は俗世を離れたい','出家を1回行う','meta','shukke:1','fa-torii-gate');
            add('meta_shukke_3','だいぶ悟ってきた','出家を3回行う','meta','shukke:3','fa-mountain-sun');
            add('meta_boss_100','百戦小勇士','ボスラッシュで100ステージ到達する','meta','bossrushBest:100','fa-skull');
            add('meta_boss_600','六百枚看板','ボスラッシュ600ステージ完全制覇する','meta','bossrushBest:600','fa-skull-crossbones');
            add('meta_clears_50','けっこう進んだ','ステージを50個クリアする','meta','clearedStages:50','fa-road');
            add('meta_clears_150','まだまだ途中','ステージを150個クリアする','meta','clearedStages:150','fa-road');
            add('meta_clears_300','妙にまじめ','ステージを300個クリアする','meta','clearedStages:300','fa-road');
            add('meta_gemlot_1','運試し','宝玉くじを1回引く','meta','gemLottery:1','fa-clover');
            add('meta_gemlot_100','くじ沼住人','宝玉くじを累計100回引く','meta','gemLottery:100','fa-clover');
            add('hidden_reset_100','リセマラの達人','リセットを100回行う','meta','resetLifetime:100','fa-user-secret', true);
            // ★ オンライン対戦: 称号ごとの実績
            PVP_TITLES.forEach(function (t, i) {
                var n = i + 1;
                add('pvp_title_' + n, '称号・' + t.name, 'オンライン対戦で称号「' + t.name + '」を獲得する', 'meta', 'pvpTitles:' + n, 'fa-medal');
            });
            ACHIEVEMENT_DEFINITIONS = defs;
            return ACHIEVEMENT_DEFINITIONS;
        }
        function achievementIsMet(def) {
            const cleared = state.clearedStages || {};
            if (def.kind === 'stage') {
                const p = def.target.split(':');
                const d = getDungeonById(p[1]);
                return !!d && (p[2] === 'final' ? !!d.stages.length && !!cleared[d.stages[d.stages.length - 1].id] : !!cleared[d.stages[0]?.id]);
            }
            if (def.kind === 'worldDungeon30') return !!state.achievementWorldClears?.[def.target]?.dungeon30;
            if (def.kind === 'worldWeekdayDungeon') {
                const [world, dungeonId] = String(def.target).split(':');
                return !!state.achievementWorldWeekdayClears?.[String(world)]?.[String(dungeonId)];
            }
            if (def.kind === 'bossrush') return !!state.achievementWorldClears?.[def.target]?.bossrush;
            if (def.kind === 'gacha') {
                const [k, n] = def.target.split(':');
                return (Number(state.gachaCounts?.[k]) || 0) >= Number(n);
            }
            if (def.kind === 'characters') {
                const n = (state.ownedUnits || []).filter(id => id !== 'ch_000').length;
                return def.target === 'all'
                    ? n >= (typeof ALL_GACHA_CHARACTERS === 'function' ? new Set(ALL_GACHA_CHARACTERS().map(u => u.id)).size : Infinity)
                    : n >= Number(def.target);
            }
            if (def.kind === 'meta') {
                const [key, rawValue] = String(def.target).split(':');
                const value = Number(rawValue);
                if (key === 'coins') return (state.coins || 0) >= value;
                if (key === 'gems') return (state.gems || 0) >= value;
                if (key === 'pulls') return getTotalGachaPulls() >= value;
                if (key === 'kaguya') return (state.kaguyaCount || 0) >= value;
                if (key === 'duplicate') return getMaxOwnedDuplicateCount() >= value;
                if (key === 'shukke') return (state.shukkeCount || 0) >= value;
                if (key === 'bossrushBest') return (state.bossRushBest || 0) >= value;
                if (key === 'clearedStages') return Object.keys(cleared).length >= value;
                if (key === 'gemLottery') return (state.gemLotteryDraws || 0) >= value;
                if (key === 'weekdayFinals') return getWeekdayFinalClearCount() >= value;
                if (key === 'resetLifetime') return getResetLifetimeCount() >= value;
                if (key === 'pvpTitles') return (state.pvpTitles || 0) >= value;
            }
            return false;
        }
        function showNextAchievementToast() { if (achievementToastBusy || !achievementToastQueue.length) return; achievementToastBusy=true; const d=achievementToastQueue.shift(); const wrap=document.getElementById('achievementToastWrap')||(()=>{const x=document.createElement('div');x.id='achievementToastWrap';x.className='achievement-toast-wrap';document.body.appendChild(x);return x})(); const el=document.createElement('div'); el.className='achievement-toast'; __PERF.setHTML(el, `<div class="achievement-toast-icon"><i class="fa-solid ${d.icon}"></i></div><div><div class="achievement-toast-label">実績解除</div><div class="achievement-toast-name">${d.name}</div></div>`); wrap.appendChild(el); setTimeout(()=>{el.style.opacity='0';el.style.transform='translateX(110%)';el.style.transition='all .25s ease';setTimeout(()=>{el.remove();achievementToastBusy=false;showNextAchievementToast()},260)},3600); }
        function checkAchievements() {
            const defs = getAchievementDefinitions();
            if (!state.achievements || typeof state.achievements !== 'object') state.achievements = {};
            let changed = false;
            defs.forEach(d => {
                if (!state.achievements[d.id] && achievementIsMet(d)) {
                    state.achievements[d.id] = true;
                    achievementToastQueue.push(d);
                    changed = true;
                }
            });
            if (!changed) {
                if (isAchievementsViewVisible()) renderAchievementsView();
                return false;
            }
            ACHIEVEMENT_RENDER_VERSION += 1;
            saveState();
            if (isAchievementsViewVisible()) renderAchievementsView(true);
            renderHeader();
            showNextAchievementToast();
            return true;
        }
        function renderAchievementsView(force = false) {
            const grid = document.getElementById('achievementGrid');
            if (!grid) return;
            const defs = getAchievementDefinitions().filter(d => !d.hidden || state.achievements?.[d.id]);
            const info = getAchievementCompletionInfo();
            const sum = document.getElementById('achievementSummary');
            if (sum) sum.textContent = `${info.unlockedVisible} / ${info.totalVisible}`;
            const bar = document.getElementById('achievementProgressBar');
            if (bar) bar.style.width = `${info.totalVisible ? info.unlockedVisible / info.totalVisible * 100 : 0}%`;
            const nextVersion = `${ACHIEVEMENT_RENDER_VERSION}:${defs.length}:${info.unlockedVisible}`;
            if (!force && LAST_ACHIEVEMENT_RENDERED_VERSION === nextVersion) return;
            LAST_ACHIEVEMENT_RENDERED_VERSION = nextVersion;
            grid.innerHTML = defs.map(d => {
                const ok = !!state.achievements?.[d.id];
                return `<div class="achievement-card ${ok ? 'unlocked' : 'locked'}"><div class="flex gap-3 items-start"><div class="achievement-medal"><i class="fa-solid ${d.icon}"></i></div><div class="min-w-0"><div class="font-bold text-amber-100 text-sm leading-snug">${d.name}</div><div class="text-[11px] text-gray-300 mt-1 leading-relaxed">${d.desc}</div><div class="text-[10px] mt-2 font-bold ${ok ? 'text-green-300' : 'text-gray-500'}">${ok ? '✓ 獲得済み' : '未獲得'}</div></div></div></div>`;
            }).join('');
        }
        function markAchievementWorld(kind, world) { const w=String(parseInt(world,10)||1); if(!state.achievementWorldClears) state.achievementWorldClears={}; if(!state.achievementWorldClears[w]) state.achievementWorldClears[w]={}; state.achievementWorldClears[w][kind]=true; }
        function markAchievementWeekdayWorld(world, dungeonId) {
            const w = String(parseInt(world, 10) || 1);
            const d = String(parseInt(dungeonId, 10) || 0);
            if (!state.achievementWorldWeekdayClears || typeof state.achievementWorldWeekdayClears !== 'object') state.achievementWorldWeekdayClears = {};
            if (!state.achievementWorldWeekdayClears[w]) state.achievementWorldWeekdayClears[w] = {};
            state.achievementWorldWeekdayClears[w][d] = true;
        }

        function saveState(immediate = false) {
            if (immediate) {
                flushStateToStorage();
                return;
            }
            if (__saveStateTimer) return;
            __saveStateTimer = setTimeout(flushStateToStorage, 120);
        }

        function loadState() {
            try {
                const saved = localStorage.getItem("kobun_battle_state");
                if (saved) {
                    const parsed = JSON.parse(saved);
                    state = { ...state, ...parsed };
                    if (!state.unitSpecialLevels || typeof state.unitSpecialLevels !== 'object') state.unitSpecialLevels = {};
                    Object.keys(state.unitSpecialLevels).forEach(k => { state.unitSpecialLevels[k] = Math.min(50, Math.max(1, Math.floor(Number(state.unitSpecialLevels[k]) || 1))); });
                    if (!state.wrongWords) state.wrongWords = [];
                    if (typeof state.shukkeCount !== "number") state.shukkeCount = 0;
                    if (!Array.isArray(state.permanentOwned)) state.permanentOwned = [];
                    if (!Array.isArray(state.subDeck)) state.subDeck = [];
                    if (!state.godPreserved || typeof state.godPreserved !== 'object') state.godPreserved = { owned: [], levels: {}, specLevels: {} };
                    if (!Array.isArray(state.formations)) state.formations = [];
                    if (typeof state.worldLevel !== "number" || state.worldLevel < 1) state.worldLevel = 1;
                    if (typeof state.bossRushBest !== "number" || state.bossRushBest < 0) state.bossRushBest = 0;
                    if (!Array.isArray(state.bossRushClearedLevels)) state.bossRushClearedLevels = [];
                    if (!state.bossRushRewardClaimed || typeof state.bossRushRewardClaimed !== 'object') state.bossRushRewardClaimed = {};
                    if (!state.dataTransferUsage || typeof state.dataTransferUsage !== 'object') state.dataTransferUsage = { date: '', count: 0 };
                    if (!state.gachaUnlocks || typeof state.gachaUnlocks !== 'object') state.gachaUnlocks = {};
                    if (!state.gachaCounts || typeof state.gachaCounts !== 'object') state.gachaCounts = {};
                    Object.keys(state.gachaCounts).forEach(k => { state.gachaCounts[k] = Math.max(0, Math.floor(Number(state.gachaCounts[k]) || 0)); });
                    if (!state.achievements || typeof state.achievements !== 'object') state.achievements = {};
                    if (!state.achievementWorldClears || typeof state.achievementWorldClears !== 'object') state.achievementWorldClears = {};
                    if (!state.achievementWorldWeekdayClears || typeof state.achievementWorldWeekdayClears !== 'object') state.achievementWorldWeekdayClears = {};
                    if (typeof state.gemLotteryDraws !== 'number' || state.gemLotteryDraws < 0) state.gemLotteryDraws = 0;
                    state.ownedUnits = Array.isArray(state.ownedUnits) ? [...new Set(state.ownedUnits.filter(id => id === 'ch_000' || !!getUnit(id)))] : ['ch_000'];
                    if (!state.ownedUnits.includes('ch_000')) state.ownedUnits.unshift('ch_000');
                    if (!state.unitOwnershipCounts || typeof state.unitOwnershipCounts !== 'object') state.unitOwnershipCounts = {};
                    if (!state.weekdayPoints || typeof state.weekdayPoints !== 'object') state.weekdayPoints = {};
                    ['mon','tue','wed','thu','fri'].forEach(k => { state.weekdayPoints[k] = Math.max(0, Math.floor(Number(state.weekdayPoints[k]) || 0)); });
                    if (typeof state.reviewPoints !== 'number' || state.reviewPoints < 0) state.reviewPoints = 0;
                    if (typeof state.reviewGachaPityCount !== 'number' || state.reviewGachaPityCount < 0) state.reviewGachaPityCount = 0;
                    if (typeof state.pvpPoints !== 'number' || state.pvpPoints < 0) state.pvpPoints = 0;
                    if (typeof state.pvpTitles !== 'number' || state.pvpTitles < 0) state.pvpTitles = 0;
                            if (!state.settings || typeof state.settings !== 'object') state.settings = { hideBattleSkills: false, hideBattleSynergies: false };
                    state.settings.hideBattleSkills = !!state.settings.hideBattleSkills;
                    state.settings.hideBattleSynergies = !!state.settings.hideBattleSynergies;
                    state.settings.learnMode = !!state.settings.learnMode;
                    state.settings.smartphoneMode = !!state.settings.smartphoneMode;
                    if (state.noble) { if (state.noble.gender !== '男性' && state.noble.gender !== '女性') state.noble.gender = '男性'; }
                }
                if (typeof state.kaguyaCount !== 'number' || state.kaguyaCount < 0) state.kaguyaCount = 0;
                state.butsuOwned = !!state.butsuOwned;
                state.butsuEverOwned = !!state.butsuEverOwned;
                if (!state.kenreimoninUsed || typeof state.kenreimoninUsed !== 'object') state.kenreimoninUsed = {};
                state.bossRushClearedLevels = [...new Set(state.bossRushClearedLevels.map(v => parseInt(v, 10)).filter(v => !isNaN(v) && v >= 1 && v <= 10))].sort((a, b) => a - b);
                state.dataTransferUsage.date = typeof state.dataTransferUsage.date === 'string' ? state.dataTransferUsage.date : '';
                state.dataTransferUsage.count = Math.max(0, Math.floor(state.dataTransferUsage.count || 0));
                bossRushState = (state.bossRushProgress && typeof state.bossRushProgress === 'object') ? state.bossRushProgress : null;
                ensureUnitOwnershipCounts();
                ensureNobleFixedDeck();
                normalizeBossRushSelection();
            } catch (e) { console.error("Failed to load state", e); }
        }

        // 出家回数に応じたデッキ最大枠を返す（貴族固定1枠 + 自由枠）
        // 未出家: 自由5枠(合計6), 1回: 自由6枠(合計7), 2回以上: 自由7枠(合計8)
        function getMaxDeckSize() {
            // ★ オンライン対戦中はホストが設定した枠数を問答無用で全員に適用（出家状況は関係なし）
            if (isPvpRoomActive()) {
                try {
                    const r = window.PVPROOT && window.PVPROOT.roomSlots ? window.PVPROOT.roomSlots() : null;
                    if (r) return r;
                } catch (e) {}
            }
            // ① メイン出撃枠: 出家1回ごとに+1枠、貴族を含めて最大 10 枠
            const sc = (typeof state.shukkeCount === "number") ? state.shukkeCount : 0;
            const max = Math.min(10, 6 + sc);
            return max;
        }
        // ① 出家回数がメイン最大枠(10)を超えたぶん、サブ枠数を返す（オンライン対戦中はサブ枠なし）
        function getMaxSubDeckSize() {
            // ★ オンライン対戦中はサブ枠を使わず、ホスト設定の枠数だけに合わせる
            if (isPvpRoomActive()) return 0;
            const sc = (typeof state.shukkeCount === "number") ? state.shukkeCount : 0;
            // メイン枠が10になるまでに必要な出家回数 = 4 (初期5 + 4回)
            return Math.max(0, sc - 4);
        }

        // オンライン対戦中のみ TRUE（貴族を外す操作を許可する）
        function isPvpRoomActive() {
            try { return !!(window.PVPROOT && window.PVPROOT.isInRoom && window.PVPROOT.isInRoom()); } catch (e) { return false; }
        }

        // 貴族は通常モードでは先頭の固定枠。オンライン対戦中は外すことができる。
        function ensureNobleFixedDeck() {
            const pvpMode = isPvpRoomActive();
            const maxFree = getMaxDeckSize() - 1; // 貴族の固定1枠を除いた自由枠数
            const otherUnits = (Array.isArray(state.deck) ? state.deck : [])
                .filter(id => id !== "ch_000" && state.ownedUnits.includes(id));
            if (pvpMode) {
                const hadNoble = (Array.isArray(state.deck) ? state.deck : []).includes("ch_000");
                if (hadNoble) {
                    state.deck = ["ch_000", ...otherUnits.slice(0, maxFree)];
                } else {
                    state.deck = otherUnits.slice(0, getMaxDeckSize());
                }
            } else {
                state.deck = ["ch_000", ...otherUnits.slice(0, maxFree)];
            }
            if (!Array.isArray(state.subDeck)) state.subDeck = [];
            const subMax = getMaxSubDeckSize();
            const normalizedSub = [];
            state.subDeck.forEach(id => {
                if (id === "ch_000") return;
                if (!state.ownedUnits.includes(id)) return;
                if (state.deck.includes(id)) return;
                if (normalizedSub.includes(id)) return;
                if (normalizedSub.length >= subMax) return;
                normalizedSub.push(id);
            });
            state.subDeck = normalizedSub;
        }

        // レア度の数値ランク（URが最上位。一覧の並び替えに使用）
        function rarityRank(r) {
            return r === '神' ? 5 : r === 'UR' ? 4 : r === 'SSR' ? 3 : r === 'SR' ? 2 : r === 'R' ? 1 : 0;
        }

        function getNobleRankInfo(level) {
            if (isNobleGodEvolved()) return { group: "神格", title: "神", rankStr: "神" };
            if (level >= 100) return { group: "上達部（公卿）", title: "太政大臣", rankStr: "正一位・太政大臣" };
            if (level >= 80) return { group: "上達部（公卿）", title: "左大臣", rankStr: "従一位・左大臣" };
            if (level >= 60) return { group: "上達部（公卿）", title: "大納言", rankStr: "正二位・大納言" };
            if (level >= 40) return { group: "殿上人", title: "蔵人頭", rankStr: "正四位・蔵人頭" };
            if (level >= 20) return { group: "殿上人", title: "少納言", rankStr: "従五位・少納言" };
            return { group: "下級・地方官", title: "国主", rankStr: "正六位・国主" };
        }

        const KAGUYA_UNIT = { id: "kaguya_001", name: "かぐや姫", gender: "女性", rarity: "神", icon: "fa-moon", description: "月より降り立った、帝の系譜にのみ心を開く隠しキャラ。", skill: { name: "月影の加護", effect: "正解時の与ダメージと必殺チャージを大幅強化。敵の妨害を受けにくい。" }, special_move: { name: "天つ乙女の月帰り", effect: "敵全体に超絶月光ダメージ＋行動不能＋味方全回復" }, gaugePerCorrect: 40, gaugeNeedsVotes: 2, synergies: [{ target_id: "ge_001", title: "帝系統・月影の契り", effect: "帝系統と編成時、味方全体の攻撃力・必殺チャージ大幅アップ" }, { target_id: "ge_003", title: "帝系統・月影の契り", effect: "帝系統と編成時、敵の妨害耐性アップ" }, { target_id: "ge_004", title: "帝系統・月影の契り", effect: "帝系統と編成時、月光ダメージ強化" }] };
        const BUTSU_UNIT = {
            id: "butsu_001", name: "仏", gender: "男性", rarity: "神", icon: "fa-dharmachakra",
            description: "2度目の出家で得られる最強キャラ。すべてのリセットを超えて永久に君のもの。",
            skill: { name: "悟りの境地", effect: "毎秒必殺ゲージ+3%" },
            special_move: { name: "極楽往生の光", effect: "敵全体に超絶ダメージ＋味方全回復" },
            gaugePerCorrect: 10, gaugeNeedsVotes: 5, synergies: []
        };
        addPairSynergy('kaguya_001', 'butsu_001', '月仏共鳴', '敵の攻撃をときどき大きく和らげる', '敵の攻撃をときどき大きく和らげる');
        // ★ 称号システム最高報酬: 天照大御神（日本神話の最高神・太陽を司る皇祖神）[Wikipedia: https://ja.wikipedia.org/wiki/天照大神]
        const AMATERASU_UNIT = {
            id: "amaterasu_001", name: "天照大御神", gender: "女性", rarity: "神", icon: "fa-sun",
            description: "日本神話の最高神。高天原を統べる太陽の女神。オンライン対戦で最高称号「太政大臣」に到達した者だけが抱ける、八百万の光そのもの。",
            skill: { name: "日輪の契り・八百万共鳴", trigger: "combo3", fx: { healPct: 0.18, cleanse: true, buffAll: [45, 12], buffSpecGain: [40, 12], buffDmgUp: [35, 12] }, effect: "3連続正解時、日輪の陽光が味方全体のデバフを浄化し、全ステータス・与ダメージ・必殺チャージを大幅強化。日輪の温もりでHPも回復する。" },
            special_move: { name: "天岩戸開闢・高天原黎明", effect: "敵全体に超絶神光ダメージ＋味方HP特大回復＋全ステータス強化＋行動不能付与＋強固なバリア＆再生＋敵の攻撃・速度低下" },
            gaugePerCorrect: 42, gaugeNeedsVotes: 2,
            synergies: [
                { target_id: "br_god_02", title: "天照と須佐の誓約（うけい）", effect: "双方の攻撃力・会心率が大幅アップ" },
                { target_id: "br_god_01", title: "天岩戸の神楽", effect: "必殺技威力大幅アップ＋味方のデバフ耐性アップ" },
                { target_id: "br_god_03", title: "三貴子の共鳴", effect: "味方全体の全ステータスが大幅アップ" },
                { target_id: "kaguya_001", title: "月と太陽の双璧", effect: "初期必殺ゲージ大幅増加＋月光・神光ダメージ強化" },
                { target_id: "ok_003", title: "神代と人代の頂", effect: "必殺技必要正解数低下＋回復効果アップ" }
            ]
        };
        const BOSS_RUSH_GOD_UNITS = {
            1: { id: "br_god_01", name: "天鈿女命", gender: "女性", rarity: "神", icon: "fa-sun", description: "世界Lv1ボスラッシュ完全制覇の証。夜を裂き、勝利の幕を開く舞神。", skill: { name: "天岩戸の神楽", effect: "3連続正解時、味方のデバフを浄化し、攻撃速度と必殺加速を上げる。", trigger: "combo3", fx: { cleanse: true, buffSpeed: [35, 12], buffSpecGain: [35, 12] } }, special_move: { name: "暁天招来・神楽ノ舞", effect: "敵全体に神光ダメージ＋味方全体の全ステータス上昇＋回復" }, gaugePerCorrect: 36, gaugeNeedsVotes: 3, synergies: [{ target_id: "kaguya_001", title: "月と岩戸の舞", effect: "必殺技威力大幅アップ" }] },
            2: { id: "br_god_02", name: "須佐之男命", gender: "男性", rarity: "神", icon: "fa-cloud-bolt", description: "世界Lv2制覇で顕現する暴風の軍神。荒ぶる力で道をこじ開ける。", skill: { name: "八岐裂きの気迫", effect: "被弾後、一度だけ敵の攻撃力を削ぎ、自身の攻撃力を引き上げる。", trigger: "afterHit", fx: { enemyAtkDown: [35, 10], buffAtk: [30, 10] } }, special_move: { name: "天羽々斬・荒魂", effect: "敵全体へ荒神の斬撃＋持続ダメージ＋会心" }, gaugePerCorrect: 35, gaugeNeedsVotes: 3, synergies: [{ target_id: "so_005", title: "荒ぶる炎", effect: "会心ダメージアップ" }] },
            3: { id: "br_god_03", name: "月読命", gender: "男性", rarity: "神", icon: "fa-moon", description: "世界Lv3踏破で月より現れる静謐の支配者。時の流れすら眠らせる。", skill: { name: "宵闇の采配", effect: "必殺ゲージが高い正解時、敵の速度を落とし、自身の与ダメージを高める。", trigger: "highGaugeCorrect", fx: { enemySpeedDown: [35, 10], buffDmgUp: [35, 10] } }, special_move: { name: "月詠・千夜封陣", effect: "敵全体に月蝕ダメージ＋行動不能＋攻撃低下" }, gaugePerCorrect: 37, gaugeNeedsVotes: 3, synergies: [{ target_id: "br_god_01", title: "天照らす前夜", effect: "初期必殺ゲージ増加" }] },
            4: { id: "br_god_04", name: "稲荷明神", gender: "女性", rarity: "神", icon: "fa-torii-gate", description: "世界Lv4攻略で豊穣と幸運を授ける守護神。安定感に優れる。", skill: { name: "御饌の加護", effect: "HPが減った状態で正解すると、回復と再生を付与する。", trigger: "lowHpCorrect", fx: { healPct: 0.22, regen: [6, 0.02] } }, special_move: { name: "千本鳥居・福徳開帳", effect: "味方を大きく回復しつつ、防御と全体火力を底上げする。" }, gaugePerCorrect: 34, gaugeNeedsVotes: 3, synergies: [{ target_id: "ok_001", title: "学問と五穀", effect: "正解ダメージアップ" }] },
            5: { id: "br_god_05", name: "大国主神", gender: "男性", rarity: "神", icon: "fa-seedling", description: "世界Lv5を制した者に寄り添う国造りの神。守りと再起に長ける。", skill: { name: "国造りの盟約", effect: "同レアリティの仲間と共に正解した時、結界と防御上昇を得る。", trigger: "sameRarityCorrect", fx: { buffDef: [40, 12], healPct: 0.15 } }, special_move: { name: "葦原中つ国の脈動", effect: "敵全体へ大地の衝撃＋味方へ防御・回復・再生を与える。" }, gaugePerCorrect: 34, gaugeNeedsVotes: 3, synergies: [{ target_id: "br_god_04", title: "国土豊穣", effect: "HP上限大幅アップ" }] },
            6: { id: "br_god_06", name: "弁財天", gender: "女性", rarity: "神", icon: "fa-music", description: "世界Lv6突破の証。流麗な調べで火力と回転率を極限まで高める。", skill: { name: "天女の調べ", effect: "3連続正解時、攻撃力・与ダメージ・必殺加速をまとめて高める。", trigger: "combo3", fx: { buffAtk: [30, 12], buffDmgUp: [35, 12], buffSpecGain: [35, 12] } }, special_move: { name: "八音天河・妙音乱舞", effect: "敵全体へ連続神音ダメージ＋味方全体へ全体強化" }, gaugePerCorrect: 39, gaugeNeedsVotes: 2, synergies: [{ target_id: "se_001", title: "才の極み", effect: "必殺技威力倍増" }] },
            7: { id: "br_god_07", name: "毘沙門天", gender: "男性", rarity: "神", icon: "fa-shield-halved", description: "世界Lv7を踏破した者の前に立つ武神。攻守一体の前線支配者。", skill: { name: "七難即滅", effect: "被弾後、敵の攻勢を削ぎつつ味方の守りを押し上げる。", trigger: "afterHit", fx: { enemyAtkDown: [40, 10], buffDef: [40, 10], cleanse: true } }, special_move: { name: "宝塔・勝鬨連環", effect: "敵全体に豪破ダメージ＋味方に防御・攻撃・結界を展開" }, gaugePerCorrect: 38, gaugeNeedsVotes: 2, synergies: [{ target_id: "br_god_05", title: "守護の双璧", effect: "被ダメージ大幅軽減" }] },
            8: { id: "br_god_08", name: "不動明王", gender: "男性", rarity: "神", icon: "fa-fire", description: "世界Lv8の極地で降臨する不退転の明王。危地でこそ真価を発揮する。", skill: { name: "火生三昧", effect: "HPが減った時に発動し、浄化と全強化、再生を一斉に与える。", trigger: "lowHpHit", fx: { cleanse: true, buffAll: [45, 12], regen: [7, 0.02] } }, special_move: { name: "迦楼羅炎・障魔破断", effect: "敵全体に炎獄ダメージ＋行動不能＋攻撃速度低下" }, gaugePerCorrect: 40, gaugeNeedsVotes: 2, synergies: [{ target_id: "so_003", title: "呪法鎮圧", effect: "状態異常耐性大幅アップ" }] },
            9: { id: "br_god_09", name: "観世音菩薩", gender: "女性", rarity: "神", icon: "fa-hands-praying", description: "世界Lv9を越えた先で救済を示す慈悲の化身。立て直し能力は最高峰。", skill: { name: "大悲の雫", effect: "被弾後、一度だけ味方を大きく回復し、再生と浄化を授ける。", trigger: "afterHit", fx: { healPct: 0.3, regen: [6, 0.025], cleanse: true } }, special_move: { name: "千手慈航・無辺光", effect: "味方を大回復しつつ敵を弱体化、さらに神光で大打撃を与える。" }, gaugePerCorrect: 38, gaugeNeedsVotes: 2, synergies: [{ target_id: "butsu_001", title: "極楽の導き", effect: "回復量と防御力が大幅上昇" }] },
            10: { id: "br_god_10", name: "終ノ神・大和言霊", gender: "女性", rarity: "神", icon: "fa-crown", description: "世界Lv10の無限ボスラッシュを踏破した者だけが得る、本当の終わりを示す禁断の神格。これまでの要素を一身に束ねたチート級の最終到達点。", skill: { name: "万象収束", effect: "3連続正解時、浄化・再生・全強化・必殺加速・敵弱体化を同時展開する。", trigger: "combo3", fx: { healPct: 0.35, cleanse: true, buffAll: [70, 15], buffSpecGain: [70, 15], enemyAtkDown: [35, 12], enemySpeedDown: [35, 12], regen: [7, 0.02] } }, special_move: { name: "終焉開闢・古今無双", effect: "敵全体に超絶ダメージ＋70%回復＋行動不能＋強化＋弱体＋再生＋結界を一括展開" }, gaugePerCorrect: 45, gaugeNeedsVotes: 1, synergies: [{ target_ids: ["butsu_001", "kaguya_001"], title: "真終の三位一体", effect: "初期必殺ゲージ大幅増加＋与ダメージ特大アップ" }, { target_id: "ch_000", title: "人の世の終着", effect: "貴族の攻撃力・最大HP超大幅アップ" }] }
        };
        const BOSS_RUSH_GOD_UNITS_LIST = Object.values(BOSS_RUSH_GOD_UNITS);

