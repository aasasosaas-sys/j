        // ============================================================
        // ★ オンライン対戦 称号システム
        //    公式設定の対戦のみ称号ポイント獲得対象。
        //    勝ち:+30 / 負け:-10（相手の称号が自分より5個以上なら+10）
        //    試合全体で20問以上正解＆30秒以上プレーが条件。200ptで1称号昇格。
        //    称号は「舎人」から始まり律令官位の順に段階的に昇進。
        //    最高称号「太政大臣」到達で神キャラ「天照大御神」解放。
        // ============================================================
        const PVP_TITLES = [
            { name: '舎人', color: '#3E2723', desc: '皇族や貴族の身辺警護・雑務を担う者' },
            { name: '衛士', color: '#455A64', desc: '宮門の警備やエスコートを担う兵士' },
            { name: '主典', color: '#A0522D', desc: '書類作成や実務手続きを担う役人' },
            { name: '判官', color: '#00695C', desc: '各省庁の実務・審理を担当する幹部' },
            { name: '蔵人', color: '#F57F17', desc: '天皇の身の回りの世話と機密を扱う秘書官' },
            { name: '検非違使', color: '#263238', desc: '法の執行と治安を守る警察官' },
            { name: '国司', color: '#2E7D32', desc: '一国の行政と治安を担う地方長官' },
            { name: '陰陽頭', color: '#303F9F', desc: '天文・暦・呪術を司る機関の最高責任者' },
            { name: '大宰権帥', color: '#0D47A1', desc: '九州・大宰府を統轄する地方最高幹部' },
            { name: '近衛中将', color: '#F4511E', desc: '精鋭部隊を率いる花形の武官' },
            { name: '蔵人頭', color: '#D84315', desc: '天皇の側近中の側近。機密文書と勅命を司る長官' },
            { name: '検非違使別当', color: '#212121', desc: '京の治安と警察権を統轄する絶対的最高責任者' },
            { name: '近衛大将', color: '#B71C1C', desc: '皇城を守護する近衛府の最高指揮官' },
            { name: '参議', color: '#512DA8', desc: '宰相とも呼ばれ政務に参画する英傑' },
            { name: '中納言', color: '#7B1FA2', desc: '大納言に次ぎ政務の議定に参加する公卿' },
            { name: '大納言', color: '#4A148C', desc: '国家の大事を審議する最高参謀' },
            { name: '内大臣', color: '#DAA520', desc: '左右大臣に次ぐ重要職。特別なる大臣' },
            { name: '右大臣', color: '#E0E0E0', desc: '左大臣を補佐し政務を統率する重臣' },
            { name: '左大臣', color: '#E65100', desc: '太政官の実質的な最高執政官' },
            { name: '摂政', color: '#9B111E', desc: '幼き帝を支え天下を統率する者' },
            { name: '関白', color: '#800080', desc: '帝に代わり全政務を執る絶対的権力者' },
            { name: '太政大臣', color: '#FFD700', desc: '万官の頂点。国政の最高権威' }
        ];
        const PVP_TITLE_COST = 200;
        const PVP_GOD_UNIT_ID = 'amaterasu_001';
        function pvpTitleCount() { return Math.max(0, Math.min(PVP_TITLES.length, Math.floor(Number(state.pvpTitles) || 0))); }
        function pvpTitleIndex() { return Math.max(0, Math.min(PVP_TITLES.length - 1, pvpTitleCount())); }
        function pvpPoints() { return Math.max(0, Math.floor(Number(state.pvpPoints) || 0)); }
        function pvpPointsToNext() { if (pvpTitleCount() >= PVP_TITLES.length) return 0; return Math.max(0, PVP_TITLE_COST - pvpPoints()); }
        function pvpTitlePanelHtml() {
            const cur = PVP_TITLES[pvpTitleIndex()];
            const earned = pvpTitleCount();
            const isMax = earned >= PVP_TITLES.length;
            const nPanels = PVP_TITLES.map(function (t, i) {
                const got = i < earned;
                return '<div class="text-center rounded-lg px-1 py-1 ' + (got ? '' : 'opacity-40') + '" style="border:1px solid ' + t.color + '55;background:' + t.color + '14">' +
                    '<div class="text-[9px] font-mincho font-black truncate" style="color:' + (got ? t.color : '#9ca3af') + '">' + t.name + '</div></div>';
            }).join('');
            return '<div class="bg-heian-darkpurple border-2 border-heian-gold/50 rounded-2xl p-4 shadow-xl mb-4">' +
                '<div class="flex flex-wrap items-center justify-between gap-2">' +
                '  <div class="flex items-center gap-3">' +
                '    <div class="w-12 h-12 rounded-full flex items-center justify-center text-lg font-black shadow-lg" style="background:linear-gradient(135deg,' + cur.color + '22,' + cur.color + '66);border:2px solid ' + cur.color + ';color:' + cur.color + '">' + earned + '</div>' +
                '    <div><div class="text-[10px] text-amber-200 font-bold tracking-wider">現在の称号</div>' +
                '      <div class="font-mincho font-black text-xl" style="color:' + cur.color + ';text-shadow:0 0 12px ' + cur.color + '88">' + cur.name + '</div>' +
                '      <div class="text-[10px] text-gray-400">' + cur.desc + '</div></div>' +
                '  </div>' +
                '  <div class="text-right">' +
                '    <div class="text-[10px] text-gray-400">対戦ポイント</div>' +
                '    <div class="font-mono font-black text-amber-300 text-lg">' + pvpPoints().toLocaleString() + ' pt</div>' +
                (isMax ? '<div class="text-[10px] text-yellow-300 font-bold">★ 全称号コンプリート！</div>' : '<div class="text-[10px] text-emerald-300 font-bold">次の称号「' + PVP_TITLES[earned].name + '」まで あと ' + pvpPointsToNext().toLocaleString() + ' pt</div>') +
                '  </div>' +
                '</div>' +
                '<div class="mt-3 grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-1.5">' + nPanels + '</div>' +
                '<div class="mt-2 text-[9px] text-gray-500">※ 公式設定の対戦のみポイント獲得対象。勝ち+30 / 負け-10（相手の称号が5個以上上なら+10）／ 試合全体で20問以上正解＆30秒以上プレーで変動。ポイントは0未満になりません。</div>' +
                '</div>';
        }


