        // ============================================================
        // ★ キャラクター図鑑（追加）
        // 全キャラ（貴族・通常ガチャ・追加ガチャ・曜日ガチャ・神ランク）を
        // ランクごとに段落分けして表示。未所持=グレー、所持=ランク色で発光。
        // 未所持の神ランクのみ名前・スキル・必殺を「？？？」で秘匿（入手方法は表示）。
        // ============================================================
        const DEX_RARITY_ORDER = ['神', 'UR', 'SSR', 'SR', 'R', 'N'];
        let dexFilter = 'all';
        function setDexFilter(f) {
            dexFilter = f;
            ['all', 'owned', 'unowned'].forEach(k => {
                const b = document.getElementById('dexFilter' + k.charAt(0).toUpperCase() + k.slice(1));
                if (b) b.classList.toggle('dex-filter-active', k === f);
            });
            renderDexView();
        }
        function dexObtainText(u) {
            if (!u) return '';
            if (u.id === 'ch_000') return '最初から所持している主人公（貴族）。';
            if (u.id === 'kaguya_001') return '「復習の恵みガチャ」で入手（学習の雫30個/1回・確率0.5%・100回で天井確定）。';
            if (u.id === 'butsu_001') return '出家を2回行うと永久所持になる最強キャラ。';
            if (u.id === 'amaterasu_001') return 'オンライン対戦で最高称号「太政大臣」に到達すると入手。';
            if (/^br_god_\d{2}$/.test(u.id || '')) return 'ボスラッシュ 世界Lv' + parseInt(u.id.slice(-2), 10) + '完全制覇の報酬として入手。';
            if (/^n10_/.test(u.id || '')) return '追加ガチャ「古典作者・王朝絵巻」で入手（ダンジョン10完全制覇で解放・5,000文/1回）。';
            if (/^n20_/.test(u.id || '')) return '追加ガチャ「軍記・説話の英傑」で入手（ダンジョン20完全制覇で解放・10,000文/1回）。';
            if (/^wd_(mon|tue|wed|thu|fri)_/.test(u.id || '')) {
                const dayMap = { mon: '月曜ガチャ（月影ポイント1,000で1回）', tue: '火曜ガチャ（火焔ポイント1,000で1回）', wed: '水曜ガチャ（水鏡ポイント1,000で1回）', thu: '木曜ガチャ（古語ポイント1,000で1回）', fri: '金曜ガチャ（鏡像ポイント1,000で1回）' };
                const key = u.id.slice(3, 6);
                return (dayMap[key] || '曜日ガチャ') + 'で入手。対応する曜日ダンジョン(31〜35)クリアでポイント獲得。';
            }
            return 'ガチャ「平安文人 招集」で入手（1,000文/1回・10連10,000文）。';
        }
        function getDexAllUnits() {
            const map = new Map();
            const add = u => { if (u && u.id && !map.has(u.id)) map.set(u.id, u); };
            GACHA_CHARACTERS.forEach(add);
            getNewBannerUnitsFlat().forEach(add);
            getWeekdayUnitsFlat().forEach(add);
            try { add(KAGUYA_UNIT); } catch (e) {}
            try { add(BUTSU_UNIT); } catch (e) {}
            try { add(AMATERASU_UNIT); } catch (e) {}
            try { BOSS_RUSH_GOD_UNITS_LIST.forEach(add); } catch (e) {}
            const noble = getUnit('ch_000');
            if (noble) add(noble);
            return Array.from(map.values());
        }
        function dexShort(text, max) {
            text = text || '';
            return text.length > max ? text.slice(0, max) + '…' : text;
        }
        function renderDexView() {
            const container = document.getElementById('dexContainer');
            if (!container) return;
            const units = getDexAllUnits();
            const badgeCls = {
                神: 'from-amber-300 to-yellow-500 text-black',
                UR: 'from-red-500 to-rose-700 text-white',
                SSR: 'from-amber-400 to-orange-600 text-black',
                SR: 'from-purple-400 to-violet-600 text-white',
                R: 'from-sky-400 to-blue-600 text-white',
                N: 'from-gray-400 to-gray-600 text-white'
            };
            const rankLabelCls = {
                神: 'color:#FFD700;border-color:#FFD700;background:rgba(255,215,0,.12);text-shadow:0 0 8px rgba(255,215,0,.6)',
                UR: 'color:#fca5a5;border-color:#f87171;background:rgba(248,113,113,.10)',
                SSR: 'color:#fcd34d;border-color:#fbbf24;background:rgba(251,191,36,.10)',
                SR: 'color:#c4b5fd;border-color:#a78bfa;background:rgba(167,139,250,.10)',
                R: 'color:#a5d8ff;border-color:#7dd3fc;background:rgba(125,211,252,.08)',
                N: 'color:#cbd5e1;border-color:#9ca3af;background:rgba(156,163,175,.10)'
            };
            let html = '';
            DEX_RARITY_ORDER.forEach(rarity => {
                const list = units.filter(u => (u.rarity || 'N') === rarity);
                if (list.length === 0) return;
                const owned = list.filter(u => state.ownedUnits.includes(u.id)).length;
                if (dexFilter === 'owned' && owned === 0) return;
                if (dexFilter === 'unowned' && owned === list.length) return;
                const shown = list.filter(u => {
                    const isOwned = state.ownedUnits.includes(u.id);
                    if (dexFilter === 'owned') return isOwned;
                    if (dexFilter === 'unowned') return !isOwned;
                    return true;
                });
                if (shown.length === 0) return;
                html += '<div class="mt-4">';
                html += '<div class="dex-rank-header"><span class="dex-rank-label" style="' + (rankLabelCls[rarity] || rankLabelCls.N) + '">ランク ' + rarity + '</span><span class="dex-rank-count">入手 ' + owned + ' / ' + list.length + ' 体</span></div>';
                html += '<div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">';
                shown.forEach(u => {
                    const isOwned = state.ownedUnits.includes(u.id);
                    const isGodHidden = u.rarity === '神' && !isOwned;
                    const nameShow = isGodHidden ? '？？？' : u.name;
                    const descShow = isGodHidden ? '入手すると真の姿が解放されます。' : (u.description || '');
                    const skillS = isGodHidden ? { name: '？？？', effect: '所持すると解放されます。' } : (u.skill || { name: 'なし', effect: 'なし' });
                    const spS = isGodHidden ? { name: '？？？', effect: '所持すると解放されます。' } : (u.special_move || { name: 'なし', effect: 'なし' });
                    const showDetails = !isGodHidden;
                    const genderS = isGodHidden ? '' : genderMark(u);
                    html += '<div class="dex-card ' + (isOwned ? 'dex-owned' : 'dex-unowned') + ' rar-' + rarity + '">';
                    html += '<div class="flex items-start justify-between gap-1 mb-1">';
                    html += '<div class="w-9 h-9 rounded-full bg-black/50 border ' + (isOwned ? 'border-yellow-300/60' : 'border-gray-500/50') + ' flex items-center justify-center text-base shrink-0"><i class="fa-solid ' + (u.icon || 'fa-user') + ' ' + (isOwned ? 'text-amber-300' : 'text-gray-400') + '"></i></div>';
                    html += '<span class="text-[9px] font-bold px-1.5 py-0.5 rounded bg-gradient-to-r ' + (badgeCls[rarity] || badgeCls.N) + '">' + rarity + '</span>';
                    html += '</div>';
                    html += '<div class="font-mincho font-bold text-sm leading-tight ' + (isOwned ? 'text-yellow-100' : 'text-gray-400') + '">' + nameShow + genderS + '</div>';
                    html += '<div class="text-[10px] text-gray-300 leading-snug mt-1">' + dexShort(descShow, 52) + '</div>';
                    html += '<div class="text-[10px] mt-1.5 leading-snug"><span class="text-cyan-300 font-bold">入手:</span> <span class="text-gray-300">' + dexObtainText(u) + '</span></div>';
                    html += '<div class="text-[10px] mt-1 leading-snug"><span class="text-emerald-300 font-bold">所持数:</span> <span class="text-gray-300">' + getOwnedUnitCount(u.id).toLocaleString() + '体</span></div>';
                    if (showDetails) {
                        html += '<div class="text-[10px] mt-1.5 leading-snug"><span class="text-purple-300 font-bold">スキル:</span> <span class="text-gray-300">' + skillS.name + '</span></div>';
                        html += '<div class="text-[9px] text-gray-400 leading-snug">' + dexShort(skillS.effect, 60) + '</div>';
                        html += '<div class="text-[10px] mt-1 leading-snug"><span class="text-amber-300 font-bold">必殺:</span> <span class="text-gray-300">' + spS.name + '</span></div>';
                        html += '<div class="text-[9px] text-gray-400 leading-snug">' + dexShort(spS.effect, 60) + '</div>';
                    } else {
                        html += '<div class="text-[10px] text-purple-300/80 mt-1">スキル・必殺: ？？？</div>';
                    }
                    html += isOwned
                        ? '<div class="dex-tag mt-1.5 inline-block bg-amber-500/20 text-amber-300 border border-amber-500/40">✨ 入手済み</div>'
                        : '<div class="dex-tag mt-1.5 inline-block bg-gray-800 text-gray-500 border border-gray-600">未入手</div>';
                    html += '</div>';
                });
                html += '</div></div>';
            });
            container.innerHTML = html || '<div class="text-center text-gray-400 text-sm py-8">該当するキャラクターがいません。</div>';
        }

