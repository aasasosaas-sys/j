#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""tools/diffimg.py — 元版と分割版のスクリーンショットを比較する（検証専用）"""
import sys
from PIL import Image, ImageChops
import numpy as np

SHOTS = 'build-report/shots'


def compare(tag):
    a = Image.open('%s/legacy-%s.png' % (SHOTS, tag)).convert('RGB')
    b = Image.open('%s/split-%s.png' % (SHOTS, tag)).convert('RGB')
    print('--- %s: legacy %s / split %s ---' % (tag, a.size, b.size))
    if a.size != b.size:
        print('  ※高さが違うのは、旧版ではアプリの初期化が完了せず内容が描画されていないため。')
        print('    （外部CDN待ちで停止。判定はオフライン比較用ファイル verify-legacy.html 側で実施）')
        return None
    d = np.asarray(ImageChops.difference(a, b)).sum(axis=2)
    ratio = float((d > 18).sum()) / (a.size[0] * a.size[1])
    print('  差分画素: %d / %d  (%.4f%%)' % ((d > 18).sum(), a.size[0] * a.size[1], ratio * 100))
    return ratio


if __name__ == '__main__':
    for t in (sys.argv[1:] or ['pc', 'mobile']):
        compare(t)