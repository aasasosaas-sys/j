#!/usr/bin/env node
/**
 * tools/standalone.mjs （検証専用ツール / 配布物ではない）
 *
 * sandbox 内から外部サイトを読み込めないため、比較用の「完全オフライン単一HTML」を2つ作る。
 *   build-report/verify-legacy.html … 元の1ファイル版（Font Awesome は本家フルCSS+フォントを内包）
 *   build-report/verify-standalone.html … 分割後ソース（サブセットCSS+フォントを内包）
 * どちらも Tailwind CDN と Google Fonts は外部参照できない（＝両者同じ条件）ため、
 * この2枚を撮影して差分を取れば「分割・置換による見た目の変化」だけを比較できる。
 *   node tools/standalone.mjs
 */
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';

const OUT_DIR = 'build-report';
mkdirSync(OUT_DIR, { recursive: true });
const b64 = (p) => readFileSync(p).toString('base64');

const FONT_SPLIT = 'src/vendor/webfonts/fa-solid-900.woff2';
const FONT_LEGACY = 'src/vendor/webfonts/fa-solid-900.woff2';
const inlineFonts = (css, fontPath) => css.replace(
  /url\(\s*\.\.\/(?:vendor\/)?webfonts\/fa-solid-900\.woff2\s*\)/g,
  `url(data:font/woff2;base64,${b64(fontPath)})`
);

// ------------------------------------------------------------------ 分割後ソース
{
  let html = readFileSync('src/index.html', 'utf8');
  const jsFiles = [...html.matchAll(/<script src="\.\/js\/([^"]+)"><\/script>/g)].map((m) => m[1]);
  const cssFiles = [...html.matchAll(/<link rel="stylesheet" href="\.\/css\/([^"]+)">/g)].map((m) => m[1]);
  if (!jsFiles.length || !cssFiles.length) throw new Error('src/index.html の参照を解決できませんでした');

  const css = cssFiles
    .map((f) => inlineFonts(readFileSync(`src/css/${f}`, 'utf8'), FONT_SPLIT))
    .join('\n');
  html = html.replace(/[ \t]*<link rel="stylesheet" href="\.\/css\/[^"]+">\n/g, '');
  html = html.replace(/[ \t]*<!--[^\n]*インラインCSSを分離[^\n]*-->\n/g, '');
  html = html.replace('</head>', `<style>\n${css}\n</style>\n</head>`);  // 元CSSと同じ位置＝カスケード不変

  const js = jsFiles
    .map((f) => readFileSync(`src/js/${f}`, 'utf8').replace(/<\/script/gi, '<\\/script'))
    .join('\n');
  let done = false;
  html = html.replace(/[ \t]*<script src="\.\/js\/[^"]+"><\/script>\n/g, () => {
    if (done) return '';
    done = true;
    return `<script>\n${js}</script>\n`;
  });
  html = html.replace(/[ \t]*<script type="module" src="https:\/\/static\.cloudflareinsights\.com[^\n]*\n/g, '');
  writeFileSync(`${OUT_DIR}/verify-standalone.html`, html);
  console.log(`verify-standalone.html : JS ${jsFiles.length} + CSS ${cssFiles.length} を内包 / ${(Buffer.byteLength(html) / 1024).toFixed(1)}KB`);
}

// ------------------------------------------------------------------ 元の1ファイル版
{
  let html = readFileSync('legacy/index7.html', 'utf8');
  const FA_LINK = '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">';
  if (!html.includes(FA_LINK)) throw new Error('Font Awesome の CDN リンクが見つかりません');
  const faCss = inlineFonts(readFileSync('vendor/fa-all.min.css', 'utf8'), FONT_LEGACY);
  html = html.replace(FA_LINK, `<style>${faCss}</style>`);
  html = html.replace(/[ \t]*<script type="module" src="https:\/\/static\.cloudflareinsights\.com[^\n]*\n/g, '');
  writeFileSync(`${OUT_DIR}/verify-legacy.html`, html);
  console.log(`verify-legacy.html     : 本家フルCSS(${faCss.length}B)を内包 / ${(Buffer.byteLength(html) / 1024).toFixed(1)}KB`);
}
