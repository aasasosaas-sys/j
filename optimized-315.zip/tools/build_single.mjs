#!/usr/bin/env node
/**
 * tools/build_single.mjs
 * dist/ の中身（最小化済み）を1ファイルに内包し、dist-single/index.html を作る。
 * 配信先が「単一HTMLを置くだけ」の環境でも、同じ分割ソースから軽量版を出せるようにするため。
 * CSS / JS / Font Awesome の woff2 は data URI で内包（＝アイコン欠けが起きない）。
 *   node tools/build_single.mjs
 */
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import * as htmlMinNS from 'html-minifier-terser';

const htmlMinify = htmlMinNS.minify || (htmlMinNS.default && htmlMinNS.default.minify);
if (typeof htmlMinify !== 'function') throw new Error('html-minifier-terser を解決できません');

let html = readFileSync('dist/index.html', 'utf8');
const fontPath = 'dist/vendor/webfonts/fa-solid-900.woff2';
if (!existsSync(fontPath)) throw new Error('同梱フォントがありません: ' + fontPath);
const fontB64 = readFileSync(fontPath).toString('base64');

const cssFiles = [...html.matchAll(/<link rel="stylesheet" href="\.\/css\/([^"]+)">/g)].map((m) => m[1]);
const jsFiles = [...html.matchAll(/<script src="\.\/js\/([^"]+)"><\/script>/g)].map((m) => m[1]);
if (!cssFiles.length || !jsFiles.length) throw new Error('dist/index.html の参照を解決できませんでした');

const css = cssFiles
  .map((f) => readFileSync('dist/css/' + f, 'utf8').replace(
    /url\(\.\.\/vendor\/webfonts\/fa-solid-900\.woff2\)/g,
    `url(data:font/woff2;base64,${fontB64})`))
  .join('\n');

html = html.replace(/[ \t]*<link rel="stylesheet" href="\.\/css\/[^"]+">\n/g, '');
html = html.replace(/[ \t]*<!--[^\n]*インラインCSSを分離[^\n]*-->\n/g, '');
html = html.replace('</head>', `<style>${css}</style></head>`);   // 元CSSと同じ位置＝カスケード不変

const js = jsFiles
  .map((f) => readFileSync('dist/js/' + f, 'utf8').replace(/<\/script/gi, '<\\/script'))
  .join('\n');
let inlined = false;
html = html.replace(/[ \t]*<script src="\.\/js\/[^"]+"><\/script>\n/g, () => {
  if (inlined) return '';
  inlined = true;
  return `<script>${js}</script>\n`;
});

// 解析ビーコンは単一ファイル版では不要（見た目・挙動に無関係）
html = html.replace(/[ \t]*<script type="module" src="https:\/\/static\.cloudflareinsights\.com[^\n]*\n/g, '');

const out = await htmlMinify(html, {
  collapseWhitespace: 'conservative',
  conservativeCollapse: true,
  removeComments: true,
  minifyCSS: false,
  minifyJS: false,
  removeOptionalTags: false,
  removeRedundantAttributes: false,
  removeAttributeQuotes: false,
  keepClosingSlash: true,
  caseSensitive: true,
  sortAttributes: false,
  sortClassName: false,
  useShortDoctype: false,
});
mkdirSync('dist-single', { recursive: true });
writeFileSync('dist-single/index.html', out);
console.log(`dist-single/index.html: ${(Buffer.byteLength(out) / 1024).toFixed(1)}KB` +
  `  (CSS ${cssFiles.length} + JS ${jsFiles.length} + woff2 を内包した単一ファイル)`);