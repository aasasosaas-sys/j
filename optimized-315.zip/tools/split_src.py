#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
tools/split_src.py
単一ファイル版 (legacy/index7.html) を、見た目・挙動を変えずに
  src/index.html / src/css/theme.css / src/js/*.js
へ分割する。

設計:
  * JS は元の1つの <script> を機能単位に切るだけ。グローバルスコープ・実行順は不変。
  * 切断位置は「前後の断片がそれぞれ単体で構文として成立する」ことを
    node --check で実際に判定し、成立しない候補は次の候補へ吸収合併する。
    （元コードのネット対戦層は巨大な IIFE に包まれており、
      「切れて見えるが切ると壊れる」境界が実在するため、この実測判定が必要）
  * 分割結果は「全ファイルを連結すると元テキストと完全一致」でも検証する。

  python3 tools/split_src.py
"""
import os
import re
import subprocess
import sys

LEGACY = os.environ.get('LEGACY_HTML', 'legacy/index7.html')
OUTDIR = os.environ.get('SRC_DIR', 'src')
REPORTDIR = 'build-report'
TMPFRAG = os.path.join(REPORTDIR, '_frag.js')

HEAD = (1, 39)
STYLE = (41, 744)
BODY = (746, 1513)
JS_BODY = (1515, 14844)
BEACONS = (14846, 14859)

# 「ここまでで1区間にしたい」候補（この行で最初に切る。切れなければ次へ吸収）
RAW_CUTS = [
    (1642, 'audio-fx'),
    (5234, 'gacha-characters'),
    (5301, 'pvp-titles'),
    (5732, 'achievements'),
    (6124, 'synergies-extra'),
    (6366, 'stage-unlock'),
    (7043, 'formations'),
    (7166, 'dex'),
    (7477, 'gem-lottery'),
    (7659, 'gacha-animation'),
    (8319, 'stage-explain-enemy-stats'),
    (9991, 'weekday-dungeons'),
    (10586, 'special-move-fx'),
    (10945, 'data-migration-settings'),
    (11223, 'boss-rush'),
    (12058, 'p2p-hybrid'),
    (13839, 'p2p-battle'),
    (14844, 'pvp-titles-apply-init'),
]
# ネットワーク同期系の区間（タブ非表示でも停止してはいけない）
NETWORK_LABELS = {'p2p-hybrid', 'p2p-battle', 'pvp-titles-apply-init'}
MERGED_NAME = 'p2p-online'

FA_LINK = '    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">\n'
GF_LINK = ('    <link href="https://fonts.googleapis.com/css2?family=Shippori+Mincho:wght@500;700;800'
           '&family=Zen+Kaku+Gothic+New:wght@400;600;700&display=swap" rel="stylesheet">\n')

INJECT = (
    '    <!-- ★軽量改修: フォント配信元への接続を事前確立（見た目は不変・表示速度のみ） -->\n'
    '    <link rel="preconnect" href="https://fonts.googleapis.com">\n'
    '    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n'
    '    <link rel="dns-prefetch" href="https://fonts.googleapis.com">\n'
    '    <link rel="dns-prefetch" href="https://fonts.gstatic.com">\n'
    '    <link rel="dns-prefetch" href="https://cdn.tailwindcss.com">\n'
    '    <!-- ★軽量改修: Font Awesome は「使用アイコンのみ」のサブセットCSSを同梱（CDN往復を削減） -->\n'
    '    <link rel="stylesheet" href="./css/vendor-fontawesome-subset.css">\n'
    + GF_LINK +
    '    <!-- ★軽量改修: インラインCSSを分離（内容は完全に同一） -->\n'
    '    <link rel="stylesheet" href="./css/theme.css">\n'
)


# ------------------------------------------------------------------ 字句スキャナ
def _skip_string(s, i):
    q = s[i]
    i += 1
    while i < len(s):
        if s[i] == '\\':
            i += 2
            continue
        if s[i] == q:
            return i + 1
        i += 1
    return len(s)


def _skip_line_comment(s, i):
    j = s.find('\n', i)
    return len(s) if j < 0 else j


def _skip_block_comment(s, i):
    j = s.find('*/', i + 2)
    return len(s) if j < 0 else j + 2


_PREFIX_OK = set("(,=:[!&|?{};+-*%~^<>")


def _skip_regex(s, i):
    i += 1
    in_class = False
    while i < len(s):
        c = s[i]
        if c == '\\':
            i += 2
            continue
        if c == '[':
            in_class = True
        elif c == ']':
            in_class = False
        elif c == '/' and not in_class:
            return i + 1
        elif c == '\n':
            return i
        i += 1
    return len(s)


def scan_template(s, i):
    if i >= len(s) or s[i] != '`':
        return None
    i += 1
    depth = 0
    n = len(s)
    while i < n:
        c = s[i]
        if c == '\\':
            i += 2
            continue
        if depth == 0:
            if c == '`':
                return i + 1
            if c == '$' and i + 1 < n and s[i + 1] == '{':
                depth += 1
                i += 2
                continue
            i += 1
        else:
            if c == '{':
                depth += 1
                i += 1
            elif c == '}':
                depth -= 1
                i += 1
            elif c == '`':
                j = scan_template(s, i)
                if j is None:
                    return None
                i = j
            elif c in '"\'':
                i = _skip_string(s, i)
            elif c == '/' and i + 1 < n and s[i + 1] == '/':
                i = _skip_line_comment(s, i)
            elif c == '/' and i + 1 < n and s[i + 1] == '*':
                i = _skip_block_comment(s, i)
            elif c == '/':
                prev = s[i - 1] if i else ''
                i = _skip_regex(s, i) if prev in _PREFIX_OK else i + 1
            else:
                i += 1
    return None


RE_ASSIGN = re.compile(r'([A-Za-z_$][A-Za-z0-9_$.]*)\.innerHTML\s*=\s*')
RE_EMPTY = re.compile(r'([A-Za-z_$][A-Za-z0-9_$.]*)\.innerHTML\s*=\s*(""|\'\')\s*;')


def patch_inner_html(text, stats):
    """`X.innerHTML = `...`;` → `__PERF.setHTML(X, `...`);`
       描画結果は完全に同一（同一のHTMLを同じ要素へ設定する）。安全側に、
       テンプレート1個だけの単文のみを対象に限定する。"""
    out, pos = [], 0
    while True:
        m = RE_ASSIGN.search(text, pos)
        if not m:
            out.append(text[pos:])
            break
        i = m.end()
        end = scan_template(text, i) if (i < len(text) and text[i] == '`') else None
        if end is not None and end < len(text) and text[end] == ';':
            out.append(text[pos:m.start()])
            out.append('__PERF.setHTML(%s, %s);' % (m.group(1), text[i:end]))
            pos = end + 1
            stats['template'] += 1
        else:
            out.append(text[pos:m.end()])
            pos = m.end()
            stats['left'] += 1
    text = ''.join(out)

    def _empty(m):
        stats['empty'] += 1
        return '__PERF.setHTML(%s, "");' % m.group(1)

    return RE_EMPTY.sub(_empty, text)


def parses(code):
    """node --check による実測判定（ブラウザと同じ構文規則で判定する）"""
    os.makedirs(REPORTDIR, exist_ok=True)
    with open(TMPFRAG, 'w', encoding='utf-8') as f:
        f.write(code)
    return subprocess.run(['node', '--check', TMPFRAG], capture_output=True).returncode == 0


def main():
    if not os.path.exists(LEGACY):
        sys.exit('legacy HTML not found: %s' % LEGACY)
    lines = open(LEGACY, encoding='utf-8').read().splitlines(keepends=True)

    def seg(a, b):
        return ''.join(lines[a - 1:b])

    for line, want in [(40, '<style>'), (745, '</style>'), (746, '</head>'),
                       (1514, '<script>'), (14845, '</script>'), (14861, '</html>')]:
        assert seg(line, line).strip() == want, 'line %d is not %s' % (line, want)

    os.makedirs(os.path.join(OUTDIR, 'js'), exist_ok=True)
    os.makedirs(os.path.join(OUTDIR, 'css'), exist_ok=True)
    for f in os.listdir(os.path.join(OUTDIR, 'js')):
        # 00-perf.js は手書きのヘルパなので残す
        if re.match(r'^\d\d-.*\.js$', f) and f != '00-perf.js':
            os.remove(os.path.join(OUTDIR, 'js', f))

    report = []

    # ---------------- CSS ----------------
    css = seg(*STYLE)
    with open(os.path.join(OUTDIR, 'css', 'theme.css'), 'w', encoding='utf-8') as f:
        f.write(css)
    report.append('css/theme.css                      %7d bytes  元の <style> と完全一致' % len(css.encode()))

    # ---------------- 候補区間 ----------------
    naive, prev = [], JS_BODY[0] - 1
    for cut, label in RAW_CUTS:
        naive.append([prev + 1, cut, label, [label]])
        prev = cut
    assert naive[-1][1] == JS_BODY[1]

    # ---------------- 実測で「切れる境界」だけ採用（切れない区間は吸収合併） ----------------
    body_raw = {tuple(s[:2]): seg(s[0], s[1]) for s in naive}
    for s in naive:
        s.append(body_raw[(s[0], s[1])])          # s[4] = 原文
        s.append(parses(s[4]))                    # s[5] = 単体で構文成立するか

    merges = 0
    guard = 0
    while guard < len(RAW_CUTS) + 5:
        guard += 1
        bad = next((k for k, s in enumerate(naive) if not s[5]), None)
        if bad is None:
            break
        merges += 1
        if bad + 1 < len(naive):                       # 次の区間と統合
            a, b = naive[bad], naive[bad + 1]
            merged = [a[0], b[1], b[2], a[3] + b[3], seg(a[0], b[1])]
            merged.append(parses(merged[4]))
            naive[bad:bad + 2] = [merged]
        elif bad > 0:                                  # 最終区間が不正 → 直前と統合
            a, b = naive[bad - 1], naive[bad]
            merged = [a[0], b[1], b[2], a[3] + b[3], seg(a[0], b[1])]
            merged.append(parses(merged[4]))
            naive[bad - 1:bad + 1] = [merged]
        else:
            break
    sections = naive

    # ---------------- ファイル化 ----------------
    js_original = seg(*JS_BODY)
    joined = ''.join(s[4] for s in sections)
    assert joined == js_original, 'split不整合: %d != %d' % (len(joined), len(js_original))

    total = {'template': 0, 'empty': 0, 'left': 0}
    files = []
    for idx, (a, b, label, labels, body, ok) in enumerate(sections, 1):
        assert ok, '区間が構文として成立していません: %s' % label
        is_net = any(l in NETWORK_LABELS for l in labels)
        name = label if len(labels) == 1 else MERGED_NAME
        stats = {'template': 0, 'empty': 0, 'left': 0}
        fixed = patch_inner_html(body, stats)
        for k in stats:
            total[k] += stats[k]
        note = ''
        if is_net:
            n = fixed.count('setInterval(')
            fixed = fixed.replace('setInterval(', '__PERF.keepAliveInterval(')
            note = '  [ネット同期系: setInterval %d 箇所を停止対象外]' % n
        assert parses(fixed), 'パッチ後の区間が構文として成立していません: %s' % name
        fn = '%02d-%s.js' % (idx, name)
        with open(os.path.join(OUTDIR, 'js', fn), 'w', encoding='utf-8') as f:
            f.write(fixed)
        files.append(fn)
        report.append('js/%-33s %5d 行 %8d bytes  元 %d-%d 行  setHTML化=%d(保留%d)%s'
                      % (fn, body.count('\n') + 1, len(fixed.encode()), a, b,
                         stats['template'] + stats['empty'], stats['left'], note))

    # ---------------- HTML ----------------
    head = seg(*HEAD)
    assert FA_LINK in head and GF_LINK in head, 'CDNリンク行が見つかりません'
    head = head.replace(FA_LINK, '').replace(GF_LINK, '')
    head = head.replace('    <!-- FontAwesome icons -->\n',
                        '    <!-- FontAwesome icons（使用アイコンのみのサブセットを同梱） -->\n')

    scripts = ('    <!-- ★軽量改修: 巨大な1つの<script>を機能単位に分割'
               '（グローバルスコープ・実行順は元と同一） -->\n')
    scripts += '    <script src="./js/00-perf.js"></script>\n'
    for f in files:
        scripts += '    <script src="./js/%s"></script>\n' % f

    uniq, seen = [], set()
    for ln in seg(*BEACONS).splitlines(keepends=True):
        k = ln.strip()
        if not k or k in seen:
            continue
        seen.add(k)
        uniq.append(ln)

    html_out = head + INJECT + seg(*BODY) + '\n' + scripts + ''.join(uniq) + '\n</body>\n</html>\n'
    assert 'tailwind.config' in html_out
    assert 'id="dungeonGrid"' in html_out and 'id="customDialogModal"' in html_out
    with open(os.path.join(OUTDIR, 'index.html'), 'w', encoding='utf-8') as f:
        f.write(html_out)

    report.append('index.html                         %7d bytes  script=%d本 / beacon重複除去 %d行→%d行'
                  % (len(html_out.encode()), len(files) + 1,
                     len(seg(*BEACONS).splitlines()), len(uniq)))
    report.append('')
    report.append('分割の完全一致検証   : OK (%d bytes == 元 %d bytes)' % (len(joined.encode()), len(js_original.encode())))
    report.append('各断片の構文検証     : OK (全 %d ファイルが node --check を通過＝単体で実行可能)' % len(files))
    report.append('境界の実測調整       : 候補 %d → %d 区間（%d 回の吸収合併、切ると壊れる境界を回避）'
                  % (len(RAW_CUTS), len(sections), merges))
    report.append('innerHTML → setHTML  : テンプレート%d件 / クリア%d件 / 保留%d件（保留は無改変）'
                  % (total['template'], total['empty'], total['left']))
    with open(os.path.join(REPORTDIR, 'split-report.txt'), 'w', encoding='utf-8') as f:
        f.write('\n'.join(report) + '\n')
    print('\n'.join(report))


if __name__ == '__main__':
    main()