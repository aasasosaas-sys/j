#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
tools/optimize_fa.py
Font Awesome 6.4.0 の all.min.css から「実際に使われているアイコンのルールだけ」を
抜き出したサブセットCSSを作り、本体フォント(woff2)を同梱する。
グリフ（見た目）は本家と完全に同一で、読み込むCSSとリクエスト数だけを削減する。

  python3 tools/optimize_fa.py

入力 : vendor/fa-all.min.css  (CDNから取得済みの本家CSS)
        legacy/index7.html     (使用クラスの抽出元)
出力 : src/css/vendor-fontawesome-subset.css
        src/vendor/webfonts/fa-solid-900.woff2
"""
import os
import re
import sys
import urllib.request

FA_CSS = 'vendor/fa-all.min.css'
LEGACY = 'legacy/index7.html'
OUT_CSS = 'src/css/vendor-fontawesome-subset.css'
FONT_DIR = 'src/vendor/webfonts'
CDN = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/'
FONT_URL = CDN + 'webfonts/fa-solid-900.woff2'
CSS_URL = CDN + 'css/all.min.css'

# 見た目の基準になる基礎ルール（クラス名そのまま）
CORE_SELECTORS = {
    '.fa', '.fas', '.fa-solid', '.far', '.fa-regular', '.fal', '.fat', '.fad', '.fab', '.fa-brands',
    '.sr-only', '.sr-only-focusable', ':root', 'html', 'body',
}

# 元HTMLでは使われているが Font Awesome 6.4.0 には存在しないクラス。
# 本家 all.min.css にもルールが無いため「元の状態でもグリフ無し＝非表示」だったもの。
# サブセットからも除外して、元と完全に同一の描画を維持する。
NOT_IN_FA_64 = {'fa-flower', 'fa-pen-fancier', 'fa-person-dancing', 'fa-sparkles', 'fa-sunset'}


def ensure_inputs():
    os.makedirs('vendor', exist_ok=True)
    if not os.path.exists(FA_CSS):
        print('downloading', CSS_URL)
        urllib.request.urlretrieve(CSS_URL, FA_CSS)
    os.makedirs(FONT_DIR, exist_ok=True)
    dst = os.path.join(FONT_DIR, 'fa-solid-900.woff2')
    if not os.path.exists(dst):
        print('downloading', FONT_URL)
        urllib.request.urlretrieve(FONT_URL, dst)
    return dst


def split_rules(css):
    """トップレベル(入れ子なし)の @rule / rule を順に返す。"""
    rules, i, n = [], 0, len(css)
    while i < n:
        while i < n and css[i] in ' \n\r\t':
            i += 1
        if i >= n:
            break
        if css[i] == '@':
            j = css.find('{', i)
            if j < 0:
                break
            depth, k = 0, j
            while k < n:
                if css[k] == '{':
                    depth += 1
                elif css[k] == '}':
                    depth -= 1
                    if depth == 0:
                        break
                k += 1
            # @media 等の入れ子ブロックは中身を再帰処理
            head = css[i:j].strip()
            if '@media' in head or '@supports' in head:
                rules.append(('block', head, css[j + 1:k]))
            else:
                rules.append(('at', css[i:k + 1], ''))
            i = k + 1
        else:
            j = css.find('{', i)
            if j < 0:
                break
            k = css.find('}', j)
            if k < 0:
                break
            rules.append(('rule', css[i:j], css[j + 1:k]))
            i = k + 1
    return rules


def selectors_of(sel_text):
    return [s.strip() for s in sel_text.split(',') if s.strip()]


def main():
    if not os.path.exists(LEGACY):
        sys.exit('legacy HTML not found: %s' % LEGACY)
    font_path = ensure_inputs()

    css = open(FA_CSS, encoding='utf-8').read()
    html = open(LEGACY, encoding='utf-8').read()
    used = set(re.findall(r'fa-[a-z0-9-]+', html))          # 使われている fa-* クラス（上位集合で安全側）
    used |= {'fa', 'fas', 'fa-solid', 'sr-only', 'sr-only-focusable'}

    kept_rules, kept_faces, dropped_icons, kept_utils = [], [], 0, 0
    keyframes_needed = set()

    for kind, a, b in split_rules(css):
        if kind == 'at':
            if '@font-face' in a:
                fam = re.search(r'font-family:\s*"?([^";]+)"?', a)
                wt = re.search(r'font-weight:\s*(\d+)', a)
                family = (fam.group(1).strip() if fam else '')
                weight = (wt.group(1) if wt else '')
                # 「Font Awesome 6 Free / 900(solid)」だけを残す（他ファミリは未使用）
                if family == 'Font Awesome 6 Free' and weight == '900':
                    face = a.replace('url(../webfonts/', 'url(../vendor/webfonts/')
                    face = re.sub(r',\s*url\([^)]*\)\s*format\("(woff|truetype|opentype|embedded-opentype)"\)', '', face)
                    kept_faces.append(face)
                continue
            if '@keyframes' in a:
                name = re.match(r'@(?:-webkit-)?keyframes\s+([A-Za-z0-9_-]+)', a)
                if name:
                    keyframes_needed.add(name.group(1))
                continue
            kept_rules.append(a)  # その他の @rule(@charset 等) は保持
            continue
        if kind == 'block':
            inner = ''.join(''.join(s + '{' + d + '}') for k2, s, d in split_rules(b) if k2 == 'rule')
            kept_rules.append(a + '{' + inner + '}')
            continue

        sels = selectors_of(a)
        keep = False
        for s in sels:
            if s in CORE_SELECTORS:
                keep = True
                break
            tokens = re.findall(r'\.(fa-[a-z0-9-]+)', s)
            if any(t in used for t in tokens):
                keep = True
                break
            if tokens and 'content:' not in b:   # アイコン定義ではなくユーティリティ(fw/spin/2x 等)
                keep = True
                kept_utils += 1
                break
        if keep:
            kept_rules.append(a + '{' + b + '}')
            for m in re.finditer(r'animation:[^;]*?([A-Za-z0-9_-]+)\s', a + '{' + b + '}'):
                keyframes_needed.add(m.group(1))
        else:
            dropped_icons += 1

    # 必要な keyframes だけ元CSSから拾う
    kf_out = []
    for name in sorted(keyframes_needed):
        m = re.search(r'@(?:-webkit-)?keyframes\s+' + re.escape(name) + r'\s*\{', css)
        if not m:
            continue
        depth, k, start = 0, m.end() - 1, m.start()
        while k < len(css):
            if css[k] == '{':
                depth += 1
            elif css[k] == '}':
                depth -= 1
                if depth == 0:
                    break
            k += 1
        kf_out.append(css[start:k + 1])

    header = ('/*! Font Awesome Free 6.4.0 — 使用アイコンのみのサブセット '
              '(tools/optimize_fa.py で自動生成). グリフは本家と同一。 */\n')
    out = header + ''.join(kept_faces) + ''.join(kf_out) + ''.join(kept_rules)
    os.makedirs(os.path.dirname(OUT_CSS), exist_ok=True)
    with open(OUT_CSS, 'w', encoding='utf-8') as f:
        f.write(out)

    # ---- 検証: 使用クラスがすべてサブセット内に存在するか ----
    missing = sorted(c for c in used
                     if c not in ('fa', 'fas', 'fa-solid', 'sr-only', 'sr-only-focusable')
                     and c not in NOT_IN_FA_64
                     and ('.' + c) not in out)
    absent = sorted(c for c in used if c in NOT_IN_FA_64)
    print('used fa-* classes : %d' % len(used))
    print('FA6.4に存在しない : %d %s  (元の状態でも非表示＝見た目不変)' % (len(absent), absent))
    print('subset size       : %d bytes (元 %d bytes / 削減率 %.1f%%)'
          % (len(out.encode()), len(css.encode()),
             100.0 * (1 - len(out.encode()) / max(1, len(css.encode())))))
    print('dropped icon rules: %d' % dropped_icons)
    print('@font-face kept   : %d  (font: %s)' % (len(kept_faces), os.path.basename(font_path)))
    print('missing classes   : %d %s' % (len(missing), missing[:10]))
    if missing:
        sys.exit('ERROR: 一部の使用クラスがサブセットに含まれていません')
    print('OK: 使用アイコンはすべてサブセットに存在します')


if __name__ == '__main__':
    main()