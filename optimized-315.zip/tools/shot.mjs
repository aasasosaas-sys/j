#!/usr/bin/env node
/**
 * tools/shot.mjs （検証専用 / 配布物ではない）
 * 元の1ファイル版とビルド済み版を同一条件でスクリーンショットし、
 * 画素レベルの差分量を計測する。要: playwright + chromium。
 *   node tools/shot.mjs
 * 出力: build-report/shots/*.png と差分レポート（標準出力）
 */
import { chromium } from 'playwright';
import { mkdirSync, writeFileSync, existsSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';

const OUT = 'build-report/shots';
mkdirSync(OUT, { recursive: true });

const targets = [
  { name: 'legacy', url: 'file:///home/user/work/build-report/verify-legacy.html' },
  { name: 'split', url: 'file:///home/user/work/build-report/verify-standalone.html' },
];
const viewports = [
  { tag: 'pc', width: 1280, height: 900 },
  { tag: 'mobile', width: 390, height: 844 },
];

const browser = await chromium.launch({ args: ['--allow-file-access-from-files', '--no-sandbox'] });
const results = [];

for (const vp of viewports) {
  for (const t of targets) {
    const ctx = await browser.newContext({ viewport: { width: vp.width, height: vp.height }, deviceScaleFactor: 1 });
    const page = await ctx.newPage();
    const errors = [];
    page.on('pageerror', (e) => errors.push(String(e.message).slice(0, 120)));
    page.on('requestfailed', (r) => errors.push('reqfail:' + r.url().slice(0, 80)));
    await page.goto(t.url, { waitUntil: 'load', timeout: 60000 }).catch((e) => errors.push('goto:' + e.message));
    await page.waitForTimeout(2500);
    const file = `${OUT}/${t.name}-${vp.tag}.png`;
    await page.screenshot({ path: file, fullPage: true });
    const info = await page.evaluate(() => {
      const cnt = (s) => document.querySelectorAll(s).length;
      const faOk = (function () {
        try {
          const probe = document.createElement('i');
          probe.className = 'fa-solid fa-scroll';
          probe.style.position = 'absolute';
          document.body.appendChild(probe);
          const cs = getComputedStyle(probe, '::before');
          const fam = cs.fontFamily;
          const content = cs.content;
          probe.remove();
          return fam + '|' + content.slice(0, 12);
        } catch (e) { return 'err'; }
      })();
      return {
        title: document.title,
        bodyBg: getComputedStyle(document.body).backgroundColor,
        bodyFont: getComputedStyle(document.body).fontFamily,
        heianCardBg: (function () {
          const el = document.querySelector('.bg-heian-card');
          return el ? getComputedStyle(el).backgroundColor : 'none';
        })(),
        buttons: cnt('button'),
        icons: cnt('i'),
        faProbe: faOk,
        docH: document.documentElement.scrollHeight,
        innerHTMLCount: (window.__PERF && window.__PERF.stats) ? window.__PERF.stats.htmlWrites : null,
        skipped: (window.__PERF && window.__PERF.stats) ? window.__PERF.stats.htmlSkips : null,
        perf: !!window.__PERF,
      };
    }).catch((e) => ({ err: e.message }));
    results.push({ who: `${t.name}-${vp.tag}`, file, info, errors: errors.slice(0, 6), errCount: errors.length });
    await ctx.close();
  }
}
await browser.close();

// PNG ハッシュ + 画素数差分
function diff(a, b) {
  try {
    const py = `from PIL import Image, ImageChops
import sys
a=Image.open(sys.argv[1]).convert('RGB'); b=Image.open(sys.argv[2]).convert('RGB')
print('sizeA', a.size, 'sizeB', b.size)
if a.size!=b.size: a=a.resize(b.size)
d=ImageChops.difference(a,b); bbox=d.getbbox()
tot=b.size[0]*b.size[1]
import numpy as np
arr=np.asarray(d).sum(axis=2)
print('diff_pixels', int((arr>18).sum()), 'ratio', round(float((arr>18).sum())/tot,5), 'bbox', bbox)`;
    writeFileSync('/tmp/pixdiff.py', py);
    return execFileSync('python3', ['/tmp/pixdiff.py', a, b], { encoding: 'utf8' }).trim();
  } catch (e) { return 'diff計算不可: ' + e.message.slice(0, 80); }
}

for (const r of results) {
  console.log(`--- ${r.who} ---`);
  console.log('  ' + JSON.stringify(r.info));
  console.log('  参照: ' + r.file);
  console.log('  エラー' + r.errCount + ': ' + JSON.stringify(r.errors));
  if (existsSync(r.file)) {
    console.log('  sha256: ' + createHash('sha256').update(readFileSync(r.file)).digest('hex').slice(0, 16) +
      '  size: ' + readFileSync(r.file).length + 'B');
  }
}
for (const vp of viewports) {
  console.log(`=== 画素比較 ${vp.tag} (legacy -> split) ===`);
  console.log('  ' + diff(`${OUT}/legacy-${vp.tag}.png`, `${OUT}/split-${vp.tag}.png`));
}
