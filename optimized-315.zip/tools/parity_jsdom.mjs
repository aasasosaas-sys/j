#!/usr/bin/env node
/**
 * tools/parity_jsdom.mjs  (検証用・ビルドには不要 / 要: npm i --no-save jsdom)
 *
 * 元の1ファイル版の <script> 本体と、分割後の src/js/*.js を
 * 同一の DOM 上で順に実行し、
 *   ・発生したエラー（種類・メッセージ）
 *   ・グローバル(window)プロパティの集合と型
 *   ・主要データ配列の長さ
 * を比較する。一致すれば「分割でスコープや読み込み順が壊れていない」強い証拠になる。
 */
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';

let JSDOM;
try {
  ({ JSDOM } = await import('jsdom'));
} catch {
  console.log('[skip] jsdom がインストールされていないため parity テストを省略します');
  process.exit(0);
}

const LEGACY = 'legacy/index7.html';
const SRC_JS = 'src/js';
const HEAD = 39, BODY_START = 746, BODY_END = 1513, JS_START = 1515, JS_END = 14844;

const lines = readFileSync(LEGACY, 'utf8').split(/(?<=\n)/);
const seg = (a, b) => lines.slice(a - 1, b).join('');

const html = seg(1, HEAD) + seg(BODY_START, BODY_END) + '\n</body>\n</html>\n';
const singleJs = seg(JS_START, JS_END);
const splitJs = readdirSync(SRC_JS).filter((f) => f.endsWith('.js')).sort()
  .map((f) => [f, readFileSync(join(SRC_JS, f), 'utf8')]);

const STUBS = `
  window.requestIdleCallback = window.requestIdleCallback || function (cb) { return setTimeout(function(){ cb({didTimeout:false,timeRemaining:function(){return 5;}}); }, 0); };
  window.AudioContext = window.AudioContext || function(){ throw new Error('no-audio'); };
  window.RTCPeerConnection = window.RTCPeerConnection || function(){ throw new Error('no-webrtc'); };
  if (window.HTMLCanvasElement) window.HTMLCanvasElement.prototype.getContext = function(){ return null; };
`;

async function run(label, snippets, order) {
  const errors = [];
  const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true, url: 'https://example.test/' });
  const { window } = dom;
  window.addEventListener('error', (e) => errors.push('error:' + (e.message || e.error)));
  const origErr = window.console.error;
  window.console.error = (...a) => { errors.push('console.error:' + String(a[0])); };
  const inject = (code) => {
    const s = window.document.createElement('script');
    s.textContent = code;
    window.document.body.appendChild(s);
  };
  inject(STUBS);
  try {
    if (order === 'single') inject(snippets);
    else for (const [, code] of snippets) inject(code);
  } catch (e) {
    errors.push('throw:' + e.message);
  }
  await new Promise((r) => setTimeout(r, 300));

  const props = Object.getOwnPropertyNames(window).filter((k) => /^[A-Za-z_$]/.test(k)).sort();
  const types = {};
  for (const k of props) { try { types[k] = typeof window[k]; } catch { types[k] = 'throw'; } }
  const probes = {};
  for (const k of ['GACHA_CHARACTERS', 'SPECIAL_EFFECTS', 'KOGO_REVERSE_QUIZ', 'GEM_LOTTERY_RESULTS', 'PVP_TITLES', 'WEEKDAY_MON', 'DEX_RARITY_ORDER']) {
    const v = window[k];
    probes[k] = Array.isArray(v) ? 'array:' + v.length : (v && typeof v === 'object' ? 'object:' + Object.keys(v).length : typeof v);
  }
  const keyFns = ['renderFormations', 'renderDungeonsView', 'startBattle', 'switchTab', 'openSettingsModal', 'getWorldLevel', 'HybridP2PManager'];
  const fnTypes = {};
  for (const k of keyFns) fnTypes[k] = typeof window[k];
  const res = { label, errors: errors.slice(0, 30), errorCount: errors.length, props, types, probes, fnTypes };
  window.close();
  window.console.error = origErr;
  return res;
}

const a = await run('single(1ファイル版)', singleJs, 'single');
const b = await run('split(分割版)', splitJs, 'split');

const diff = (x, y) => x.filter((v) => !y.includes(v));
const report = [];
report.push(`グローバル数: single=${a.props.length} split=${b.props.length}`);
const onlySingle = diff(a.props, b.props);
const onlySplit = diff(b.props, a.props);
report.push(`  split に無いキー: ${onlySingle.length ? onlySingle.slice(0, 15).join(', ') : 'なし'}`);
report.push(`  split のみのキー: ${onlySplit.length ? onlySplit.slice(0, 15).join(', ') : 'なし'}`);
const typeDiff = a.props.filter((k) => b.types[k] !== undefined && a.types[k] !== b.types[k])
  .map((k) => `${k}: ${a.types[k]} -> ${b.types[k]}`);
report.push(`  型の差異: ${typeDiff.length ? typeDiff.slice(0, 10).join(' / ') : 'なし'}`);
report.push('データ配列:');
for (const k of Object.keys(a.probes)) {
  if (a.probes[k] !== b.probes[k]) report.push(`  NG ${k}: ${a.probes[k]} -> ${b.probes[k]}`);
}
const sameProbes = Object.keys(a.probes).every((k) => a.probes[k] === b.probes[k]);
const fnDiff = Object.entries(a.fnTypes).filter(([k, v]) => b.fnTypes[k] !== v)
  .map(([k, v]) => `${k}: ${v} -> ${b.fnTypes[k]}`);
report.push(`主要関数: ${fnDiff.length ? fnDiff.join(' / ') : 'すべて同名・同型で存在'}`);
report.push(`エラー: single=${a.errorCount} split=${b.errorCount}`);
if (a.errorCount || b.errorCount) {
  report.push('  single: ' + JSON.stringify(a.errors.slice(0, 4)));
  report.push('  split : ' + JSON.stringify(b.errors.slice(0, 4)));
}
const sameErrors = JSON.stringify(a.errors) === JSON.stringify(b.errors);
const ok = onlySingle.length === 0 && typeDiff.length === 0 && sameProbes && fnDiff.length === 0 && sameErrors;
console.log(report.join('\n'));
console.log(ok ? '[PASS] 1ファイル版と分割版でグローバル環境・挙動が一致' : '[WARN] 差異あり（上記を確認）');