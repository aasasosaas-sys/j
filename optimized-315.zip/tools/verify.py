#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
tools/verify.py
「見た目・挙動を変えていない」ことを機械的に検証する（ビルド後に実行）。

  1. src/js/*.js と dist/js/*.js が構文エラーなし（node --check）
  2. 最小化の前後でトップレベル識別子の集合が完全一致（改名・削除が無い証明）
  3. dist/index.html の参照がすべて dist 内に存在し、src と一致（残骸なし）
  4. Font Awesome の CDN 参照が消え、preconnect / display=swap が入っている
  5. 使用アイコンがサブセットCSSにすべて含まれ、本体フォントが同梱されている
  6. サイズ集計
"""
import os
import re
import subprocess
import sys

SRC, DIST, LEGACY = 'src', 'dist', 'legacy/index7.html'
fails, notes = [], []


def sh(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True)


def js_files(d):
    p = os.path.join(d, 'js')
    if not os.path.isdir(p):
        return []
    return [os.path.join(p, f) for f in sorted(os.listdir(p)) if f.endswith('.js')]


def check_syntax():
    targets = js_files(SRC) + js_files(DIST)
    bad = [(f, sh('node --check "%s"' % f).stderr.strip()[:160]) for f in targets
           if sh('node --check "%s"' % f).returncode != 0]
    if bad:
        fails.append('構文エラー: %d ファイル' % len(bad))
        for f, e in bad[:5]:
            notes.append('  NG %s: %s' % (f, e))
    else:
        notes.append('OK 構文チェック: src+dist の %d ファイルすべて node --check 通過' % len(targets))


DECL = re.compile(r'\b(?:async\s+)?(?:function|const|let|var|class)\s+([A-Za-z_$][A-Za-z0-9_$]*)')
WIN = re.compile(r'\bwindow\.([A-Za-z_$][A-Za-z0-9_$]*)\s*=')


def names_of(files):
    ns = set()
    for f in files:
        t = open(f, encoding='utf-8').read()
        ns |= set(DECL.findall(t)) | set(WIN.findall(t))
    return ns


def check_globals():
    src_names, dst_names = names_of(js_files(SRC)), names_of(js_files(DIST))
    notes.append('トップレベル識別子: src=%d / dist=%d' % (len(src_names), len(dst_names)))
    if not dst_names:
        fails.append('dist/js が空です（ビルド未実行の可能性）')
        return
    missing = sorted(n for n in (src_names - dst_names) if not n.startswith('__PERF') and n != 'PERF')
    added = sorted(dst_names - src_names)
    if missing or added:
        fails.append('最小化で識別子が変化 (missing=%d added=%d) %s %s'
                     % (len(missing), len(added), missing[:5], added[:5]))
    else:
        notes.append('OK 最小化前後で識別子集合が完全一致（改名・削除なし＝グローバル参照は安全）')


def check_dist_refs():
    path = os.path.join(DIST, 'index.html')
    if not os.path.exists(path):
        fails.append('dist/index.html が存在しません')
        return
    html = open(path, encoding='utf-8').read()
    refs = re.findall(r'(?:src|href)="(\./[^"]+)"', html)
    missing = [r for r in refs if not os.path.exists(os.path.join(DIST, r[2:]))]
    if missing:
        fails.append('dist 内に存在しない参照: %s' % missing)
    else:
        notes.append('OK dist/index.html の相対参照 %d 件がすべて存在（オフラインでも動作）' % len(refs))

    if 'cdnjs.cloudflare.com/ajax/libs/font-awesome' in html:
        fails.append('Font Awesome の CDN 参照が残っています')
    else:
        notes.append('OK Font Awesome CDN 参照を除去（サブセットCSS + フォント同梱に置換）')

    if 'rel="preconnect"' not in html or 'fonts.gstatic.com' not in html:
        fails.append('Google Fonts の preconnect が index.html にありません')
    elif 'display=swap' not in html:
        fails.append('font-display: swap（display=swap）が失われています')
    else:
        notes.append('OK preconnect / dns-prefetch を追加し、display=swap を維持')

    if html.count('<script src="./js/') and len(re.findall(r'<script src="\./js/', html)) < 10:
        fails.append('分割スクリプトの参照数が不足しています')
    else:
        hd = sorted(re.findall(r'<script src="\./js/([^"]+)">', html))
        disk = sorted(f for f in os.listdir(os.path.join(SRC, 'js')) if f.endswith('.js'))
        if hd != disk:
            fails.append('HTML の参照と src/js が不一致（HTML %d / src %d）' % (len(hd), len(disk)))
        else:
            notes.append('OK 分割スクリプト %d 本を読み込み順どおり参照（残骸なし）' % len(hd))


def check_icons():
    if not os.path.exists(LEGACY):
        notes.append('-- legacy が無いためアイコン被覆チェックを省略')
        return
    html = open(LEGACY, encoding='utf-8').read()
    used = set(re.findall(r'fa-[a-z0-9-]+', html)) - {'fa', 'fas', 'fa-solid'}
    css = open(os.path.join(SRC, 'css', 'vendor-fontawesome-subset.css'), encoding='utf-8').read()
    absent = {'fa-flower', 'fa-pen-fancier', 'fa-person-dancing', 'fa-sparkles', 'fa-sunset'}
    expect = sorted(c for c in used if c not in absent)
    missing = sorted(c for c in expect if ('.' + c) not in css)
    if missing:
        fails.append('サブセットCSSに不足するアイコン: %d 件 %s' % (len(missing), missing[:8]))
    else:
        notes.append('OK 使用アイコン %d 種すべてがサブセットCSSに存在（グリフは本家フォントと同一）' % len(expect))
        notes.append('   FA6.4本体に該当ルールが無い %d 種は元の状態でも非表示のため除外: %s'
                     % (len(absent), ', '.join(sorted(absent))))
    fp = os.path.join(SRC, 'vendor', 'webfonts', 'fa-solid-900.woff2')
    if os.path.exists(fp):
        notes.append('OK 本体フォントを同梱: %d bytes' % os.path.getsize(fp))
    else:
        fails.append('同梱フォントがありません: %s' % fp)


def report_sizes():
    def total(d):
        s = 0
        for root, _, files in os.walk(d):
            for f in files:
                s += os.path.getsize(os.path.join(root, f))
        return s
    notes.append('サイズ: src=%d bytes / dist=%d bytes' % (total(SRC), total(DIST)))


def main():
    check_syntax()
    check_globals()
    check_dist_refs()
    check_icons()
    report_sizes()
    print('\n'.join(notes))
    print('-' * 72)
    if fails:
        print('[FAIL]')
        for f in fails:
            print(' - ' + f)
        sys.exit(1)
    print('[PASS] すべての検証に合格（構文 / 識別子不変 / 参照整合 / アイコン被覆 / フォント同梱）')


if __name__ == '__main__':
    main()