#!/usr/bin/env node
/**
 * tools/build.mjs
 * src/ を最小化して dist/ へ出力する（見た目・挙動は不変、サイズとリクエスト数だけ削減）。
 *
 *   node tools/build.mjs
 *
 * - JS  : Terser（mangle:false / toplevel:false / unused:false →
 *         グローバル名も未使用トップレベル宣言も一切変更しない。
 *         インライン onclick やファイル間のグローバル共有を壊さないための必須設定）
 * - CSS : esbuild（コメント・空白の除去のみ）
 * - HTML: html-minifier-terser（collapseWhitespace: 'conservative'。
 *         white-space:pre 系を壊さない安全設定）
 * - Font Awesome の本体フォント（woff2）を dist へ同梱する
 */
import { createRequire } from 'node:module';
import { readFileSync, writeFileSync, mkdirSync, rmSync, cpSync, existsSync, readdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { gzipSync } from 'node:zlib';
import { transform as cssTransform } from 'esbuild';

const require = createRequire(import.meta.url);
const terserMinify = require('terser').minify;
const htmlMinify = require('html-minifier-terser').minify;
if (typeof terserMinify !== 'function' || typeof htmlMinify !== 'function') {
  throw new Error('minifier の解決に失敗しました (terser / html-minifier-terser)');
}

// AGGRESSIVE=1 を付けた場合のみ「未参照の内部宣言の除去」まで行う（既定は無効）
const AGGRESSIVE = process.env.AGGRESSIVE === '1';
const TERSER_SAFE = { compress: false, mangle: false, format: { comments: false, ascii_only: false } };
const TERSER_AGGRESSIVE = {
  ecma: 2018,
  compress: { passes: 2, toplevel: false, unused: true, side_effects: false, keep_fargs: true },
  mangle: false,
  format: { comments: false, ascii_only: false },
};

const ROOT = process.cwd();
const SRC = join(ROOT, 'src');
const DIST = join(ROOT, 'dist');
const FA_FONT = join(SRC, 'vendor', 'webfonts', 'fa-solid-900.woff2');
const FA_FONT_URL = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/webfonts/fa-solid-900.woff2';

const rows = [];
const kb = (n) => (n / 1024).toFixed(1) + 'KB';
const record = (name, before, after) => rows.push({ name, before, after });

async function ensureVendorFont() {
  if (existsSync(FA_FONT)) return;
  console.log('[build] 同梱フォントが無いため取得します: ' + FA_FONT_URL);
  mkdirSync(dirname(FA_FONT), { recursive: true });
  const res = await fetch(FA_FONT_URL);
  if (!res.ok) throw new Error('font fetch failed: ' + res.status);
  writeFileSync(FA_FONT, Buffer.from(await res.arrayBuffer()));
}

async function buildJs() {
  const srcDir = join(SRC, 'js');
  const outDir = join(DIST, 'js');
  mkdirSync(outDir, { recursive: true });
  const files = readdirSync(srcDir).filter((f) => f.endsWith('.js')).sort();
  for (const file of files) {
    const code = readFileSync(join(srcDir, file), 'utf8');
    // 既定は「空白・コメント除去のみ」＝構文木を変えない最も安全な最小化
    const out = await terserMinify(code, AGGRESSIVE ? TERSER_AGGRESSIVE : TERSER_SAFE);
    if (out.error) throw out.error;
    writeFileSync(join(outDir, file), out.code);
    record('js/' + file, Buffer.byteLength(code), Buffer.byteLength(out.code));
  }
  return files.length;
}

async function buildCss() {
  const srcDir = join(SRC, 'css');
  const outDir = join(DIST, 'css');
  mkdirSync(outDir, { recursive: true });
  for (const file of readdirSync(srcDir).filter((f) => f.endsWith('.css')).sort()) {
    const code = readFileSync(join(srcDir, file), 'utf8');
    const res = await cssTransform(code, { loader: 'css', minify: true });
    writeFileSync(join(outDir, file), res.code);
    record('css/' + file, Buffer.byteLength(code), Buffer.byteLength(res.code));
  }
}

async function buildHtml() {
  const html = readFileSync(join(SRC, 'index.html'), 'utf8');
  const out = await htmlMinify(html, {
    collapseWhitespace: 'conservative',   // pre / pre-wrap を壊さない
    conservativeCollapse: true,
    removeComments: true,
    minifyCSS: false,                     // CSS は外部ファイル（個別に最小化済み）
    minifyJS: false,                      // JS は外部ファイル（Terser で最小化済み）
    removeRedundantAttributes: false,     // Tailwind のクラス・属性は一切触らない
    removeEmptyAttributes: false,
    removeOptionalTags: false,
    removeAttributeQuotes: false,
    collapseBooleanAttributes: false,
    keepClosingSlash: true,
    caseSensitive: true,
    sortAttributes: false,
    sortClassName: false,
    useShortDoctype: false,
  });
  writeFileSync(join(DIST, 'index.html'), out);
  record('index.html', Buffer.byteLength(html), Buffer.byteLength(out));
}

async function main() {
  rmSync(DIST, { recursive: true, force: true });
  mkdirSync(DIST, { recursive: true });
  await ensureVendorFont();
  cpSync(join(SRC, 'vendor'), join(DIST, 'vendor'), { recursive: true });

  const nJs = await buildJs();
  await buildCss();
  await buildHtml();

  console.log('\n=== build result (dist/) ===');
  let b = 0, a = 0;
  for (const r of rows) {
    b += r.before; a += r.after;
    console.log('  ' + r.name.padEnd(38) + kb(r.before).padStart(9) + ' -> ' + kb(r.after).padStart(9));
  }
  console.log('  files: ' + (nJs + 3) + '  (js ' + nJs + ' / css 2 / html 1 / font 1)');
  console.log('  最小化モード: ' + (AGGRESSIVE ? 'aggressive (未参照の内部宣言も除去)' : 'safe (空白・コメント除去のみ / 構文木は不変)'));
  console.log('  テキスト資産(gzip): index.html ' +
    kb(gzipSync(readFileSync(join(SRC, 'index.html'))).length) + ' -> ' +
    kb(gzipSync(readFileSync(join(DIST, 'index.html'))).length) +
    ' / 合計 ' + kb(b) + ' -> ' + kb(a));
  if (!existsSync(join(DIST, 'js', '00-perf.js'))) throw new Error('00-perf.js が dist に存在しません');
  console.log('done.');
}

main().catch((e) => { console.error(e); process.exit(1); });