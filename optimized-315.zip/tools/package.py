#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""tools/package.py — 納品用の zip を作る（node_modules と一時ファイルは除外）。"""
import os
import zipfile

OUT = 'optimized-315.zip'
DIRS = ['src', 'tools', 'dist', 'dist-single', 'legacy', '.github', 'build-report']
FILES = ['package.json', 'package-lock.json', 'README.md']
SKIP_EXT = ('.png',)

n = 0
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for f in FILES:
        if os.path.exists(f):
            z.write(f)
            n += 1
    for d in DIRS:
        for root, dirs, files in os.walk(d):
            dirs[:] = [x for x in dirs if x not in ('node_modules', 'shots')]
            for fn in sorted(files):
                p = os.path.join(root, fn)
                if 'node_modules' in p or p.endswith(SKIP_EXT) or 'verify-standalone' in p:
                    continue
                z.write(p)
                n += 1
print('%s : %d files, %d bytes' % (OUT, n, os.path.getsize(OUT)))