# 戦って覚える315 — 軽量化ビルド構成（見た目・挙動は不変）

単一ファイル版 `legacy/index7.html`（1.24MB / 14,861行）を機能単位に分割し、
CDN依存の削減・DOM更新の差分化・タイマー停止・自動 minify + 自動デプロイを行います。
**UI（配色・レイアウト・アニメーション）とゲームロジック／パラメータは一切変更していません。**

## ディレクトリ構成

```
src/
  index.html                        … HTML（preconnect追加 / CSS・JSを参照）
  css/theme.css                     … 元の <style> ブロックと同一
  css/vendor-fontawesome-subset.css … 使用アイコンのみに絞った FA サブセット（自動生成）
  js/00-perf.js                     … 軽量化ヘルパ（setHTML / タイマー停止）
  js/01-audio-fx.js … 18-*.js       … 旧巨大 <script> の分割（順に連結すると元と一致）
  vendor/webfonts/fa-solid-900.woff2
legacy/index7.html                  … 元の単一ファイル（分割の入力・改変禁止）
tools/
  split_src.py     … 分割 + innerHTML→setHTML 置換（差分のみ・完全一致検証つき）
  optimize_fa.py   … FA サブセットCSS生成 + フォント同梱
  build.mjs        … Terser / esbuild / html-minifier-terser で dist 生成
  verify.py        … 構文・識別子不変・参照整合・アイコン被覆の自動検証
  parity_jsdom.mjs … 元1ファイル版と分割版のグローバル環境一致テスト（任意）
.github/workflows/build.yml         … push で minify → dist → Pages デプロイ
```

## 作業手順

```bash
npm ci            # 依存（terser / esbuild / html-minifier-terser）
npm run src       # (初回のみ) 元HTMLを分割し直す: src/ を再生成
npm run build     # src/ → dist/ へ最小化（HTML/CSS/JS）
npm run verify    # 見た目・挙動を変えていないことの自動検証
npm run preview   # dist/ をローカル確認（http://localhost:3000）
```

`src/` を編集したら `npm run build` だけで OK（`npm run src` は分割のやり直し時のみ）。
日常の修正は `src/js/*.js` / `src/css/theme.css` / `src/index.html` を直接編集し、
`legacy/index7.html` は触らないでください（再分割で上書きされます）。

## 最適化の内容

| # | 要件 | 実装 | 効果 |
|---|------|------|------|
| 1 | アイコンライブラリ | 使用 219 アイコンのルールのみ抽出した `vendor-fontawesome-subset.css` + woff2 同梱（グリフは本家と同一） | CSS 102KB → 約41KB、外部ドメイン往復・DNS/TLS を削減 |
| 1 | Google Fonts | `preconnect`（fonts.googleapis.com / fonts.gstatic.com）+ `dns-prefetch` 追加、`display=swap` は維持 | フォント接続の事前確立のみ（字形・ウェイトは不変） |
| 2 | innerHTML | テンプレート代入 40 箇所超を `__PERF.setHTML()` へ置換。直前のDOMと同一なら描画をスキップ（差分更新）、書き換え時も 1 回のパース + `replaceChildren` | 毎tickの再描画によるフリーズ・GC 負荷を低減 |
| 2 | setInterval | タブ非表示/`pagehide` でゲーム用タイマーを停止、`visibilitychange` で同間隔で再開（`clearInterval`/真偽判定は透過） | 裏側での消費を削減。ネットワーク同期系 5 本は `__PERF.keepAliveInterval` で停止させない |
| 2 | requestAnimationFrame | 元コードに **0 箇所**（調査済み）。将来追加時のために `__PERF.pauseTimers()/resumeTimers()` を用意 | — |
| 3 | 分割 | `src/index.html` + `css/` + `js/`（18分割 + ヘルパ） | 全ファイル連結が元テキストと完全一致することを自動検証 |
| 3 | minify | JS=Terser（`mangle:false`/`toplevel:false`）、CSS=esbuild、HTML=html-minifier-terser（`conservative`） | `dist/` を生成。グローバル名は変更しないため `onclick=` 等も安全 |
| 3 | デプロイ | `.github/workflows/build.yml` → `dist/` を Pages へ。gh-pages 版も併記 | main への push だけで自動公開 |

## 注意点

- **`pauseHiddenTimers`**: 裏に回すとソロ戦闘・演出タイマーも止まります（=裏での進行なし）。
  従来どおり裏でも進めたい場合は `src/index.html` の `00-perf.js` より前に
  `<script>window.__PERF={pauseHiddenTimers:false};</script>` を追加してください。
  オンライン対戦の同期ループは停止対象外です。
- **Cloudflare beacon**: 元ファイルには同一 `src` の beacon が 12 回重複していたため 1 つに集約しました
  （アクセス解析のみ。GitHub Pages 公開時は不要なので削除しても構いません）。
- **Tailwind CDN**: クラス設計に影響しないよう、そのまま（Play CDN）維持しています。
  さらに軽量化したい場合はビルド時 Tailwind 化が有効ですが、
  クラス抽出結果が変わるリスクがあるため本改修では対象外にしています。